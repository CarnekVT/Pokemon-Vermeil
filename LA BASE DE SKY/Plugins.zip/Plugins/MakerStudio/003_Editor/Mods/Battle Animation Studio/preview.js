import { getAllClips, getAnimatable, getBattlerTrack, getCameraTrack, sortPositionKeys, sampleValue, sampleVisible } from "./model.js";
import { fallbackBattleContext } from "./context.js";
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const lerp = (a, b, t) => a + (b - a) * t;
const ease = (t, m) => { const x = clamp(t, 0, 1); if (m === "linear")
    return x; if (m === "ease_in")
    return x * x; if (m === "ease_out")
    return 1 - (1 - x) * (1 - x); return x < .5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2; };
const css = (n, f) => getComputedStyle(document.documentElement).getPropertyValue(n).trim() || f;
const hash32 = (s) => { let h = 2166136261 >>> 0; for (const c of String(s)) {
    h ^= c.charCodeAt(0);
    h = Math.imul(h, 16777619);
} return h >>> 0; };
const seeded = (seed) => { let x = seed >>> 0; return () => { x ^= x << 13; x ^= x >>> 17; x ^= x << 5; return ((x >>> 0) % 1000000) / 1000000; }; };
function parseHexColor(raw, tone = false) {
    const s = String(raw || "").trim();
    if (tone) {
        const m = s.match(/^([+-]\d+)([+-]\d+)([+-]\d+)([+-]\d+)$/);
        if (m)
            return { r: Number(m[1]), g: Number(m[2]), b: Number(m[3]), a: Number(m[4]) };
    }
    const h = s.replace(/^#/, '');
    if (/^[0-9a-f]{8}$/i.test(h))
        return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16), a: parseInt(h.slice(6, 8), 16) };
    return { r: 0, g: 0, b: 0, a: 0 };
}
export class BattlePreview {
    constructor(canvas, callbacks = {}) {
        this.canvas = canvas;
        this.ctx = canvas.getContext("2d");
        this.callbacks = callbacks;
        this.animation = null;
        this.selectedObjectId = null;
        this.frame = 0;
        this.playing = false;
        this.context = fallbackBattleContext();
        this.images = { user: null, target: null, userFront: null, userBack: null, targetFront: null, targetBack: null };
        this.urls = {};
        this.battlerMeta = { user: {}, target: {}, userFront: {}, userBack: {}, targetFront: {}, targetBack: {} };
        this.clipImages = new Map();
        this.maskImages = new Map();
        this.sceneImages = { background: null, playerBase: null, enemyBase: null };
        this.sceneUrls = {};
        this.fxCache = new Map();
        this.dpr = Math.max(1, window.devicePixelRatio || 1);
        this.lastTransform = null;
        this.hitShapes = [];
        this.dragging = null;
        this.dragStart = null;
        this.editFrame = 0;
        this._pd = e => this.pointerDown(e);
        this._pm = e => this.pointerMove(e);
        this._pu = e => this.pointerUp(e);
        this._cm = e => e.preventDefault();
        this._wh = e => this.wheel(e);
        canvas.addEventListener("pointerdown", this._pd);
        window.addEventListener("pointermove", this._pm);
        window.addEventListener("pointerup", this._pu);
        canvas.addEventListener("contextmenu", this._cm);
        canvas.addEventListener("wheel", this._wh, { passive: false });
        this.resizeObserver = new ResizeObserver(() => this.draw());
        this.resizeObserver.observe(canvas);
    }
    destroy() {
        this.canvas.removeEventListener("pointerdown", this._pd);
        window.removeEventListener("pointermove", this._pm);
        window.removeEventListener("pointerup", this._pu);
        this.canvas.removeEventListener("contextmenu", this._cm);
        this.canvas.removeEventListener("wheel", this._wh);
        this.resizeObserver.disconnect();
        for (const u of Object.values(this.urls))
            if (u)
                URL.revokeObjectURL(u);
        for (const u of Object.values(this.sceneUrls))
            if (u)
                URL.revokeObjectURL(u);
        for (const r of [...this.clipImages.values(), ...this.maskImages.values()])
            if (r === null || r === void 0 ? void 0 : r.url)
                URL.revokeObjectURL(r.url);
    }
    setState(animation, selectedObjectId, frame, { playing = this.playing } = {}) { this.animation = animation; this.selectedObjectId = selectedObjectId; this.frame = Number(frame) || 0; this.playing = !!playing; this.draw(); }
    setContext(c) { this.context = c || fallbackBattleContext(); this.draw(); }
    setBattlers(user, target, variants = {}, metadata = {}) {
        this.battlerMeta = Object.assign(Object.assign({}, this.battlerMeta), metadata);
        this._setNamed("user", user);
        this._setNamed("target", target);
        this._setNamed("userFront", variants.userFront || null);
        this._setNamed("userBack", variants.userBack || user);
        this._setNamed("targetFront", variants.targetFront || target);
        this._setNamed("targetBack", variants.targetBack || null);
    }
    setSceneImages(background, playerBase, enemyBase) { this._setScene("background", background); this._setScene("playerBase", playerBase); this._setScene("enemyBase", enemyBase); }
    setClipImage(id, url) { this._setMapImage(this.clipImages, id, url); }
    setClipSwitchImage(id, path, url) { this._setMapImage(this.clipImages, `${id}@@${String(path || "")}`, url); }
    setMaskImage(id, url) { this._setMapImage(this.maskImages, id, url); }
    clearClipImages(valid = []) { const keep = new Set(valid); for (const map of [this.clipImages, this.maskImages])
        for (const [id, r] of map) {
            const base = String(id).split("@@")[0];
            if (keep.has(base))
                continue;
            if (r === null || r === void 0 ? void 0 : r.url)
                URL.revokeObjectURL(r.url);
            map.delete(id);
        } }
    _setMapImage(map, id, url) { const old = map.get(id); if ((old === null || old === void 0 ? void 0 : old.url) === url)
        return; if (old === null || old === void 0 ? void 0 : old.url)
        URL.revokeObjectURL(old.url); if (!url) {
        map.delete(id);
        this.draw();
        return;
    } const im = new Image(), r = { url, image: null }; map.set(id, r); im.onload = () => { r.image = im; this.draw(); }; im.onerror = () => { r.image = null; this.draw(); }; im.src = url; }
    _setNamed(key, url) { if (this.urls[key] && this.urls[key] !== url)
        URL.revokeObjectURL(this.urls[key]); this.urls[key] = url || null; this.images[key] = null; if (!url) {
        this.draw();
        return;
    } const im = new Image(); im.onload = () => { this.images[key] = im; this.draw(); }; im.onerror = () => { this.images[key] = null; this.draw(); }; im.src = url; }
    _setScene(key, url) { if (this.sceneUrls[key] && this.sceneUrls[key] !== url)
        URL.revokeObjectURL(this.sceneUrls[key]); this.sceneUrls[key] = url || null; this.sceneImages[key] = null; if (!url) {
        this.draw();
        return;
    } const im = new Image(); im.onload = () => { this.sceneImages[key] = im; this.draw(); }; im.onerror = () => { this.sceneImages[key] = null; this.draw(); }; im.src = url; }
    logicalSize() { var _a, _b; return { width: Number(((_a = this.context) === null || _a === void 0 ? void 0 : _a.width) || 512), height: Number(((_b = this.context) === null || _b === void 0 ? void 0 : _b.height) || 384) }; }
    semanticOpposing() { var _a, _b, _c, _d; return !!(((_b = (_a = this.animation) === null || _a === void 0 ? void 0 : _a.source) === null || _b === void 0 ? void 0 : _b.opposing) || ((_d = (_c = this.animation) === null || _c === void 0 ? void 0 : _c.source) === null || _d === void 0 ? void 0 : _d.sideContext) === "foe"); }
    semanticInfo(side) { var _a, _b, _c, _d; const opp = this.semanticOpposing(); if (side === "user")
        return opp ? (((_a = this.context) === null || _a === void 0 ? void 0 : _a.target) || {}) : (((_b = this.context) === null || _b === void 0 ? void 0 : _b.user) || {}); return opp ? (((_c = this.context) === null || _c === void 0 ? void 0 : _c.user) || {}) : (((_d = this.context) === null || _d === void 0 ? void 0 : _d.target) || {}); }
    semanticIndex(side) { var _a, _b, _c, _d, _e, _f, _g, _h; const opp = this.semanticOpposing(); if (side === "user")
        return Number(opp ? ((_b = (_a = this.context) === null || _a === void 0 ? void 0 : _a.targetIndex) !== null && _b !== void 0 ? _b : 1) : ((_d = (_c = this.context) === null || _c === void 0 ? void 0 : _c.userIndex) !== null && _d !== void 0 ? _d : 0)); return Number(opp ? ((_f = (_e = this.context) === null || _e === void 0 ? void 0 : _e.userIndex) !== null && _f !== void 0 ? _f : 0) : ((_h = (_g = this.context) === null || _g === void 0 ? void 0 : _g.targetIndex) !== null && _h !== void 0 ? _h : 1)); }
    semanticBase(side) { return this.semanticOpposing() ? (side === "user" ? "target" : "user") : side; }
    resizeCanvas() { const r = this.canvas.getBoundingClientRect(), w = Math.max(1, Math.round(r.width)), h = Math.max(1, Math.round(r.height)), pw = Math.max(1, Math.round(w * this.dpr)), ph = Math.max(1, Math.round(h * this.dpr)); if (this.canvas.width !== pw || this.canvas.height !== ph) {
        this.canvas.width = pw;
        this.canvas.height = ph;
    } this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0); const l = this.logicalSize(), s = Math.min(w / l.width, h / l.height), ox = (w - l.width * s) / 2, oy = (h - l.height * s) / 2; return this.lastTransform = { width: w, height: h, scale: s, offsetX: ox, offsetY: oy, logicalWidth: l.width, logicalHeight: l.height }; }
    battlerImageAndMeta(side) {
        const opp = this.semanticOpposing(), idx = this.semanticIndex(side), semanticUser = side === "user";
        let image = null, meta = {};
        if (!opp) {
            if (semanticUser) {
                image = idx % 2 === 0 ? (this.images.userBack || this.images.user) : (this.images.userFront || this.images.user);
                meta = idx % 2 === 0 ? (this.battlerMeta.userBack || this.battlerMeta.user || {}) : (this.battlerMeta.userFront || this.battlerMeta.user || {});
            }
            else {
                image = idx % 2 === 0 ? (this.images.targetBack || this.images.target) : (this.images.targetFront || this.images.target);
                meta = idx % 2 === 0 ? (this.battlerMeta.targetBack || this.battlerMeta.target || {}) : (this.battlerMeta.targetFront || this.battlerMeta.target || {});
            }
        }
        else {
            if (semanticUser) {
                image = idx % 2 === 0 ? (this.images.targetBack || this.images.target) : (this.images.targetFront || this.images.target);
                meta = idx % 2 === 0 ? (this.battlerMeta.targetBack || this.battlerMeta.target || {}) : (this.battlerMeta.targetFront || this.battlerMeta.target || {});
            }
            else {
                image = idx % 2 === 0 ? (this.images.userBack || this.images.user) : (this.images.userFront || this.images.user);
                meta = idx % 2 === 0 ? (this.battlerMeta.userBack || this.battlerMeta.user || {}) : (this.battlerMeta.userFront || this.battlerMeta.user || {});
            }
        }
        return { image, meta: meta || {} };
    }
    contextMatchesBattler(info = {}, meta = {}) {
        const ctxSpecies = String((info && (info.species || info.species_id || info.speciesId)) || "").toUpperCase();
        const metaSpecies = String((meta && (meta.speciesId || meta.species || meta.id)) || "").toUpperCase();
        // Do not apply a live-captured bitmap/origin/zoom from Charizard/Dragonite
        // to AnimBackTest or to a manually chosen battler whose species is unknown.
        // This was the main cause of huge/misplaced duplicate-looking battlers.
        if (ctxSpecies && !metaSpecies)
            return false;
        if (!ctxSpecies || !metaSpecies)
            return true;
        const a = ctxSpecies.split(/[_-]/)[0], b = metaSpecies.split(/[_-]/)[0];
        return ctxSpecies === metaSpecies || a === b;
    }
    battlerFrameInfo(image, meta = {}, ctxInfo = {}) {
        var _a;
        if (!image)
            return { sx: 0, sy: 0, sw: 0, sh: 0, count: 1, index: 0, scale: 1 };
        const strip = image.width > image.height * 2, sw = strip ? image.height : image.width, sh = image.height, count = strip ? Math.max(1, Math.floor(image.width / sw)) : 1;
        const delay = Math.max(16, Number(meta.frameDelayMs || 120));
        const timeMs = (Number(this.frame || 0) / Math.max(1, Number(((_a = this.animation) === null || _a === void 0 ? void 0 : _a.fps) || 20))) * 1000;
        const index = (this.playing && count > 1) ? Math.floor(timeMs / delay) % count : 0;
        let scale = Number(meta.scale || 1);
        // A live runtime capture already knows the final rendered bitmap size. Use
        // that in preference to static DBK defaults so Battle New/custom scaling
        // matches the actual battle scene.
        const bw = Number((ctxInfo === null || ctxInfo === void 0 ? void 0 : ctxInfo.bitmapWidth) || 0), bh = Number((ctxInfo === null || ctxInfo === void 0 ? void 0 : ctxInfo.bitmapHeight) || 0);
        if (this.contextMatchesBattler(ctxInfo, meta) && bw > 0 && bh > 0 && sw > 0 && sh > 0)
            scale = Math.min(bw / sw, bh / sh) || scale;
        return { sx: index * sw, sy: 0, sw, sh, count, index, scale: Math.max(.01, scale || 1) };
    }
    anchors() {
        const c = this.context || fallbackBattleContext(), u = this.semanticInfo("user"), t = this.semanticInfo("target"), ui = this.semanticIndex("user"), ti = this.semanticIndex("target"), ub = this.battlerImageAndMeta("user"), tb = this.battlerImageAndMeta("target");
        const focus = (info, bundle, dx, dy) => {
            var _a, _b, _c, _d, _e, _f;
            const captured = this.contextMatchesBattler(info, bundle.meta || {}) && Number((info === null || info === void 0 ? void 0 : info.bitmapHeight) || 0) > 0;
            if (captured)
                return { x: Number((_b = (_a = info === null || info === void 0 ? void 0 : info.focusX) !== null && _a !== void 0 ? _a : info === null || info === void 0 ? void 0 : info.x) !== null && _b !== void 0 ? _b : dx), y: Number((_d = (_c = info === null || info === void 0 ? void 0 : info.focusY) !== null && _c !== void 0 ? _c : info === null || info === void 0 ? void 0 : info.y) !== null && _d !== void 0 ? _d : dy) };
            const m = bundle.meta || {}, fi = this.battlerFrameInfo(bundle.image, m, info), baseX = Number((_e = info === null || info === void 0 ? void 0 : info.x) !== null && _e !== void 0 ? _e : dx) + Number(m.metricX || 0), baseY = Number((_f = info === null || info === void 0 ? void 0 : info.y) !== null && _f !== void 0 ? _f : dy) + Number(m.metricY || 0);
            // Match New Animation Editor exactly: its static/editor focus is
            // `sprite.y - sprite.bitmap.height / 2` AFTER metrics are applied. The
            // DBK display scale affects how the battler is drawn, but does not change
            // the raw bitmap height used by AnimationPlayer's focus coordinate.
            const rawH = Number(fi.sh || 0);
            return { x: baseX, y: baseY - (rawH > 0 ? rawH / 2 : 40) };
        };
        const baseline = (info, bundle, dx, dy) => { var _a, _b; const captured = this.contextMatchesBattler(info, bundle.meta || {}) && Number((info === null || info === void 0 ? void 0 : info.bitmapHeight) || 0) > 0, m = bundle.meta || {}; return { x: Number((_a = info === null || info === void 0 ? void 0 : info.x) !== null && _a !== void 0 ? _a : dx) + (captured ? 0 : Number(m.metricX || 0)), y: Number((_b = info === null || info === void 0 ? void 0 : info.y) !== null && _b !== void 0 ? _b : dy) + (captured ? 0 : Number(m.metricY || 0)) }; };
        const uf = focus(u, ub, 128, c.height - 80), tf = focus(t, tb, c.width - 128, (c.height * 3 / 4) - 112), up = baseline(u, ub, 128, c.height - 80), tp = baseline(t, tb, c.width - 128, (c.height * 3 / 4) - 112);
        return { user: uf, target: tf, user_battler: up, target_battler: tp };
    }
    resolvePoint(p) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        const { width, height } = this.logicalSize(), a = this.anchors(), ctx = this.context || {};
        if (!p)
            return { x: width / 2, y: height / 2 };
        if (String(p.anchor || "").startsWith("pbs:")) {
            const f = String(p.anchor).slice(4), su = { x: a.user.x, y: a.user.y }, st = { x: a.target.x, y: a.target.y }, opp = this.semanticOpposing(), scriptU = opp ? (ctx.scriptTarget || ctx.target) : (ctx.scriptUser || ctx.user), scriptT = opp ? (ctx.scriptUser || ctx.user) : (ctx.scriptTarget || ctx.target), pu = { x: a.user.x, y: Number((_a = scriptU === null || scriptU === void 0 ? void 0 : scriptU.y) !== null && _a !== void 0 ? _a : a.user.y) }, pt = { x: a.target.x, y: Number((_b = scriptT === null || scriptT === void 0 ? void 0 : scriptT.y) !== null && _b !== void 0 ? _b : a.target.y) };
            let x = Number(p.x || 0), y = Number(p.y || 0), one = null, pair = null;
            if (f === "user")
                one = su;
            else if (f === "user_position")
                one = pu;
            else if (f === "target")
                one = st;
            else if (f === "target_position")
                one = pt;
            else if (f === "user_and_target")
                pair = [su, st];
            else if (f === "user_position_and_target")
                pair = [pu, st];
            else if (f === "user_and_target_position")
                pair = [su, pt];
            else if (f === "user_position_and_target_position")
                pair = [pu, pt];
            else if (f === "user_side_foreground" || f === "user_side_background")
                one = { x: Number((_c = scriptU === null || scriptU === void 0 ? void 0 : scriptU.x) !== null && _c !== void 0 ? _c : su.x), y: Number((_d = scriptU === null || scriptU === void 0 ? void 0 : scriptU.y) !== null && _d !== void 0 ? _d : su.y) };
            else if (f === "target_side_foreground" || f === "target_side_background")
                one = { x: Number((_e = scriptT === null || scriptT === void 0 ? void 0 : scriptT.x) !== null && _e !== void 0 ? _e : st.x), y: Number((_f = scriptT === null || scriptT === void 0 ? void 0 : scriptT.y) !== null && _f !== void 0 ? _f : st.y) };
            const relativeIndex = !f.includes("and") ? (f.startsWith("user") ? this.semanticIndex("user") : f.startsWith("target") ? this.semanticIndex("target") : -1) : -1;
            if (relativeIndex >= 0 && relativeIndex % 2 === 1) {
                if (p.foeInvertX)
                    x *= -1;
                if (p.foeInvertY)
                    y *= -1;
            }
            if (pair) {
                // The New Animation Editor truncates the relative User/Target offset
                // to an integer before adding the focus point (Ruby `to_i`). Tiny
                // fractional differences accumulate into visibly different paths.
                const rx = Math.trunc((x / 200) * (pair[1].x - pair[0].x)), ry = Math.trunc((y / -200) * (pair[1].y - pair[0].y));
                return { x: pair[0].x + rx + Number(p.offsetX || 0), y: pair[0].y + ry + Number(p.offsetY || 0) };
            }
            if (one)
                return { x: one.x + x + Number(p.offsetX || 0), y: one.y + y + Number(p.offsetY || 0) };
            return { x: x + Number(p.offsetX || 0), y: y + Number(p.offsetY || 0) };
        }
        if (p.anchor === "user_target") {
            return { x: a.user.x + Math.trunc((Number(p.x || 0) / 200) * (a.target.x - a.user.x)) + Number(p.offsetX || 0), y: a.user.y + Math.trunc((Number(p.y || 0) / -200) * (a.target.y - a.user.y)) + Number(p.offsetY || 0) };
        }
        if (a[p.anchor])
            return { x: a[p.anchor].x + Number(p.offsetX || 0), y: a[p.anchor].y + Number(p.offsetY || 0) };
        return { x: Number((_g = p.x) !== null && _g !== void 0 ? _g : width / 2) + Number(p.offsetX || 0), y: Number((_h = p.y) !== null && _h !== void 0 ? _h : height / 2) + Number(p.offsetY || 0) };
    }
    baseBattlerPosition(side) { return Object.assign({}, this.anchors()[side === "user" ? "user_battler" : "target_battler"]); }
    pbsBattlerBaselineOffset(o) {
        var _a, _b;
        if (!o || o.type !== "battler" || ((_a = o.imported) === null || _a === void 0 ? void 0 : _a.format) !== "pbs" || !((_b = o.imported) === null || _b === void 0 ? void 0 : _b.pbsBattlerParticle))
            return 0;
        const side = o.side === "target" ? "target" : "user", info = this.semanticInfo(side), capturedH = Number((info === null || info === void 0 ? void 0 : info.bitmapHeight) || 0);
        if (capturedH > 0)
            return capturedH / 2;
        const bundle = this.battlerImageAndMeta(side), fi = this.battlerFrameInfo(bundle.image, bundle.meta || {}, info);
        return Number(fi.sh || 0) / 2;
    }
    resolveObjectPoint(o, p) {
        var _a;
        const q = this.resolvePoint(p);
        // In PBS, the User/Target particle is positioned at the battler focus
        // (visual centre) and then `get_xy_offset` moves its bitmap down by half
        // its height. Our battler renderer uses a bottom-origin, so convert the
        // imported PBS focus coordinate back to that baseline here.
        if ((o === null || o === void 0 ? void 0 : o.type) === "battler" && ((_a = o.imported) === null || _a === void 0 ? void 0 : _a.pbsBattlerParticle) && String((p === null || p === void 0 ? void 0 : p.anchor) || "").startsWith("pbs:"))
            q.y += this.pbsBattlerBaselineOffset(o);
        return q;
    }
    samplePosition(o, frame = this.frame) { if (!o)
        return { x: this.logicalSize().width / 2, y: this.logicalSize().height / 2 }; const ks = sortPositionKeys(o); if (!ks.length)
        return { x: this.logicalSize().width / 2, y: this.logicalSize().height / 2 }; if (frame <= ks[0].frame)
        return this.resolveObjectPoint(o, ks[0].point); if (frame >= ks.at(-1).frame)
        return this.resolveObjectPoint(o, ks.at(-1).point); for (let i = 0; i < ks.length - 1; i++) {
        const a = ks[i], b = ks[i + 1];
        if (frame < a.frame || frame > b.frame)
            continue;
        const pa = this.resolveObjectPoint(o, a.point), pb = this.resolveObjectPoint(o, b.point), t = ease((frame - a.frame) / Math.max(.0001, b.frame - a.frame), a.easing || "ease_both");
        return { x: lerp(pa.x, pb.x, t), y: lerp(pa.y, pb.y, t) };
    } return this.resolveObjectPoint(o, ks[0].point); }
    active(o, frame = this.frame) { var _a, _b, _c, _d, _e, _f, _g, _h; if (!o)
        return false; if (o.type === "battler" || o.type === "camera")
        return sampleVisible(o, frame); const emitter = String(((_a = o.pbs) === null || _a === void 0 ? void 0 : _a.emitter) || ((_b = o.pbs) === null || _b === void 0 ? void 0 : _b.emitterType) || "none").toLowerCase(); if (emitter && emitter !== "none")
        return frame >= 0 && frame <= Number((_e = (_d = (_c = this.animation) === null || _c === void 0 ? void 0 : _c.duration) !== null && _d !== void 0 ? _d : o.endFrame) !== null && _e !== void 0 ? _e : 0); if (!sampleVisible(o, frame))
        return false; return frame >= Number(o.startFrame || 0) && frame <= Number((_h = (_f = o.endFrame) !== null && _f !== void 0 ? _f : (_g = this.animation) === null || _g === void 0 ? void 0 : _g.duration) !== null && _h !== void 0 ? _h : 0); }
    draw() { if (!this.ctx)
        return; const tr = this.resizeCanvas(), c = this.ctx; c.clearRect(0, 0, tr.width, tr.height); c.fillStyle = css("--canvas-bg", "#0e1017"); c.fillRect(0, 0, tr.width, tr.height); c.save(); c.translate(tr.offsetX, tr.offsetY); c.scale(tr.scale, tr.scale); this.drawBattleScene(); c.restore(); }
    cameraState() { const cam = getCameraTrack(this.animation); if (!cam)
        return { x: 0, y: 0, zoom: 1, rot: 0 }; return { x: sampleValue(cam, "cameraX", this.frame, 0), y: sampleValue(cam, "cameraY", this.frame, 0), zoom: Math.max(.05, sampleValue(cam, "cameraZoom", this.frame, 100) / 100), rot: sampleValue(cam, "cameraRotation", this.frame, 0) * Math.PI / 180 }; }
    drawBattleScene() {
        var _a, _b;
        const c = this.ctx, { width, height } = this.logicalSize(), accent = css("--accent", "#7b82ff"), text = css("--text-secondary", "#b7bac8");
        this.hitShapes = [];
        c.fillStyle = "#0b0d13";
        c.fillRect(0, 0, width, height);
        const cam = this.cameraState();
        c.save();
        c.translate(width / 2, height / 2);
        c.scale(cam.zoom, cam.zoom);
        c.rotate(cam.rot);
        c.translate(-width / 2 - cam.x, -height / 2 - cam.y);
        this.drawBackground(width, height);
        this.drawBase("target", this.sceneImages.enemyBase);
        this.drawBase("user", this.sceneImages.playerBase);
        const drawables = [], ub = getBattlerTrack(this.animation, "user"), tb = getBattlerTrack(this.animation, "target"), ui = this.semanticIndex("user"), ti = this.semanticIndex("target"), uinfo = this.semanticInfo("user"), tinfo = this.semanticInfo("target"), ubundle = this.battlerImageAndMeta("user"), tbundle = this.battlerImageAndMeta("target");
        if (ub && this.active(ub))
            drawables.push({ z: Number((uinfo === null || uinfo === void 0 ? void 0 : uinfo.z) || 100) + sampleValue(ub, "z", this.frame, 0), order: 1000, draw: () => this.drawBattler(ubundle.image, uinfo, ub, "USER", text, ui % 2 === 0, (ub === null || ub === void 0 ? void 0 : ub.id) === this.selectedObjectId, accent, ubundle.meta) });
        if (tb && this.active(tb))
            drawables.push({ z: Number((tinfo === null || tinfo === void 0 ? void 0 : tinfo.z) || 100) + sampleValue(tb, "z", this.frame, 0), order: 1001, draw: () => this.drawBattler(tbundle.image, tinfo, tb, "TARGET", text, ti % 2 === 0, (tb === null || tb === void 0 ? void 0 : tb.id) === this.selectedObjectId, accent, tbundle.meta) });
        if (this.animation)
            getAllClips(this.animation).forEach((clip, i) => { if (this.active(clip))
                drawables.push({ z: this.clipZ(clip), order: 2000 + i, draw: () => this.drawClipOrEmitter(clip, clip.id === this.selectedObjectId, accent) }); });
        drawables.sort((a, b) => a.z - b.z || a.order - b.order).forEach(x => x.draw());
        c.restore();
        this.drawScreenEvents(width, height);
        c.fillStyle = "rgba(0,0,0,.48)";
        c.fillRect(8, 8, Math.min(width - 16, 390), 24);
        c.fillStyle = text;
        c.font = "10px sans-serif";
        c.fillText(`${((_a = this.context) === null || _a === void 0 ? void 0 : _a.source) || "default"} · ${width}×${height}${((_b = this.context) === null || _b === void 0 ? void 0 : _b.captureKind) ? ` · ${this.context.captureKind}` : ""}`, 14, 24);
    }
    drawBackground(width, height) { const c = this.ctx, im = this.sceneImages.background; if (im) {
        c.imageSmoothingEnabled = false;
        c.drawImage(im, 0, 0, width, height);
        return;
    } const g = c.createLinearGradient(0, 0, 0, height); g.addColorStop(0, "#090a10"); g.addColorStop(.58, "#11131b"); g.addColorStop(1, "#1b1e29"); c.fillStyle = g; c.fillRect(0, 0, width, height); }
    drawBase(side, im) { var _a, _b, _c, _d, _e, _f; if (!im)
        return; const c = this.ctx, pos = ((_b = (_a = this.context) === null || _a === void 0 ? void 0 : _a.bases) === null || _b === void 0 ? void 0 : _b[side]) || this.baseBattlerPosition(side), x = Number((_c = pos.x) !== null && _c !== void 0 ? _c : 0), y = Number((_d = pos.y) !== null && _d !== void 0 ? _d : 0), zx = Number((_e = pos.zoomX) !== null && _e !== void 0 ? _e : 1), zy = Number((_f = pos.zoomY) !== null && _f !== void 0 ? _f : 1), w = im.width * zx, h = im.height * zy; c.save(); c.globalAlpha = pos.visible === false ? 0 : 1; c.imageSmoothingEnabled = false; const oy = side === "user" ? h : h / 2; c.drawImage(im, x - w / 2, y - oy, w, h); c.restore(); }
    drawBattler(im, ctxInfo, obj, label, text, isPlayerSide, selected, accent, meta = {}) {
        var _a, _b;
        const runtimeMatch = this.contextMatchesBattler(ctxInfo, meta);
        const c = this.ctx, pos = this.samplePosition(obj), fi = this.battlerFrameInfo(im, meta, ctxInfo), baseScale = fi.scale, ctxZoomX = runtimeMatch ? Number((_a = ctxInfo === null || ctxInfo === void 0 ? void 0 : ctxInfo.zoomX) !== null && _a !== void 0 ? _a : 1) : 1, ctxZoomY = runtimeMatch ? Number((_b = ctxInfo === null || ctxInfo === void 0 ? void 0 : ctxInfo.zoomY) !== null && _b !== void 0 ? _b : 1) : 1, sx = Math.abs(sampleValue(obj, "scaleX", this.frame, 100) / 100) * sampleValue(obj, "size", this.frame, 100) / 100 * ctxZoomX * baseScale, sy = Math.abs(sampleValue(obj, "scaleY", this.frame, 100) / 100) * sampleValue(obj, "size", this.frame, 100) / 100 * ctxZoomY * baseScale, opa = clamp(sampleValue(obj, "opacity", this.frame, 100) / 100, 0, 1), ang = (sampleValue(obj, "rotation", this.frame, 0) + (runtimeMatch ? Number((ctxInfo === null || ctxInfo === void 0 ? void 0 : ctxInfo.angle) || 0) : 0)) * Math.PI / 180, flip = sampleValue(obj, "flip", this.frame, 0) >= .5 || (runtimeMatch && !!(ctxInfo === null || ctxInfo === void 0 ? void 0 : ctxInfo.mirror));
        let w = 80 * sx, h = 80 * sy;
        c.save();
        c.translate(pos.x, pos.y);
        c.rotate(-ang);
        if (flip)
            c.scale(-1, 1);
        c.globalAlpha = opa;
        if (im) {
            w = fi.sw * sx;
            h = fi.sh * sy;
            c.imageSmoothingEnabled = false;
            const captured = runtimeMatch && Number((ctxInfo === null || ctxInfo === void 0 ? void 0 : ctxInfo.bitmapHeight) || 0) > 0, ox = (captured ? Number((ctxInfo === null || ctxInfo === void 0 ? void 0 : ctxInfo.ox) || fi.sw / 2) : fi.sw / 2) * sx, oy = (captured ? Number((ctxInfo === null || ctxInfo === void 0 ? void 0 : ctxInfo.oy) || fi.sh) : fi.sh) * sy;
            const fx = this.fxImage(im, { sx: fi.sx, sy: fi.sy, sw: fi.sw, sh: fi.sh }, this.fxAt(obj, "tone", this.frame), this.fxAt(obj, "color", this.frame));
            c.drawImage(fx.image, fx.src.sx, fx.src.sy, fx.src.sw, fx.src.sh, -ox, -oy, w, h);
        }
        else {
            c.fillStyle = "rgba(120,135,210,.28)";
            c.beginPath();
            c.ellipse(0, -30, 34, 52, 0, 0, Math.PI * 2);
            c.fill();
        }
        c.restore();
        this.hitShapes.push({ objectId: obj.id, x: pos.x, y: pos.y - h / 2, w: Math.max(28, w), h: Math.max(40, h), kind: "battler" });
        if (selected && !this.playing) {
            c.strokeStyle = accent;
            c.setLineDash([5, 3]);
            c.strokeRect(pos.x - w / 2 - 5, pos.y - h - 5, w + 10, h + 10);
            c.setLineDash([]);
        }
        c.fillStyle = text;
        c.font = "9px sans-serif";
        c.textAlign = "center";
        c.fillText(label, pos.x, pos.y + 14);
        c.textAlign = "left";
    }
    clipZ(clip) {
        var _a, _b, _c;
        const focus = String(((_a = clip.pbs) === null || _a === void 0 ? void 0 : _a.focus) || ""), z = sampleValue(clip, "z", this.frame, Number(((_b = clip.visual) === null || _b === void 0 ? void 0 : _b.z) || 0));
        const rgssBattlerZ = (idx) => 1000 + ((100 * (Math.floor(Number(idx || 0) / 2) + 1)) * (Number(idx || 0) % 2 === 0 ? 1 : -1));
        const apply = (value, base) => Array.isArray(base) ? this.applyPbsZFocus(value, base) : Number(value || 0) + Number(base || 0);
        if (((_c = clip.imported) === null || _c === void 0 ? void 0 : _c.format) === "pbs" || clip.type === "pbs-particle") {
            const ui = this.semanticIndex("user"), ti = this.semanticIndex("target"), uz = rgssBattlerZ(ui), tz = rgssBattlerZ(ti);
            if (focus === "foreground")
                return 2000 + z;
            if (focus === "midground")
                return 1000 + z;
            if (focus === "background")
                return z;
            if (focus === "user" || focus === "user_position")
                return apply(z, uz);
            if (focus === "target" || focus === "target_position")
                return apply(z, tz);
            if (focus.includes("user") && focus.includes("target"))
                return apply(z, [uz, tz]);
            if (focus === "user_side_foreground")
                return 1000 + (ui % 2 === 0 ? 1000 : 0) + z;
            if (focus === "target_side_foreground")
                return 1000 + (ti % 2 === 0 ? 1000 : 0) + z;
            if (focus === "user_side_background")
                return (ui % 2 === 0 ? 1000 : 0) + z;
            if (focus === "target_side_background")
                return (ti % 2 === 0 ? 1000 : 0) + z;
        }
        return z;
    }
    applyPbsZFocus(z, focus) {
        z = Number(z || 0);
        const distance = -100, u = Number((focus === null || focus === void 0 ? void 0 : focus[0]) || 0), t = Number((focus === null || focus === void 0 ? void 0 : focus[1]) || 0);
        if (z >= 0)
            return u > t ? u + z : u - z;
        if (z <= distance)
            return u > t ? t + z + distance : t - z + distance;
        return u + ((z / distance) * (t - u));
    }
    drawClipOrEmitter(clip, selected, accent) { var _a, _b; const emitter = String(((_a = clip.pbs) === null || _a === void 0 ? void 0 : _a.emitter) || ((_b = clip.pbs) === null || _b === void 0 ? void 0 : _b.emitterType) || "none").toLowerCase(); if (emitter && emitter !== "none")
        this.drawEmitter(clip, selected, accent);
    else
        this.drawClip(clip, selected, accent, this.frame, null); }
    emitterValue(clip, name, frame, def = 0) { var _a, _b; const list = ((_b = (_a = clip.pbs) === null || _a === void 0 ? void 0 : _a.emitterCommands) === null || _b === void 0 ? void 0 : _b[name]) || []; if (!list.length)
        return def; let value = def; for (const c of list) {
        if (frame < c.frame)
            break;
        if (c.duration > 0 && frame < c.frame + c.duration) {
            const t = ease((frame - c.frame) / c.duration, c.easing || "linear");
            return typeof c.value === "number" ? lerp(value, c.value, t) : c.value;
        }
        value = c.value;
    } return value; }
    emitterEmissionFrames(clip, now, fps, rate, limit = 500) {
        var _a, _b;
        // GameData::Animation emitters are OFF by default. Each SetEmitting=true
        // starts/restarts an emission cadence at exactly that command time; false
        // stops it. This mirrors AnimationPlayer::Emitter's @next_emission logic.
        const list = (((_b = (_a = clip.pbs) === null || _a === void 0 ? void 0 : _a.emitterCommands) === null || _b === void 0 ? void 0 : _b.emitting) || []).slice().sort((a, b) => Number(a.frame || 0) - Number(b.frame || 0));
        if (!list.length)
            return [];
        const interval = fps / Math.max(.01, rate), out = [];
        let state = false, start = null;
        const flush = (end) => {
            if (!state || start === null)
                return;
            const stop = Math.min(now, Number.isFinite(end) ? end : now);
            for (let f = start; f <= stop + 1e-6 && out.length < limit; f += interval)
                out.push(f);
        };
        for (const cmd of list) {
            const f = Number(cmd.frame || 0);
            if (f > now + 1e-6)
                break;
            flush(f - 1e-7);
            state = !!cmd.value;
            start = state ? f : null;
        }
        flush(now);
        return out;
    }
    emitterRandomized(clip, key, rangeKey, frame, rnd, def = 0) {
        const base = Number(this.emitterValue(clip, key, frame, def) || 0), range = Math.max(0, Number(this.emitterValue(clip, rangeKey, frame, 0) || 0));
        return range > 0 ? base + (rnd() * 2 - 1) * range : base;
    }
    drawEmitter(clip, selected, accent) {
        var _a, _b, _c, _d;
        const fps = Math.max(1, ((_a = this.animation) === null || _a === void 0 ? void 0 : _a.fps) || 20), rate = Math.max(.01, Number(((_b = clip.pbs) === null || _b === void 0 ? void 0 : _b.emitterRate) || 1)), intensity = Math.max(1, Math.round(Number(((_c = clip.pbs) === null || _c === void 0 ? void 0 : _c.emitterIntensity) || 1))), now = this.frame, type = String(((_d = clip.pbs) === null || _d === void 0 ? void 0 : _d.emitter) || "none").toLowerCase();
        const emissionFrames = this.emitterEmissionFrames(clip, now, fps, rate, 500), particles = [];
        for (const ef of emissionFrames) {
            for (let j = 0; j < intensity && particles.length < 500; j++) {
                const age = now - ef;
                if (age < 0)
                    continue;
                const seed = hash32(`${clip.id}:${Math.round(ef * 1000)}:${j}`), rnd = seeded(seed);
                const ox = this.emitterRandomized(clip, "emitX", "emitXRange", ef, rnd, 0), oy = this.emitterRandomized(clip, "emitY", "emitYRange", ef, rnd, 0);
                const speed = this.emitterRandomized(clip, "emitSpeed", "emitSpeedRange", ef, rnd, 0), angleDeg = this.emitterRandomized(clip, "emitAngle", "emitAngleRange", ef, rnd, 0);
                const gravity = this.emitterRandomized(clip, "emitGravity", "emitGravityRange", ef, rnd, 0);
                const periodX = Math.max(.0001, this.emitterRandomized(clip, "emitPeriodX", "emitPeriodXRange", ef, rnd, 100) / 100);
                const periodY = Math.max(.0001, this.emitterRandomized(clip, "emitPeriodY", "emitPeriodYRange", ef, rnd, 100) / 100);
                const periodZ = Math.max(.0001, this.emitterRandomized(clip, "emitPeriodZ", "emitPeriodZRange", ef, rnd, 100) / 100);
                const radiusXMult = (100 + (rnd() * 2 - 1) * Math.max(0, Number(this.emitterValue(clip, "emitRadiusXRange", ef, 0) || 0))) / 100;
                const radiusYMult = (100 + (rnd() * 2 - 1) * Math.max(0, Number(this.emitterValue(clip, "emitRadiusYRange", ef, 0) || 0))) / 100;
                const radiusZMult = (100 + (rnd() * 2 - 1) * Math.max(0, Number(this.emitterValue(clip, "emitRadiusZRange", ef, 0) || 0))) / 100;
                const zoomMult = (100 + (rnd() * 2 - 1) * Math.max(0, Number(this.emitterValue(clip, "emitZoomRange", ef, 0) || 0))) / 100;
                const zoomXMult = (100 + (rnd() * 2 - 1) * Math.max(0, Number(this.emitterValue(clip, "emitZoomXRange", ef, 0) || 0))) / 100;
                const zoomYMult = (100 + (rnd() * 2 - 1) * Math.max(0, Number(this.emitterValue(clip, "emitZoomYRange", ef, 0) || 0))) / 100;
                const clockwise = !!this.emitterValue(clip, "emitClockwise", ef, false), sec = age / fps, dir = clockwise ? -1 : 1, phase = angleDeg * Math.PI / 180;
                const radiusX = Number(this.samplePbsScalar(clip, "radiusX", age, 0) || 0), radiusY = Number(this.samplePbsScalar(clip, "radiusY", age, 0) || 0), radiusZ = Number(this.samplePbsScalar(clip, "radiusZ", age, 0) || 0);
                let dx = ox, dy = oy, zOffset = 0;
                if (type === "straight" || type === "projectile") {
                    const ar = phase;
                    dx += Math.cos(ar) * speed * sec;
                    dy -= Math.sin(ar) * speed * sec;
                    if (type === "projectile")
                        dy += gravity * sec * sec / 2;
                }
                else if (type === "helix") {
                    if (periodX > 0)
                        dx += radiusX * radiusXMult * Math.sin(phase + (Math.PI * 2 * sec / periodX) * dir);
                    if (speed !== 0)
                        dy += speed * sec;
                    if (periodZ > 0)
                        zOffset += radiusZ * radiusZMult * Math.cos(phase + (Math.PI * 2 * sec / periodZ) * dir);
                }
                else if (type === "polar") {
                    if (periodX > 0)
                        dx += radiusX * radiusXMult * Math.sin(phase + (Math.PI * 2 * sec / periodX) * dir);
                    // The original player intentionally does not apply clockwise to Y.
                    if (periodY > 0)
                        dy += radiusY * radiusYMult * Math.cos(phase + (Math.PI * 2 * sec / periodY));
                }
                particles.push({ ef, j, age, seed, dx, dy, zOffset, scaleXMult: zoomMult * zoomXMult, scaleYMult: zoomMult * zoomYMult });
            }
        }
        particles.sort((a, b) => a.zOffset - b.zOffset);
        for (const p of particles) {
            const extra = { offsetX: p.dx, offsetY: p.dy, zOffset: p.zOffset, scaleXMult: p.scaleXMult, scaleYMult: p.scaleYMult, randomSeed: p.seed, emissionFrame: p.ef };
            this.drawClip(clip, selected && p.j === 0 && Math.abs(p.ef) < 1e-6, accent, p.age, extra);
        }
    }
    rgssAngleBetween(x1, y1, x2, y2) {
        // Exact convention used by AnimationPlayer::Helper.angle_between:
        // 0° points up and positive angles turn anticlockwise in RGSS space.
        const dx = Number(x1) - Number(x2), dy = Number(y1) - Number(y2);
        if (Math.abs(dy) < 1e-9)
            return dx >= 0 ? 90 : -90;
        let ret = Math.atan(dx / dy) * 180 / Math.PI;
        if (dy < 0)
            ret += 180;
        return ret;
    }
    pbsInitialCommandValue(clip, prop) {
        var _a, _b;
        const list = ((_b = (_a = clip === null || clip === void 0 ? void 0 : clip.pbs) === null || _a === void 0 ? void 0 : _a.commands) === null || _b === void 0 ? void 0 : _b[prop]) || [], first = list[0];
        // The official helper only considers the first X/Y command, and only if
        // it is an instantaneous Set command. If that first command moves, the
        // starting value remains 0.
        if (!first || Number(first.duration || 0) > 0)
            return 0;
        return Number(first.value || 0);
    }
    pbsInitialAngleOrigin(clip) {
        var _a;
        const focus = String(((_a = clip === null || clip === void 0 ? void 0 : clip.pbs) === null || _a === void 0 ? void 0 : _a.focus) || "foreground"), p = { anchor: `pbs:${focus}`, x: this.pbsInitialCommandValue(clip, "x"), y: this.pbsInitialCommandValue(clip, "y"), offsetX: 0, offsetY: 0, foeInvertX: false, foeInvertY: false };
        return this.resolvePoint(p);
    }
    pbsAngleTarget(clip) {
        var _a, _b, _c, _d;
        const f = String(((_a = clip === null || clip === void 0 ? void 0 : clip.pbs) === null || _a === void 0 ? void 0 : _a.focus) || "").toLowerCase(), a = this.anchors(), ctx = this.context || {}, opp = this.semanticOpposing(), scriptU = opp ? (ctx.scriptTarget || ctx.target) : (ctx.scriptUser || ctx.user), scriptT = opp ? (ctx.scriptUser || ctx.user) : (ctx.scriptTarget || ctx.target);
        return f.includes("and_target_position") ? { x: a.target.x, y: Number((_b = scriptT === null || scriptT === void 0 ? void 0 : scriptT.y) !== null && _b !== void 0 ? _b : a.target.y) } : f.includes("and_target") ? Object.assign({}, a.target) : f.startsWith("target_position") ? { x: a.target.x, y: Number((_c = scriptT === null || scriptT === void 0 ? void 0 : scriptT.y) !== null && _c !== void 0 ? _c : a.target.y) } : f.startsWith("target") ? Object.assign({}, a.target) : f.startsWith("user_position") ? { x: a.user.x, y: Number((_d = scriptU === null || scriptU === void 0 ? void 0 : scriptU.y) !== null && _d !== void 0 ? _d : a.user.y) } : Object.assign({}, a.user);
    }
    samplePbsScalar(clip, prop, frame, def) { var _a, _b; const cmds = ((_b = (_a = clip.pbs) === null || _a === void 0 ? void 0 : _a.commands) === null || _b === void 0 ? void 0 : _b[prop]) || []; if (!cmds.length)
        return def; let state = def; for (const x of cmds) {
        if (frame < x.frame)
            break;
        if (x.duration > 0 && frame < x.frame + x.duration) {
            const t = ease((frame - x.frame) / Math.max(.001, x.duration), x.easing || "linear");
            return typeof x.value === "number" ? lerp(state, x.value, t) : x.value;
        }
        state = x.value;
    } return state; }
    drawClip(clip, selected, accent, localFrame = this.frame, extra = null) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;
        if ((extra === null || extra === void 0 ? void 0 : extra.emissionFrame) !== undefined && !sampleVisible(clip, localFrame))
            return;
        const c = this.ctx, oldFrame = this.frame;
        this.frame = localFrame;
        let basePos = this.samplePosition(clip, localFrame);
        this.frame = oldFrame;
        basePos = { x: basePos.x + Number((extra === null || extra === void 0 ? void 0 : extra.offsetX) || 0), y: basePos.y + Number((extra === null || extra === void 0 ? void 0 : extra.offsetY) || 0) };
        let r = this.clipImages.get(clip.id);
        const switches = (clip.graphicSwitches || []).slice().sort((a, b) => Number(a.frame || 0) - Number(b.frame || 0));
        let activeSwitch = null;
        for (const sw of switches) {
            if (Number(sw.frame || 0) > localFrame)
                break;
            activeSwitch = sw;
        }
        if (activeSwitch) {
            const sr = this.clipImages.get(`${clip.id}@@${String(activeSwitch.value || "")}`);
            if (sr === null || sr === void 0 ? void 0 : sr.image)
                r = sr;
        }
        const specialBundle = this.specialBattlerBundle((_a = clip.graphic) === null || _a === void 0 ? void 0 : _a.source), special = (specialBundle === null || specialBundle === void 0 ? void 0 : specialBundle.image) || null, im = special || ((r === null || r === void 0 ? void 0 : r.image) || null);
        if (!im && !selected)
            return;
        let size = Math.max(.01, this.sampleAt(clip, "size", localFrame, 100) / 100), sxScale = this.sampleAt(clip, "scaleX", localFrame, 100) / 100 * size * Number((_b = extra === null || extra === void 0 ? void 0 : extra.scaleXMult) !== null && _b !== void 0 ? _b : 1), syScale = this.sampleAt(clip, "scaleY", localFrame, 100) / 100 * size * Number((_c = extra === null || extra === void 0 ? void 0 : extra.scaleYMult) !== null && _c !== void 0 ? _c : 1), opacity = clamp(this.sampleAt(clip, "opacity", localFrame, 100) / 100, 0, 1), rotation = this.sampleAt(clip, "rotation", localFrame, 0), blend = Math.round(this.sampleAt(clip, "blend", localFrame, 0)), invert = this.sampleAt(clip, "invert", localFrame, 0) >= .5;
        if (specialBundle === null || specialBundle === void 0 ? void 0 : specialBundle.meta) {
            const bs = Math.max(.01, Number(specialBundle.meta.scale || 1));
            sxScale *= bs;
            syScale *= bs;
        }
        const rnd = seeded(Number((extra === null || extra === void 0 ? void 0 : extra.randomSeed) || hash32(clip.id)));
        let src = this.sourceFrame(clip, im, localFrame, extra === null || extra === void 0 ? void 0 : extra.randomSeed), focus = String(((_d = clip.pbs) === null || _d === void 0 ? void 0 : _d.focus) || ""), relativeIndex = focus.includes("and") ? -1 : focus.startsWith("user") ? this.semanticIndex("user") : focus.startsWith("target") ? this.semanticIndex("target") : -1, flip = this.sampleAt(clip, "flip", localFrame, 0) >= .5 || (((_e = clip.pbs) === null || _e === void 0 ? void 0 : _e.foeFlip) && relativeIndex >= 0 && relativeIndex % 2 === 1);
        if (((_f = clip.pbs) === null || _f === void 0 ? void 0 : _f.randomInvertFlip) && rnd() < .5)
            flip = !flip;
        // New Animation Editor angle order is significant:
        //   command value + (InitialAngleToFocus OR random angle offset)
        //   OR AlwaysPointAtFocus + offset + command value
        //   THEN RandomInvertAngle. RandomAngleRange REPLACES the base angle offset.
        // Applying inversion/randomness before AngleOverride produced mirrored arcs.
        let angleOffset = 0;
        const range = Math.max(0, Number(((_g = clip.pbs) === null || _g === void 0 ? void 0 : _g.randomAngleRange) || 0));
        const mode = String(((_h = clip.pbs) === null || _h === void 0 ? void 0 : _h.angleOverride) || "none").toLowerCase();
        const xyOffset = (special && src) ? Number(src.sh || 0) / 2 : 0;
        if (range > 0) {
            // Ruby rand(-range, range) is integer for integer PBS values. Keep a
            // deterministic import preview while preserving the same bounds.
            angleOffset = Math.floor(rnd() * (range * 2 + 1)) - range;
        }
        else if (mode.includes("initial") && mode.includes("focus")) {
            const origin = this.pbsInitialAngleOrigin(clip), target = this.pbsAngleTarget(clip);
            // initial_angle_between adds get_xy_offset only to the source point.
            origin.y += xyOffset;
            angleOffset = this.rgssAngleBetween(origin.x, origin.y, target.x, target.y);
        }
        if (mode.includes("always") && mode.includes("focus")) {
            const origin = Object.assign({}, basePos), target = Object.assign({}, this.pbsAngleTarget(clip));
            // During playback the sprite position already contains offset_xy and the
            // target calculation adds the same offset, exactly as ParticleSprite.
            origin.y += xyOffset;
            target.y += xyOffset;
            rotation += this.rgssAngleBetween(origin.x, origin.y, target.x, target.y) + angleOffset;
        }
        else {
            rotation += angleOffset;
        }
        if (((_j = clip.pbs) === null || _j === void 0 ? void 0 : _j.randomInvertAngle) && rnd() < .5)
            rotation *= -1;
        let w = 32 * Math.abs(sxScale), h = 32 * Math.abs(syScale), pos = Object.assign({}, basePos);
        if (special && src)
            pos.y += src.sh / 2;
        c.save();
        c.translate(pos.x, pos.y);
        c.rotate(-rotation * Math.PI / 180);
        if (flip)
            c.scale(-1, 1);
        c.globalAlpha = opacity;
        if (invert)
            c.filter = "invert(1)";
        if (blend === 1)
            c.globalCompositeOperation = "lighter";
        else if (blend === 2)
            c.globalCompositeOperation = "multiply";
        if (im && src) {
            const fx = this.fxImage(im, src, this.fxAt(clip, "tone", localFrame), this.fxAt(clip, "color", localFrame)), drawIm = fx.image, drawSrc = fx.src;
            w = drawSrc.sw * Math.abs(sxScale);
            h = drawSrc.sh * Math.abs(syScale);
            c.imageSmoothingEnabled = false;
            let dx = -w / 2, dy = -h / 2;
            const origin = ((_k = clip.graphic) === null || _k === void 0 ? void 0 : _k.origin) || "auto", screenFocus = ["foreground", "midground", "background"].includes(focus);
            if (origin === "bottom" || special)
                dy = -h;
            else if (origin === "top_left" || (origin === "auto" && screenFocus && drawSrc.sw >= this.logicalSize().width * .8)) {
                dx = 0;
                dy = 0;
            }
            if ((_l = clip.pbs) === null || _l === void 0 ? void 0 : _l.tiled)
                this.drawTiledImage(c, clip, drawIm, drawSrc, dx, dy, w, h, localFrame, pos);
            else
                this.drawImageMasked(c, clip, drawIm, drawSrc, dx, dy, w, h, localFrame);
            if ((_m = clip.pbs) === null || _m === void 0 ? void 0 : _m.secondLayer)
                this.drawSecondLayer(c, clip, drawIm, drawSrc, dx, dy, w, h, localFrame);
        }
        else {
            const rr = 15 * Math.max(Math.abs(sxScale), Math.abs(syScale)), gl = c.createRadialGradient(0, 0, 2, 0, 0, rr * 1.8);
            gl.addColorStop(0, "rgba(255,255,255,.98)");
            gl.addColorStop(.32, accent);
            gl.addColorStop(1, "rgba(90,120,255,0)");
            c.fillStyle = gl;
            c.beginPath();
            c.arc(0, 0, rr * 1.8, 0, Math.PI * 2);
            c.fill();
        }
        c.restore();
        if (localFrame === this.frame) {
            this.hitShapes.push({ objectId: clip.id, x: pos.x, y: pos.y, w: Math.max(20, w), h: Math.max(20, h), kind: "clip" });
            if (selected && !this.playing) {
                if (sortPositionKeys(clip).length && ((_p = (_o = this.callbacks).showPath) === null || _p === void 0 ? void 0 : _p.call(_o)) !== false)
                    this.drawPath(clip, accent);
                c.save();
                c.translate(pos.x, pos.y);
                c.rotate(-rotation * Math.PI / 180);
                c.strokeStyle = accent;
                c.lineWidth = 1.2;
                c.setLineDash([4, 3]);
                c.strokeRect(-w / 2 - 5, -h / 2 - 5, w + 10, h + 10);
                c.restore();
            }
        }
    }
    sampleAt(o, prop, frame, def) { const old = this.frame; this.frame = frame; const v = sampleValue(o, prop, frame, def); this.frame = old; return v; }
    drawTiledImage(c, clip, image, src, dx, dy, w, h, frame, pos) { if (!image || !src || !w || !h)
        return; const logical = this.logicalSize(), tw = Math.max(1, Math.abs(w)), th = Math.max(1, Math.abs(h)), pad = 2; const minX = -Number((pos === null || pos === void 0 ? void 0 : pos.x) || 0) - tw * pad, maxX = logical.width - Number((pos === null || pos === void 0 ? void 0 : pos.x) || 0) + tw * pad, minY = -Number((pos === null || pos === void 0 ? void 0 : pos.y) || 0) - th * pad, maxY = logical.height - Number((pos === null || pos === void 0 ? void 0 : pos.y) || 0) + th * pad; for (let yy = Math.floor(minY / th) * th; yy <= maxY; yy += th)
        for (let xx = Math.floor(minX / tw) * tw; xx <= maxX; xx += tw)
            c.drawImage(image, src.sx, src.sy, src.sw, src.sh, xx, yy, w, h); }
    drawImageMasked(c, clip, image, src, dx, dy, w, h, frame) { var _a; const mask = (_a = this.maskImages.get(clip.id)) === null || _a === void 0 ? void 0 : _a.image; if (!mask) {
        c.drawImage(image, src.sx, src.sy, src.sw, src.sh, dx, dy, w, h);
        return;
    } const cv = document.createElement("canvas"); cv.width = Math.max(1, Math.round(Math.abs(w))); cv.height = Math.max(1, Math.round(Math.abs(h))); const x = cv.getContext("2d"); x.imageSmoothingEnabled = false; x.drawImage(image, src.sx, src.sy, src.sw, src.sh, 0, 0, cv.width, cv.height); x.globalCompositeOperation = "destination-in"; const mx = this.samplePbsScalar(clip, "maskX", frame, 0), my = this.samplePbsScalar(clip, "maskY", frame, 0), mzX = this.samplePbsScalar(clip, "maskZoomX", frame, 100) / 100, mzY = this.samplePbsScalar(clip, "maskZoomY", frame, 100) / 100, mop = this.samplePbsScalar(clip, "maskOpacity", frame, 255) / 255; x.globalAlpha = mop; x.drawImage(mask, mx, my, mask.width * mzX, mask.height * mzY); c.drawImage(cv, dx, dy, w, h); }
    drawSecondLayer(c, clip, image, src, dx, dy, w, h, frame) {
        const x2 = this.samplePbsScalar(clip, "x2", frame, 0), y2 = this.samplePbsScalar(clip, "y2", frame, 0), zx = this.samplePbsScalar(clip, "zoomX2", frame, 100) / 100, zy = this.samplePbsScalar(clip, "zoomY2", frame, 100) / 100, opaOffset = this.samplePbsScalar(clip, "opacity2", frame, 0), ang = this.samplePbsScalar(clip, "angle2", frame, 0) * Math.PI / 180, flip = this.samplePbsScalar(clip, "flip2", frame, 0), blend = Math.round(this.samplePbsScalar(clip, "blending2", frame, 0)), baseOpacity = this.sampleAt(clip, "opacity", frame, 100) * 255 / 100, alpha = clamp((baseOpacity + Number(opaOffset || 0)) / 255, 0, 1);
        if (alpha <= 0)
            return;
        let src2 = Object.assign({}, src);
        const fr2 = Math.max(0, Math.round(this.samplePbsScalar(clip, "frame2", frame, src.frame || 0)));
        if ((src.frames || 1) > 1) {
            const cw = src.sw, ch = src.sh, cols = Math.max(1, Math.floor(image.width / cw)), count = Math.max(1, Math.floor(image.width / cw) * Math.floor(image.height / ch)), f = fr2 % count;
            src2 = Object.assign(Object.assign({}, src), { sx: (f % cols) * cw, sy: Math.floor(f / cols) * ch, frame: f });
        }
        const toneRaw = this.samplePbsScalar(clip, "tone2", frame, "+000+000+000+000"), colorRaw = this.samplePbsScalar(clip, "color2", frame, "#00000000"), fx = this.fxImage(image, src2, typeof toneRaw === "string" ? parseHexColor(toneRaw, true) : { r: 0, g: 0, b: 0, a: 0 }, typeof colorRaw === "string" ? parseHexColor(colorRaw, false) : { r: 0, g: 0, b: 0, a: 0 }), invBase = this.sampleAt(clip, "invert", frame, 0) >= .5, inv2 = !!this.samplePbsScalar(clip, "invertColor2", frame, false);
        c.save();
        c.translate(x2, y2);
        c.rotate(-ang);
        if (flip)
            c.scale(-1, 1);
        c.globalAlpha = alpha;
        if (invBase !== inv2)
            c.filter = "invert(1)";
        if (blend === 1)
            c.globalCompositeOperation = "lighter";
        else if (blend === 2)
            c.globalCompositeOperation = "multiply";
        c.drawImage(fx.image, fx.src.sx, fx.src.sy, fx.src.sw, fx.src.sh, dx, dy, w * zx, h * zy);
        c.restore();
    }
    dynamicCodeGrid(image) { const width = Number((image === null || image === void 0 ? void 0 : image.width) || 0), height = Number((image === null || image === void 0 ? void 0 : image.height) || 0); if (width <= 0 || height <= 0)
        return { cols: 1, rows: 1, fw: Math.max(1, width), fh: Math.max(1, height), count: 1 }; if (width === height)
        return { cols: 1, rows: 1, fw: width, fh: height, count: 1 }; if (width >= height * 2 && width % height === 0 && width / height <= 16) {
        const cols = width / height;
        return { cols, rows: 1, fw: height, fh: height, count: cols };
    } if (height >= width * 2 && height % width === 0 && height / width <= 16) {
        const rows = height / width;
        return { cols: 1, rows, fw: width, fh: width, count: rows };
    } let best = { cols: 1, rows: 1, fw: width, fh: height, count: 1 }, score = Infinity; for (let cols = 1; cols <= 8; cols++) {
        if (width % cols)
            continue;
        for (let rows = 1; rows <= 8; rows++) {
            if (height % rows || (cols === 1 && rows === 1))
                continue;
            const fw = width / cols, fh = height / rows;
            if (fw < 12 || fh < 12)
                continue;
            const ratio = fw / fh, pen = Math.abs(Math.log(Math.max(.0001, Math.abs(ratio)))) + Math.max(0, cols * rows - 16) + (fw * fh < 22 * 22 ? 10 : 0);
            if (pen < score) {
                score = pen;
                best = { cols, rows, fw, fh, count: cols * rows };
            }
        }
    } return best; }
    sourceFrame(clip, image, frame = this.frame, seed = 0) {
        var _a;
        if (!(image === null || image === void 0 ? void 0 : image.width) || !(image === null || image === void 0 ? void 0 : image.height))
            return null;
        const g = clip.graphic || {}, customW = this.sampleAt(clip, "srcW", frame, 0), customH = this.sampleAt(clip, "srcH", frame, 0);
        if (customW > 0 && customH > 0) {
            const sx = this.sampleAt(clip, "srcX", frame, 0), sy = this.sampleAt(clip, "srcY", frame, 0);
            return { sx: Math.max(0, sx), sy: Math.max(0, sy), sw: Math.max(1, Math.min(customW, image.width - Math.max(0, sx))), sh: Math.max(1, Math.min(customH, image.height - Math.max(0, sy))), frames: 1, frame: 0 };
        }
        let fr = Math.max(0, Math.round(this.sampleAt(clip, "graphicFrame", frame, Number(g.frame || 0))));
        if ((_a = clip.pbs) === null || _a === void 0 ? void 0 : _a.randomFrameMax) {
            const r = seeded(Number(seed || hash32(`${clip.id}:${Math.floor(frame)}`)))();
            fr = Math.floor(r * (Number(clip.pbs.randomFrameMax) + 1));
        }
        if (g.spritesheet === "rmxp") {
            const cw = Number(g.cellW || 192), ch = Number(g.cellH || 192), cols = Math.max(1, Number(g.cols || Math.floor(image.width / cw) || 5)), rows = Math.max(1, Math.floor(image.height / ch)), count = Math.max(1, cols * rows);
            fr = ((fr % count) + count) % count;
            return { sx: (fr % cols) * cw, sy: Math.floor(fr / cols) * ch, sw: Math.min(cw, image.width), sh: Math.min(ch, image.height), frames: count, frame: fr };
        }
        if (g.spritesheet === "code-dynamic-grid") {
            const grid = this.dynamicCodeGrid(image);
            let idx = 0, style = String(g.sheetStyle || "default").toLowerCase();
            if (style === "charge")
                idx = Math.min(Math.floor(grid.count / 3), grid.count - 1);
            else if (style === "burst")
                idx = Math.min(grid.count - 1, Math.floor(grid.rows / 2) * grid.cols + Math.floor(grid.cols / 2));
            if (g.playSheet) {
                const start = Number(g.playStart || 0), count = Math.max(1, Math.min(grid.count, Number(g.playFrameCount || grid.count))), ticks = Math.max(1, Number(g.ticksPerFrame || 1)), base = style === "burst" ? Math.max(0, Math.floor(grid.count / 3)) : 0;
                idx = base + Math.max(0, Math.floor((frame - start) / ticks)) % count;
            }
            idx = ((idx % grid.count) + grid.count) % grid.count;
            let sw = grid.fw, sh = grid.fh, sx = (idx % grid.cols) * sw, sy = Math.floor(idx / grid.cols) * sh;
            if ((sw === image.width && sh === image.height) || sw > 192 || sh > 192) {
                const crop = Math.max(1, Math.min(image.width, image.height, 192));
                sw = sh = crop;
                sx = Math.round((image.width - crop) / 2);
                sy = Math.round((image.height - crop) / 2);
            }
            return { sx, sy, sw, sh, frames: grid.count, frame: idx };
        }
        if (g.spritesheet === "code-auto-grid" || g.spritesheet === "code-grid") {
            const fallback = g.cellMode === "square-height" ? image.height : Math.min(image.width, image.height), cw = Math.max(1, Number(g.cellW) || fallback), ch = Math.max(1, Number(g.cellH) || cw), cols = Math.max(1, Number(g.gridCols || g.cols) || Math.floor(image.width / cw)), rows = Math.max(1, Math.floor(image.height / ch)), count = Math.max(1, cols * rows);
            if (g.playSheet) {
                const ticks = Math.max(1, Number(g.ticksPerFrame || 1)), start = Number(g.playStart || clip.startFrame || 0), first = Math.max(0, Number(g.playFirstFrame || 0)), limited = Math.max(0, Number(g.playFrameCount || 0)), span = limited > 0 ? Math.min(count, limited) : count;
                fr = first + Math.max(0, Math.floor((frame - start) / ticks)) % Math.max(1, span);
            }
            fr = ((fr % count) + count) % count;
            return { sx: (fr % cols) * cw, sy: Math.floor(fr / cols) * ch, sw: Math.min(cw, image.width), sh: Math.min(ch, image.height), frames: count, frame: fr };
        }
        let sheet = g.spritesheet === "sheet";
        if (g.spritesheet === "auto") {
            const codeLike = g.source === "code" || String(clip.type || "").includes("code");
            if (codeLike && (image.width > image.height * 1.35 || image.height > image.width * 1.35)) {
                const grid = this.dynamicCodeGrid(image);
                if (grid.count > 1) {
                    fr = ((fr % grid.count) + grid.count) % grid.count;
                    return { sx: (fr % grid.cols) * grid.fw, sy: Math.floor(fr / grid.cols) * grid.fh, sw: Math.min(grid.fw, image.width), sh: Math.min(grid.fh, image.height), frames: grid.count, frame: fr };
                }
            }
            sheet = codeLike ? (image.width > image.height && image.width % image.height === 0) : image.width > image.height * 2;
        }
        if (!sheet)
            return { sx: 0, sy: 0, sw: image.width, sh: image.height, frames: 1, frame: 0 };
        const side = image.height, count = Math.max(1, Math.floor(image.width / side));
        if (g.playSheet && this.animation) {
            const sec = Math.max(0, frame - (clip.startFrame || 0)) / Math.max(1, this.animation.fps || 20);
            fr = Math.floor(sec * Math.max(1, Number(g.sheetFps || 20)));
        }
        fr = ((fr % count) + count) % count;
        return { sx: fr * side, sy: 0, sw: side, sh: side, frames: count, frame: fr };
    }
    fxAt(clip, kind, frame = this.frame) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        const zero = { r: 0, g: 0, b: 0, a: 0 }, toFx = (raw) => { var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k; if (typeof raw === "string")
            return parseHexColor(raw, kind === "tone"); if (raw && typeof raw === "object")
            return { r: Number((_b = (_a = raw.red) !== null && _a !== void 0 ? _a : raw.r) !== null && _b !== void 0 ? _b : 0), g: Number((_d = (_c = raw.green) !== null && _c !== void 0 ? _c : raw.g) !== null && _d !== void 0 ? _d : 0), b: Number((_f = (_e = raw.blue) !== null && _e !== void 0 ? _e : raw.b) !== null && _f !== void 0 ? _f : 0), a: Number(kind === "tone" ? ((_h = (_g = raw.gray) !== null && _g !== void 0 ? _g : raw.a) !== null && _h !== void 0 ? _h : 0) : ((_k = (_j = raw.alpha) !== null && _j !== void 0 ? _j : raw.a) !== null && _k !== void 0 ? _k : 0)) }; return Object.assign({}, zero); };
        const mix = (a, b, t) => ({ r: lerp(a.r, b.r, t), g: lerp(a.g, b.g, t), b: lerp(a.b, b.b, t), a: lerp(a.a, b.a, t) });
        let value = Object.assign({}, zero);
        const ops = (clip.fxOps || []).slice().sort((a, b) => { var _a, _b, _c, _d, _e, _f; return Number((_c = (_a = a.frame) !== null && _a !== void 0 ? _a : (_b = a.args) === null || _b === void 0 ? void 0 : _b[0]) !== null && _c !== void 0 ? _c : 0) - Number((_f = (_d = b.frame) !== null && _d !== void 0 ? _d : (_e = b.args) === null || _e === void 0 ? void 0 : _e[0]) !== null && _f !== void 0 ? _f : 0); });
        for (const op of ops) {
            const name = String(op.name || ""), f = Number((_c = (_a = op.frame) !== null && _a !== void 0 ? _a : (_b = op.args) === null || _b === void 0 ? void 0 : _b[0]) !== null && _c !== void 0 ? _c : 0);
            if (f > frame)
                break;
            if (name === "legacyFx") {
                const v = op[kind];
                if (v)
                    value = toFx(v);
                continue;
            }
            if (kind === "tone" && !/Tone/i.test(name))
                continue;
            if (kind === "color" && !/Color/i.test(name))
                continue;
            const args = op.args || [], moving = /^move/i.test(name) || /^Move/.test(name), raw = (_d = op.value) !== null && _d !== void 0 ? _d : (moving ? ((_e = args[2]) !== null && _e !== void 0 ? _e : args.at(-1)) : ((_f = args[1]) !== null && _f !== void 0 ? _f : args.at(-1))), target = toFx(raw), dur = moving ? Math.max(0, Number((_h = (_g = op.duration) !== null && _g !== void 0 ? _g : args[1]) !== null && _h !== void 0 ? _h : 0)) : 0;
            if (moving && dur > 0 && frame < f + dur) {
                const t = ease((frame - f) / dur, op.easing || args[3] || "linear");
                return mix(value, target, t);
            }
            value = target;
        }
        return value;
    }
    fxImage(image, src, tone, color) { if (!image || !src)
        return { image, src }; const key = [image.src, src.sx, src.sy, src.sw, src.sh, Math.round(tone.r), Math.round(tone.g), Math.round(tone.b), Math.round(tone.a), Math.round(color.r), Math.round(color.g), Math.round(color.b), Math.round(color.a)].join("|"); if (this.fxCache.has(key))
        return this.fxCache.get(key); const cv = document.createElement("canvas"); cv.width = Math.max(1, Math.round(src.sw)); cv.height = Math.max(1, Math.round(src.sh)); const cx = cv.getContext("2d", { willReadFrequently: true }); cx.imageSmoothingEnabled = false; cx.drawImage(image, src.sx, src.sy, src.sw, src.sh, 0, 0, cv.width, cv.height); try {
        const d = cx.getImageData(0, 0, cv.width, cv.height), p = d.data, gray = clamp(tone.a / 255, 0, 1), ca = clamp(color.a / 255, 0, 1);
        for (let i = 0; i < p.length; i += 4) {
            let r = clamp(p[i] + tone.r, 0, 255), g = clamp(p[i + 1] + tone.g, 0, 255), b = clamp(p[i + 2] + tone.b, 0, 255);
            if (gray > 0) {
                const y = .299 * r + .587 * g + .114 * b;
                r = lerp(r, y, gray);
                g = lerp(g, y, gray);
                b = lerp(b, y, gray);
            }
            if (ca > 0) {
                r = lerp(r, color.r, ca);
                g = lerp(g, color.g, ca);
                b = lerp(b, color.b, ca);
            }
            p[i] = r;
            p[i + 1] = g;
            p[i + 2] = b;
        }
        cx.putImageData(d, 0, 0);
    }
    catch (_a) { } const ret = { image: cv, src: { sx: 0, sy: 0, sw: cv.width, sh: cv.height, frames: 1, frame: 0 } }; this.fxCache.set(key, ret); if (this.fxCache.size > 256)
        this.fxCache.delete(this.fxCache.keys().next().value); return ret; }
    specialBattlerBundle(source) {
        const opp = this.semanticOpposing(), ui = this.semanticIndex("user"), ti = this.semanticIndex("target");
        const pick = (imageKey, metaKey, fallbackImage, fallbackMeta) => ({ image: this.images[imageKey] || this.images[fallbackImage] || null, meta: this.battlerMeta[metaKey] || this.battlerMeta[fallbackMeta] || {} });
        const actual = (role, variant) => {
            const semanticUser = role === "user";
            if (opp) {
                if (semanticUser) {
                    if (variant === "front")
                        return pick("targetFront", "targetFront", "target", "target");
                    if (variant === "back")
                        return pick("targetBack", "targetBack", "target", "target");
                    return ui % 2 === 0 ? pick("targetBack", "targetBack", "target", "target") : pick("targetFront", "targetFront", "target", "target");
                }
                if (variant === "front")
                    return pick("userFront", "userFront", "user", "user");
                if (variant === "back")
                    return pick("userBack", "userBack", "user", "user");
                return ti % 2 === 0 ? pick("userBack", "userBack", "user", "user") : pick("userFront", "userFront", "user", "user");
            }
            if (semanticUser) {
                if (variant === "front")
                    return pick("userFront", "userFront", "user", "user");
                if (variant === "back")
                    return pick("userBack", "userBack", "user", "user");
                return ui % 2 === 0 ? pick("userBack", "userBack", "user", "user") : pick("userFront", "userFront", "user", "user");
            }
            if (variant === "front")
                return pick("targetFront", "targetFront", "target", "target");
            if (variant === "back")
                return pick("targetBack", "targetBack", "target", "target");
            return ti % 2 === 0 ? pick("targetBack", "targetBack", "target", "target") : pick("targetFront", "targetFront", "target", "target");
        };
        switch (source) {
            case "battler-user-front": return actual("user", "front");
            case "battler-user-back": return actual("user", "back");
            case "battler-user-opp": return actual("user", ui % 2 === 0 ? "front" : "back");
            case "battler-user": return actual("user", "");
            case "battler-target-front": return actual("target", "front");
            case "battler-target-back": return actual("target", "back");
            case "battler-target-opp": return actual("target", ti % 2 === 0 ? "front" : "back");
            case "battler-target": return actual("target", "");
            default: return null;
        }
    }
    specialBattlerImage(source) { var _a; return ((_a = this.specialBattlerBundle(source)) === null || _a === void 0 ? void 0 : _a.image) || null; }
    drawScreenEvents(width, height) {
        var _a, _b;
        const c = this.ctx;
        for (const ev of ((_a = this.animation) === null || _a === void 0 ? void 0 : _a.events) || []) {
            const type = String(ev.type || "");
            const start = Number(ev.frame || 0), dur = Math.max(1, Number(ev.duration || 1));
            if (this.frame < start || this.frame > start + dur)
                continue;
            if (type === "screen_black_envelope" || type === "screen_white_envelope") {
                const local = this.frame - start, fi = Math.max(1, Number(ev.fadeIn || 1)), hold = Math.max(0, Number(ev.hold || 0)), fo = Math.max(1, Number(ev.fadeOut || Math.max(1, dur - fi - hold)));
                let alpha = 1;
                if (local < fi)
                    alpha = clamp(local / fi, 0, 1);
                else if (local > fi + hold)
                    alpha = clamp(1 - (local - fi - hold) / fo, 0, 1);
                c.save();
                c.globalAlpha = alpha;
                c.fillStyle = type === "screen_black_envelope" ? "#000" : "#fff";
                c.fillRect(0, 0, width, height);
                c.restore();
                continue;
            }
            if (!["screen_flash", "flash", "darken"].includes(type))
                continue;
            const t = 1 - (this.frame - start) / dur, col = ev.color || [255, 255, 255, 255], alpha = (Number((_b = col[3]) !== null && _b !== void 0 ? _b : 255) / 255) * clamp(t, 0, 1);
            c.save();
            c.globalAlpha = alpha;
            c.fillStyle = `rgb(${Number(col[0] || 0)},${Number(col[1] || 0)},${Number(col[2] || 0)})`;
            c.fillRect(0, 0, width, height);
            c.restore();
        }
    }
    drawPath(o, accent) { if (!o)
        return; const c = this.ctx, ks = sortPositionKeys(o); if (!ks.length)
        return; c.save(); c.strokeStyle = "rgba(126,153,255,.62)"; c.lineWidth = 1.3; c.setLineDash([5, 4]); c.beginPath(); ks.forEach((k, i) => { const p = this.resolvePoint(k.point); i ? c.lineTo(p.x, p.y) : c.moveTo(p.x, p.y); }); c.stroke(); c.restore(); for (const k of ks) {
        const p = this.resolvePoint(k.point), act = Math.round(this.frame) === k.frame, s = act ? 7 : 5;
        c.save();
        c.translate(p.x, p.y);
        c.rotate(Math.PI / 4);
        c.fillStyle = act ? "#fff" : accent;
        c.strokeStyle = "rgba(0,0,0,.75)";
        c.fillRect(-s / 2, -s / 2, s, s);
        c.strokeRect(-s / 2, -s / 2, s, s);
        c.restore();
    } }
    eventLogical(e) { if (!this.lastTransform)
        this.resizeCanvas(); const r = this.canvas.getBoundingClientRect(), { scale, offsetX, offsetY } = this.lastTransform; return { x: (e.clientX - r.left - offsetX) / scale, y: (e.clientY - r.top - offsetY) / scale }; }
    hitObject(p) { for (let i = this.hitShapes.length - 1; i >= 0; i--) {
        const h = this.hitShapes[i];
        if (!h.objectId)
            continue;
        if (Math.abs(p.x - h.x) <= h.w / 2 + 10 && Math.abs(p.y - h.y) <= h.h / 2 + 10)
            return h;
    } return null; }
    nearestSelectedKey(p) { const o = getAnimatable(this.animation, this.selectedObjectId); if (!o || o.type === "camera")
        return null; let n = null, d = Infinity; for (const k of sortPositionKeys(o)) {
        const q = this.resolvePoint(k.point), dd = Math.hypot(p.x - q.x, p.y - q.y);
        if (dd < 11 && dd < d) {
            n = k;
            d = dd;
        }
    } return n; }
    pointerDown(e) { var _a, _b, _c, _d, _e, _f; if (!this.animation || this.playing)
        return; const p = this.eventLogical(e), key = this.nearestSelectedKey(p); if (e.button === 0 && key) {
        (_b = (_a = this.callbacks).onSelectKey) === null || _b === void 0 ? void 0 : _b.call(_a, this.selectedObjectId, key.id, key.frame);
        return;
    } const hit = this.hitObject(p); if (!hit)
        return; if (hit.objectId !== this.selectedObjectId)
        (_d = (_c = this.callbacks).onSelectObject) === null || _d === void 0 ? void 0 : _d.call(_c, hit.objectId); const o = getAnimatable(this.animation, hit.objectId); if (!o)
        return; if (e.button === 2) {
        this.dragging = "rotate";
        this.editFrame = Math.round(this.frame);
        this.dragStart = { p, rotation: sampleValue(o, "rotation", this.frame, 0), center: this.samplePosition(o), objectId: o.id };
    }
    else if (e.button === 0) {
        this.dragging = "move";
        this.editFrame = Math.round(this.frame);
        this.dragStart = { objectId: o.id };
    }
    else
        return; e.preventDefault(); (_f = (_e = this.canvas).setPointerCapture) === null || _f === void 0 ? void 0 : _f.call(_e, e.pointerId); }
    pointerMove(e) { var _a, _b, _c, _d; if (!this.dragging || !this.animation || !this.dragStart)
        return; const o = getAnimatable(this.animation, this.dragStart.objectId); if (!o)
        return; const p = this.eventLogical(e), { width, height } = this.logicalSize(); if (this.dragging === "move")
        (_b = (_a = this.callbacks).onMove) === null || _b === void 0 ? void 0 : _b.call(_a, { objectId: o.id, frame: this.editFrame, x: clamp(p.x, 0, width), y: clamp(p.y, 0, height) });
    else {
        const cc = this.dragStart.center, a0 = Math.atan2(this.dragStart.p.y - cc.y, this.dragStart.p.x - cc.x), a1 = Math.atan2(p.y - cc.y, p.x - cc.x);
        (_d = (_c = this.callbacks).onRotate) === null || _d === void 0 ? void 0 : _d.call(_c, o.id, this.dragStart.rotation - (a1 - a0) * 180 / Math.PI);
    } }
    pointerUp() { var _a, _b; if (!this.dragging)
        return; this.dragging = null; this.dragStart = null; (_b = (_a = this.callbacks).onEditEnd) === null || _b === void 0 ? void 0 : _b.call(_a); }
    wheel(e) { var _a, _b, _c, _d; if (!this.animation || this.playing)
        return; const p = this.eventLogical(e), hit = this.hitObject(p); if (!hit)
        return; e.preventDefault(); if (hit.objectId !== this.selectedObjectId)
        (_b = (_a = this.callbacks).onSelectObject) === null || _b === void 0 ? void 0 : _b.call(_a, hit.objectId); (_d = (_c = this.callbacks).onScale) === null || _d === void 0 ? void 0 : _d.call(_c, hit.objectId, e.deltaY < 0 ? 5 : -5); }
}
