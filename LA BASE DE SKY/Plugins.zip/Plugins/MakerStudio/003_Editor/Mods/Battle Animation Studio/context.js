import { CONTEXT_FILE, clampNumber } from "./model.js";
export function fallbackBattleContext(width = 512, height = 384, source = "default") {
    const w = clampNumber(width, 160, 4096, 512), h = clampNumber(height, 120, 4096, 384);
    // Match Essentials 21.1 Battle::Scene.pbBattlerPosition exactly.
    // These are not percentages: PLAYER_BASE_X is fixed at 128, while the
    // opposite side and both Y coordinates are derived from the active screen.
    const ux = 128, uy = h - 80, tx = w - 128, ty = (h * 3 / 4) - 112;
    return { version: 4, source, captureKind: "fallback", capturedAt: null, sceneClass: "Battle::Scene", width: w, height: h, graphicsWidth: w, graphicsHeight: h, settingsWidth: w, settingsHeight: h, userIndex: 0, targetIndex: 1, sideSizes: { user: 1, target: 1 },
        user: { x: ux, y: uy, focusX: ux, focusY: uy - 40, zoomX: 1, zoomY: 1, z: 100, ox: 0, oy: 0, bitmapWidth: 0, bitmapHeight: 0, tone: null, color: null },
        target: { x: tx, y: ty, focusX: tx, focusY: ty - 40, zoomX: 1, zoomY: 1, z: 100, ox: 0, oy: 0, bitmapWidth: 0, bitmapHeight: 0, tone: null, color: null },
        scriptUser: { x: ux, y: uy }, scriptTarget: { x: tx, y: ty },
        bases: { user: { x: ux, y: uy, width: w * .34, height: h * .12, zoomX: 1, zoomY: 1 }, target: { x: tx, y: ty, width: w * .27, height: h * .10, zoomX: 1, zoomY: 1 } }, raw: null };
}
function num(v, f) { const n = Number(v); return Number.isFinite(n) ? n : f; }
function normalizeSprite(s, f) { var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l; if (!s || typeof s !== "object")
    return Object.assign({}, f); return { x: num(s.x, f.x), y: num(s.y, f.y), focusX: num((_a = s.focus_x) !== null && _a !== void 0 ? _a : s.focusX, f.focusX), focusY: num((_b = s.focus_y) !== null && _b !== void 0 ? _b : s.focusY, f.focusY), zoomX: num((_c = s.zoom_x) !== null && _c !== void 0 ? _c : s.zoomX, 1), zoomY: num((_d = s.zoom_y) !== null && _d !== void 0 ? _d : s.zoomY, 1), z: num(s.z, (_e = f.z) !== null && _e !== void 0 ? _e : 100), ox: num(s.ox, 0), oy: num(s.oy, 0), bitmapWidth: num((_f = s.bitmap_width) !== null && _f !== void 0 ? _f : s.bitmapWidth, 0), bitmapHeight: num((_g = s.bitmap_height) !== null && _g !== void 0 ? _g : s.bitmapHeight, 0), visible: s.visible !== false, mirror: !!s.mirror, angle: num(s.angle, 0), tone: (_j = (_h = s.tone) !== null && _h !== void 0 ? _h : f.tone) !== null && _j !== void 0 ? _j : null, color: (_l = (_k = s.color) !== null && _k !== void 0 ? _k : f.color) !== null && _l !== void 0 ? _l : null, species: String(s.species || s.species_id || s.speciesId || f.species || "") }; }
function normalizeBase(s, f) { var _a, _b, _c, _d; if (!s || typeof s !== "object")
    return Object.assign({}, f); return { x: num(s.x, f.x), y: num(s.y, f.y), width: num((_a = s.bitmap_width) !== null && _a !== void 0 ? _a : s.bitmapWidth, f.width), height: num((_b = s.bitmap_height) !== null && _b !== void 0 ? _b : s.bitmapHeight, f.height), zoomX: num((_c = s.zoom_x) !== null && _c !== void 0 ? _c : s.zoomX, 1), zoomY: num((_d = s.zoom_y) !== null && _d !== void 0 ? _d : s.zoomY, 1), ox: num(s.ox, 0), oy: num(s.oy, 0), visible: s.visible !== false }; }
export function normalizeRuntimeContext(raw) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v;
    if (!raw || typeof raw !== "object")
        return null;
    const width = clampNumber((_c = (_b = (_a = raw.width) !== null && _a !== void 0 ? _a : raw.detected_width) !== null && _b !== void 0 ? _b : raw.graphics_width) !== null && _c !== void 0 ? _c : raw.settings_width, 160, 4096, 512), height = clampNumber((_f = (_e = (_d = raw.height) !== null && _d !== void 0 ? _d : raw.detected_height) !== null && _e !== void 0 ? _e : raw.graphics_height) !== null && _f !== void 0 ? _f : raw.settings_height, 120, 4096, 384), fb = fallbackBattleContext(width, height, "runtime");
    const bs = Array.isArray(raw.battlers) ? raw.battlers : [], ui = Number.isInteger(Number(raw.user_index)) ? Number(raw.user_index) : 0, ti = Number.isInteger(Number(raw.target_index)) ? Number(raw.target_index) : 1;
    const ur = bs.find(b => Number(b.index) === ui) || raw.user, tr = bs.find(b => Number(b.index) === ti) || raw.target;
    const usp = raw.user_battler_position || ((_g = raw.script_positions) === null || _g === void 0 ? void 0 : _g.user) || [fb.user.x, fb.user.y], tsp = raw.target_battler_position || ((_h = raw.script_positions) === null || _h === void 0 ? void 0 : _h.target) || [fb.target.x, fb.target.y];
    const user = normalizeSprite(ur, fb.user), target = normalizeSprite(tr, fb.target);
    // Match New Animation Editor's focal point: battler X and Y minus half bitmap height.
    // Runtime captures may provide a more exact focus (e.g. animated sprite plugins); keep it when present.
    if (!(ur && (ur.focus_y != null || ur.focusY != null)) && user.bitmapHeight > 0)
        user.focusY = user.y - user.bitmapHeight / 2;
    if (!(tr && (tr.focus_y != null || tr.focusY != null)) && target.bitmapHeight > 0)
        target.focusY = target.y - target.bitmapHeight / 2;
    return { version: Number(raw.version || 3), source: "runtime", captureKind: raw.capture_kind || raw.captureKind || "runtime", capturedAt: (_k = (_j = raw.captured_at) !== null && _j !== void 0 ? _j : raw.capturedAt) !== null && _k !== void 0 ? _k : null, sceneClass: raw.scene_class || raw.sceneClass || "Battle::Scene", width, height,
        graphicsWidth: num(raw.graphics_width, width), graphicsHeight: num(raw.graphics_height, height), settingsWidth: num(raw.settings_width, width), settingsHeight: num(raw.settings_height, height),
        userIndex: ui, targetIndex: ti, sideSizes: { user: Number((_o = (_l = raw.user_side_size) !== null && _l !== void 0 ? _l : (_m = raw.side_sizes) === null || _m === void 0 ? void 0 : _m.user) !== null && _o !== void 0 ? _o : 1), target: Number((_r = (_p = raw.target_side_size) !== null && _p !== void 0 ? _p : (_q = raw.side_sizes) === null || _q === void 0 ? void 0 : _q.target) !== null && _r !== void 0 ? _r : 1) }, user, target,
        scriptUser: { x: num(usp[0], fb.user.x), y: num(usp[1], fb.user.y) }, scriptTarget: { x: num(tsp[0], fb.target.x), y: num(tsp[1], fb.target.y) },
        bases: { user: normalizeBase((_t = (_s = raw.bases) === null || _s === void 0 ? void 0 : _s.user) !== null && _t !== void 0 ? _t : raw.base_0, fb.bases.user), target: normalizeBase((_v = (_u = raw.bases) === null || _u === void 0 ? void 0 : _u.target) !== null && _v !== void 0 ? _v : raw.base_1, fb.bases.target) }, raw };
}
export async function readRuntimeContext(ctx) { var _a, _b; try {
    if (!(await ctx.fs.projectExists(CONTEXT_FILE)))
        return null;
    return normalizeRuntimeContext(JSON.parse(await ctx.fs.readProjectFile(CONTEXT_FILE)));
}
catch (e) {
    (_b = (_a = ctx.log) === null || _a === void 0 ? void 0 : _a.warn) === null || _b === void 0 ? void 0 : _b.call(_a, "Battle Animation Studio: invalid battle context snapshot", e);
    return null;
} }
export function effectiveBattleContext(preview, runtime, projectDetected = null) {
    var _a, _b, _c, _d;
    const mode = (preview === null || preview === void 0 ? void 0 : preview.contextMode) || "auto";
    // A static project scan is more trustworthy than an early legacy-sized
    // plugin_load capture. Runtime battle captures remain the final authority.
    let autoRuntime = runtime;
    if (mode === "auto" && runtime && projectDetected) {
        const early = /^(plugin_load|game_load|static)$/i.test(String(runtime.captureKind || ""));
        const legacy = Number(runtime.width) === 512 && Number(runtime.height) === 384;
        const projectDiff = Number(projectDetected.width) !== Number(runtime.width) || Number(projectDetected.height) !== Number(runtime.height);
        if (early && legacy && projectDiff)
            autoRuntime = null;
    }
    const chosenRuntime = mode === "auto" ? autoRuntime : runtime;
    if ((mode === "auto" || mode === "runtime" || mode === "script") && chosenRuntime) {
        if (mode === "script") {
            const c = (typeof structuredClone === "function") ? structuredClone(chosenRuntime) : JSON.parse(JSON.stringify(chosenRuntime));
            c.source = "script";
            c.user = Object.assign(Object.assign({}, c.user), { x: c.scriptUser.x, y: c.scriptUser.y, focusX: (_a = c.user.focusX) !== null && _a !== void 0 ? _a : c.scriptUser.x, focusY: (_b = c.user.focusY) !== null && _b !== void 0 ? _b : (c.scriptUser.y - c.user.bitmapHeight / 2) });
            c.target = Object.assign(Object.assign({}, c.target), { x: c.scriptTarget.x, y: c.scriptTarget.y, focusX: (_c = c.target.focusX) !== null && _c !== void 0 ? _c : c.scriptTarget.x, focusY: (_d = c.target.focusY) !== null && _d !== void 0 ? _d : (c.scriptTarget.y - c.target.bitmapHeight / 2) });
            return c;
        }
        const c = (typeof structuredClone === "function") ? structuredClone(chosenRuntime) : JSON.parse(JSON.stringify(chosenRuntime));
        c.source = mode === "auto" ? "auto" : chosenRuntime.source;
        return c;
    }
    if (mode === "auto" && projectDetected) {
        const c = (typeof structuredClone === "function") ? structuredClone(projectDetected) : JSON.parse(JSON.stringify(projectDetected));
        c.source = "project";
        return c;
    }
    if (mode === "manual") {
        const m = (preview === null || preview === void 0 ? void 0 : preview.manualContext) || {}, b = fallbackBattleContext(m.width || 512, m.height || 384, "manual");
        b.user = Object.assign(Object.assign({}, b.user), (m.user || {}));
        b.target = Object.assign(Object.assign({}, b.target), (m.target || {}));
        return b;
    }
    if (runtime)
        return runtime;
    if (projectDetected)
        return projectDetected;
    return fallbackBattleContext(512, 384, "default");
}
