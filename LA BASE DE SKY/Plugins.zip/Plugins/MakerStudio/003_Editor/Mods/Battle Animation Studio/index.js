import { SAVE_DIR, SAVE_FILE, CODE_CAPTURE_FILE, COMPILED_FILE, GAME_RUNTIME_DIR, GAME_RUNTIME_FILE, createAnimation, createProject, createProjectile, getAllClips, getEffectsTrack, getAnimatable, getAllAnimatables, getBattlerTrack, getCameraTrack, normalizeProject, uid, positionKeyAt, getPositionKeyById, setPositionKey, movePositionKey, removePositionKey, clampNumber, sortPositionKeys, setValueKey, setVisibleKey, sampleValue, sampleVisible, cloneClipForLibrary, instantiateReusableClip } from "./model.js";
import { BattlePreview } from "./preview.js";
import { scanAnimationAssets, scanBattlerAssets, scanUiAssets, loadProjectImageUrl, loadAbsoluteImageUrl, readAbsoluteText, readAbsoluteBinary, detectExternalGameRoot, resolveExternalGraphicPath, resolveLegacyGraphic, compactProjectPath, scanProjectFiles, scanAbsoluteFiles, absoluteProjectPath, scanBattlebackAssets } from "./assets.js";
import { readRuntimeContext, effectiveBattleContext } from "./context.js";
import { detectProjectBattleContext, loadProjectMoveCatalog, loadBattlerRenderingInfo } from "./project_tools.js";
import { STYLES } from "./styles.js";
import { parsePbsFile, animationFromPbsSection, animationFromCode, animationFromCodeCapture, animationFromLegacy, discoverCodeMetadata, discoverCinematicControllerMappings } from "./importers.js";
import { parseLegacyAnimationsRxdata, parseMove2AnimDat, buildLegacyCatalog } from "./legacy_rxdata.js";
import { collectAnimationGraphics, planGraphicItems, importGraphicIntoProject, localizeGraphic, basename as gfxBasename, stemOf as gfxStemOf } from "./graphics_localize.js";
const PANEL_ID = "battle-animation-studio.main";
const RUNTIME_PLUGIN_DIR = "Plugins/Battle Animation Studio Preview Bridge";
const TIMELINE_LABEL_WIDTH = 188;
export function activate(ctx) {
    ctx.log.info("Battle Animation Studio 1.2.0 activated");
    ctx.ui.registerPanel({
        id: PANEL_ID,
        title: "Battle Animation Studio",
        icon: "video",
        defaultPosition: "right",
        defaultSize: { width: 1500, height: 960 },
        showInMenu: false,
        render(host) { return renderStudio(ctx, host); }
    });
    ctx.menu.registerMenuItem({ menu: "Mods", label: "Battle Animation Studio", icon: "video", shortcut: "Ctrl+Shift+A", handler: () => ctx.ui.openPanel(PANEL_ID) });
    ctx.commands.register("battle-animation-studio.open", () => ctx.ui.openPanel(PANEL_ID));
}
function renderStudio(ctx, host) {
    var _a;
    let project = createProject();
    let activeAnimationId = ((_a = project.animations[0]) === null || _a === void 0 ? void 0 : _a.id) || null;
    let selectedObjectId = "battler_user";
    let selectedKeyId = null;
    let frame = 0;
    let playing = false;
    let lastTime = 0;
    let raf = 0;
    let preview = null;
    let runtimeContext = null;
    let projectScriptContext = null;
    let moveCatalog = new Map();
    const codeSourceCache = new Map();
    let contextSignature = "";
    let contextPoll = 0;
    let animationAssets = null;
    let loadedClipPaths = new Map();
    let loadedBattlerSignature = "";
    let sourceStatus = { vanilla: 0, pbs: false, code: false, assets: { new: 0, legacy: 0, code: 0 } };
    let statusTimer = 0;
    let viewMode = "library";
    let libraryMode = "moves";
    let librarySelectedMove = null;
    let librarySelectedAnimationId = null;
    let battlebackCatalog = null;
    const audioCache = new Map();
    const activeAudios = new Set();
    const warnedAudio = new Set();
    let audioContext = null;
    host.innerHTML = "";
    const style = document.createElement("style");
    style.textContent = STYLES;
    host.appendChild(style);
    const root = document.createElement("div");
    root.className = "bas-root";
    root.innerHTML = shellHtml();
    host.appendChild(root);
    host.tabIndex = 0;
    const activeAnimation = () => project.animations.find((a) => a.id === activeAnimationId) || project.animations[0] || null;
    const selectedObject = () => getAnimatable(activeAnimation(), selectedObjectId);
    const selectedKey = () => selectedObject() ? getPositionKeyById(selectedObject(), selectedKeyId) : null;
    let undoStack = [], redoStack = [], lastUndoSig = "";
    const stateSnapshot = () => JSON.stringify({ project, activeAnimationId, selectedObjectId, selectedKeyId, frame, viewMode, libraryMode, librarySelectedMove, librarySelectedAnimationId });
    function pushUndo(label = "edit") {
        const snap = stateSnapshot();
        if (snap === lastUndoSig) return;
        undoStack.push(snap);
        if (undoStack.length > 80) undoStack.shift();
        redoStack = [];
        lastUndoSig = snap;
        setStatus(`Undo listo: ${label}`);
    }
    function restoreSnapshot(snap, targetStack) {
        if (!snap) return;
        targetStack.push(stateSnapshot());
        const data = JSON.parse(snap);
        project = normalizeProject(data.project || createProject());
        activeAnimationId = data.activeAnimationId || (project.animations[0] && project.animations[0].id) || null;
        selectedObjectId = data.selectedObjectId || "battler_user";
        selectedKeyId = data.selectedKeyId || null;
        frame = Number(data.frame || 0);
        viewMode = data.viewMode || viewMode;
        libraryMode = data.libraryMode || libraryMode;
        librarySelectedMove = data.librarySelectedMove || null;
        librarySelectedAnimationId = data.librarySelectedAnimationId || null;
        lastUndoSig = stateSnapshot();
        refreshAll();
        ensureSceneImages();
        ensureBattlers(false);
        ensureAllClipAssets(true);
        preview.setState(activeAnimation(), selectedObjectId, frame, { playing: false });
    }
    function undo() { const snap = undoStack.pop(); if (!snap) return toast("No hay nada que deshacer", "warn"); restoreSnapshot(snap, redoStack); }
    function redo() { const snap = redoStack.pop(); if (!snap) return toast("No hay nada que rehacer", "warn"); restoreSnapshot(snap, undoStack); }
    preview = new BattlePreview(root.querySelector('[data-role="preview"]'), {
        showPath: () => project.preview.showPath !== false,
        onSelectObject: (objectId) => selectObject(objectId),
        onSelectKey: (objectId, keyId, keyFrame) => {
            selectObject(objectId, { renderTimelineNow: false });
            selectedKeyId = keyId;
            setFrame(keyFrame, { renderTimelineNow: false, renderPropertiesNow: true });
        },
        onMove: ({ objectId, frame: keyFrame, x, y }) => {
            const object = getAnimatable(activeAnimation(), objectId);
            if (!object)
                return;
            const existing = positionKeyAt(object, keyFrame);
            if (project.preview.autoKey === false && !existing) {
                setStatus("Auto Key apagado · pulsa K o doble clic en el timeline para crear un key");
                return;
            }
            let pointData = { x, y };
            if (object.type === "battler") {
                const base = preview.baseBattlerPosition(object.side);
                pointData = { anchor: `${object.side}_battler`, x: 0, y: 0, offsetX: x - base.x, offsetY: y - base.y };
            }
            const key = setPositionKey(object, keyFrame, pointData, "ease_both", pointData.anchor || "screen");
            selectedObjectId = objectId;
            selectedKeyId = key.id;
            frame = keyFrame;
            updateFrameUi();
            updatePlayhead();
            updateTimelineFrameState();
            preview.setState(activeAnimation(), selectedObjectId, frame, { playing: false });
            const xInput = root.querySelector('[data-prop="x"]');
            const yInput = root.querySelector('[data-prop="y"]');
            if (xInput)
                xInput.value = String(Math.round(x));
            if (yInput)
                yInput.value = String(Math.round(y));
        },
        onRotate: (objectId, value) => {
            const object = getAnimatable(activeAnimation(), objectId);
            if (!object)
                return;
            setValueKey(object, "rotation", Math.round(frame), Math.round(value * 10) / 10);
            selectedObjectId = objectId;
            renderProperties();
            preview.setState(activeAnimation(), selectedObjectId, frame, { playing: false });
        },
        onScale: (objectId, delta) => {
            const object = getAnimatable(activeAnimation(), objectId);
            if (!object)
                return;
            const value = clampNumber(sampleValue(object, "size", frame, 100) + delta, 5, 800, 100);
            setValueKey(object, "size", Math.round(frame), value);
            selectedObjectId = objectId;
            renderProperties();
            preview.setState(activeAnimation(), selectedObjectId, frame, { playing: false });
        },
        onEditEnd: () => { renderTimeline(); renderProperties(); }
    });
    wireStaticEvents();
    wireSplitters();
    host.addEventListener("keydown", keyboard);
    root.addEventListener("focusin", (e) => {
        const t = e.target;
        if (t && /^(INPUT|SELECT|TEXTAREA)$/i.test(t.tagName || "")) pushUndo("cambio de propiedad");
    });
    root.addEventListener("pointerdown", (e) => {
        const t = e.target;
        if (t && (t.closest && (t.closest("button") || t.closest("canvas") || t.closest("[data-action]") || t.closest("[data-key-id]")))) pushUndo("edición visual");
    }, true);
    loadProject();
    contextPoll = window.setInterval(() => loadRuntimeContext({ silent: true, onlyIfChanged: true }), 1500);
    return () => {
        var _a, _b, _c;
        cancelAnimationFrame(raf);
        clearTimeout(statusTimer);
        clearInterval(contextPoll);
        stopAllPreviewAudio();
        for (const data of audioCache.values())
            if ((_b = (_a = data === null || data === void 0 ? void 0 : data.url) === null || _a === void 0 ? void 0 : _a.startsWith) === null || _b === void 0 ? void 0 : _b.call(_a, "blob:"))
                URL.revokeObjectURL(data.url);
        try {
            (_c = audioContext === null || audioContext === void 0 ? void 0 : audioContext.close) === null || _c === void 0 ? void 0 : _c.call(audioContext);
        }
        catch (_d) { }
        preview === null || preview === void 0 ? void 0 : preview.destroy();
        host.removeEventListener("keydown", keyboard);
    };
    function shellHtml() {
        return `
      <section class="bas-library-page" data-view="library">
        <div class="bas-library-header">
          <div><h2>Battle Animation Studio</h2><p>Elige una animación o impórtala. La edición se abre después.</p><small class="bas-storage-line">Editable: ${SAVE_FILE} · Juego: ${COMPILED_FILE}</small></div>
          <div class="bas-library-actions">
            <button class="bas-button primary" data-lib-action="new">＋ Nueva</button>
            <button class="bas-button" data-lib-action="import-pbs">Importar PBS</button>
            <button class="bas-button" data-lib-action="import-vanilla">Importar RXDATA</button>
            <button class="bas-button" data-lib-action="import-code">Importar Ruby / Code</button>
            <button class="bas-button" data-lib-action="import-capture">Importar captura Code</button>
            <button class="bas-button" data-lib-action="import-package">Importar .animpack</button>
            <button class="bas-button" data-lib-action="reload">↻ Recargar</button>
          </div>
        </div>
        <div class="bas-library-toolbar">
          <div class="bas-browser-tabs"><button data-lib-tab="moves">Moves <b data-lib-count="moves">0</b></button><button data-lib-tab="common">Common <b data-lib-count="common">0</b></button></div>
          <input class="bas-input" data-role="library-search" placeholder="Buscar por nombre, Move ID, animación, versión o fuente…">
        </div>
        <div class="bas-library-main">
          <div class="bas-library-moves" data-role="library-moves"></div>
          <div class="bas-library-versions" data-role="library-versions"></div>
        </div>
        <div class="bas-library-footer">
          <span data-role="library-selection">Selecciona un movimiento y una versión.</span>
          <div class="spacer"></div>
          <button class="bas-button danger" data-lib-action="delete" disabled>🗑 Eliminar animación</button>
          <button class="bas-button primary" data-lib-action="open" disabled>Abrir en editor</button>
        </div>
      </section>

      <section class="bas-editor-page hidden" data-view="editor">
        <div class="bas-toolbar">
          <button class="bas-button" data-action="library">← Biblioteca</button>
          <button class="bas-button primary" data-action="save">Guardar</button>
          <button class="bas-button" data-action="reload">Recargar</button>
          <span class="bas-toolbar-sep"></span>
          <button class="bas-button" data-action="scene">Escena</button>
          <button class="bas-button" data-action="battlers">Battlers</button>
          <button class="bas-button" data-action="context">Contexto</button>
          <button class="bas-button" data-action="code-context">Code</button>
          <button class="bas-button" data-action="presets">＋ Acciones</button>
          <button class="bas-button" data-action="focus-mode">Focus</button>
          <button class="bas-button" data-action="export">Exportar al juego</button>
          <div class="spacer"></div>
          <div class="bas-context-badge" data-role="context-badge">Contexto…</div>
          <div class="bas-title" data-role="title"></div>
          <div class="bas-status" data-role="status"></div>
        </div>

        <div class="bas-workspace">
          <aside class="bas-side bas-side-left">
            <div class="bas-section grow"><div class="bas-section-head"><div class="bas-section-title">Elementos</div><button class="bas-icon-button" title="Añadir efecto" data-action="add-projectile">＋</button></div><div class="bas-scroll-list" data-role="elements"></div></div>
            <div class="bas-section compact"><div class="bas-section-title">Assets</div><div class="bas-source-summary" data-role="source-summary"></div></div>
          </aside>
          <div class="bas-splitter vertical" data-splitter="left" title="Arrastra para cambiar el tamaño"></div>

          <section class="bas-preview-wrap">
            <canvas class="bas-preview" data-role="preview"></canvas>
            <div class="bas-preview-hud"><span>Arrastra para mover · rueda = tamaño · clic derecho + arrastre = rotación · Space = reproducir</span></div>
          </section>

          <div class="bas-splitter vertical" data-splitter="right" title="Arrastra para cambiar el tamaño"></div>
          <aside class="bas-side bas-side-right"><div class="bas-section bas-properties-section"><div class="bas-section-title">Objeto seleccionado</div><div data-role="properties"></div></div></aside>
        </div>

        <div class="bas-splitter horizontal" data-splitter="timeline" title="Arrastra para ampliar el timeline"></div>
        <section class="bas-timeline">
          <div class="bas-transport">
            <button class="bas-record active" data-action="autokey"><span>●</span> Auto Key</button>
            <span class="bas-toolbar-sep"></span>
            <button class="bas-button icon" data-action="rewind">|◀</button>
            <button class="bas-button icon" data-action="prev-key">◆◀</button>
            <button class="bas-button icon play" data-action="play">▶</button>
            <button class="bas-button icon" data-action="next-key">▶◆</button>
            <button class="bas-button icon active-toggle" data-action="loop">↻</button>
            <span class="bas-toolbar-sep"></span>
            <button class="bas-button icon" data-action="prev-frame">◀ 1</button>
            <label class="bas-transport-field">Frame <input data-role="frame-input" type="number" min="0" step="1"></label>
            <button class="bas-button icon" data-action="next-frame">1 ▶</button>
            <input class="bas-frame-scrub" data-role="frame-scrub" type="range" min="0" max="30" value="0" step="1">
            <label class="bas-transport-field">Duración <input data-role="duration-input" type="number" min="1" max="9999" step="1"></label>
            <div class="spacer"></div>
            <label class="bas-transport-field zoom">Zoom <input data-role="timeline-zoom" type="range" min="8" max="46" step="2"></label>
          </div>
          <div class="bas-timeline-scroll" data-role="timeline-scroll"><div data-role="timeline-content"></div></div>
        </section>
      </section>`;
    }
    async function loadProject({ notify = false } = {}) {
        var _a, _b;
        stopPlayback(false);
        try {
            if (await ctx.fs.projectExists(SAVE_FILE))
                project = normalizeProject(JSON.parse(await ctx.fs.readProjectFile(SAVE_FILE)));
            else
                project = createProject();
        }
        catch (error) {
            ctx.log.error(error);
            project = createProject();
            toast("No se pudo leer animations.json; se abrió una biblioteca nueva", "warn");
        }
        activeAnimationId = ((_a = project.editor) === null || _a === void 0 ? void 0 : _a.lastAnimationId) && project.animations.some(a => a.id === project.editor.lastAnimationId)
            ? project.editor.lastAnimationId : (((_b = project.animations[0]) === null || _b === void 0 ? void 0 : _b.id) || null);
        selectedObjectId = "battler_user";
        selectedKeyId = null;
        frame = 0;
        applyLayout();
        await upgradeInstalledPreviewBridgeIfNeeded();
        await Promise.all([detectSources(), loadRuntimeContext({ silent: true }), detectStaticProjectContext(), loadMoveNames()]);
        showLibraryView();
        if (notify)
            toast(`Cargado: ${SAVE_FILE}`, "info");
    }
    async function saveProject() {
        try {
            await ctx.fs.projectMkdir(SAVE_DIR);
            project.version = 10;
            await ctx.fs.writeProjectFile(SAVE_FILE, JSON.stringify(project, null, 2));
            setStatus("Guardado");
            toast("Animaciones guardadas", "info");
        }
        catch (error) {
            ctx.log.error(error);
            toast("No se pudo guardar", "error");
        }
    }
    async function detectSources() {
        var _a, _b, _c, _d;
        try {
            sourceStatus.vanilla = (((_b = (_a = ctx.projectData).animations) === null || _b === void 0 ? void 0 : _b.call(_a)) || []).filter((r) => (r === null || r === void 0 ? void 0 : r.id) > 0 && (r === null || r === void 0 ? void 0 : r.name)).length;
        }
        catch (_e) {
            sourceStatus.vanilla = 0;
        }
        try {
            await ctx.fs.listProjectDir("PBS/Animations");
            sourceStatus.pbs = true;
        }
        catch (_f) {
            sourceStatus.pbs = false;
        }
        try {
            sourceStatus.code = (((_d = (_c = ctx.plugins).list) === null || _d === void 0 ? void 0 : _d.call(_c)) || []).some((p) => /battle\s*animations|battleanimations|new animation editor/i.test(p.name || ""));
        }
        catch (_g) {
            sourceStatus.code = false;
        }
        try {
            animationAssets = await scanAnimationAssets(ctx);
            sourceStatus.assets = { new: 0, legacy: 0, code: 0 };
            for (const asset of animationAssets)
                if (sourceStatus.assets[asset.source] !== undefined)
                    sourceStatus.assets[asset.source]++;
        }
        catch (error) {
            ctx.log.warn("Could not scan animation graphics", error);
            animationAssets = [];
        }
    }
    function refreshAll() {
        const animation = activeAnimation();
        if (!animation)
            return;
        frame = clampNumber(frame, 0, animation.duration, 0);
        root.querySelector('[data-role="title"]').textContent = animation.name;
        renderElements();
        renderSourceSummary();
        renderProperties();
        renderTimeline();
        updateTransportState();
        applyEffectiveContext();
        preview.setState(animation, selectedObjectId, frame, { playing });
    }
    function wireStaticEvents() {
        // Library is a real page, not a modal over the editor.
        root.querySelector('[data-lib-action="new"]').onclick = async () => {
            const name = await ctx.ui.showInputDialog({ title: "Nueva animación", message: "Nombre:", defaultValue: "New Animation" });
            if (!name)
                return;
            const animation = createAnimation(name);
            project.animations.push(animation);
            await saveProject();
            await activateAnimation(animation);
        };
        root.querySelector('[data-lib-action="import-pbs"]').onclick = openPbsImportDialog;
        root.querySelector('[data-lib-action="import-vanilla"]').onclick = openVanillaImportDialog;
        root.querySelector('[data-lib-action="import-code"]').onclick = openCodeImportDialog;
        root.querySelector('[data-lib-action="import-capture"]').onclick = openCodeCaptureImportDialog;
        root.querySelector('[data-lib-action="import-package"]').onclick = openPackageImportDialog;
        root.querySelector('[data-lib-action="reload"]').onclick = () => loadProject({ notify: true });
        root.querySelector('[data-lib-action="open"]').onclick = async () => {
            const a = project.animations.find(x => x.id === librarySelectedAnimationId);
            if (a)
                await activateAnimation(a);
        };
        root.querySelector('[data-lib-action="delete"]').onclick = async () => {
            var _a, _b;
            const i = project.animations.findIndex(x => x.id === librarySelectedAnimationId);
            if (i < 0)
                return;
            const a = project.animations[i];
            const ok = await ((_b = (_a = ctx.ui).showConfirmDialog) === null || _b === void 0 ? void 0 : _b.call(_a, { title: "Eliminar animación", message: `¿Eliminar ${a.name} de la biblioteca?` }));
            if (ok === false)
                return;
            project.animations.splice(i, 1);
            librarySelectedAnimationId = null;
            librarySelectedMove = null;
            await saveProject();
            renderLibraryPage();
        };
        root.querySelectorAll('[data-lib-tab]').forEach(b => b.onclick = () => { libraryMode = b.dataset.libTab; librarySelectedMove = null; librarySelectedAnimationId = null; renderLibraryPage(); });
        root.querySelector('[data-role="library-search"]').oninput = renderLibraryPage;
        root.querySelector('[data-action="library"]').onclick = showLibraryView;
        root.querySelector('[data-action="save"]').onclick = saveProject;
        root.querySelector('[data-action="reload"]').onclick = () => loadProject({ notify: true });
        root.querySelector('[data-action="scene"]').onclick = openSceneDialog;
        root.querySelector('[data-action="battlers"]').onclick = openBattlerDialog;
        root.querySelector('[data-action="context"]').onclick = openContextDialog;
        root.querySelector('[data-action="code-context"]').onclick = openCodeContextDialog;
        root.querySelector('[data-action="presets"]').onclick = openPresetsDialog;
        root.querySelector('[data-action="focus-mode"]').onclick = toggleFocusMode;
        root.querySelector('[data-action="export"]').onclick = openExportDialog;
        root.querySelector('[data-action="add-projectile"]').onclick = addProjectile;
        root.querySelector('[data-action="autokey"]').onclick = () => { project.preview.autoKey = !project.preview.autoKey; updateTransportState(); };
        root.querySelector('[data-action="rewind"]').onclick = () => setFrame(0);
        root.querySelector('[data-action="prev-key"]').onclick = () => jumpKey(-1);
        root.querySelector('[data-action="play"]').onclick = togglePlay;
        root.querySelector('[data-action="next-key"]').onclick = () => jumpKey(1);
        root.querySelector('[data-action="loop"]').onclick = () => { project.preview.loop = !project.preview.loop; updateTransportState(); };
        root.querySelector('[data-action="prev-frame"]').onclick = () => setFrame(Math.round(frame) - 1);
        root.querySelector('[data-action="next-frame"]').onclick = () => setFrame(Math.round(frame) + 1);
        root.querySelector('[data-role="frame-input"]').oninput = (e) => setFrame(Number(e.target.value), { renderPropertiesNow: false });
        root.querySelector('[data-role="frame-input"]').onchange = () => renderProperties();
        const scrub = root.querySelector('[data-role="frame-scrub"]');
        scrub.oninput = (e) => setFrame(Number(e.target.value), { renderPropertiesNow: false });
        scrub.onchange = () => renderProperties();
        root.querySelector('[data-role="duration-input"]').onchange = (e) => {
            const a = activeAnimation();
            if (!a)
                return;
            a.duration = clampNumber(e.target.value, 1, 9999, a.duration);
            frame = Math.min(frame, a.duration);
            for (const object of getAllAnimatables(a))
                for (const key of sortPositionKeys(object))
                    key.frame = Math.min(a.duration, key.frame);
            renderTimeline();
            renderProperties();
            updateTransportState();
            preview.setState(a, selectedObjectId, frame, { playing: false });
        };
        root.querySelector('[data-role="timeline-zoom"]').oninput = (e) => { project.preview.layout.framePixels = clampNumber(e.target.value, 8, 46, 24); renderTimeline(); };
    }
    function wireSplitters() {
        for (const splitter of root.querySelectorAll("[data-splitter]")) {
            splitter.addEventListener("pointerdown", (event) => {
                event.preventDefault();
                const type = splitter.dataset.splitter;
                const startX = event.clientX, startY = event.clientY;
                const layout = project.preview.layout;
                const startLeft = layout.leftWidth, startRight = layout.rightWidth, startTimeline = layout.timelineHeight;
                const move = (e) => {
                    if (type === "left")
                        layout.leftWidth = clampNumber(startLeft + (e.clientX - startX), 150, 430, 220);
                    else if (type === "right")
                        layout.rightWidth = clampNumber(startRight - (e.clientX - startX), 260, 720, 400);
                    else
                        layout.timelineHeight = clampNumber(startTimeline - (e.clientY - startY), 220, Math.max(340, root.clientHeight * .70), 330);
                    applyLayout();
                };
                const up = () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); preview.draw(); };
                window.addEventListener("pointermove", move);
                window.addEventListener("pointerup", up);
            });
        }
    }
    function applyLayout() {
        const layout = project.preview.layout;
        root.style.setProperty("--left-w", `${clampNumber(layout.leftWidth, 150, 430, 220)}px`);
        root.style.setProperty("--right-w", `${clampNumber(layout.rightWidth, 260, 720, 400)}px`);
        root.style.setProperty("--timeline-h", `${clampNumber(layout.timelineHeight, 220, 760, 330)}px`);
    }
    function addProjectile() {
        const a = activeAnimation();
        const clip = createProjectile({ id: uid("clip"), name: `Projectile ${getAllClips(a).length + 1}` });
        clip.endFrame = Math.min(a.duration, 18);
        clip.positionKeys[clip.positionKeys.length - 1].frame = clip.endFrame;
        getEffectsTrack(a).clips.push(clip);
        selectedObjectId = clip.id;
        selectedKeyId = clip.positionKeys[0].id;
        frame = clip.positionKeys[0].frame;
        renderElements();
        renderProperties();
        renderTimeline();
        updateFrameUi();
        preview.setState(a, selectedObjectId, frame, { playing: false });
    }
    function selectObject(objectId, { renderTimelineNow = true } = {}) {
        const object = getAnimatable(activeAnimation(), objectId);
        if (!object)
            return;
        selectedObjectId = objectId;
        const keyAtFrame = positionKeyAt(object, Math.round(frame));
        selectedKeyId = (keyAtFrame === null || keyAtFrame === void 0 ? void 0 : keyAtFrame.id) || null;
        renderElements();
        renderProperties();
        if (renderTimelineNow)
            renderTimeline();
        else
            updateTimelineFrameState();
        preview.setState(activeAnimation(), selectedObjectId, frame, { playing: false });
        if (object.type !== "battler")
            ensureClipAsset(object);
    }
    function showLibraryView() {
        var _a, _b;
        stopPlayback(false);
        viewMode = "library";
        (_a = root.querySelector('[data-view="library"]')) === null || _a === void 0 ? void 0 : _a.classList.remove("hidden");
        (_b = root.querySelector('[data-view="editor"]')) === null || _b === void 0 ? void 0 : _b.classList.add("hidden");
        renderLibraryPage();
    }
    function showEditorView() {
        var _a, _b;
        viewMode = "editor";
        (_a = root.querySelector('[data-view="library"]')) === null || _a === void 0 ? void 0 : _a.classList.add("hidden");
        (_b = root.querySelector('[data-view="editor"]')) === null || _b === void 0 ? void 0 : _b.classList.remove("hidden");
    }
    function animationLibraryMaps() {
        const moves = new Map(), common = new Map();
        for (const a of project.animations) {
            const src = a.source || {}, isCommon = src.catalogType === "common", key = String(src.move || a.name || "Animation"), map = isCommon ? common : moves;
            if (!map.has(key))
                map.set(key, []);
            map.get(key).push(a);
        }
        const sorter = (a, b) => { var _a, _b, _c, _d; return Number((_a = a.source) === null || _a === void 0 ? void 0 : _a.opposing) - Number((_b = b.source) === null || _b === void 0 ? void 0 : _b.opposing) || Number(((_c = a.source) === null || _c === void 0 ? void 0 : _c.version) || 0) - Number(((_d = b.source) === null || _d === void 0 ? void 0 : _d.version) || 0) || String(a.name).localeCompare(String(b.name), undefined, { numeric: true, sensitivity: "base" }); };
        for (const m of [moves, common])
            for (const arr of m.values())
                arr.sort(sorter);
        return { moves, common };
    }
    function renderLibraryPage() {
        var _a, _b, _c, _d, _e;
        const { moves, common } = animationLibraryMaps(), map = libraryMode === "common" ? common : moves, q = (((_a = root.querySelector('[data-role="library-search"]')) === null || _a === void 0 ? void 0 : _a.value) || "").trim().toLowerCase();
        root.querySelectorAll('[data-lib-tab]').forEach(b => b.classList.toggle('active', b.dataset.libTab === libraryMode));
        const mc = root.querySelector('[data-lib-count="moves"]'), cc = root.querySelector('[data-lib-count="common"]');
        if (mc)
            mc.textContent = String(moves.size);
        if (cc)
            cc.textContent = String(common.size);
        const keys = [...map.keys()].sort((a, b) => { if (libraryMode === "common")
            return a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" }); const ia = moveInfo(a), ib = moveInfo(b); return ia.order - ib.order || ia.name.localeCompare(ib.name, undefined, { numeric: true, sensitivity: "base" }) || a.localeCompare(b); }).filter(k => { if (!q)
            return true; const info = moveInfo(k), arr = map.get(k) || [], hay = [k, info.name, ...arr.flatMap(a => { var _a, _b, _c, _d, _e, _f; return [a.name, (_a = a.source) === null || _a === void 0 ? void 0 : _a.type, (_b = a.source) === null || _b === void 0 ? void 0 : _b.path, (_c = a.source) === null || _c === void 0 ? void 0 : _c.className, (_d = a.source) === null || _d === void 0 ? void 0 : _d.behavior, (_e = a.source) === null || _e === void 0 ? void 0 : _e.sideContext, `v${((_f = a.source) === null || _f === void 0 ? void 0 : _f.version) || 0}`]; })].join(' ').toLowerCase(); return hay.includes(q); });
        if (!keys.includes(librarySelectedMove))
            librarySelectedMove = keys[0] || null;
        const names = root.querySelector('[data-role="library-moves"]'), versions = root.querySelector('[data-role="library-versions"]');
        names.innerHTML = '';
        versions.innerHTML = '';
        for (const k of keys) {
            const info = libraryMode === "moves" ? moveInfo(k) : { name: k, id: k };
            const row = document.createElement('button');
            row.className = `bas-library-move${k === librarySelectedMove ? ' active' : ''}`;
            row.innerHTML = `<span><strong>${escapeHtml(info.name || k)}</strong><small>${libraryMode === 'moves' ? escapeHtml(k) : 'Common'} · ${(map.get(k) || []).length} versión${(map.get(k) || []).length === 1 ? '' : 'es'}</small></span><b>›</b>`;
            row.onclick = () => { librarySelectedMove = k; librarySelectedAnimationId = null; renderLibraryPage(); };
            names.appendChild(row);
        }
        if (!keys.length)
            names.innerHTML = '<div class="bas-empty padded">No hay animaciones en esta sección. Importa PBS, RXDATA o Ruby desde arriba.</div>';
        const arr = map.get(librarySelectedMove) || [];
        if (!arr.some(a => a.id === librarySelectedAnimationId))
            librarySelectedAnimationId = ((_b = arr[0]) === null || _b === void 0 ? void 0 : _b.id) || null;
        for (const a of arr) {
            const src = a.source || {}, row = document.createElement('button'), source = String(src.type || 'studio').toUpperCase(), exact = src.type === 'code' && src.approximate === false;
            row.className = `bas-library-version${a.id === librarySelectedAnimationId ? ' active' : ''}`;
            row.innerHTML = `<div class="bas-library-version-top"><span class="bas-origin ${escapeHtml(src.type || 'studio')}">${escapeHtml(source)}</span>${src.opposing ? '<span class="bas-ver foe">FOE</span>' : ''}<span class="bas-ver">V${Number(src.version || 0)}</span>${src.behavior ? `<span class="bas-ver behavior">${escapeHtml(src.behavior)}</span>` : ''}${src.sideContext ? `<span class="bas-ver">${escapeHtml(src.sideContext)}</span>` : ''}${exact ? '<span class="bas-ver exact">EXACT</span>' : ''}</div><strong>${escapeHtml(a.name)}</strong><small>${escapeHtml(src.className || src.path || src.move || 'Studio')}</small>`;
            row.onclick = () => { librarySelectedAnimationId = a.id; renderLibraryPage(); };
            row.ondblclick = () => activateAnimation(a);
            versions.appendChild(row);
        }
        if (!arr.length)
            versions.innerHTML = '<div class="bas-empty padded">Selecciona un movimiento.</div>';
        const chosen = project.animations.find(a => a.id === librarySelectedAnimationId), open = root.querySelector('[data-lib-action="open"]'), del = root.querySelector('[data-lib-action="delete"]'), label = root.querySelector('[data-role="library-selection"]');
        if (open)
            open.disabled = !chosen;
        if (del)
            del.disabled = !chosen;
        if (label)
            label.textContent = chosen ? `${libraryMode === 'moves' ? `${moveInfo(librarySelectedMove).name} (${librarySelectedMove})` : librarySelectedMove} · ${((_c = chosen.source) === null || _c === void 0 ? void 0 : _c.opposing) ? 'Foe · ' : ''}V${Number(((_d = chosen.source) === null || _d === void 0 ? void 0 : _d.version) || 0)} · ${String(((_e = chosen.source) === null || _e === void 0 ? void 0 : _e.type) || 'studio').toUpperCase()}` : 'Selecciona un movimiento y una versión.';
    }
    function renderAnimationList() { renderLibraryPage(); }
    function cloneContext(c) { return !c ? null : ((typeof structuredClone === "function") ? structuredClone(c) : JSON.parse(JSON.stringify(c))); }
    function baseBattleContext() { return effectiveBattleContext(project.preview, runtimeContext, projectScriptContext); }
    function animationContext(animation = activeAnimation()) {
        var _a, _b;
        const base = baseBattleContext();
        if (!base)
            return base;
        if (((_a = animation === null || animation === void 0 ? void 0 : animation.source) === null || _a === void 0 ? void 0 : _a.type) !== "code" || ((_b = animation === null || animation === void 0 ? void 0 : animation.source) === null || _b === void 0 ? void 0 : _b.sideContext) !== "foe")
            return base;
        const c = cloneContext(base);
        [c.user, c.target] = [c.target, c.user];
        [c.scriptUser, c.scriptTarget] = [c.scriptTarget, c.scriptUser];
        [c.userIndex, c.targetIndex] = [c.targetIndex, c.userIndex];
        if (c.bases)
            [c.bases.user, c.bases.target] = [c.bases.target, c.bases.user];
        return c;
    }
    async function activateAnimation(animation, { loadAssets = true } = {}) {
        if (!animation)
            return;
        stopPlayback(false);
        activeAnimationId = animation.id;
        project.editor || (project.editor = {});
        project.editor.lastAnimationId = animation.id;
        selectedObjectId = "battler_user";
        selectedKeyId = null;
        frame = 0;
        showEditorView();
        loadedClipPaths.clear();
        preview.clearClipImages([]);
        refreshAll();
        await ensureSceneImages();
        if (loadAssets)
            await ensureAllClipAssets(true);
        await ensureBattlers(false);
        preview.setState(animation, selectedObjectId, frame, { playing: false });
    }
    async function detectStaticProjectContext() { try {
        projectScriptContext = await detectProjectBattleContext(ctx);
    }
    catch (e) {
        ctx.log.warn("Could not detect project screen settings", e);
        projectScriptContext = null;
    } renderContextBadge(); }
    async function loadMoveNames() { try {
        moveCatalog = await loadProjectMoveCatalog(ctx);
    }
    catch (e) {
        ctx.log.warn("Could not load move catalog", e);
        moveCatalog = new Map();
    } }
    function moveInfo(id) { const key = String(id || "").toUpperCase(), hit = moveCatalog.get(key); return hit || { id: key, name: key, order: Number.MAX_SAFE_INTEGER }; }
    function renderElements() {
        const list = root.querySelector('[data-role="elements"]');
        list.innerHTML = "";
        const a = activeAnimation();
        const battlers = [getBattlerTrack(a, "user"), getBattlerTrack(a, "target")].filter(Boolean);
        for (const object of battlers) {
            const row = document.createElement("div");
            row.className = `bas-list-row element system${object.id === selectedObjectId ? " selected" : ""}`;
            row.innerHTML = `<button class="bas-eye" title="Mostrar/Ocultar">${sampleVisible(object, frame) ? "●" : "○"}</button><span class="bas-list-icon">${object.side === "user" ? "◀" : "▶"}</span><span class="bas-list-text">${object.side === "user" ? "User / Battler" : "Target / Battler"}</span>`;
            row.querySelector(".bas-eye").onclick = (e) => { e.stopPropagation(); setVisibleKey(object, Math.round(frame), !sampleVisible(object, frame)); renderElements(); renderProperties(); preview.draw(); };
            row.onclick = () => selectObject(object.id);
            list.appendChild(row);
        }
        const camera = getCameraTrack(a);
        if (camera) {
            const row = document.createElement("div");
            row.className = `bas-list-row element system${camera.id === selectedObjectId ? " selected" : ""}`;
            row.innerHTML = `<span class="bas-eye">●</span><span class="bas-list-icon">▣</span><span class="bas-list-text">Camera</span>`;
            row.onclick = () => selectObject(camera.id);
            list.appendChild(row);
        }
        const clips = getAllClips(a);
        if (!clips.length) {
            const empty = document.createElement("div");
            empty.className = "bas-empty compact";
            empty.textContent = "Sin efectos. Usa + para añadir uno.";
            list.appendChild(empty);
            return;
        }
        for (const clip of clips) {
            const row = document.createElement("div");
            row.className = `bas-list-row element${clip.id === selectedObjectId ? " selected" : ""}${clip.enabled === false ? " disabled" : ""}`;
            row.innerHTML = `<button class="bas-eye" title="Mostrar/Ocultar">${clip.enabled === false ? "○" : "●"}</button><span class="bas-list-icon">◆</span><span class="bas-list-text"></span>`;
            row.querySelector(".bas-list-text").textContent = clip.name;
            row.querySelector(".bas-eye").onclick = (e) => { e.stopPropagation(); clip.enabled = clip.enabled === false; renderElements(); renderTimeline(); preview.draw(); };
            row.onclick = () => selectObject(clip.id);
            list.appendChild(row);
        }
    }
    function renderSourceSummary() {
        const h = root.querySelector('[data-role="source-summary"]');
        h.innerHTML = `
      <span class="bas-source-pill ${sourceStatus.assets.new ? "ok" : ""}" title="Graphics/Battle animations">New ${sourceStatus.assets.new || "—"}</span>
      <span class="bas-source-pill ${sourceStatus.assets.legacy ? "ok" : ""}" title="Graphics/Animations">Vanilla ${sourceStatus.assets.legacy || "—"}</span>
      <span class="bas-source-pill ${sourceStatus.assets.code ? "ok" : ""}" title="Graphics/BattleParticlesAnimations">Code ${sourceStatus.assets.code || "—"}</span>`;
    }
    function renderProperties() {
        var _a, _b, _c, _d, _e;
        const h = root.querySelector('[data-role="properties"]');
        const object = selectedObject();
        if (!object) {
            h.innerHTML = '<div class="bas-empty">Selecciona un objeto.</div>';
            return;
        }
        const f = Math.round(frame), currentKey = positionKeyAt(object, f);
        if (currentKey && !selectedKeyId)
            selectedKeyId = currentKey.id;
        const key = selectedKey() || currentKey, pos = preview.samplePosition(object, f), autoKey = project.preview.autoKey !== false;
        const size = Math.round(sampleValue(object, "size", f, 100)), rotation = Math.round(sampleValue(object, "rotation", f, 0) * 10) / 10, opacity = Math.round(sampleValue(object, "opacity", f, 100));
        if (object.type === "camera") {
            const cx = Math.round(sampleValue(object, "cameraX", f, 0)), cy = Math.round(sampleValue(object, "cameraY", f, 0)), cz = Math.round(sampleValue(object, "cameraZoom", f, 100)), cr = Math.round(sampleValue(object, "cameraRotation", f, 0) * 10) / 10;
            h.innerHTML = `<div class="bas-object-head"><strong class="bas-object-title">Camera</strong></div><div class="bas-prop-group"><div class="bas-prop-title">Cámara · frame ${f}</div><div class="bas-xy-grid"><label>Pan X <input class="bas-input" data-cam="cameraX" type="number" value="${cx}"></label><label>Pan Y <input class="bas-input" data-cam="cameraY" type="number" value="${cy}"></label></div><div class="bas-field"><label>Zoom %</label><input class="bas-range" data-cam="cameraZoom" type="range" min="25" max="300" value="${cz}"><input class="bas-input" data-camnum="cameraZoom" type="number" min="10" max="800" value="${cz}"></div><label class="bas-field">Rotación <input class="bas-input" data-cam="cameraRotation" type="number" value="${cr}"></label></div><div class="bas-prop-group"><div class="bas-prop-title">Acciones rápidas</div><div class="bas-quick-grid"><button class="bas-button" data-camaction="shake">📳 Shake</button><button class="bas-button" data-camaction="zoom-user">🔍 User</button><button class="bas-button" data-camaction="zoom-target">🔍 Target</button><button class="bas-button" data-camaction="reset">↩ Reset</button></div></div>`;
            h.querySelectorAll('[data-cam]').forEach(el => { const prop = el.dataset.cam; const apply = (v) => { setValueKey(object, prop, f, Number(v) || 0, "ease_both"); preview.draw(); }; el.oninput = e => apply(e.target.value); el.onchange = e => { apply(e.target.value); renderTimeline(); }; });
            const zr = h.querySelector('[data-cam="cameraZoom"]'), zn = h.querySelector('[data-camnum="cameraZoom"]');
            if (zr && zn) {
                zr.oninput = e => { zn.value = e.target.value; setValueKey(object, "cameraZoom", f, Number(e.target.value) || 100); preview.draw(); };
                zn.onchange = e => { zr.value = e.target.value; setValueKey(object, "cameraZoom", f, Number(e.target.value) || 100); renderTimeline(); preview.draw(); };
            }
            h.querySelectorAll('[data-camaction]').forEach(b => b.onclick = () => applyCameraQuickAction(b.dataset.camaction));
            return;
        }
        if (object.type === "battler") {
            const sideName = object.side === "user" ? "User" : "Target";
            h.innerHTML = `<div class="bas-object-head"><strong class="bas-object-title">${sideName} / Battler</strong><label class="bas-toggle"><input data-prop="visible" type="checkbox" ${sampleVisible(object, f) ? "checked" : ""}> Visible</label></div>
        <div class="bas-prop-group"><div class="bas-prop-title-row"><div class="bas-prop-title">Transform · frame ${f}</div><span class="bas-key-indicator ${currentKey ? "on" : ""}">${currentKey ? "◆ Key" : autoKey ? "Mover = crea key" : "Interpolado"}</span></div>
          <div class="bas-xy-grid"><label>X <input class="bas-input" data-prop="x" type="number" value="${Math.round(pos.x)}"></label><label>Y <input class="bas-input" data-prop="y" type="number" value="${Math.round(pos.y)}"></label></div>
          <div class="bas-field"><label>Tamaño</label><div class="bas-slider-row"><input class="bas-range" data-prop="size" type="range" min="20" max="250" step="5" value="${size}"><input class="bas-input short" data-prop="sizeNumber" type="number" min="5" max="800" value="${size}"></div></div>
          <div class="bas-xy-grid"><label>Rotación <input class="bas-input" data-prop="rotation" type="number" value="${rotation}"></label><label>Opacidad <input class="bas-input" data-prop="opacity" type="number" min="0" max="100" value="${opacity}"></label></div></div>
        <div class="bas-prop-group"><div class="bas-prop-title">Acciones rápidas</div><div class="bas-quick-grid">
          <button class="bas-button" data-quick="impact">💥 Impacto</button><button class="bas-button" data-quick="dash">➜ Dash</button><button class="bas-button" data-quick="return">↩ Volver</button><button class="bas-button" data-quick="hide">Ocultar</button><button class="bas-button" data-quick="show">Mostrar</button></div><small class="bas-help">Crean keyframes editables; no son efectos cerrados.</small></div>
        ${keyframeHtml(object, key, currentKey, f)}`;
            bindObjectTransform(h, object, f);
            h.querySelector('[data-prop="visible"]').onchange = (e) => { setVisibleKey(object, f, e.target.checked); renderElements(); preview.draw(); };
            h.querySelectorAll('[data-quick]').forEach(b => b.onclick = () => applyBattlerQuickAction(object, b.dataset.quick));
            bindKeyframeControls(h, object, f, currentKey);
            return;
        }
        const path = ((_a = object.graphic) === null || _a === void 0 ? void 0 : _a.projectPath) || ((_b = object.graphic) === null || _b === void 0 ? void 0 : _b.externalRelativePath) || ((_c = object.graphic) === null || _c === void 0 ? void 0 : _c.relativeHint) || (((_d = object.graphic) === null || _d === void 0 ? void 0 : _d.name) ? `Graphics/${object.graphic.folder}/${object.graphic.name}` : "Sin gráfico"), graphicMode = ((_e = object.graphic) === null || _e === void 0 ? void 0 : _e.spritesheet) || "auto";
        h.innerHTML = `<div class="bas-object-head"><input class="bas-name-input" data-prop="name" value="${escapeHtml(object.name)}"><label class="bas-toggle"><input data-prop="enabled" type="checkbox" ${object.enabled !== false ? "checked" : ""}> Visible</label></div>
      <div class="bas-prop-group"><div class="bas-prop-title">Gráfico</div><button class="bas-button wide" data-action="asset-library">Elegir gráfico…</button><div class="bas-path">${escapeHtml(compactProjectPath(path))}</div></div>
      <div class="bas-prop-group"><div class="bas-prop-title-row"><div class="bas-prop-title">Transform · frame ${f}</div><span class="bas-key-indicator ${currentKey ? "on" : ""}">${currentKey ? "◆ Key" : autoKey ? "Mover = crea key" : "Interpolado"}</span></div>
        <div class="bas-xy-grid"><label>X <input class="bas-input" data-prop="x" type="number" value="${Math.round(pos.x)}"></label><label>Y <input class="bas-input" data-prop="y" type="number" value="${Math.round(pos.y)}"></label></div>
        <div class="bas-field"><label>Tamaño</label><div class="bas-slider-row"><input class="bas-range" data-prop="size" type="range" min="5" max="300" step="5" value="${size}"><input class="bas-input short" data-prop="sizeNumber" type="number" min="5" max="800" value="${size}"></div></div>
        <div class="bas-xy-grid"><label>Rotación <input class="bas-input" data-prop="rotation" type="number" value="${rotation}"></label><label>Opacidad <input class="bas-input" data-prop="opacity" type="number" min="0" max="100" value="${opacity}"></label></div></div>
      ${keyframeHtml(object, key, currentKey, f)}
      <details class="bas-details"><summary>Spritesheet y opciones</summary><div class="bas-prop-group inner"><label class="bas-field">Lectura del gráfico<select class="bas-select" data-prop="spritesheet"><option value="auto" ${graphicMode === "auto" ? "selected" : ""}>Automático (New Editor)</option><option value="single" ${graphicMode === "single" ? "selected" : ""}>Imagen completa</option><option value="sheet" ${graphicMode === "sheet" ? "selected" : ""}>Spritesheet horizontal</option><option value="code-auto-grid" ${graphicMode === "code-auto-grid" ? "selected" : ""}>Code · tira/grid detectado</option><option value="code-grid" ${graphicMode === "code-grid" ? "selected" : ""}>Code · setSrc/setSrcSize</option><option value="rmxp" ${graphicMode === "rmxp" ? "selected" : ""}>Vanilla RMXP (192×192)</option></select></label>${graphicMode.startsWith("code-") ? `<div class="bas-dialog-note compact">Tira detectada · celda ${object.graphic.cellW || "auto"}×${object.graphic.cellH || "auto"}${object.graphic.playSheet ? ` · ${object.graphic.ticksPerFrame || 1} ticks/frame` : ""}</div>` : ""}<label class="bas-toggle"><input data-prop="playSheet" type="checkbox" ${object.graphic.playSheet ? "checked" : ""}> Reproducir frames automáticamente</label><div class="bas-xy-grid"><label>Frame gráfico <input class="bas-input" data-prop="graphicFrame" type="number" min="0" value="${Math.round(sampleValue(object, "graphicFrame", f, object.graphic.frame || 0))}"></label><label>FPS sheet <input class="bas-input" data-prop="sheetFps" type="number" min="1" max="120" value="${object.graphic.sheetFps || 20}"></label></div><div class="bas-xy-grid"><label>Zoom X % <input class="bas-input" data-prop="scaleX" type="number" min="1" max="1600" value="${Math.round(sampleValue(object, "scaleX", f, 100))}"></label><label>Zoom Y % <input class="bas-input" data-prop="scaleY" type="number" min="1" max="1600" value="${Math.round(sampleValue(object, "scaleY", f, 100))}"></label></div><div class="bas-xy-grid"><label>Z <input class="bas-input" data-prop="z" type="number" value="${Math.round(sampleValue(object, "z", f, 0))}"></label><label>Blend <select class="bas-select" data-prop="blend"><option value="0" ${Math.round(sampleValue(object, "blend", f, 0)) === 0 ? "selected" : ""}>Normal</option><option value="1" ${Math.round(sampleValue(object, "blend", f, 0)) === 1 ? "selected" : ""}>Add</option><option value="2" ${Math.round(sampleValue(object, "blend", f, 0)) === 2 ? "selected" : ""}>Subtract aprox.</option></select></label></div><label class="bas-toggle"><input data-prop="showPath" type="checkbox" ${project.preview.showPath !== false ? "checked" : ""}> Mostrar trayectoria</label></div></details>
      <div class="bas-prop-footer"><button class="bas-button" data-action="save-clip">Guardar como Clip</button><button class="bas-button danger-subtle" data-action="delete-element">Eliminar elemento</button></div>`;
        h.querySelector('[data-prop="name"]').onchange = (e) => { object.name = e.target.value || "Effect"; renderElements(); renderTimeline(); };
        h.querySelector('[data-prop="enabled"]').onchange = (e) => { object.enabled = e.target.checked; renderElements(); renderTimeline(); preview.draw(); };
        h.querySelector('[data-action="asset-library"]').onclick = () => openGraphicLibrary(object);
        bindObjectTransform(h, object, f);
        bindKeyframeControls(h, object, f, currentKey);
        h.querySelector('[data-prop="spritesheet"]').onchange = (e) => { object.graphic.spritesheet = e.target.value; preview.draw(); };
        h.querySelector('[data-prop="playSheet"]').onchange = (e) => { object.graphic.playSheet = e.target.checked; preview.draw(); };
        h.querySelector('[data-prop="graphicFrame"]').onchange = (e) => { setValueKey(object, "graphicFrame", f, Math.max(0, Math.round(Number(e.target.value) || 0))); preview.draw(); };
        h.querySelector('[data-prop="sheetFps"]').onchange = (e) => { object.graphic.sheetFps = clampNumber(e.target.value, 1, 120, 20); preview.draw(); };
        h.querySelector('[data-prop="scaleX"]').onchange = (e) => { setValueKey(object, "scaleX", f, clampNumber(e.target.value, 1, 1600, 100)); preview.draw(); };
        h.querySelector('[data-prop="scaleY"]').onchange = (e) => { setValueKey(object, "scaleY", f, clampNumber(e.target.value, 1, 1600, 100)); preview.draw(); };
        h.querySelector('[data-prop="z"]').onchange = (e) => { setValueKey(object, "z", f, Number(e.target.value) || 0); preview.draw(); };
        h.querySelector('[data-prop="blend"]').onchange = (e) => { setValueKey(object, "blend", f, Number(e.target.value) || 0); preview.draw(); };
        h.querySelector('[data-prop="showPath"]').onchange = (e) => { project.preview.showPath = e.target.checked; preview.draw(); };
        h.querySelector('[data-action="delete-element"]').onclick = deleteSelectedElement;
        h.querySelector('[data-action="save-clip"]').onclick = () => saveSelectedAsReusableClip(object);
    }
    function keyframeHtml(object, key, currentKey, f) {
        return `<div class="bas-prop-group"><div class="bas-prop-title">Keyframe de posición</div>${key ? `<div class="bas-xy-grid"><label>Frame <input class="bas-input" data-prop="keyFrame" type="number" min="0" max="${activeAnimation().duration}" value="${key.frame}"></label><label>Movimiento <select class="bas-select" data-prop="easing"><option value="ease_both" ${key.easing === "ease_both" ? "selected" : ""}>Suave</option><option value="linear" ${key.easing === "linear" ? "selected" : ""}>Constante</option><option value="ease_in" ${key.easing === "ease_in" ? "selected" : ""}>Acelera</option><option value="ease_out" ${key.easing === "ease_out" ? "selected" : ""}>Frena</option></select></label></div><button class="bas-button danger-subtle wide" data-action="delete-key" ${sortPositionKeys(object).length <= 1 ? "disabled" : ""}>Borrar keyframe</button>` : `<button class="bas-button wide" data-action="add-key">◆ Crear key en frame ${f}</button>`}</div>`;
    }
    function bindObjectTransform(h, object, f) {
        const commitXY = () => { const x = Number(h.querySelector('[data-prop="x"]').value), y = Number(h.querySelector('[data-prop="y"]').value); let data = { x, y }; if (object.type === "battler") {
            const base = preview.baseBattlerPosition(object.side);
            data = { anchor: `${object.side}_battler`, x: 0, y: 0, offsetX: x - base.x, offsetY: y - base.y };
        } const k = setPositionKey(object, f, data, "ease_both", data.anchor || "screen"); selectedKeyId = k.id; renderTimeline(); renderProperties(); preview.draw(); };
        h.querySelector('[data-prop="x"]').onchange = commitXY;
        h.querySelector('[data-prop="y"]').onchange = commitXY;
        bindPair(h, "size", "sizeNumber", v => { setValueKey(object, "size", f, clampNumber(v, 5, 800, 100)); preview.draw(); });
        h.querySelector('[data-prop="rotation"]').onchange = (e) => { setValueKey(object, "rotation", f, Number(e.target.value) || 0); preview.draw(); };
        h.querySelector('[data-prop="opacity"]').onchange = (e) => { setValueKey(object, "opacity", f, clampNumber(e.target.value, 0, 100, 100)); preview.draw(); };
    }
    function bindKeyframeControls(h, object, f, currentKey) {
        var _a, _b, _c, _d;
        (_a = h.querySelector('[data-action="add-key"]')) === null || _a === void 0 ? void 0 : _a.addEventListener("click", () => { const p = preview.samplePosition(object, f); let d = { x: p.x, y: p.y }; if (object.type === "battler") {
            const base = preview.baseBattlerPosition(object.side);
            d = { anchor: `${object.side}_battler`, x: 0, y: 0, offsetX: p.x - base.x, offsetY: p.y - base.y };
        } const k = setPositionKey(object, f, d, "ease_both", d.anchor || "screen"); selectedKeyId = k.id; renderTimeline(); renderProperties(); preview.draw(); });
        (_b = h.querySelector('[data-action="delete-key"]')) === null || _b === void 0 ? void 0 : _b.addEventListener("click", () => { const k = selectedKey() || currentKey; if (k && removePositionKey(object, k.id)) {
            selectedKeyId = null;
            renderTimeline();
            renderProperties();
            preview.draw();
        } });
        (_c = h.querySelector('[data-prop="keyFrame"]')) === null || _c === void 0 ? void 0 : _c.addEventListener("change", (e) => { const k = selectedKey() || currentKey; if (!k)
            return; movePositionKey(object, k.id, Number(e.target.value), activeAnimation().duration); frame = k.frame; selectedKeyId = k.id; updateFrameUi(); renderTimeline(); renderProperties(); preview.draw(); });
        (_d = h.querySelector('[data-prop="easing"]')) === null || _d === void 0 ? void 0 : _d.addEventListener("change", (e) => { const k = selectedKey() || currentKey; if (k) {
            k.easing = e.target.value;
            preview.draw();
        } });
    }
    function applyBattlerQuickAction(object, action) {
        const a = activeAnimation(), f = Math.round(frame), p = preview.samplePosition(object, f), base = preview.baseBattlerPosition(object.side), other = preview.baseBattlerPosition(object.side === "user" ? "target" : "user");
        const keyAt = (fr, x, y) => { const d = { anchor: `${object.side}_battler`, x: 0, y: 0, offsetX: x - base.x, offsetY: y - base.y }; return setPositionKey(object, Math.min(a.duration, fr), d, "ease_both", d.anchor); };
        if (action === "impact") {
            const dir = (base.x > other.x ? 1 : -1), sz = sampleValue(object, "size", f, 100);
            keyAt(f, p.x, p.y);
            keyAt(f + 1, p.x + dir * 12, p.y);
            keyAt(f + 2, p.x - dir * 9, p.y);
            keyAt(f + 3, p.x + dir * 5, p.y);
            keyAt(f + 4, p.x, p.y);
            setValueKey(object, "size", f, sz, "linear");
            setValueKey(object, "size", Math.min(a.duration, f + 1), sz * 1.04, "ease_out");
            setValueKey(object, "size", Math.min(a.duration, f + 4), sz, "ease_both");
        }
        else if (action === "dash") {
            keyAt(f, p.x, p.y);
            const dir = other.x > base.x ? 1 : -1;
            keyAt(f + 5, other.x - dir * 58, other.y + 18);
        }
        else if (action === "return") {
            keyAt(f, p.x, p.y);
            keyAt(f + 5, base.x, base.y);
        }
        else if (action === "hide")
            setVisibleKey(object, f, false);
        else if (action === "show")
            setVisibleKey(object, f, true);
        renderElements();
        renderTimeline();
        renderProperties();
        preview.draw();
    }
    function deleteSelectedElement() {
        const a = activeAnimation(), object = selectedObject();
        if (!object || object.type === "battler")
            return;
        const track = getEffectsTrack(a), idx = track.clips.findIndex(c => c.id === selectedObjectId);
        if (idx < 0)
            return;
        track.clips.splice(idx, 1);
        selectedObjectId = "battler_user";
        selectedKeyId = null;
        preview.clearClipImages(getAllClips(a).map(c => c.id));
        renderElements();
        renderProperties();
        renderTimeline();
        preview.setState(a, selectedObjectId, frame, { playing: false });
    }
    function renderTimeline() {
        var _a;
        const scroll = root.querySelector('[data-role="timeline-scroll"]'), content = root.querySelector('[data-role="timeline-content"]'), a = activeAnimation();
        if (!scroll || !content || !a)
            return;
        const oldLeft = scroll.scrollLeft, oldTop = scroll.scrollTop, framePx = clampNumber(project.preview.layout.framePixels, 8, 46, 24), laneWidth = Math.max(520, a.duration * framePx + 36), totalWidth = TIMELINE_LABEL_WIDTH + laneWidth, tickEvery = framePx >= 28 ? 1 : framePx >= 16 ? 5 : 10;
        let ticks = "";
        for (let f = 0; f <= a.duration; f += tickEvery)
            ticks += `<span class="bas-tick major" style="left:${f * framePx}px"><i></i><b>${f}</b></span>`;
        let rows = `<div class="bas-time-row ruler-row"><div class="bas-time-label sticky">Tracks</div><div class="bas-time-lane ruler-lane" data-ruler style="width:${laneWidth}px">${ticks}</div></div>`;
        for (const object of getAllAnimatables(a)) {
            const selected = object.id === selectedObjectId, isBattler = object.type === "battler", start = isBattler ? 0 : Number(object.startFrame || 0), end = isBattler ? a.duration : Number(object.endFrame || start), spanX = start * framePx, spanW = Math.max(3, (end - start) * framePx);
            const keys = sortPositionKeys(object).map(key => `<button class="bas-time-key${key.id === selectedKeyId || (selected && Math.round(frame) === key.frame) ? " active" : ""}" data-object-id="${object.id}" data-key-id="${key.id}" data-key-frame="${key.frame}" style="left:${key.frame * framePx}px" title="Frame ${key.frame}"></button>`).join("");
            rows += `<div class="bas-time-row${selected ? " selected" : ""}${object.enabled === false ? " disabled" : ""}" data-row-object="${object.id}"><div class="bas-time-label sticky" data-select-object="${object.id}"><button class="bas-eye small" data-toggle-object="${object.id}">${object.enabled === false ? "○" : "●"}</button><span>${isBattler ? (object.side === "user" ? "◀" : "▶") : object.type === "camera" ? "▣" : "◆"}</span><strong>${escapeHtml(object.name)}</strong></div><div class="bas-time-lane" data-lane-object="${object.id}" style="width:${laneWidth}px"><div class="bas-time-span ${isBattler ? "battler" : ""}" data-span-object="${object.id}" style="left:${spanX}px;width:${spanW}px"></div>${keys}</div></div>`;
        }
        const eventMarkers = (a.events || []).map((ev, i) => `<button class="bas-event-marker ${escapeHtml(String(ev.type || 'event'))}" data-event-index="${i}" data-event-frame="${Number(ev.frame || 0)}" style="left:${Number(ev.frame || 0) * framePx}px" title="${escapeHtml(String(ev.type || 'Event'))} · frame ${Number(ev.frame || 0)}${ev.name ? ` · ${escapeHtml(String(ev.name))}` : ''}"></button>`).join('');
        rows += `<div class="bas-time-row bas-events-row"><div class="bas-time-label sticky"><span>♫</span><strong>Events / SE</strong><small>${(a.events || []).length}</small></div><div class="bas-time-lane" data-events-lane style="width:${laneWidth}px">${eventMarkers}</div></div>`;
        rows += `<div class="bas-global-playhead" data-role="playhead" style="left:${TIMELINE_LABEL_WIDTH + frame * framePx}px"></div>`;
        content.style.width = `${totalWidth}px`;
        content.dataset.framePx = String(framePx);
        content.innerHTML = rows;
        scroll.scrollLeft = oldLeft;
        scroll.scrollTop = oldTop;
        content.querySelectorAll('[data-select-object]').forEach(el => el.onclick = () => selectObject(el.dataset.selectObject));
        content.querySelectorAll('[data-toggle-object]').forEach(el => el.onclick = (e) => { e.stopPropagation(); const o = getAnimatable(a, el.dataset.toggleObject); if (!o)
            return; if (o.type === "battler")
            setVisibleKey(o, Math.round(frame), !sampleVisible(o, frame));
        else
            o.enabled = o.enabled === false; renderElements(); renderTimeline(); preview.draw(); });
        content.querySelectorAll('[data-lane-object]').forEach(lane => { lane.onclick = (e) => { if (e.target.closest('.bas-time-key'))
            return; const rect = lane.getBoundingClientRect(), f = Math.round((e.clientX - rect.left) / framePx); selectObject(lane.dataset.laneObject, { renderTimelineNow: false }); setFrame(f, { renderPropertiesNow: true }); }; lane.ondblclick = (e) => { if (e.target.closest('.bas-time-key'))
            return; const o = getAnimatable(a, lane.dataset.laneObject); if (!o)
            return; const rect = lane.getBoundingClientRect(), f = clampNumber(Math.round((e.clientX - rect.left) / framePx), 0, a.duration, 0), p = preview.samplePosition(o, f); let d = { x: p.x, y: p.y }; if (o.type === "battler") {
            const base = preview.baseBattlerPosition(o.side);
            d = { anchor: `${o.side}_battler`, x: 0, y: 0, offsetX: p.x - base.x, offsetY: p.y - base.y };
        } const k = setPositionKey(o, f, d, "ease_both", d.anchor || "screen"); selectedObjectId = o.id; selectedKeyId = k.id; frame = f; updateFrameUi(); renderElements(); renderProperties(); renderTimeline(); preview.setState(a, selectedObjectId, frame, { playing: false }); }; });
        content.querySelectorAll('.bas-time-key').forEach(el => wireKeyDrag(el, framePx));
        content.querySelectorAll('.bas-event-marker').forEach(el => el.onclick = (e) => { e.stopPropagation(); setFrame(Number(el.dataset.eventFrame || 0), { renderPropertiesNow: true }); });
        (_a = content.querySelector('[data-events-lane]')) === null || _a === void 0 ? void 0 : _a.addEventListener('click', (e) => { if (e.target.closest('.bas-event-marker'))
            return; const r = e.currentTarget.getBoundingClientRect(); setFrame(Math.round((e.clientX - r.left) / framePx), { renderPropertiesNow: true }); });
        wireRulerScrub(content.querySelector('[data-ruler]'), framePx);
        updatePlayhead();
        updateTimelineFrameState();
    }
    function wireRulerScrub(ruler, framePx) {
        if (!ruler)
            return;
        const scrub = (e) => { const r = ruler.getBoundingClientRect(); setFrame(Math.round((e.clientX - r.left) / framePx), { renderPropertiesNow: false }); };
        ruler.onpointerdown = (e) => { if (e.button !== 0)
            return; e.preventDefault(); scrub(e); const move = (ev) => scrub(ev), up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); renderProperties(); }; window.addEventListener('pointermove', move); window.addEventListener('pointerup', up); };
    }
    function updateTimelineFrameState() {
        const f = Math.round(frame);
        root.querySelectorAll('.bas-time-key').forEach(el => el.classList.toggle('active', el.dataset.objectId === selectedObjectId && Number(el.dataset.keyFrame) === f));
    }
    function wireKeyDrag(keyEl, framePx) {
        keyEl.onpointerdown = (event) => { event.stopPropagation(); event.preventDefault(); const object = getAnimatable(activeAnimation(), keyEl.dataset.objectId), key = object && getPositionKeyById(object, keyEl.dataset.keyId); if (!object || !key)
            return; selectedObjectId = object.id; selectedKeyId = key.id; frame = key.frame; renderElements(); renderProperties(); updateFrameUi(); preview.setState(activeAnimation(), selectedObjectId, frame, { playing: false }); const startX = event.clientX, startFrame = key.frame, span = root.querySelector(`[data-span-object="${object.id}"]`); const move = (e) => { movePositionKey(object, key.id, startFrame + Math.round((e.clientX - startX) / framePx), activeAnimation().duration); frame = key.frame; keyEl.dataset.keyFrame = String(key.frame); keyEl.style.left = `${key.frame * framePx}px`; if (span && object.type !== "battler") {
            span.style.left = `${object.startFrame * framePx}px`;
            span.style.width = `${Math.max(3, (object.endFrame - object.startFrame) * framePx)}px`;
        } updateFrameUi(); updatePlayhead(); preview.setState(activeAnimation(), selectedObjectId, frame, { playing: false }); }; const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); renderTimeline(); renderProperties(); }; window.addEventListener('pointermove', move); window.addEventListener('pointerup', up); };
    }
    function updatePlayhead() {
        const content = root.querySelector('[data-role="timeline-content"]');
        const head = root.querySelector('[data-role="playhead"]');
        if (!content || !head)
            return;
        const framePx = Number(content.dataset.framePx || project.preview.layout.framePixels || 20);
        head.style.left = `${TIMELINE_LABEL_WIDTH + frame * framePx}px`;
    }
    function openImportDialog() {
        let dialog;
        dialog = ctx.ui.showCustomDialog({
            title: "Importar / Probar animación",
            width: "760px", height: "520px",
            render(body) {
                body.innerHTML = `<div class="bas-import-grid">
          <button class="bas-import-card" data-kind="pbs"><strong>New Animation Editor / PBS</strong><span>Proyecto actual o elegir archivo</span><small>Si eliges un archivo externo, el Studio detecta su juego de origen en segundo plano para resolver los gráficos.</small></button>
          <button class="bas-import-card" data-kind="vanilla"><strong>Vanilla / PkmnAnimations.rxdata</strong><span>Moves / Common + versiones</span><small>Lee directamente el RXDATA, sin bridge. Puede abrir el archivo de este juego o de cualquier otro y usa move2anim.dat si está disponible.</small></button>
          <button class="bas-import-card" data-kind="code"><strong>BattleAnimations / Ruby</strong><span>Proyecto actual o elegir .rb · multi-Move</span><small>Elige el script directamente. La raíz del juego y sus assets se detectan automáticamente.</small></button>
          <button class="bas-import-card" data-kind="capture"><strong>Code capturado · exacto</strong><span>Importar la última animación ejecutada en batalla</span><small>Reproduce primero la animación en el juego. El bridge registra el estado resuelto frame a frame después de ejecutar loops, rand, helpers, callbacks y cambios de battlers.</small></button>
        </div>`;
                body.querySelectorAll('[data-kind]').forEach(b => b.onclick = () => {
                    const kind = b.dataset.kind;
                    dialog.close();
                    setTimeout(() => kind === "pbs" ? openPbsImportDialog() : kind === "vanilla" ? openVanillaImportDialog() : kind === "capture" ? openCodeCaptureImportDialog() : openCodeImportDialog(), 0);
                });
            }
        });
    }
    async function pickExternalFile(title, extensions) {
        var _a, _b;
        const picked = await ((_b = (_a = ctx.ui).showFilePicker) === null || _b === void 0 ? void 0 : _b.call(_a, {
            multiple: false,
            directory: false,
            filters: [{ name: title, extensions }]
        }));
        if (!picked)
            return null;
        return Array.isArray(picked) ? (picked[0] || null) : picked;
    }
    async function pickExternalDirectory(title) {
        var _a, _b;
        const picked = await ((_b = (_a = ctx.ui).showFilePicker) === null || _b === void 0 ? void 0 : _b.call(_a, { multiple: false, directory: true, title }));
        if (!picked)
            return null;
        return Array.isArray(picked) ? (picked[0] || null) : picked;
    }
    function chooseImportSource(kindLabel) {
        return new Promise(resolve => { let dialog; dialog = ctx.ui.showCustomDialog({ title: `Origen · ${kindLabel}`, width: "620px", height: "300px", render(body) { body.innerHTML = `<div class="bas-source-choice"><button class="bas-source-button" data-source="project"><strong>Proyecto actual</strong><span>Usar los datos del proyecto abierto</span></button><button class="bas-source-button" data-source="file"><strong>Elegir archivo…</strong><span>Seleccionar el archivo directamente</span></button></div>`; body.querySelectorAll('[data-source]').forEach(b => b.onclick = () => { const v = b.dataset.source; dialog.close(); resolve(v); }); } }); });
    }
    function basename(path) {
        return String(path || "").replace(/\\/g, "/").split("/").pop() || String(path || "");
    }
    async function openPbsImportDialog() {
        const origin = await chooseImportSource("PBS");
        if (!origin)
            return;
        const processFile = async (filePath, text, sourceRoot, external = true) => { var _a, _b; try {
            if (!text)
                text = external ? await readAbsoluteText(filePath) : await ctx.fs.readProjectFile(filePath);
            if (!sourceRoot)
                sourceRoot = external ? await detectExternalGameRoot(filePath) : (((_b = (_a = ctx.editor).gameRoot) === null || _b === void 0 ? void 0 : _b.call(_a)) || "");
            const sections = parsePbsFile(text, filePath);
            if (!sections.length) {
                toast("Ese archivo no contiene animaciones PBS compatibles", "warn");
                return;
            }
            const commit = async (sec) => { const anim = animationFromPbsSection(sec, filePath); anim.source.external = external; anim.source.gameRoot = sourceRoot; for (const clip of getAllClips(anim))
                if (clip.graphic && sourceRoot)
                    clip.graphic.externalGameRoot = sourceRoot; await commitImportedAnimation(anim); };
            openMovesCommonSelector({ title: `PBS · ${basename(filePath)}`, catalog: catalogFromPbsSections(sections), note: `${filePath}${sourceRoot ? ` · Juego: ${sourceRoot}` : ""}`, onChoose: commit });
        }
        catch (e) {
            ctx.log.error(e);
            toast("No se pudo abrir/importar ese PBS", "error");
        } };
        if (origin === "project") {
            const files = await scanProjectFiles(ctx, "PBS/Animations", ["txt"], 14);
            if (!files.length) {
                toast("No encontré .txt en PBS/Animations", "warn");
                return;
            }
            openFileListDialog("PBS · proyecto actual", files, f => { var _a, _b; return processFile(f.projectPath, null, ((_b = (_a = ctx.editor).gameRoot) === null || _b === void 0 ? void 0 : _b.call(_a)) || "", false); });
            return;
        }
        const path = await pickExternalFile("PBS Animation", ["txt"]);
        if (path)
            await processFile(path, null, "", true);
    }
    async function openPackageImportDialog() {
        const path = await pickExternalFile("Battle Animation Studio package", ["json"]);
        if (!path)
            return;
        try {
            const raw = JSON.parse(await readAbsoluteText(path));
            if ((raw === null || raw === void 0 ? void 0 : raw.format) !== "battle-animation-studio-package" || !raw.animation) {
                toast("Ese archivo no es un .animpack válido", "warn");
                return;
            }
            const temp = normalizeProject({ format: "battle-animation-studio", version: 11, animations: [raw.animation], reusableClips: raw.reusableClips || [] }), anim = temp.animations[0];
            if (!anim)
                return;
            anim.id = uid("anim");
            for (const o of getAllAnimatables(anim))
                if (o.id && !String(o.id).startsWith("battler_") && o.id !== "camera_main")
                    o.id = uid(o.type === "battler" ? "battler" : "obj");
            for (const c of getAllClips(anim))
                c.id = uid("clip");
            if (Array.isArray(raw.reusableClips)) {
                project.reusableClips || (project.reusableClips = []);
                for (const clip of raw.reusableClips)
                    project.reusableClips.push(cloneClipForLibrary(clip, clip.name || "Clip"));
            }
            await commitImportedAnimation(anim);
            toast(`Paquete importado: ${anim.name}`, "info");
        }
        catch (e) {
            ctx.log.error(e);
            toast("No se pudo importar el .animpack", "error");
        }
    }
    async function readCodeCapture() {
        try {
            if (!(await ctx.fs.projectExists(CODE_CAPTURE_FILE)))
                return null;
            return JSON.parse(await ctx.fs.readProjectFile(CODE_CAPTURE_FILE));
        }
        catch (e) {
            ctx.log.warn("Invalid code capture", e);
            return null;
        }
    }
    async function readCodeCaptureFromGameRoot(gameRoot) {
        if (!gameRoot)
            return null;
        const path = `${String(gameRoot).replace(/[\\/]+$/, "")}/${CODE_CAPTURE_FILE}`;
        try {
            return JSON.parse(await readAbsoluteText(path));
        }
        catch (_a) {
            return null;
        }
    }
    function sameSourceFile(capture, selectedPath, sourceText = "") {
        const cap = (capture === null || capture === void 0 ? void 0 : capture.capture) || capture;
        const source = String((cap === null || cap === void 0 ? void 0 : cap.source_file) || "").replace(/\\/g, "/").toLowerCase();
        const selected = String(selectedPath || "").replace(/\\/g, "/").toLowerCase();
        if (source && selected && source.split("/").pop() === selected.split("/").pop())
            return true;
        const cls = String((cap === null || cap === void 0 ? void 0 : cap.class_name) || "").split("::").pop();
        return !!(cls && sourceText.includes(`class ${cls}`));
    }
    async function openCodeCaptureImportDialog() {
        var _a, _b;
        const raw = await readCodeCapture();
        if (!raw) {
            toast(`No existe ${CODE_CAPTURE_FILE}. Instala el bridge v1.2, abre una batalla y reproduce la animación una vez.`, "warn");
            return;
        }
        const animation = animationFromCodeCapture(raw);
        if (!animation) {
            toast("La última captura de código no es válida", "error");
            return;
        }
        animation.source || (animation.source = {});
        animation.source.gameRoot = ((_b = (_a = ctx.editor).gameRoot) === null || _b === void 0 ? void 0 : _b.call(_a)) || "";
        for (const clip of getAllClips(animation))
            if (clip.graphic)
                clip.graphic.externalGameRoot = animation.source.gameRoot;
        await commitImportedAnimation(animation);
        toast("Animación importada desde la ejecución real del juego.", "info");
    }
    async function openCodeImportDialog() {
        const origin = await chooseImportSource("BattleAnimations / Ruby");
        if (!origin)
            return;
        const processFile = async (filePath, text, sourceRoot, external = true) => {
            var _a, _b;
            try {
                if (!text)
                    text = external ? await readAbsoluteText(filePath) : await ctx.fs.readProjectFile(filePath);
                if (!sourceRoot)
                    sourceRoot = external ? await detectExternalGameRoot(filePath) : (((_b = (_a = ctx.editor).gameRoot) === null || _b === void 0 ? void 0 : _b.call(_a)) || "");
                const metadata = discoverCodeMetadata(text, basename(filePath));
                // If a Cinematic Engine Controller exists in/near this game, use it to expand legacy shared classes to every mapped move.
                let controller = null;
                try {
                    if (sourceRoot) {
                        const all = await scanAbsoluteFiles(`${String(sourceRoot).replace(/[\\/]+$/, "")}/Plugins`, ["rb"], 12);
                        const cf = all.find(f => /cinematic.*(?:engine|controller)|engine.*controller/i.test(f.filename));
                        if (cf) {
                            const cm = discoverCinematicControllerMappings(await readAbsoluteText(cf.absolutePath));
                            controller = cm;
                            for (const cls of metadata.classes || [])
                                for (const mv of cm.byClass.get(cls) || [])
                                    if (!metadata.moves.includes(mv))
                                        metadata.moves.push(mv);
                            for (const cls of metadata.classes || [])
                                if (cm.behaviorByClass.has(cls))
                                    metadata.behavior = cm.behaviorByClass.get(cls);
                        }
                    }
                }
                catch (_c) { }
                const variants = metadata.moves || [];
                const importVariant = async (choice = null) => {
                    var _a, _b;
                    const moveId = (choice === null || choice === void 0 ? void 0 : choice.move) || (choice === null || choice === void 0 ? void 0 : choice.id) || (variants.length === 1 ? variants[0] : null), sideContext = (choice === null || choice === void 0 ? void 0 : choice.sideContext) || ((choice === null || choice === void 0 ? void 0 : choice.opposing) ? "foe" : "player"), hitNum = Number((choice === null || choice === void 0 ? void 0 : choice.hitNum) || 0), currentRoot = ((_b = (_a = ctx.editor).gameRoot) === null || _b === void 0 ? void 0 : _b.call(_a)) || "", captured = sourceRoot ? (await readCodeCaptureFromGameRoot(sourceRoot)) : (await readCodeCapture()), cap = (captured === null || captured === void 0 ? void 0 : captured.capture) || captured, capMove = String((cap === null || cap === void 0 ? void 0 : cap.move) || "").toUpperCase();
                    let animation = null, exact = false;
                    if (captured && sameSourceFile(captured, filePath, text) && (!moveId || !capMove || capMove === String(moveId).toUpperCase()) && (!(cap === null || cap === void 0 ? void 0 : cap.side_context) || cap.side_context === sideContext)) {
                        animation = animationFromCodeCapture(captured);
                        exact = !!animation;
                    }
                    if (!animation)
                        animation = animationFromCode(text, basename(filePath), baseBattleContext(), { moveId, version: Number((choice === null || choice === void 0 ? void 0 : choice.version) || 0), behavior: (choice === null || choice === void 0 ? void 0 : choice.behavior) || metadata.behavior, sideContext, hitNum, metadata });
                    animation.source || (animation.source = {});
                    Object.assign(animation.source, { path: filePath, external, gameRoot: sourceRoot || (exact ? currentRoot : ""), approximate: !exact, move: moveId || animation.source.move, behavior: (choice === null || choice === void 0 ? void 0 : choice.behavior) || animation.source.behavior || metadata.behavior, sideContext, opposing: sideContext === "foe", hitNum });
                    for (const clip of getAllClips(animation))
                        if (clip.graphic && animation.source.gameRoot)
                            clip.graphic.externalGameRoot = animation.source.gameRoot;
                    codeSourceCache.set(animation.id, { text, filePath, sourceRoot, external, metadata });
                    await commitImportedAnimation(animation);
                    if (exact)
                        toast("Code importado desde captura runtime exacta.", "info");
                    else
                        toast(`Code interpretado como ${animation.source.behavior} · ${sideContext === "foe" ? "Foe" : "Player"}. Para callbacks/rand complejos usa captura exacta.`, "warn");
                };
                const moves = new Map();
                for (const v of variants.length ? variants : [basename(filePath).replace(/\.rb$/i, "")]) {
                    const arr = [];
                    for (const sideContext of ["player", "foe"])
                        arr.push({ move: v, label: `${v} · ${sideContext === "foe" ? "Foe" : "Player"}`, version: 0, opposing: sideContext === "foe", sideContext, behavior: metadata.behavior, id: `${v}:${sideContext}` });
                    moves.set(v, arr);
                }
                openMovesCommonSelector({ title: `Code · ${basename(filePath)}`, catalog: { moves, common: new Map() }, note: `Behavior: ${metadata.behavior} · ${metadata.classes.join(", ") || "clase no identificada"} · elige también Player/Foe`, onChoose: importVariant });
            }
            catch (e) {
                ctx.log.error(e);
                toast("No se pudo abrir/importar ese archivo Ruby", "error");
            }
        };
        if (origin === "project") {
            const files = await scanProjectFiles(ctx, "Plugins", ["rb"], 16);
            if (!files.length) {
                toast("No encontré archivos Ruby en Plugins", "warn");
                return;
            }
            openFileListDialog("Code · proyecto actual", files, f => { var _a, _b; return processFile(f.projectPath, null, ((_b = (_a = ctx.editor).gameRoot) === null || _b === void 0 ? void 0 : _b.call(_a)) || "", false); }, "Buscar .rb, clase o carpeta…");
            return;
        }
        const path = await pickExternalFile("Ruby Battle Animation", ["rb"]);
        if (path)
            await processFile(path, null, "", true);
    }
    function dirname(path) { const p = String(path || "").replace(/\\/g, "/"); const i = p.lastIndexOf("/"); return i >= 0 ? p.slice(0, i) : ""; }
    async function loadExternalMoveInfo(gameRoot) { const map = new Map(); if (!gameRoot)
        return map; try {
        const text = await readAbsoluteText(`${String(gameRoot).replace(/[\\/]+$/, "")}/PBS/moves.txt`);
        let id = null, rec = null;
        const flush = () => { if (id && rec)
            map.set(id, rec); };
        for (const raw of String(text || "").split(/\r?\n/)) {
            const line = raw.replace(/#.*$/, "").trim();
            if (!line)
                continue;
            const sm = line.match(/^\[([^\]]+)\]$/);
            if (sm) {
                flush();
                id = sm[1].trim().toUpperCase();
                rec = { id, name: id, target: null };
                continue;
            }
            if (!rec)
                continue;
            let m = line.match(/^Name\s*=\s*(.+)$/i);
            if (m)
                rec.name = m[1].trim();
            m = line.match(/^Target\s*=\s*(.+)$/i);
            if (m)
                rec.target = m[1].trim();
        }
        flush();
    }
    catch (_a) { } return map; }
    async function openVanillaImportDialog() {
        var _a, _b;
        const origin = await chooseImportSource("Vanilla / RXDATA");
        if (!origin)
            return;
        const processFile = async (filePath, sourceRoot = "") => { try {
            setStatus("Leyendo PkmnAnimations.rxdata…");
            if (!sourceRoot)
                sourceRoot = await detectExternalGameRoot(filePath);
            const bytes = await readAbsoluteBinary(filePath), animations = parseLegacyAnimationsRxdata(bytes, filePath);
            let moveMap = null, mapPath = `${dirname(filePath)}/move2anim.dat`;
            try {
                moveMap = parseMove2AnimDat(await readAbsoluteBinary(mapPath));
            }
            catch (_a) { }
            const catalog = buildLegacyCatalog(animations, moveMap), externalMoves = await loadExternalMoveInfo(sourceRoot);
            if (!catalog.records.length) {
                toast("No encontré animaciones Vanilla válidas", "warn");
                return;
            }
            openMovesCommonSelector({ title: `Vanilla · ${basename(filePath)}`, catalog, note: `${animations.length} entradas · ${catalog.moves.size} movimientos · ${catalog.common.size} comunes${moveMap ? " · move2anim.dat cargado" : " · sin move2anim.dat"}`, onChoose: async (rec) => { const mi = externalMoves.get(String(rec.move || "").toUpperCase()) || moveInfo(rec.move); const anim = animationFromLegacy(rec, { sourceRoot, sourcePath: filePath, moveInfo: mi }); anim.source.gameRoot = sourceRoot; await commitImportedAnimation(anim); } });
        }
        catch (e) {
            ctx.log.error(e);
            toast("No se pudo leer PkmnAnimations.rxdata", "error");
        } };
        if (origin === "project") {
            const rootPath = ((_b = (_a = ctx.editor).gameRoot) === null || _b === void 0 ? void 0 : _b.call(_a)) || "", known = ["Data/PkmnAnimations.rxdata", "PkmnAnimations.rxdata"];
            for (const rel of known) {
                try {
                    if (await ctx.fs.projectExists(rel)) {
                        await processFile(absoluteProjectPath(ctx, rel), rootPath);
                        return;
                    }
                }
                catch (_c) { }
            }
            toast("No encontré PkmnAnimations.rxdata en el proyecto actual", "warn");
            return;
        }
        const path = await pickExternalFile("PkmnAnimations.rxdata", ["rxdata"]);
        if (path)
            await processFile(path);
    }
    function catalogFromPbsSections(sections) { var _a, _b; const moves = new Map(), common = new Map(); for (const sec of sections || []) {
        const type = String(sec.type || "Move").toLowerCase(), isCommon = type.includes("common"), opposing = type.includes("opp") || type.includes("foe"), target = isCommon ? common : moves, key = String(sec.move || ((_a = sec.props) === null || _a === void 0 ? void 0 : _a.Name) || "Animation");
        const item = Object.assign(Object.assign({}, sec), { label: String(((_b = sec.props) === null || _b === void 0 ? void 0 : _b.Name) || sec.move || key), move: key, version: Number(sec.version || 0), opposing });
        if (!target.has(key))
            target.set(key, []);
        target.get(key).push(item);
    } for (const map of [moves, common])
        for (const arr of map.values())
            arr.sort((a, b) => Number(a.opposing) - Number(b.opposing) || Number(a.version) - Number(b.version)); return { moves, common }; }
    function openMovesCommonSelector({ title = "Animation Library", catalog, note = "", onChoose, actionLabel = "Importar a biblioteca" }) {
        const moves = (catalog === null || catalog === void 0 ? void 0 : catalog.moves) instanceof Map ? catalog.moves : new Map(), common = (catalog === null || catalog === void 0 ? void 0 : catalog.common) instanceof Map ? catalog.common : new Map();
        let mode = moves.size ? "moves" : "common", selectedName = null, selectedVersion = null, dialog;
        const sortedKeys = (map) => [...map.keys()].sort((a, b) => { if (mode !== "moves")
            return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: "base" }); const ia = moveInfo(a), ib = moveInfo(b); return ia.order - ib.order || ia.name.localeCompare(ib.name, undefined, { numeric: true, sensitivity: "base" }) || String(a).localeCompare(String(b)); });
        selectedName = sortedKeys(mode === "moves" ? moves : common)[0] || null;
        dialog = ctx.ui.showCustomDialog({ title, width: "1040px", height: "720px", render(body) {
                body.innerHTML = `<div class="bas-browser"><div class="bas-browser-top"><div class="bas-browser-tabs"><button data-tab="moves">Moves <b>${moves.size}</b></button><button data-tab="common">Common <b>${common.size}</b></button></div><input class="bas-input" data-search placeholder="Buscar por nombre del movimiento, Move ID o animación…"></div>${note ? `<div class="bas-dialog-note">${escapeHtml(note)}</div>` : ""}<div class="bas-browser-body"><div class="bas-browser-names" data-names></div><div class="bas-browser-versions" data-versions></div></div><div class="bas-browser-footer"><span data-selection>Selecciona una animación y una versión.</span><div class="spacer"></div><div class="bas-import-side-actions" data-side-actions><button class="bas-button" data-import-side="player" hidden>Importar Player</button><button class="bas-button" data-import-side="foe" hidden>Importar Foe</button><button class="bas-button primary" data-import-side="both" hidden>Importar ambos</button><button class="bas-button primary" data-open disabled>${escapeHtml(actionLabel)}</button></div></div></div>`;
                const names = body.querySelector('[data-names]'), versions = body.querySelector('[data-versions]'), search = body.querySelector('[data-search]'), open = body.querySelector('[data-open]'), sel = body.querySelector('[data-selection]'), currentMap = () => mode === "moves" ? moves : common;
                const sideButtons = [...body.querySelectorAll('[data-import-side]')];
                const renderTabs = () => body.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('active', b.dataset.tab === mode));
                const relatedSides = () => { if (mode !== "moves" || !selectedVersion)
                    return { player: null, foe: null }; const arr = currentMap().get(selectedName) || [], ver = Number(selectedVersion.version || 0); return { player: arr.find(v => Number(v.version || 0) === ver && !v.opposing && String(v.sideContext || 'player') !== 'foe') || null, foe: arr.find(v => Number(v.version || 0) === ver && (v.opposing || String(v.sideContext || '') === 'foe')) || null }; };
                const renderNames = () => { const q = search.value.trim().toLowerCase(), map = currentMap(), keys = sortedKeys(map).filter(k => { const info = moveInfo(k), hay = [String(k), info.name, ...(map.get(k) || []).flatMap(v => [v.label, v.name, v.id, v.behavior, v.sideContext])].join(" ").toLowerCase(); return !q || hay.includes(q); }); names.innerHTML = ""; if (!keys.includes(selectedName))
                    selectedName = keys[0] || null; for (const k of keys) {
                    const info = mode === "moves" ? moveInfo(k) : { name: k, id: k };
                    const row = document.createElement('button');
                    row.className = `bas-browser-name${k === selectedName ? " active" : ""}`;
                    row.innerHTML = `<strong>${escapeHtml(info.name || k)}</strong><small>${mode === "moves" ? `${escapeHtml(String(k))} · ` : ""}${map.get(k).length} versión${map.get(k).length === 1 ? "" : "es"}</small>`;
                    row.onclick = () => { selectedName = k; selectedVersion = null; renderNames(); renderVersions(); };
                    names.appendChild(row);
                } if (!keys.length)
                    names.innerHTML = '<div class="bas-empty padded">Sin resultados.</div>'; renderVersions(); };
                const renderVersions = () => {
                    const arr = currentMap().get(selectedName) || [];
                    versions.innerHTML = "";
                    if (!arr.includes(selectedVersion))
                        selectedVersion = arr[0] || null;
                    for (const v of arr) {
                        const row = document.createElement('button');
                        row.className = `bas-browser-version${v === selectedVersion ? " active" : ""}`;
                        const badges = `${v.opposing ? '<span class="bas-ver foe">FOE</span>' : '<span class="bas-ver player">PLAYER</span>'}<span class="bas-ver">V${Number(v.version || 0)}</span>${v.behavior ? `<span class="bas-ver behavior">${escapeHtml(v.behavior)}</span>` : ""}`;
                        row.innerHTML = `<div>${mode === "moves" ? badges : `<span class="bas-ver">V${Number(v.version || 0)}</span>`}<strong>${escapeHtml(v.label || v.name || v.move || selectedName)}</strong></div><small>${v.id != null ? `#${escapeHtml(String(v.id))} · ` : ""}${escapeHtml(v.name || v.type || v.sideContext || "")}</small>`;
                        row.onclick = () => { selectedVersion = v; renderVersions(); };
                        row.ondblclick = () => chooseOne(v);
                        versions.appendChild(row);
                    }
                    const sides = relatedSides(), hasSides = mode === "moves" && (!!sides.player || !!sides.foe);
                    open.hidden = hasSides;
                    open.disabled = !selectedVersion;
                    for (const b of sideButtons) {
                        const k = b.dataset.importSide;
                        b.hidden = !hasSides || (k === 'player' && !sides.player) || (k === 'foe' && !sides.foe) || (k === 'both' && !(sides.player && sides.foe));
                        b.disabled = !selectedVersion;
                    }
                    const info = moveInfo(selectedName);
                    sel.textContent = selectedVersion ? `${mode === "moves" ? `${info.name} (${selectedName})` : selectedName} · ${selectedVersion.opposing ? "Foe · " : "Player · "}V${Number(selectedVersion.version || 0)}` : "Selecciona una animación.";
                };
                const chooseOne = async (v) => { if (!v)
                    return; dialog.close(); await onChoose(v); };
                const chooseSide = async (kind) => { const sides = relatedSides(); if (kind === 'both') {
                    if (!sides.player || !sides.foe)
                        return;
                    dialog.close();
                    await onChoose(sides.player);
                    await onChoose(sides.foe);
                    return;
                } await chooseOne(sides[kind]); };
                body.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { mode = b.dataset.tab; selectedName = sortedKeys(currentMap())[0] || null; selectedVersion = null; renderTabs(); renderNames(); });
                search.oninput = renderNames;
                open.onclick = () => chooseOne(selectedVersion);
                sideButtons.forEach(b => b.onclick = () => chooseSide(b.dataset.importSide));
                renderTabs();
                renderNames();
            } });
    }
    function openAnimationLibrary() { showLibraryView(); }
    function openFileListDialog(title, files, choose, placeholder = "Buscar archivo…") {
        let dialog;
        dialog = ctx.ui.showCustomDialog({ title, width: "780px", height: "620px", render(body) { body.innerHTML = `<div class="bas-dialog-stack"><input class="bas-input" data-search placeholder="${escapeHtml(placeholder)}"><div class="bas-import-list" data-list></div></div>`; const search = body.querySelector('[data-search]'), list = body.querySelector('[data-list]'); const render = () => { const q = search.value.toLowerCase(); list.innerHTML = ""; files.filter(f => !q || f.relativePath.toLowerCase().includes(q)).forEach(file => { const row = document.createElement('button'); row.className = 'bas-file-row'; row.innerHTML = `<strong>${escapeHtml(file.filename)}</strong><small>${escapeHtml(file.relativePath)}</small>`; row.onclick = async () => { dialog.close(); try {
                await choose(file);
            }
            catch (e) {
                ctx.log.error(e);
                toast("No se pudo importar ese archivo", "error");
            } }; list.appendChild(row); }); }; search.oninput = render; render(); } });
    }
    async function commitImportedAnimation(animation) {
        var _a, _b, _c, _d;
        if (!animation)
            return;
        animation.source || (animation.source = {});
        if (!animation.source.gameRoot)
            animation.source.gameRoot = ((_b = (_a = ctx.editor).gameRoot) === null || _b === void 0 ? void 0 : _b.call(_a)) || "";
        project.animations.push(animation);
        libraryMode = ((_c = animation.source) === null || _c === void 0 ? void 0 : _c.catalogType) === "common" ? "common" : "moves";
        librarySelectedMove = String(((_d = animation.source) === null || _d === void 0 ? void 0 : _d.move) || animation.name);
        librarySelectedAnimationId = animation.id;
        await saveProject();
        showLibraryView();
        offerAnimationGraphicResolution(animation);
        toast(`Importado a la biblioteca: ${animation.name}`, "info");
    }
    // After an import, check every graphic the animation references. Graphics that
    // are not present in the current project are offered for localization: either
    // link a similar graphic already in the project or import the exact source
    // file from the source game. Returns a human-readable summary or null.
    async function offerAnimationGraphicResolution(animation) {
        var _a, _b, _c;
        try {
            const items = collectAnimationGraphics(animation);
            if (!items.length)
                return null;
            if (!animationAssets)
                animationAssets = await scanAnimationAssets(ctx);
            const externalRoot = String(((_a = animation.source) === null || _a === void 0 ? void 0 : _a.gameRoot) || "").replace(/[\\/]+$/, "").toLowerCase();
            const localRoot = String(((_c = (_b = ctx.editor).gameRoot) === null || _c === void 0 ? void 0 : _c.call(_b)) || "").replace(/[\\/]+$/, "").toLowerCase();
            const useExternal = !!externalRoot && externalRoot !== localRoot;
            const planned = await planGraphicItems(ctx, items, useExternal ? externalRoot : "", animationAssets);
            const decisions = planned.filter((p) => !p.plan.existing && (p.plan.sourcePath || p.plan.similars.length));
            if (!decisions.length)
                return null;
            const state = decisions.map((item) => {
                const plan = item.plan;
                let value;
                if (plan.existing)
                    value = "existing";
                else if (plan.sourcePath)
                    value = "import";
                else
                    value = "similar:" + plan.similars[0].projectPath;
                return { item, plan, value };
            });
            const blobUrls = new Set();
            const hold = (url) => { if (url)
                blobUrls.add(url); return url; };
            let dialog;
            dialog = ctx.ui.showCustomDialog({
                title: `Gráficos de «${animation.name}» · ${decisions.length} sin resolver`,
                width: "820px",
                height: "660px",
                render(body) {
                    body.innerHTML = `<div class="bas-dialog-stack">
              <div class="bas-dialog-note">${decisions.length} gráfico(s) de esta animación no existen en este proyecto. Para cada uno puedes <b>importar la fuente</b> (copia exacta del juego de origen al proyecto) o <b>usar un gráfico similar</b> que ya esté en el proyecto.</div>
              <div class="bas-gfx-actions">
                <button class="bas-button" data-bulk="import">Todas: importar fuente</button>
                <button class="bas-button" data-bulk="similar">Todas: usar similar</button>
                <button class="bas-button" data-bulk="skip">Todas: omitir</button>
              </div>
              <div class="bas-gfx-list" data-list></div>
              <div class="bas-gfx-actions">
                <span class="bas-muted" data-summary></span>
                <div class="spacer"></div>
                <button class="bas-button" data-cancel>Cancelar</button>
                <button class="bas-button primary" data-apply>Aplicar</button>
              </div>
            </div>`;
                    const list = body.querySelector("[data-list]");
                    const summary = body.querySelector("[data-summary]");
                    const selects = [];
                    const updateSummary = () => {
                        const imp = state.filter((s) => s.value === "import").length;
                        const sim = state.filter((s) => s.value.startsWith("similar:")).length;
                        const exi = state.filter((s) => s.value === "existing").length;
                        summary.textContent = `${imp} a importar · ${sim} con similar${exi ? ` · ${exi} existentes` : ""}`;
                    };
                    (async () => {
                        for (const s of state) {
                            const plan = s.plan;
                            const sourceUrl = plan.sourcePath ? hold(await loadAbsoluteImageUrl(plan.sourcePath)) : null;
                            const localAsset = plan.existing ? { projectPath: plan.existing, name: gfxStemOf(plan.existing) } : (plan.similars[0] || null);
                            const localUrl = localAsset ? hold(await loadProjectImageUrl(ctx, localAsset.projectPath)) : null;
                            const opts = [];
                            if (plan.existing)
                                opts.push(["existing", `Usar existente: ${gfxBasename(plan.existing)}`]);
                            if (plan.sourcePath)
                                opts.push(["import", `Importar fuente exacta → ${gfxBasename(plan.sourcePath)}`]);
                            for (const sim of plan.similars)
                                opts.push(["similar:" + sim.projectPath, `Usar similar: ${sim.name} (${sim.relativePath})`]);
                            opts.push(["skip", "No usar / omitir"]);
                            const row = document.createElement("div");
                            row.className = "bas-gfx-row";
                            const thumbs = document.createElement("div");
                            thumbs.className = "bas-gfx-thumbs";
                            thumbs.innerHTML = `<div class="bas-gfx-thumb"><span>origen</span>${sourceUrl ? `<img src="${sourceUrl}" alt="">` : ""}</div><div class="bas-gfx-thumb"><span>proyecto</span>${localUrl ? `<img src="${localUrl}" alt="">` : ""}</div>`;
                            const info = document.createElement("div");
                            info.className = "bas-gfx-info";
                            const label = document.createElement("strong");
                            label.textContent = s.item.label;
                            const sub = document.createElement("small");
                            sub.textContent = String(s.item.desc.projectPath || s.item.desc.externalRelativePath || s.item.desc.relativeHint || s.item.desc.name || "");
                            const sel = document.createElement("select");
                            sel.className = "bas-select";
                            sel.innerHTML = opts.map(([v, l]) => `<option value="${escapeHtml(v)}">${escapeHtml(l)}</option>`).join("");
                            sel.value = s.value;
                            sel.onchange = () => { s.value = sel.value; updateSummary(); };
                            selects.push(sel);
                            info.appendChild(label);
                            info.appendChild(sub);
                            info.appendChild(sel);
                            row.appendChild(thumbs);
                            row.appendChild(info);
                            list.appendChild(row);
                        }
                        updateSummary();
                    })();
                    body.querySelectorAll("[data-bulk]").forEach((b) => b.onclick = () => {
                        const kind = b.dataset.bulk;
                        for (const s of state) {
                            if (kind === "import" && s.plan.sourcePath)
                                s.value = "import";
                            else if (kind === "similar" && !s.plan.existing && s.plan.similars.length)
                                s.value = "similar:" + s.plan.similars[0].projectPath;
                            else if (kind === "skip")
                                s.value = "skip";
                        }
                        selects.forEach((sel, i) => { sel.value = state[i].value; });
                        updateSummary();
                    });
                    body.querySelector("[data-cancel]").onclick = () => { for (const u of blobUrls)
                        URL.revokeObjectURL(u); blobUrls.clear(); dialog.close(); };
                    body.querySelector("[data-apply]").onclick = async () => {
                        let imported = 0, linked = 0;
                        for (const s of state) {
                            const v = s.value;
                            if (v === "skip")
                                continue;
                            if (v === "existing") {
                                if (s.plan.existing && localizeGraphic(s.item, s.plan.existing))
                                    linked++;
                            }
                            else if (v.startsWith("similar:")) {
                                if (localizeGraphic(s.item, v.slice("similar:".length)))
                                    linked++;
                            }
                            else if (v === "import" && s.plan.sourcePath) {
                                const dest = await importGraphicIntoProject(ctx, s.item.desc, s.plan.sourcePath);
                                if (dest && localizeGraphic(s.item, dest))
                                    imported++;
                            }
                        }
                        for (const u of blobUrls)
                            URL.revokeObjectURL(u);
                        blobUrls.clear();
                        dialog.close();
                        if (imported || linked) {
                            animationAssets = null;
                            await saveProject();
                            ensureAllClipAssets(true);
                        }
                        if (imported || linked) {
                            const parts = [];
                            if (imported)
                                parts.push(`${imported} gráfico${imported === 1 ? "" : "s"} importado${imported === 1 ? "" : "s"}`);
                            if (linked)
                                parts.push(`${linked} enlazado${linked === 1 ? "" : "s"} a similar/existente`);
                            toast(`Gráficos resueltos: ${parts.join(" · ")}`, "info");
                        }
                    };
                }
            });
            return null;
        }
        catch (e) {
            ctx.log.error(e);
            return null;
        }
    }
    async function openGraphicLibrary(clip) {
        if (!animationAssets)
            animationAssets = await scanAnimationAssets(ctx);
        let selected = animationAssets.find((a) => { var _a; return a.projectPath === ((_a = clip.graphic) === null || _a === void 0 ? void 0 : _a.projectPath); }) || null;
        let tempUrl = null;
        let filterSource = "all";
        let dialog;
        dialog = ctx.ui.showCustomDialog({
            title: "Gráficos de animación",
            width: "860px",
            height: "600px",
            render(body) {
                body.innerHTML = `
          <div class="bas-asset-dialog">
            <div class="bas-asset-toolbar">
              <input class="bas-input" data-role="asset-search" placeholder="Buscar gráfico o carpeta…">
              <button class="bas-button small" data-source="all">Todos</button>
              <button class="bas-button small" data-source="new">New Editor</button>
              <button class="bas-button small" data-source="legacy">Vanilla</button>
              <button class="bas-button small" data-source="code">Code</button>
              <button class="bas-button small" data-action="refresh-assets">↻</button>
            </div>
            <div class="bas-asset-main">
              <div class="bas-asset-list" data-role="asset-list"></div>
              <div class="bas-asset-preview"><div class="bas-asset-preview-box" data-role="asset-preview"></div><div class="bas-asset-meta" data-role="asset-meta">Selecciona un gráfico.</div><button class="bas-button primary wide" data-action="choose-asset" disabled>Usar gráfico</button></div>
            </div>
          </div>`;
                const search = body.querySelector('[data-role="asset-search"]');
                const list = body.querySelector('[data-role="asset-list"]');
                const previewBox = body.querySelector('[data-role="asset-preview"]');
                const meta = body.querySelector('[data-role="asset-meta"]');
                const choose = body.querySelector('[data-action="choose-asset"]');
                const renderList = () => {
                    const q = search.value.trim().toLowerCase();
                    const filtered = animationAssets.filter((asset) => (filterSource === "all" || asset.source === filterSource) && (!q || asset.relativePath.toLowerCase().includes(q) || asset.sourceLabel.toLowerCase().includes(q)));
                    list.innerHTML = "";
                    for (const asset of filtered) {
                        const row = document.createElement("button");
                        row.className = `bas-asset-row${(selected === null || selected === void 0 ? void 0 : selected.projectPath) === asset.projectPath ? " selected" : ""}`;
                        row.innerHTML = `<span class="bas-asset-source ${asset.source}">${asset.source === "new" ? "NEW" : asset.source === "legacy" ? "VAN" : "CODE"}</span><span class="bas-asset-name"></span><small></small>`;
                        row.querySelector(".bas-asset-name").textContent = asset.name;
                        row.querySelector("small").textContent = asset.relativePath;
                        row.onclick = async () => { selected = asset; renderList(); await showAsset(); };
                        row.ondblclick = () => assignAsset(asset);
                        list.appendChild(row);
                    }
                    if (!filtered.length)
                        list.innerHTML = '<div class="bas-empty padded">No hay resultados.</div>';
                };
                const showAsset = async () => {
                    if (tempUrl) {
                        URL.revokeObjectURL(tempUrl);
                        tempUrl = null;
                    }
                    previewBox.innerHTML = '<span class="bas-muted">Cargando…</span>';
                    choose.disabled = !selected;
                    if (!selected)
                        return;
                    tempUrl = await loadProjectImageUrl(ctx, selected.projectPath);
                    previewBox.innerHTML = tempUrl ? `<img src="${tempUrl}" alt="">` : '<span class="bas-muted">No se pudo cargar.</span>';
                    meta.textContent = `${selected.sourceLabel} · ${compactProjectPath(selected.projectPath)}`;
                };
                const assignAsset = async (asset) => {
                    if (!asset)
                        return;
                    clip.graphic = Object.assign(Object.assign({}, clip.graphic), { source: asset.source, projectPath: asset.projectPath, folder: asset.rootProjectPath.replace(/^Graphics\//, ""), name: asset.name, spritesheet: "auto", frame: 0 });
                    dialog.close();
                    renderProperties();
                    await ensureClipAsset(clip, true);
                    preview.draw();
                };
                search.oninput = renderList;
                body.querySelectorAll("[data-source]").forEach((button) => button.onclick = () => { filterSource = button.dataset.source; body.querySelectorAll("[data-source]").forEach((b) => b.classList.toggle("active", b === button)); renderList(); });
                body.querySelector('[data-action="refresh-assets"]').onclick = async () => { animationAssets = await scanAnimationAssets(ctx); await detectSources(); renderList(); renderSourceSummary(); };
                choose.onclick = () => assignAsset(selected);
                renderList();
                if (selected)
                    showAsset();
            }
        });
    }
    async function ensureSceneImages() {
        var _a;
        const scene = Object.assign(Object.assign({}, (project.preview.scene || {})), (((_a = activeAnimation()) === null || _a === void 0 ? void 0 : _a.scene) || {}));
        const load = async (path) => path ? await loadProjectImageUrl(ctx, path) : null;
        const [bg, pb, eb] = await Promise.all([load(scene.background), load(scene.playerBase), load(scene.enemyBase)]);
        preview.setSceneImages(bg, pb, eb);
    }
    async function openSceneDialog() {
        if (!battlebackCatalog)
            battlebackCatalog = await scanBattlebackAssets(ctx);
        const a = activeAnimation();
        if (!a)
            return;
        a.scene || (a.scene = { background: "", playerBase: "", enemyBase: "", source: "project" });
        const groups = battlebackCatalog.groups || [], files = battlebackCatalog.files || [];
        let selectedGroup = "";
        let dialog;
        dialog = ctx.ui.showCustomDialog({ title: "Escena de batalla", width: "920px", height: "650px", render(body) {
                const roleFiles = { background: files.filter(f => /_bg$/i.test(f.name)), playerBase: files.filter(f => /_base0$/i.test(f.name)), enemyBase: files.filter(f => /_base1$/i.test(f.name)) };
                const opts = (role, label, current) => `<option value="">— Sin ${label} —</option>` + (roleFiles[role] || []).map(f => `<option value="${escapeHtml(f.projectPath)}" ${f.projectPath === current ? 'selected' : ''}>${escapeHtml(f.relativePath || f.name)}</option>`).join('');
                body.innerHTML = `<div class="bas-scene-dialog"><div class="bas-dialog-note">Cada selector muestra solo gráficos de su función: <strong>_bg</strong> para fondo, <strong>_base0</strong> para Player y <strong>_base1</strong> para Foe. El set predeterminado es <strong>indoor1</strong>.</div><div class="bas-field"><label>Set automático</label><div class="bas-scene-groups" data-groups></div></div><div class="bas-prop-group"><label class="bas-field">Fondo<select class="bas-select" data-scene="background">${opts('background', 'fondo', a.scene.background)}</select></label><label class="bas-field">Base Player<select class="bas-select" data-scene="playerBase">${opts('playerBase', 'base Player', a.scene.playerBase)}</select></label><label class="bas-field">Base Foe<select class="bas-select" data-scene="enemyBase">${opts('enemyBase', 'base Foe', a.scene.enemyBase)}</select></label></div><div class="bas-context-actions"><button class="bas-button" data-default>indoor1</button><button class="bas-button" data-clear>Limpiar</button><div class="spacer"></div><button class="bas-button primary" data-apply>Aplicar</button></div></div>`;
                const setGroup = (g) => { var _a, _b, _c; if (!g)
                    return; selectedGroup = g.key; body.querySelector('[data-scene="background"]').value = ((_a = g.background) === null || _a === void 0 ? void 0 : _a.projectPath) || ''; body.querySelector('[data-scene="playerBase"]').value = ((_b = g.playerBase) === null || _b === void 0 ? void 0 : _b.projectPath) || ''; body.querySelector('[data-scene="enemyBase"]').value = ((_c = g.enemyBase) === null || _c === void 0 ? void 0 : _c.projectPath) || ''; };
                const gh = body.querySelector('[data-groups]');
                for (const g of groups) {
                    const b = document.createElement('button');
                    b.className = 'bas-scene-card';
                    b.innerHTML = `<strong>${escapeHtml(g.label)}</strong><small>${g.background ? 'BG ' : ''}${g.playerBase ? 'P0 ' : ''}${g.enemyBase ? 'P1' : ''}</small>`;
                    b.onclick = () => { setGroup(g); gh.querySelectorAll('button').forEach(x => x.classList.toggle('active', x === b)); };
                    gh.appendChild(b);
                }
                body.querySelector('[data-scene="background"]').onchange = (e) => { var _a, _b, _c; const stem = (_a = String(e.target.value || '').split('/').pop()) === null || _a === void 0 ? void 0 : _a.replace(/\.[^.]+$/, '').replace(/_bg$/i, ''); const g = groups.find(x => x.key.toLowerCase() === String(stem || '').toLowerCase()); if (g) {
                    body.querySelector('[data-scene="playerBase"]').value = ((_b = g.playerBase) === null || _b === void 0 ? void 0 : _b.projectPath) || '';
                    body.querySelector('[data-scene="enemyBase"]').value = ((_c = g.enemyBase) === null || _c === void 0 ? void 0 : _c.projectPath) || '';
                } };
                const indoor = groups.find(g => g.key.toLowerCase() === 'indoor1');
                body.querySelector('[data-default]').onclick = () => setGroup(indoor);
                const apply = async () => { for (const role of ['background', 'playerBase', 'enemyBase'])
                    a.scene[role] = body.querySelector(`[data-scene="${role}"]`).value; a.scene.source = 'project'; project.preview.scene = Object.assign(Object.assign({}, project.preview.scene), a.scene); dialog.close(); await ensureSceneImages(); preview.draw(); };
                body.querySelector('[data-apply]').onclick = apply;
                body.querySelector('[data-clear]').onclick = () => { body.querySelectorAll('[data-scene]').forEach(x => x.value = ''); };
            } });
    }
    function applyCameraQuickAction(action) {
        const a = activeAnimation(), cam = getCameraTrack(a), f = Math.round(frame);
        if (!cam)
            return;
        if (action === 'shake') {
            const seq = [[0, 0], [1, -8], [2, 7], [3, -5], [4, 4], [5, 0]];
            for (const [d, x] of seq) {
                setValueKey(cam, 'cameraX', Math.min(a.duration, f + d), x, 'linear');
                setValueKey(cam, 'cameraY', Math.min(a.duration, f + d), d % 2 ? 3 : -2, 'linear');
            }
        }
        else if (action === 'zoom-user' || action === 'zoom-target') {
            const side = action.endsWith('user') ? 'user' : 'target', p = preview.baseBattlerPosition(side);
            setValueKey(cam, 'cameraX', f, 0);
            setValueKey(cam, 'cameraY', f, 0);
            setValueKey(cam, 'cameraZoom', f, 100);
            setValueKey(cam, 'cameraZoom', Math.min(a.duration, f + 6), 135, 'ease_out');
            cam.logic = [...(cam.logic || []), { type: 'focus', side, frame: f, duration: 6, target: p }];
        }
        else {
            for (const prop of ['cameraX', 'cameraY', 'cameraRotation'])
                setValueKey(cam, prop, f, 0);
            setValueKey(cam, 'cameraZoom', f, 100);
        }
        renderTimeline();
        renderProperties();
        preview.draw();
    }
    async function saveSelectedAsReusableClip(object) { const name = await ctx.ui.showInputDialog({ title: "Guardar Clip", message: "Nombre del clip reutilizable:", defaultValue: object.name }); if (!name)
        return; project.reusableClips || (project.reusableClips = []); project.reusableClips.push(cloneClipForLibrary(object, name)); await saveProject(); toast(`Clip guardado: ${name}`, "info"); }
    function addPreset(kind) {
        var _a;
        const a = activeAnimation();
        if (!a)
            return;
        const f = Math.round(frame), end = Math.min(a.duration, f + 12), add = (name, anchor = 'target') => { const c = createProjectile({ id: uid('clip'), name }); c.positionKeys = []; setPositionKey(c, f, { anchor: `pbs:${anchor}`, x: 0, y: 0 }, 'ease_out', `pbs:${anchor}`); setPositionKey(c, end, { anchor: `pbs:${anchor}`, x: 0, y: 0 }, 'ease_out', `pbs:${anchor}`); c.startFrame = f; c.endFrame = end; getEffectsTrack(a).clips.push(c); return c; };
        let c = null;
        if (kind === 'projectile') {
            c = add('Projectile', 'user');
            c.positionKeys = [];
            setPositionKey(c, f, { anchor: 'pbs:user', x: 0, y: 0 }, 'ease_out', 'pbs:user');
            setPositionKey(c, end, { anchor: 'pbs:target', x: 0, y: 0 }, 'ease_out', 'pbs:target');
        }
        else if (kind === 'impact' || kind === 'heavy-impact') {
            c = add(kind === 'impact' ? 'Impact' : 'Heavy Impact', 'target');
            setValueKey(c, 'scaleX', f, 40);
            setValueKey(c, 'scaleY', f, 40);
            setValueKey(c, 'scaleX', Math.min(a.duration, f + 4), kind === 'impact' ? 120 : 170, 'ease_out');
            setValueKey(c, 'scaleY', Math.min(a.duration, f + 4), kind === 'impact' ? 120 : 170, 'ease_out');
            setValueKey(c, 'opacity', f, 100);
            setValueKey(c, 'opacity', Math.min(a.duration, f + 8), 0, 'ease_out');
            if (kind === 'heavy-impact')
                applyCameraQuickAction('shake');
        }
        else if (kind === 'burst') {
            c = add('Particle Burst', 'target');
            c.pbs = { focus: 'target', emitter: 'NoMovement', emitterRate: 1, emitterIntensity: 16, randomFrameMax: 0, randomAngleRange: 360, randomInvertAngle: true, randomInvertFlip: true, emitterCommands: { emitXRange: [{ frame: f, duration: 0, value: 60 }], emitYRange: [{ frame: f, duration: 0, value: 60 }], emitAngle: [{ frame: f, duration: 0, value: 0 }], emitAngleRange: [{ frame: f, duration: 0, value: 360 }], emitSpeed: [{ frame: f, duration: 0, value: 4 }], emitting: [{ frame: f, duration: 0, value: true }, { frame: f + 2, duration: 0, value: false }] }, commands: {} };
        }
        else if (kind === 'flash') {
            a.events.push({ type: 'screen_flash', frame: f, duration: 4, color: [255, 255, 255, 220] });
        }
        else if (kind === 'dash-user' || kind === 'dash-target') {
            applyBattlerQuickAction(getBattlerTrack(a, kind.endsWith('user') ? 'user' : 'target'), 'dash');
            return;
        }
        if (c) {
            selectedObjectId = c.id;
            selectedKeyId = ((_a = c.positionKeys[0]) === null || _a === void 0 ? void 0 : _a.id) || null;
            ensureClipAsset(c, true);
        }
        renderElements();
        renderTimeline();
        renderProperties();
        preview.draw();
    }
    function openPresetsDialog() { const saved = project.reusableClips || []; let dialog; dialog = ctx.ui.showCustomDialog({ title: "Añadir acción / efecto", width: "820px", height: "620px", render(body) { body.innerHTML = `<div class="bas-preset-grid"><button data-preset="projectile"><strong>→ Projectile</strong><small>User → Target, listo para asignar gráfico.</small></button><button data-preset="impact"><strong>💥 Impact</strong><small>Escala y desaparece sobre Target.</small></button><button data-preset="heavy-impact"><strong>💥 Heavy Impact</strong><small>Impact + shake de cámara.</small></button><button data-preset="burst"><strong>✦ Particle Burst</strong><small>Emitter radial editable.</small></button><button data-preset="dash-user"><strong>➜ Dash User</strong><small>Mueve al atacante con keyframes.</small></button><button data-preset="dash-target"><strong>➜ Dash Target</strong><small>Mueve al objetivo con keyframes.</small></button><button data-preset="flash"><strong>□ Screen Flash</strong><small>Flash blanco de pantalla.</small></button></div><div class="bas-prop-group"><div class="bas-prop-title">Mis Clips</div><div class="bas-clip-library" data-clips></div></div>`; body.querySelectorAll('[data-preset]').forEach(b => b.onclick = () => { const k = b.dataset.preset; dialog.close(); addPreset(k); }); const h = body.querySelector('[data-clips]'); if (!saved.length)
            h.innerHTML = '<div class="bas-empty">Todavía no guardaste clips.</div>'; for (const sc of saved) {
            const b = document.createElement('button');
            b.className = 'bas-file-row';
            b.innerHTML = `<strong>${escapeHtml(sc.name)}</strong><small>Clip reutilizable</small>`;
            b.onclick = () => { const c = instantiateReusableClip(sc); getEffectsTrack(activeAnimation()).clips.push(c); dialog.close(); selectedObjectId = c.id; renderElements(); renderTimeline(); renderProperties(); ensureClipAsset(c, true); preview.draw(); };
            h.appendChild(b);
        } } }); }
    function toggleFocusMode() { var _a, _b; project.preview.focusMode = !project.preview.focusMode; (_a = root.querySelector('[data-view="editor"]')) === null || _a === void 0 ? void 0 : _a.classList.toggle('focus-mode', !!project.preview.focusMode); (_b = root.querySelector('[data-action="focus-mode"]')) === null || _b === void 0 ? void 0 : _b.classList.toggle('active', !!project.preview.focusMode); preview.draw(); }
    function openExportDialog() {
        const a = activeAnimation();
        if (!a)
            return;
        let dialog;
        dialog = ctx.ui.showCustomDialog({ title: "Guardar / Exportar al juego", width: "760px", height: "560px", render(body) {
                const unsupported = [];
                if (project.animations.some(x => { var _a, _b; return ((_a = x.source) === null || _a === void 0 ? void 0 : _a.type) === 'code' && ((_b = x.source) === null || _b === void 0 ? void 0 : _b.approximate) !== false; }))
                    unsupported.push('hay Ruby estático aproximado: usa captura Code para máxima fidelidad');
                if (project.animations.some(x => { var _a; return ((_a = getCameraTrack(x)) === null || _a === void 0 ? void 0 : _a.valueKeys) && Object.values(getCameraTrack(x).valueKeys).some(v => v === null || v === void 0 ? void 0 : v.length); }))
                    unsupported.push('la cámara avanzada todavía no se ejecuta en el runtime v1.2');
                if (project.animations.some(x => getAllClips(x).some(c => { var _a; return ((_a = c.pbs) === null || _a === void 0 ? void 0 : _a.emitter) && String(c.pbs.emitter).toLowerCase() !== 'none'; })))
                    unsupported.push('emitters PBS avanzados se previsualizan en Studio, runtime in-game todavía parcial');
                body.innerHTML = `<div class="bas-dialog-stack">
        <div class="bas-dialog-note"><strong>Dónde se guarda</strong><br>Proyecto editable: <code>${SAVE_FILE}</code><br>Datos que lee el juego: <code>${COMPILED_FILE}</code><br>Plugin reproductor: <code>${GAME_RUNTIME_FILE}</code></div>
        <button class="bas-export-card" data-exp="game"><strong>▶ Exportar biblioteca al juego</strong><span>Instala/actualiza Battle Animation Studio Runtime y compila todas las animaciones</span><small>Después de exportar, reinicia el juego. Los Moves/Common presentes en la biblioteca se reproducen desde el Studio; los demás siguen usando el sistema que ya tenga tu proyecto.</small></button>
        <button class="bas-export-card" data-exp="package"><strong>Animation Package</strong><span>.animpack.json</span><small>Solo para compartir/mover esta animación. No es el archivo que usa el juego.</small></button>
        <div class="bas-dialog-note"><strong>Estado runtime v1.2:</strong> posiciones, battlers, clones, gráficos/cambios de bitmap, src_rect/tiras, zoom X/Y, ángulo RGSS, opacidad, visibilidad, Z, blend, Tone/Color capturados y SE están conectados. ${unsupported.length ? `<br><strong>Atención:</strong> ${escapeHtml(unsupported.join(' · '))}` : ''}</div>
      </div>`;
                body.querySelector('[data-exp="game"]').onclick = async () => {
                    try {
                        await saveProject();
                        await ctx.fs.projectMkdir(SAVE_DIR);
                        const compiled = { format: 'battle-animation-studio-compiled', version: 11, exportedAt: new Date().toISOString(), animations: project.animations.map(anim => (Object.assign(Object.assign({}, anim), { source: Object.assign(Object.assign({}, (anim.source || {})), { runtimeEnabled: true }) }))) };
                        await ctx.fs.writeProjectFile(COMPILED_FILE, JSON.stringify(compiled, null, 2));
                        const [meta, code] = await Promise.all([ctx.fs.readModFile('runtime_game/meta.txt'), ctx.fs.readModFile('runtime_game/001_Runtime.rb')]);
                        await ctx.fs.projectMkdir(GAME_RUNTIME_DIR);
                        await ctx.fs.writeProjectFile(`${GAME_RUNTIME_DIR}/meta.txt`, meta);
                        await ctx.fs.writeProjectFile(GAME_RUNTIME_FILE, code);
                        dialog.close();
                        toast(`Exportado al juego: ${COMPILED_FILE} · runtime: ${GAME_RUNTIME_DIR}`, 'info');
                        setStatus('Exportado al juego');
                    }
                    catch (error) {
                        ctx.log.error(error);
                        toast('No se pudo exportar/instalar el runtime del juego', 'error');
                    }
                };
                body.querySelector('[data-exp="package"]').onclick = async () => { var _a; const safe = (((_a = a.source) === null || _a === void 0 ? void 0 : _a.move) || a.name || 'animation').replace(/[^A-Za-z0-9_-]+/g, '_'); const path = `${SAVE_DIR}/Exports/${safe}.animpack.json`; await ctx.fs.projectMkdir(`${SAVE_DIR}/Exports`); await ctx.fs.writeProjectFile(path, JSON.stringify({ format: 'battle-animation-studio-package', version: 1, animation: a, reusableClips: project.reusableClips || [] }, null, 2)); dialog.close(); toast(`Paquete guardado: ${path}`, 'info'); };
            } });
    }
    async function openBattlerDialog() {
        let dialog;
        dialog = ctx.ui.showCustomDialog({
            title: "Battlers del preview",
            width: "620px",
            height: "390px",
            render(body) {
                const user = project.preview.battlers.user, target = project.preview.battlers.target;
                body.innerHTML = `
          <div class="bas-dialog-stack">
            <div class="bas-dialog-note">Estos battlers no cambian al añadir elementos. El preview conserva la escena y sus recursos.</div>
            <div class="bas-battler-card"><strong>Usuario</strong><span>${escapeHtml(user.label || user.name || "")}</span><button class="bas-button" data-side="user">Elegir…</button></div>
            <div class="bas-battler-card"><strong>Objetivo</strong><span>${escapeHtml(target.label || target.name || "")}</span><button class="bas-button" data-side="target">Elegir…</button></div>
            <button class="bas-button wide" data-action="test-battlers">Usar AnimBackTest / AnimFrontTest</button>
          </div>`;
                body.querySelectorAll("[data-side]").forEach((button) => button.onclick = () => { const side = button.dataset.side; dialog.close(); setTimeout(() => openBattlerPicker(side), 0); });
                body.querySelector('[data-action="test-battlers"]').onclick = async () => {
                    project.preview.battlers.user = { projectPath: "Graphics/UI/AnimBackTest.png", folder: "UI", name: "AnimBackTest", label: "AnimBackTest" };
                    project.preview.battlers.target = { projectPath: "Graphics/UI/AnimFrontTest.png", folder: "UI", name: "AnimFrontTest", label: "AnimFrontTest" };
                    dialog.close();
                    loadedBattlerSignature = "";
                    await ensureBattlers(true);
                };
            }
        });
    }
    async function openBattlerPicker(side) {
        const assets = await scanBattlerAssets(ctx, side);
        let selected = null;
        let tempUrl = null;
        let dialog;
        dialog = ctx.ui.showCustomDialog({
            title: side === "user" ? "Battler del usuario" : "Battler del objetivo",
            width: "760px", height: "560px",
            render(body) {
                body.innerHTML = `<div class="bas-asset-dialog"><div class="bas-asset-toolbar"><input class="bas-input" data-role="search" placeholder="Buscar especie/form…"></div><div class="bas-asset-main"><div class="bas-asset-list" data-role="list"></div><div class="bas-asset-preview"><div class="bas-asset-preview-box" data-role="preview"></div><div class="bas-asset-meta" data-role="meta"></div><button class="bas-button primary wide" data-action="choose" disabled>Usar battler</button></div></div></div>`;
                const search = body.querySelector('[data-role="search"]'), list = body.querySelector('[data-role="list"]'), pv = body.querySelector('[data-role="preview"]'), meta = body.querySelector('[data-role="meta"]'), choose = body.querySelector('[data-action="choose"]');
                const show = async () => {
                    if (tempUrl)
                        URL.revokeObjectURL(tempUrl);
                    tempUrl = selected ? await loadProjectImageUrl(ctx, selected.projectPath) : null;
                    pv.innerHTML = "";
                    choose.disabled = !selected;
                    if (!selected) {
                        meta.textContent = "";
                        return;
                    }
                    const renderInfo = await loadBattlerRenderingInfo(ctx, { name: selected.name, projectPath: selected.projectPath }, side);
                    meta.textContent = `${selected.relativePath} · calculando escala DBK…`;
                    if (!tempUrl) {
                        pv.innerHTML = '<span class="bas-muted">No se pudo cargar.</span>';
                        return;
                    }
                    const canvas = document.createElement("canvas");
                    canvas.className = "bas-battler-picker-canvas";
                    canvas.width = 300;
                    canvas.height = 240;
                    pv.appendChild(canvas);
                    const image = new Image();
                    image.onload = () => {
                        const strip = image.width > image.height * 2;
                        const sw = strip ? image.height : image.width;
                        const sh = image.height;
                        const frames = strip ? Math.max(1, Math.floor(image.width / Math.max(1, sw))) : 1;
                        const nativeScale = Math.max(.05, Number((renderInfo === null || renderInfo === void 0 ? void 0 : renderInfo.scale) || 1));
                        const fit = Math.min((canvas.width - 24) / Math.max(1, sw * nativeScale), (canvas.height - 24) / Math.max(1, sh * nativeScale), 1);
                        const dw = sw * nativeScale * fit, dh = sh * nativeScale * fit;
                        const cx = canvas.getContext("2d");
                        cx.clearRect(0, 0, canvas.width, canvas.height);
                        cx.imageSmoothingEnabled = false;
                        cx.drawImage(image, 0, 0, sw, sh, (canvas.width - dw) / 2, canvas.height - dh - 8, dw, dh);
                        meta.textContent = `${selected.relativePath}${frames > 1 ? ` · spritesheet ${frames} frames · mostrando frame 1` : ""}${(renderInfo === null || renderInfo === void 0 ? void 0 : renderInfo.dbk) ? ` · DBK ×${Number(renderInfo.scale || 1)}` : ""}`;
                    };
                    image.onerror = () => { pv.innerHTML = '<span class="bas-muted">No se pudo cargar.</span>'; };
                    image.src = tempUrl;
                };
                const render = () => { const q = search.value.toLowerCase().trim(); list.innerHTML = ""; for (const asset of assets.filter((a) => !q || a.relativePath.toLowerCase().includes(q))) {
                    const row = document.createElement("button");
                    row.className = `bas-asset-row${(selected === null || selected === void 0 ? void 0 : selected.projectPath) === asset.projectPath ? " selected" : ""}`;
                    row.innerHTML = `<span class="bas-list-icon">◉</span><span class="bas-asset-name"></span><small></small>`;
                    row.querySelector(".bas-asset-name").textContent = asset.name;
                    row.querySelector("small").textContent = asset.relativePath;
                    row.onclick = async () => { selected = asset; render(); await show(); };
                    row.ondblclick = () => assign(asset);
                    list.appendChild(row);
                } };
                const assign = async (asset) => { if (!asset)
                    return; project.preview.battlers[side] = { projectPath: asset.projectPath, folder: asset.rootProjectPath ? asset.rootProjectPath.replace(/^Graphics\//, "") : (side === "user" ? "Pokemon/Back" : "Pokemon/Front"), name: asset.name, label: asset.name }; dialog.close(); loadedBattlerSignature = ""; await ensureBattlers(true); };
                search.oninput = render;
                choose.onclick = () => assign(selected);
                render();
            }
        });
    }
    async function openContextDialog() {
        await loadRuntimeContext({ silent: true });
        let dialog;
        dialog = ctx.ui.showCustomDialog({ title: "Contexto real de batalla", width: "760px", height: "640px", render(body) {
                const effective = effectiveBattleContext(project.preview, runtimeContext, projectScriptContext);
                const projectText = projectScriptContext ? `${projectScriptContext.width}×${projectScriptContext.height} · ${projectScriptContext.captureKind || "scripts"}` : "No detectado";
                const rtText = runtimeContext ? `${runtimeContext.width}×${runtimeContext.height} · ${runtimeContext.captureKind || "runtime"} · user ${runtimeContext.userIndex} / target ${runtimeContext.targetIndex}` : "Todavía no hay captura";
                const dimsText = runtimeContext ? `Graphics ${runtimeContext.graphicsWidth}×${runtimeContext.graphicsHeight} · Settings ${runtimeContext.settingsWidth}×${runtimeContext.settingsHeight}` : "El bridge detectará Graphics y Settings al iniciar el juego";
                const scriptText = runtimeContext ? `User ${Math.round(runtimeContext.scriptUser.x)},${Math.round(runtimeContext.scriptUser.y)} · Target ${Math.round(runtimeContext.scriptTarget.x)},${Math.round(runtimeContext.scriptTarget.y)}` : "Entra en batalla para leer pbBattlerPosition";
                body.innerHTML = `<div class="bas-dialog-stack"><div class="bas-dialog-note"><strong>Auto (recomendado)</strong> usa el tamaño efectivo detectado y, al entrar en batalla, toma los sprites vivos después de que los demás plugins hayan configurado la escena. <strong>Script</strong> permite comparar contra el resultado actual de Battle::Scene.pbBattlerPosition.</div>
      <label class="bas-context-option"><input type="radio" name="context-mode" value="auto" ${project.preview.contextMode === "auto" ? "checked" : ""}><span><strong>Auto · recomendado</strong><small>${escapeHtml(rtText)}<br>${escapeHtml(dimsText)}</small></span></label>
      <label class="bas-context-option"><input type="radio" name="context-mode" value="runtime" ${project.preview.contextMode === "runtime" ? "checked" : ""}><span><strong>Runtime / escena viva</strong><small>Fuerza las coordenadas reales de pokemon_0/pokemon_1 capturadas en Battle::Scene.</small></span></label>
      <label class="bas-context-option"><input type="radio" name="context-mode" value="script" ${project.preview.contextMode === "script" ? "checked" : ""}><span><strong>Posiciones del script</strong><small>${escapeHtml(scriptText)}</small></span></label>
      <label class="bas-context-option"><input type="radio" name="context-mode" value="manual" ${project.preview.contextMode === "manual" ? "checked" : ""}><span><strong>Manual</strong><small>Solo para una escena de prueba que quieras forzar.</small></span></label>
      <div class="bas-manual-grid"><label>Ancho <input class="bas-input" data-manual="width" type="number" min="160" value="${project.preview.manualContext.width}"></label><label>Alto <input class="bas-input" data-manual="height" type="number" min="120" value="${project.preview.manualContext.height}"></label></div>
      <div class="bas-context-actions"><button class="bas-button primary" data-action="install-bridge">Instalar/actualizar Preview Bridge v1.2</button><button class="bas-button" data-action="reload-context">Recargar captura</button></div>
      <div class="bas-dialog-note">El tamaño del proyecto se detecta desde los Settings/plugins efectivos. En batalla, el bridge espera a que pokemon_0/pokemon_1 existan y vuelve a muestrear sus posiciones, zoom y origen desde pbUpdate, sin engancharse a pbInitSprites. Para importar una animación Ruby con fidelidad total, debes reproducir esa animación una vez para generar <strong>${CODE_CAPTURE_FILE}</strong>.</div>
      <div class="bas-dialog-note">Proyecto/scripts: <strong>${escapeHtml(projectText)}</strong></div><div class="bas-context-current">Usando: <strong>${effective.source}</strong> · ${effective.width}×${effective.height}${runtimeContext ? ` · ${escapeHtml(runtimeContext.captureKind || "")}` : ""}</div></div>`;
                body.querySelectorAll('input[name="context-mode"]').forEach(r => r.onchange = () => { project.preview.contextMode = r.value; applyEffectiveContext(); renderContextBadge(); });
                body.querySelectorAll('[data-manual]').forEach(input => input.onchange = () => { project.preview.manualContext[input.dataset.manual] = Number(input.value); if (project.preview.contextMode === "manual")
                    applyEffectiveContext(); });
                body.querySelector('[data-action="install-bridge"]').onclick = installRuntimeBridge;
                body.querySelector('[data-action="reload-context"]').onclick = async () => { await loadRuntimeContext({ silent: false }); applyEffectiveContext(); renderContextBadge(); };
            } });
    }
    async function installRuntimeBridge({ silent = false } = {}) {
        try {
            const [meta, code] = await Promise.all([ctx.fs.readModFile("runtime/meta.txt"), ctx.fs.readModFile("runtime/001_PreviewBridge.rb")]);
            await ctx.fs.projectMkdir(RUNTIME_PLUGIN_DIR);
            await ctx.fs.writeProjectFile(`${RUNTIME_PLUGIN_DIR}/meta.txt`, meta);
            await ctx.fs.writeProjectFile(`${RUNTIME_PLUGIN_DIR}/001_PreviewBridge.rb`, code);
            if (!silent)
                toast("Preview Bridge v1.2 instalado. Reinicia el juego: la resolución y las posiciones se leen desde la escena viva sin tocar pbInitSprites.", "info");
            return true;
        }
        catch (error) {
            ctx.log.error(error);
            if (!silent)
                toast("No se pudo instalar el Preview Bridge", "error");
            return false;
        }
    }
    async function upgradeInstalledPreviewBridgeIfNeeded() {
        var _a, _b;
        try {
            const metaPath = `${RUNTIME_PLUGIN_DIR}/meta.txt`;
            if (!(await ctx.fs.projectExists(metaPath)))
                return;
            const meta = String(await ctx.fs.readProjectFile(metaPath) || "");
            const m = meta.match(/^Version\s*=\s*([^\r\n]+)/mi), version = String((m === null || m === void 0 ? void 0 : m[1]) || "").trim();
            if (version === "1.2.0")
                return;
            if (await installRuntimeBridge({ silent: true }))
                toast("Preview Bridge anterior actualizado automáticamente a v1.2. Reinicia el juego antes de entrar en combate.", "warn");
        }
        catch (e) {
            (_b = (_a = ctx.log).warn) === null || _b === void 0 ? void 0 : _b.call(_a, `[Battle Animation Studio] No se pudo comprobar el Preview Bridge instalado: ${(e === null || e === void 0 ? void 0 : e.message) || e}`);
        }
    }
    function openCodeContextDialog() {
        const a = activeAnimation(), src = (a === null || a === void 0 ? void 0 : a.source) || {};
        if (src.type !== "code") {
            toast("Esta animación no viene de Code/Ruby.", "warn");
            return;
        }
        const cached = codeSourceCache.get(a.id), logic = (a.logic || []).find(x => x.type === "code_dialect") || {}, exact = src.approximate === false;
        let dialog;
        dialog = ctx.ui.showCustomDialog({ title: "Code / Cinematic Engine", width: "820px", height: "650px", render(body) {
                var _a, _b, _c, _d;
                const cls = src.className || ((_b = (_a = cached === null || cached === void 0 ? void 0 : cached.metadata) === null || _a === void 0 ? void 0 : _a.classes) === null || _b === void 0 ? void 0 : _b.join(", ")) || "No identificada", flags = [((_c = cached === null || cached === void 0 ? void 0 : cached.metadata) === null || _c === void 0 ? void 0 : _c.hasCallbacks) || logic.callbacks ? "Callbacks" : "", ((_d = cached === null || cached === void 0 ? void 0 : cached.metadata) === null || _d === void 0 ? void 0 : _d.hasRandom) || logic.random ? "Random" : ""].filter(Boolean).join(" · ") || "Sin flags especiales detectados";
                body.innerHTML = `<div class="bas-dialog-stack"><div class="bas-dialog-note"><strong>${escapeHtml(src.move || a.name)}</strong> · ${exact ? "CAPTURA RUNTIME EXACTA" : "DIALECTO RUBY INTERPRETADO"}<br><small>${escapeHtml(cls)} · ${escapeHtml(flags)}</small></div>
      <div class="bas-prop-group"><div class="bas-prop-title">Semántica del Cinematic Engine</div><label class="bas-field">Behavior<select class="bas-input" data-behavior><option value="cinematic">cinematic</option><option value="self_targeting">self_targeting</option><option value="hazard">hazard</option><option value="multihit">multihit</option></select></label><label class="bas-field">Contexto<select class="bas-input" data-side><option value="player">Player usa el movimiento</option><option value="foe">Foe usa el movimiento</option></select></label><label class="bas-field">Hit # (multihit)<input class="bas-input" type="number" min="0" max="20" data-hit value="${Number(src.hitNum || 0)}"></label></div>
      <div class="bas-code-capabilities"><strong>El intérprete Code entiende</strong><span>addNewSprite / addSprite / battler clones</span><span>set/move XY, Delta, Zoom, Angle, Opacity, Tone, Color, Blend, Z</span><span>setSrc/setSrcSize + PRAS/grid/sheet helpers</span><span>loops simples, Math sin/cos, offsets User/Target, SE y spritesheets</span><span>HANDLED_MOVES, Player/Foe y los 4 BEHAVIOR del controller</span></div>
      <div class="bas-dialog-note">Para Ruby arbitrario (callbacks complejos, estado dinámico, helpers externos o ramas que dependen de la batalla), <strong>Captura runtime</strong> es la fuente de verdad: ejecuta el movimiento en el juego y reemplaza esta interpretación con lo que realmente ocurrió.</div>
      <div class="bas-context-actions"><button class="bas-button" data-reinterpret ${cached && !exact ? "" : "disabled"}>Reinterpretar</button><button class="bas-button primary" data-use-capture>Usar última captura exacta</button></div></div>`;
                const beh = body.querySelector('[data-behavior]'), side = body.querySelector('[data-side]');
                beh.value = src.behavior || "cinematic";
                side.value = src.sideContext || "player";
                body.querySelector('[data-reinterpret]').onclick = async () => { if (!cached)
                    return; const hitNum = Number(body.querySelector('[data-hit]').value || 0), animation = animationFromCode(cached.text, basename(cached.filePath), baseBattleContext(), { moveId: src.move, version: Number(src.version || 0), behavior: beh.value, sideContext: side.value, hitNum, metadata: cached.metadata }); Object.assign(animation.source, { path: cached.filePath, external: cached.external, gameRoot: cached.sourceRoot, behavior: beh.value, sideContext: side.value, opposing: side.value === "foe", hitNum }); for (const clip of getAllClips(animation))
                    if (clip.graphic && cached.sourceRoot)
                        clip.graphic.externalGameRoot = cached.sourceRoot; const i = project.animations.findIndex(x => x.id === a.id); animation.id = a.id; project.animations[i] = animation; codeSourceCache.set(animation.id, cached); dialog.close(); await activateAnimation(animation); };
                body.querySelector('[data-use-capture]').onclick = async () => { var _a, _b; const gameRoot = src.gameRoot || (cached === null || cached === void 0 ? void 0 : cached.sourceRoot) || ((_b = (_a = ctx.editor).gameRoot) === null || _b === void 0 ? void 0 : _b.call(_a)) || "", raw = gameRoot ? await readCodeCaptureFromGameRoot(gameRoot) : await readCodeCapture(); if (!raw) {
                    toast("No encontré una captura runtime. Ejecuta la animación una vez en el juego.", "warn");
                    return;
                } const cap = raw.capture || raw, moveOk = !src.move || !cap.move || String(src.move).toUpperCase() === String(cap.move).toUpperCase(), sideOk = !cap.side_context || String(cap.side_context) === String(side.value); if (!moveOk || !sideOk || (cached && !sameSourceFile(raw, cached.filePath, cached.text))) {
                    toast("La última captura no corresponde a esta variante/movimiento.", "warn");
                    return;
                } const animation = animationFromCodeCapture(raw); if (!animation) {
                    toast("La captura no es válida.", "error");
                    return;
                } animation.id = a.id; animation.source.gameRoot = gameRoot; for (const clip of getAllClips(animation))
                    if (clip.graphic)
                        clip.graphic.externalGameRoot = gameRoot; const i = project.animations.findIndex(x => x.id === a.id); project.animations[i] = animation; dialog.close(); await saveProject(); await activateAnimation(animation); toast("Interpretación reemplazada por la ejecución real capturada.", "info"); };
            } });
    }
    function openSourcesDialog() {
        const counts = sourceStatus.assets;
        ctx.ui.showCustomDialog({
            title: "Fuentes detectadas",
            width: "620px", height: "430px",
            render(body) {
                body.innerHTML = `<div class="bas-dialog-stack">
          <div class="bas-source-card"><strong>New Animation Editor</strong><span class="bas-source-pill ${counts.new ? "ok" : ""}">${counts.new} gráficos</span><small>Lee recursivamente Graphics/Battle animations, incluyendo subcarpetas.</small></div>
          <div class="bas-source-card"><strong>Vanilla / Legacy</strong><span class="bas-source-pill ${counts.legacy ? "ok" : ""}">${counts.legacy} gráficos</span><small>Graphics/Animations · ${sourceStatus.vanilla} registros legacy detectados.</small></div>
          <div class="bas-source-card"><strong>BattleAnimations por código</strong><span class="bas-source-pill ${counts.code ? "ok" : ""}">${counts.code} gráficos</span><small>Graphics/BattleParticlesAnimations · plugin ${sourceStatus.code ? "detectado" : "no detectado"}.</small></div>
          <div class="bas-source-card"><strong>PBS/Animations</strong><span class="bas-source-pill ${sourceStatus.pbs ? "ok" : ""}">${sourceStatus.pbs ? "detectado" : "no detectado"}</span><small>Usa Importar para abrir PBS, elegir animaciones vanilla o convertir un archivo Ruby. Ruby se marca como aproximado cuando contiene lógica que todavía no tiene equivalente visual.</small></div>
        </div>`;
            }
        });
    }
    async function ensureAllClipAssets(force = false) {
        const clips = getAllClips(activeAnimation());
        preview.clearClipImages(clips.map((c) => c.id));
        await Promise.all(clips.map((clip) => ensureClipAsset(clip, force)));
    }
    async function ensureClipAsset(clip, force = false) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        if (!clip)
            return;
        if (String(((_a = clip.graphic) === null || _a === void 0 ? void 0 : _a.source) || "").startsWith("battler-user") || String(((_b = clip.graphic) === null || _b === void 0 ? void 0 : _b.source) || "").startsWith("battler-target")) {
            loadedClipPaths.set(clip.id, clip.graphic.source);
            preview.setClipImage(clip.id, null);
            return;
        }
        let path = ((_c = clip.graphic) === null || _c === void 0 ? void 0 : _c.projectPath) || "", url = null, cacheKey = "";
        // Imported graphics that were localized (copied or linked into the project)
        // must always resolve from the project files, never from the source game.
        const externalRoot = clip.graphic.localized ? "" : (((_d = clip.graphic) === null || _d === void 0 ? void 0 : _d.externalGameRoot) || ((_f = (_e = activeAnimation()) === null || _e === void 0 ? void 0 : _e.source) === null || _f === void 0 ? void 0 : _f.gameRoot) || "");
        if (externalRoot) {
            const externalPath = await resolveExternalGraphicPath(externalRoot, clip.graphic || {});
            if (externalPath) {
                url = await loadAbsoluteImageUrl(externalPath);
                cacheKey = `external:${externalPath}`;
            }
        }
        if (!url && path) {
            url = await loadProjectImageUrl(ctx, path);
            if (url)
                cacheKey = `project:${path}`;
            else
                path = "";
        }
        if (!url && !path && ((_g = clip.graphic) === null || _g === void 0 ? void 0 : _g.name)) {
            if (!animationAssets)
                animationAssets = await scanAnimationAssets(ctx);
            const asset = await resolveLegacyGraphic(ctx, Object.assign(Object.assign({}, clip.graphic), { projectPath: "" }), animationAssets);
            if (asset) {
                path = asset.projectPath;
                clip.graphic.projectPath = path;
                url = await loadProjectImageUrl(ctx, path);
                cacheKey = `project:${path}`;
            }
        }
        if (!force && loadedClipPaths.get(clip.id) === cacheKey)
            return;
        loadedClipPaths.set(clip.id, cacheKey);
        preview.setClipImage(clip.id, url);
        // Code animations may replace a PictureEx bitmap mid-animation. Preload every
        // discovered switch so the preview follows the actual setBitmap timeline.
        for (const sw of clip.graphicSwitches || []) {
            const raw = String((sw === null || sw === void 0 ? void 0 : sw.value) || "");
            if (!raw)
                continue;
            let surl = null;
            if (externalRoot) {
                const desc = { source: "code", projectPath: raw, externalRelativePath: raw, relativeHint: raw, name: (raw.split(/[\\/]/).pop() || "").replace(/\.[^.]+$/g, "") };
                const sp = await resolveExternalGraphicPath(externalRoot, desc);
                if (sp)
                    surl = await loadAbsoluteImageUrl(sp);
            }
            if (!surl) {
                surl = await loadProjectImageUrl(ctx, raw);
            }
            preview.setClipSwitchImage(clip.id, raw, surl);
        }
        if ((_h = clip.pbs) === null || _h === void 0 ? void 0 : _h.maskGraphic) {
            let murl = null;
            const mg = { source: "new", folder: "Battle animations", name: String(clip.pbs.maskGraphic).replace(/\.png$/i, ""), relativeHint: clip.pbs.maskGraphic, externalGameRoot: externalRoot };
            if (externalRoot) {
                const mp = await resolveExternalGraphicPath(externalRoot, mg);
                if (mp)
                    murl = await loadAbsoluteImageUrl(mp);
            }
            if (!murl) {
                if (!animationAssets)
                    animationAssets = await scanAnimationAssets(ctx);
                const ma = await resolveLegacyGraphic(ctx, mg, animationAssets);
                if (ma)
                    murl = await loadProjectImageUrl(ctx, ma.projectPath);
            }
            preview.setMaskImage(clip.id, murl);
        }
        else
            preview.setMaskImage(clip.id, null);
    }
    async function ensureBattlers(force = false) {
        const u = project.preview.battlers.user, t = project.preview.battlers.target;
        const sig = `${(u === null || u === void 0 ? void 0 : u.projectPath) || (u === null || u === void 0 ? void 0 : u.name)}|${(t === null || t === void 0 ? void 0 : t.projectPath) || (t === null || t === void 0 ? void 0 : t.name)}|variants`;
        if (!force && loadedBattlerSignature === sig)
            return;
        loadedBattlerSignature = sig;
        const [upath, tpath] = await Promise.all([resolveBattlerPath(u, "user"), resolveBattlerPath(t, "target")]);
        const userName = (u === null || u === void 0 ? void 0 : u.name) || "", targetName = (t === null || t === void 0 ? void 0 : t.name) || "";
        const [userFrontAsset, targetBackAsset] = await Promise.all([
            findBattlerVariant(userName, "target"),
            findBattlerVariant(targetName, "user")
        ]);
        const [uurl, turl, ufurl, tburl, uMeta, tMeta, ufMeta, tbMeta] = await Promise.all([
            upath ? loadProjectImageUrl(ctx, upath) : null,
            tpath ? loadProjectImageUrl(ctx, tpath) : null,
            userFrontAsset ? loadProjectImageUrl(ctx, userFrontAsset.projectPath) : null,
            targetBackAsset ? loadProjectImageUrl(ctx, targetBackAsset.projectPath) : null,
            loadBattlerRenderingInfo(ctx, u, "user"),
            loadBattlerRenderingInfo(ctx, t, "target"),
            loadBattlerRenderingInfo(ctx, Object.assign(Object.assign({}, u), { projectPath: (userFrontAsset === null || userFrontAsset === void 0 ? void 0 : userFrontAsset.projectPath) || "" }), "target"),
            loadBattlerRenderingInfo(ctx, Object.assign(Object.assign({}, t), { projectPath: (targetBackAsset === null || targetBackAsset === void 0 ? void 0 : targetBackAsset.projectPath) || "" }), "user")
        ]);
        preview.setBattlers(uurl, turl, { userBack: uurl, userFront: ufurl, targetFront: turl, targetBack: tburl }, { user: uMeta, target: tMeta, userBack: uMeta, userFront: ufMeta, targetFront: tMeta, targetBack: tbMeta });
    }
    async function findBattlerVariant(stem, side) {
        if (!stem)
            return null;
        const files = await scanBattlerAssets(ctx, side);
        return files.find(item => item.name.toLowerCase() === String(stem).toLowerCase()) || null;
    }
    async function resolveBattlerPath(config, side) {
        if (config === null || config === void 0 ? void 0 : config.projectPath) {
            const direct = await loadProjectImageUrl(ctx, config.projectPath);
            if (direct) {
                URL.revokeObjectURL(direct);
                return config.projectPath;
            }
        }
        const stem = config === null || config === void 0 ? void 0 : config.name;
        if (!stem)
            return null;
        const roots = side === "user" ? ["Graphics/Pokemon/Back", "Graphics/UI"] : ["Graphics/Pokemon/Front", "Graphics/UI"];
        for (const rootPath of roots) {
            const files = rootPath === "Graphics/UI" ? await scanUiAssets(ctx) : await scanBattlerAssets(ctx, side);
            const found = files.find((item) => item.name.toLowerCase() === String(stem).toLowerCase());
            if (found) {
                config.projectPath = found.projectPath;
                return found.projectPath;
            }
        }
        return null;
    }
    async function loadRuntimeContext({ silent = false, onlyIfChanged = false } = {}) {
        var _a, _b, _c, _d;
        const next = await readRuntimeContext(ctx);
        const sig = next ? `${next.capturedAt || ""}|${next.captureKind || ""}|${next.width}x${next.height}|g${next.graphicsWidth}x${next.graphicsHeight}|s${next.settingsWidth}x${next.settingsHeight}|${(_a = next.user) === null || _a === void 0 ? void 0 : _a.x},${(_b = next.user) === null || _b === void 0 ? void 0 : _b.y}|${(_c = next.target) === null || _c === void 0 ? void 0 : _c.x},${(_d = next.target) === null || _d === void 0 ? void 0 : _d.y}` : "none";
        if (onlyIfChanged && sig === contextSignature)
            return;
        contextSignature = sig;
        runtimeContext = next;
        applyEffectiveContext();
        renderContextBadge();
        if (!silent)
            toast(next ? `Contexto runtime cargado: ${next.width}×${next.height}` : "No hay una captura runtime todavía", next ? "info" : "warn");
    }
    function applyEffectiveContext() {
        const context = animationContext();
        preview.setContext(context);
        preview.setState(activeAnimation(), selectedObjectId, frame, { playing });
    }
    function renderContextBadge() {
        const badge = root.querySelector('[data-role="context-badge"]');
        if (!badge)
            return;
        const c = effectiveBattleContext(project.preview, runtimeContext, projectScriptContext);
        badge.classList.toggle("runtime", c.source === "runtime" || c.source === "script" || c.source === "auto");
        const label = c.source === "auto" ? "Auto" : c.source === "runtime" ? "Runtime" : c.source === "script" ? "Script" : c.source === "project" ? "Project" : c.source === "manual" ? "Manual" : "Default";
        badge.textContent = `${label} ${c.width}×${c.height}${c.captureKind ? ` · ${c.captureKind}` : ""}`;
    }
    function setFrame(value, { renderTimelineNow = false, renderPropertiesNow = true } = {}) {
        const a = activeAnimation();
        frame = clampNumber(value, 0, a.duration, 0);
        const object = selectedObject(), key = object ? positionKeyAt(object, Math.round(frame)) : null;
        selectedKeyId = (key === null || key === void 0 ? void 0 : key.id) || null;
        updateFrameUi();
        updatePlayhead();
        updateTimelineFrameState();
        preview.setState(a, selectedObjectId, frame, { playing: false });
        if (renderPropertiesNow)
            renderProperties();
        if (renderTimelineNow)
            renderTimeline();
    }
    function updateFrameUi() {
        const a = activeAnimation(), input = root.querySelector('[data-role="frame-input"]'), duration = root.querySelector('[data-role="duration-input"]'), scrub = root.querySelector('[data-role="frame-scrub"]');
        if (input)
            input.value = String(Math.round(frame));
        if (duration)
            duration.value = String((a === null || a === void 0 ? void 0 : a.duration) || 1);
        if (scrub) {
            scrub.max = String((a === null || a === void 0 ? void 0 : a.duration) || 1);
            scrub.value = String(Math.round(frame));
        }
    }
    function updateTransportState() {
        const auto = root.querySelector('[data-action="autokey"]');
        const loop = root.querySelector('[data-action="loop"]');
        const play = root.querySelector('[data-action="play"]');
        const zoom = root.querySelector('[data-role="timeline-zoom"]');
        auto === null || auto === void 0 ? void 0 : auto.classList.toggle("active", project.preview.autoKey !== false);
        loop === null || loop === void 0 ? void 0 : loop.classList.toggle("active", project.preview.loop !== false);
        if (play)
            play.textContent = playing ? "❚❚" : "▶";
        if (zoom)
            zoom.value = String(project.preview.layout.framePixels || 20);
        updateFrameUi();
    }
    function audioMime(path) { const ext = String(path || "").split(".").pop().toLowerCase(); if (ext === "ogg")
        return "audio/ogg"; if (ext === "mp3")
        return "audio/mpeg"; if (ext === "m4a")
        return "audio/mp4"; return "audio/wav"; }
    async function ensureAudioContext() {
        try {
            audioContext || (audioContext = new (window.AudioContext || window.webkitAudioContext)());
            if (audioContext.state === "suspended")
                await audioContext.resume();
            return audioContext;
        }
        catch (_a) {
            return null;
        }
    }
    async function resolveSeData(ev, a) {
        var _a, _b, _c, _d, _e;
        const raw = String((ev === null || ev === void 0 ? void 0 : ev.name) || "").replace(/\\/g, "/").replace(/^Audio\/SE\//i, "").replace(/^\/+/, "");
        if (!raw)
            return null;
        const gameRoot = String(((_a = a === null || a === void 0 ? void 0 : a.source) === null || _a === void 0 ? void 0 : _a.gameRoot) || ((_c = (_b = ctx.editor).gameRoot) === null || _c === void 0 ? void 0 : _c.call(_b)) || "").replace(/[\\/]+$/, "");
        if (!gameRoot)
            return null;
        const sourceType = String(((_d = a === null || a === void 0 ? void 0 : a.source) === null || _d === void 0 ? void 0 : _d.type) || ((_e = a === null || a === void 0 ? void 0 : a.source) === null || _e === void 0 ? void 0 : _e.format) || "").toLowerCase();
        // PBS and legacy battle animations resolve their timing names inside
        // Audio/SE/Anim. Ruby BattleAnimations often already pass "Anim/...".
        // Try both locations so imported data keeps its original name.
        const roots = [];
        if (/^anim\//i.test(raw))
            roots.push(raw);
        else if (sourceType === "pbs" || sourceType === "vanilla" || sourceType === "legacy")
            roots.push(`Anim/${raw}`, raw, raw.replace(/^SE\//i, ""));
        else
            roots.push(raw, `Anim/${raw}`, raw.replace(/^SE\//i, ""));
        const cacheKey = `${gameRoot}|${roots.join("|")}`;
        if (audioCache.has(cacheKey))
            return audioCache.get(cacheKey);
        const rels = [];
        for (const base of roots) {
            if (/\.[A-Za-z0-9]+$/.test(base))
                rels.push(base);
            else
                for (const ext of ["wav", "ogg", "mp3", "m4a"])
                    rels.push(`${base}.${ext}`);
        }
        for (const rel of [...new Set(rels)]) {
            const abs = `${gameRoot}/Audio/SE/${rel}`;
            try {
                const bytes = await readAbsoluteBinary(abs);
                if (bytes === null || bytes === void 0 ? void 0 : bytes.length) {
                    const data = { bytes: bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes), mime: audioMime(abs), abs, buffer: null, url: null };
                    audioCache.set(cacheKey, data);
                    return data;
                }
            }
            catch (_f) { }
        }
        audioCache.set(cacheKey, null);
        if (!warnedAudio.has(cacheKey)) {
            warnedAudio.add(cacheKey);
            toast(`SE no encontrado: ${raw}`, "warn");
        }
        return null;
    }
    async function playSeEvent(ev, a) {
        var _a, _b, _c, _d;
        const data = await resolveSeData(ev, a);
        if (!data)
            return;
        const volume = Math.max(0, Math.min(1, Number((_a = ev.volume) !== null && _a !== void 0 ? _a : 100) / 100)), rate = Math.max(.25, Math.min(4, Number((_b = ev.pitch) !== null && _b !== void 0 ? _b : 100) / 100));
        const ac = await ensureAudioContext();
        if (ac) {
            try {
                if (!data.buffer) {
                    const slice = data.bytes.buffer.slice(data.bytes.byteOffset, data.bytes.byteOffset + data.bytes.byteLength);
                    data.buffer = await ac.decodeAudioData(slice);
                }
                const src = ac.createBufferSource(), gain = ac.createGain();
                src.buffer = data.buffer;
                src.playbackRate.value = rate;
                gain.gain.value = volume;
                src.connect(gain);
                gain.connect(ac.destination);
                activeAudios.add(src);
                src.onended = () => activeAudios.delete(src);
                src.start(0);
                return;
            }
            catch (e) {
                (_d = (_c = ctx.log).warn) === null || _d === void 0 ? void 0 : _d.call(_c, `[Battle Animation Studio] WebAudio SE fallback: ${(e === null || e === void 0 ? void 0 : e.message) || e}`);
            }
        }
        try {
            data.url || (data.url = URL.createObjectURL(new Blob([data.bytes], { type: data.mime })));
            const audio = new Audio(data.url);
            audio.volume = volume;
            audio.playbackRate = rate;
            activeAudios.add(audio);
            audio.onended = () => activeAudios.delete(audio);
            audio.onerror = () => activeAudios.delete(audio);
            await audio.play();
        }
        catch (e) {
            const key = data.abs || String(ev.name || "");
            if (!warnedAudio.has(key)) {
                warnedAudio.add(key);
                toast(`No se pudo reproducir SE: ${ev.name || "(sin nombre)"}`, "warn");
            }
        }
    }
    function stopAllPreviewAudio() { for (const audio of activeAudios) {
        try {
            if (typeof audio.stop === "function")
                audio.stop(0);
            else {
                audio.pause();
                audio.currentTime = 0;
            }
        }
        catch (_a) { }
    } activeAudios.clear(); }
    function triggerSeBetween(a, from, to, wrapped = false, includeStart = false) {
        const events = ((a === null || a === void 0 ? void 0 : a.events) || []).filter(ev => String(ev.type || "").toLowerCase() === "se");
        for (const ev of events) {
            const f = Number(ev.frame || 0);
            const hit = wrapped ? (f > from || f <= to) : ((includeStart ? f >= from : f > from) && f <= to);
            if (hit)
                playSeEvent(ev, a);
        }
    }
    function togglePlay() {
        if (playing) {
            stopPlayback(true);
            return;
        }
        if (frame >= activeAnimation().duration)
            frame = 0;
        stopAllPreviewAudio();
        ensureAudioContext();
        playing = true;
        lastTime = performance.now();
        triggerSeBetween(activeAnimation(), frame, frame, false, true);
        updateTransportState();
        preview.setState(activeAnimation(), selectedObjectId, frame, { playing: true });
        raf = requestAnimationFrame(stepPlayback);
    }
    function stopPlayback(refresh = true) {
        if (!playing && !raf)
            return;
        playing = false;
        cancelAnimationFrame(raf);
        raf = 0;
        stopAllPreviewAudio();
        updateTransportState();
        preview.setState(activeAnimation(), selectedObjectId, frame, { playing: false });
        if (refresh) {
            renderProperties();
            renderTimeline();
        }
    }
    function stepPlayback(now) {
        if (!playing)
            return;
        const a = activeAnimation();
        const delta = Math.min(.08, Math.max(0, (now - lastTime) / 1000));
        lastTime = now;
        const previousFrame = frame;
        frame += delta * a.fps;
        let wrapped = false;
        if (frame > a.duration) {
            if (project.preview.loop !== false) {
                frame = frame % Math.max(1, a.duration);
                wrapped = true;
            }
            else {
                triggerSeBetween(a, previousFrame, a.duration, false);
                frame = a.duration;
                stopPlayback(true);
                return;
            }
        }
        triggerSeBetween(a, previousFrame, frame, wrapped);
        updateFrameUi();
        updatePlayhead();
        preview.setState(a, selectedObjectId, frame, { playing: true });
        raf = requestAnimationFrame(stepPlayback);
    }
    function jumpKey(direction) {
        const object = selectedObject();
        const keys = object ? sortPositionKeys(object) : getAllAnimatables(activeAnimation()).flatMap(o => sortPositionKeys(o)).sort((a, b) => a.frame - b.frame);
        if (!keys.length)
            return;
        let target = direction < 0 ? [...keys].reverse().find(k => k.frame < Math.round(frame)) : keys.find(k => k.frame > Math.round(frame));
        if (!target)
            target = direction < 0 ? keys[keys.length - 1] : keys[0];
        selectedKeyId = target.id;
        setFrame(target.frame);
    }
    function keyboard(e) {
        var _a, _b, _c;
        const tag = (_b = (_a = e.target) === null || _a === void 0 ? void 0 : _a.tagName) === null || _b === void 0 ? void 0 : _b.toLowerCase();
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y") { e.preventDefault(); redo(); return; }
        if (["input", "select", "textarea"].includes(tag))
            return;
        if (viewMode === "library" && (e.key === "Delete" || e.key === "Backspace") && librarySelectedAnimationId) {
            e.preventDefault();
            (_c = root.querySelector('[data-lib-action="delete"]')) === null || _c === void 0 ? void 0 : _c.click();
            return;
        }
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
            e.preventDefault();
            saveProject();
            return;
        }
        if (e.code === "Space") {
            e.preventDefault();
            togglePlay();
            return;
        }
        if (e.key === "ArrowLeft") {
            e.preventDefault();
            setFrame(Math.round(frame) - 1);
            return;
        }
        if (e.key === "ArrowRight") {
            e.preventDefault();
            setFrame(Math.round(frame) + 1);
            return;
        }
        if (e.key.toLowerCase() === "r") {
            e.preventDefault();
            setFrame(0);
            return;
        }
        const object = selectedObject();
        if (e.key.toLowerCase() === "k" && object) {
            e.preventDefault();
            const p = preview.samplePosition(object, Math.round(frame));
            let d = { x: p.x, y: p.y };
            if (object.type === "battler") {
                const base = preview.baseBattlerPosition(object.side);
                d = { anchor: `${object.side}_battler`, x: 0, y: 0, offsetX: p.x - base.x, offsetY: p.y - base.y };
            }
            const key = setPositionKey(object, Math.round(frame), d, "ease_both", d.anchor || "screen");
            selectedKeyId = key.id;
            renderTimeline();
            renderProperties();
            preview.draw();
            return;
        }
        if ((e.key === "Delete" || e.key === "Backspace") && selectedKey() && object) {
            e.preventDefault();
            if (removePositionKey(object, selectedKeyId)) {
                selectedKeyId = null;
                renderTimeline();
                renderProperties();
                preview.draw();
            }
            return;
        }
        const moves = { w: [0, -1], a: [-1, 0], s: [0, 1], d: [1, 0] }, move = moves[e.key.toLowerCase()];
        if (move && object) {
            e.preventDefault();
            const p = preview.samplePosition(object, Math.round(frame)), mult = e.ctrlKey ? 10 : 1, x = p.x + move[0] * mult, y = p.y + move[1] * mult;
            let d = { x, y };
            if (object.type === "battler") {
                const base = preview.baseBattlerPosition(object.side);
                d = { anchor: `${object.side}_battler`, x: 0, y: 0, offsetX: x - base.x, offsetY: y - base.y };
            }
            const key = setPositionKey(object, Math.round(frame), d, "ease_both", d.anchor || "screen");
            selectedKeyId = key.id;
            renderTimeline();
            renderProperties();
            preview.draw();
        }
    }
    function setStatus(text) {
        const h = root.querySelector('[data-role="status"]');
        if (!h)
            return;
        clearTimeout(statusTimer);
        h.textContent = text;
        statusTimer = setTimeout(() => { if (h.textContent === text)
            h.textContent = ""; }, 2200);
    }
    function toast(message, level = "info") {
        ctx.ui.showToast({ message, level: level === "warn" ? "warn" : level });
    }
    function bindPair(h, rangeName, numberName, fn) {
        const range = h.querySelector(`[data-prop="${rangeName}"]`), number = h.querySelector(`[data-prop="${numberName}"]`);
        if (!range || !number)
            return;
        const commit = (value) => { range.value = value; number.value = value; fn(Number(value)); };
        range.oninput = (e) => commit(e.target.value);
        number.onchange = (e) => commit(e.target.value);
    }
    function escapeHtml(value) {
        return String(value !== null && value !== void 0 ? value : "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    }
}
