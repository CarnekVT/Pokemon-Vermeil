export const FORMAT_ID = "battle-animation-studio";
export const FORMAT_VERSION = 11;
export const SAVE_DIR = "PBS/AnimationStudio";
export const SAVE_FILE = `${SAVE_DIR}/animations.json`;
export const CONTEXT_FILE = `${SAVE_DIR}/battle_context.json`;
export const LEGACY_CACHE_FILE = `${SAVE_DIR}/legacy_animations.json`;
export const CODE_CAPTURE_FILE = `${SAVE_DIR}/code_capture.json`;
export const COMPILED_FILE = `${SAVE_DIR}/compiled_animations.json`;
export const GAME_RUNTIME_DIR = "Plugins/Battle Animation Studio Runtime";
export const GAME_RUNTIME_FILE = `${GAME_RUNTIME_DIR}/001_Runtime.rb`;
let serial = 1;
export function uid(prefix = "id") { return `${prefix}_${Date.now().toString(36)}_${(serial++).toString(36)}`; }
export function clampNumber(value, min, max, fallback) {
    const n = Number(value);
    return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}
export function point(anchor = "screen", x = 256, y = 192, offsetX = 0, offsetY = 0) {
    return { anchor, x, y, offsetX, offsetY };
}
function deepMerge(base, overrides) {
    if (!overrides || typeof overrides !== "object")
        return structuredCloneSafe(base);
    const out = Array.isArray(base) ? [...base] : Object.assign({}, base);
    for (const [k, v] of Object.entries(overrides)) {
        if (v && typeof v === "object" && !Array.isArray(v) && (base === null || base === void 0 ? void 0 : base[k]) && typeof base[k] === "object" && !Array.isArray(base[k]))
            out[k] = deepMerge(base[k], v);
        else
            out[k] = v;
    }
    return out;
}
function structuredCloneSafe(v) { return typeof structuredClone === "function" ? structuredClone(v) : JSON.parse(JSON.stringify(v)); }
export function createProjectile(overrides = {}) {
    const clip = {
        id: uid("clip"), type: "projectile", name: "Projectile", enabled: true,
        startFrame: 0, endFrame: 18,
        graphic: {
            source: "legacy", projectPath: "", folder: "Animations", name: "", relativeHint: "", externalGameRoot: "",
            hue: 0, spritesheet: "auto", frame: 0, playSheet: false, sheetFps: 20,
            cellW: 192, cellH: 192, cols: 5, rows: 0, origin: "auto", assetCandidates: []
        },
        visual: { size: 100, scaleX: 100, scaleY: 100, opacity: 100, rotation: 0, z: 0, blend: 0, flip: 0 },
        visibleKeys: [{ id: uid("vkey"), frame: 0, value: true }],
        positionKeys: [
            { id: uid("key"), frame: 0, easing: "ease_both", point: point("user", 0, 0, 0, -48) },
            { id: uid("key"), frame: 18, easing: "ease_both", point: point("target", 0, 0, 0, -42) }
        ],
        valueKeys: defaultValueKeys(),
        fxOps: [],
        pbs: null,
        logic: [],
        imported: null
    };
    return deepMerge(clip, overrides);
}
function defaultValueKeys() {
    return {
        size: [], scaleX: [], scaleY: [], rotation: [], opacity: [], graphicFrame: [],
        srcX: [], srcY: [], srcW: [], srcH: [], z: [], blend: [], flip: [],
        cameraX: [], cameraY: [], cameraZoom: [], cameraRotation: []
    };
}
export function createBattlerTrack(side) {
    const anchor = side === "user" ? "user_battler" : "target_battler";
    return {
        id: `battler_${side}`, type: "battler", side, name: side === "user" ? "User" : "Target", enabled: true,
        visual: { size: 100, scaleX: 100, scaleY: 100, opacity: 100, rotation: 0, z: 0, blend: 0, flip: 0 },
        visibleKeys: [{ id: uid("vkey"), frame: 0, value: true }],
        positionKeys: [{ id: uid("key"), frame: 0, easing: "ease_both", point: point(anchor, 0, 0, 0, 0) }],
        valueKeys: defaultValueKeys(), fxOps: [], logic: [], startFrame: 0, endFrame: 0
    };
}
export function createCameraTrack() {
    return {
        id: "camera_main", type: "camera", name: "Camera", enabled: true,
        visual: { cameraX: 0, cameraY: 0, cameraZoom: 100, cameraRotation: 0 },
        valueKeys: defaultValueKeys(),
        visibleKeys: [{ id: uid("vkey"), frame: 0, value: true }],
        positionKeys: [{ id: uid("key"), frame: 0, easing: "linear", point: point("screen", 0, 0) }],
        startFrame: 0, endFrame: 0, logic: []
    };
}
export function createAnimation(name = "New Animation") {
    return {
        id: uid("anim"), name, fps: 20, duration: 30,
        source: { type: "studio", move: null, version: 0, catalogType: "move", opposing: false },
        battlers: { user: createBattlerTrack("user"), target: createBattlerTrack("target") },
        camera: createCameraTrack(),
        tracks: [{ id: uid("track"), type: "effects", name: "Effects", clips: [] }],
        events: [], logic: [], notes: "",
        scene: { background: "Graphics/Battlebacks/indoor1_bg.png", playerBase: "Graphics/Battlebacks/indoor1_base0.png", enemyBase: "Graphics/Battlebacks/indoor1_base1.png", source: "project" }
    };
}
export function defaultPreviewSettings() {
    return {
        battlers: {
            user: { projectPath: "Graphics/UI/AnimBackTest.png", folder: "UI", name: "AnimBackTest", label: "AnimBackTest" },
            target: { projectPath: "Graphics/UI/AnimFrontTest.png", folder: "UI", name: "AnimFrontTest", label: "AnimFrontTest" }
        },
        scene: { background: "Graphics/Battlebacks/indoor1_bg.png", playerBase: "Graphics/Battlebacks/indoor1_base0.png", enemyBase: "Graphics/Battlebacks/indoor1_base1.png", showBases: true, dim: 0 },
        contextMode: "auto",
        manualContext: {
            width: 512, height: 384,
            user: { x: 128, y: 304, focusX: 128, focusY: 256, zoomX: 1, zoomY: 1 },
            target: { x: 384, y: 176, focusX: 384, focusY: 128, zoomX: 1, zoomY: 1 }
        },
        autoKey: true, loop: true, showPath: true,
        focusMode: false,
        layout: { leftWidth: 235, rightWidth: 450, timelineHeight: 390, framePixels: 24 }
    };
}
export function createProject() {
    return {
        format: FORMAT_ID, version: FORMAT_VERSION,
        preview: defaultPreviewSettings(),
        animations: [], reusableClips: [], packages: [], editor: { lastAnimationId: null }
    };
}
export function getAllClips(animation) { var _a; return ((_a = animation === null || animation === void 0 ? void 0 : animation.tracks) === null || _a === void 0 ? void 0 : _a.flatMap(t => t.clips || [])) || []; }
export function getClip(animation, id) { return getAllClips(animation).find(c => c.id === id) || null; }
export function getBattlerTrack(animation, side) { var _a; return ((_a = animation === null || animation === void 0 ? void 0 : animation.battlers) === null || _a === void 0 ? void 0 : _a[side]) || null; }
export function getCameraTrack(animation) { return (animation === null || animation === void 0 ? void 0 : animation.camera) || null; }
export function getAnimatable(animation, id) {
    if (!animation || !id)
        return null;
    if (id === "battler_user")
        return getBattlerTrack(animation, "user");
    if (id === "battler_target")
        return getBattlerTrack(animation, "target");
    if (id === "camera_main")
        return getCameraTrack(animation);
    return getClip(animation, id);
}
export function getAllAnimatables(animation) {
    return [getBattlerTrack(animation, "user"), getBattlerTrack(animation, "target"), getCameraTrack(animation), ...getAllClips(animation)].filter(Boolean);
}
export function getEffectsTrack(animation) {
    var _a;
    let t = (_a = animation === null || animation === void 0 ? void 0 : animation.tracks) === null || _a === void 0 ? void 0 : _a.find(x => x.type === "effects");
    if (!t) {
        t = { id: uid("track"), type: "effects", name: "Effects", clips: [] };
        animation.tracks || (animation.tracks = []);
        animation.tracks.push(t);
    }
    return t;
}
export function sortPositionKeys(o) { o.positionKeys || (o.positionKeys = []); o.positionKeys.sort((a, b) => Number(a.frame) - Number(b.frame)); return o.positionKeys; }
export function positionKeyAt(o, frame, tolerance = .001) { return sortPositionKeys(o).find(k => Math.abs(Number(k.frame) - Number(frame)) <= tolerance) || null; }
export function getPositionKeyById(o, id) { return sortPositionKeys(o).find(k => k.id === id) || null; }
export function setPositionKey(o, frame, p, easing = "ease_both", anchor = "screen") {
    const f = Math.max(0, Math.round(Number(frame) || 0));
    let k = positionKeyAt(o, f);
    if (!k) {
        k = { id: uid("key"), frame: f, easing, point: point(anchor, p.x || 0, p.y || 0, p.offsetX || 0, p.offsetY || 0) };
        o.positionKeys.push(k);
    }
    k.frame = f;
    k.easing = easing || k.easing || "ease_both";
    k.point = Object.assign(Object.assign({ anchor: p.anchor || anchor, x: Number(p.x) || 0, y: Number(p.y) || 0, offsetX: Number(p.offsetX) || 0, offsetY: Number(p.offsetY) || 0 }, (p.foeInvertX != null ? { foeInvertX: !!p.foeInvertX } : {})), (p.foeInvertY != null ? { foeInvertY: !!p.foeInvertY } : {}));
    recalcObjectBounds(o);
    return k;
}
export function movePositionKey(o, id, frame, duration) {
    const k = getPositionKeyById(o, id);
    if (!k)
        return null;
    let f = Math.round(clampNumber(frame, 0, duration, k.frame));
    const occ = sortPositionKeys(o).find(x => x.id !== id && x.frame === f);
    if (occ)
        f += f < duration ? 1 : -1;
    k.frame = Math.max(0, Math.min(duration, f));
    recalcObjectBounds(o);
    return k;
}
export function removePositionKey(o, idOrFrame) {
    const ks = sortPositionKeys(o);
    if (ks.length <= 1)
        return false;
    const i = typeof idOrFrame === "string" ? ks.findIndex(k => k.id === idOrFrame) : ks.findIndex(k => k.frame === Math.round(Number(idOrFrame)));
    if (i < 0)
        return false;
    ks.splice(i, 1);
    recalcObjectBounds(o);
    return true;
}
export function recalcObjectBounds(o) { const ks = sortPositionKeys(o); if (!ks.length)
    return; o.startFrame = ks[0].frame; o.endFrame = Math.max(Number(o.endFrame || 0), ks[ks.length - 1].frame); }
export function sortValueKeys(o, prop) { var _a; o.valueKeys || (o.valueKeys = {}); (_a = o.valueKeys)[prop] || (_a[prop] = []); o.valueKeys[prop].sort((a, b) => a.frame - b.frame); return o.valueKeys[prop]; }
export function setValueKey(o, prop, frame, value, easing = "ease_both") {
    const f = Math.max(0, Math.round(Number(frame) || 0));
    const arr = sortValueKeys(o, prop);
    let k = arr.find(x => x.frame === f);
    if (!k) {
        k = { id: uid("pkey"), frame: f, value: Number(value), easing };
        arr.push(k);
    }
    k.value = Number(value);
    k.easing = easing || k.easing || "ease_both";
    return k;
}
export function sampleValue(o, prop, frame, fallback) {
    var _a, _b;
    const ks = sortValueKeys(o, prop);
    const base = Number((_b = (_a = o.visual) === null || _a === void 0 ? void 0 : _a[prop]) !== null && _b !== void 0 ? _b : fallback);
    if (!ks.length)
        return base;
    if (frame <= ks[0].frame)
        return ks[0].value;
    if (frame >= ks[ks.length - 1].frame)
        return ks[ks.length - 1].value;
    for (let i = 0; i < ks.length - 1; i++) {
        const a = ks[i], b = ks[i + 1];
        if (frame < a.frame || frame > b.frame)
            continue;
        const t = ease01((frame - a.frame) / Math.max(.0001, b.frame - a.frame), a.easing);
        return a.value + (b.value - a.value) * t;
    }
    return base;
}
export function setVisibleKey(o, frame, value) {
    o.visibleKeys || (o.visibleKeys = []);
    const f = Math.max(0, Math.round(Number(frame) || 0));
    let k = o.visibleKeys.find(x => x.frame === f);
    if (!k) {
        k = { id: uid("vkey"), frame: f, value: !!value };
        o.visibleKeys.push(k);
    }
    k.value = !!value;
    o.visibleKeys.sort((a, b) => a.frame - b.frame);
    return k;
}
export function sampleVisible(o, frame) {
    const ks = (o.visibleKeys || []).slice().sort((a, b) => a.frame - b.frame);
    let v = o.enabled !== false;
    for (const k of ks) {
        if (k.frame > frame)
            break;
        v = !!k.value;
    }
    return v && o.enabled !== false;
}
function ease01(x, mode) {
    const t = Math.max(0, Math.min(1, x));
    if (mode === "linear")
        return t;
    if (mode === "ease_in")
        return t * t;
    if (mode === "ease_out")
        return 1 - (1 - t) * (1 - t);
    return t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}
export function normalizeProject(raw) {
    var _a;
    var _b;
    if (!raw || typeof raw !== "object")
        return createProject();
    if (raw.format && ![FORMAT_ID, "vermeil-battle-animation-studio"].includes(raw.format))
        return createProject();
    const sourceVersion = Number(raw.version || 1), d = defaultPreviewSettings();
    const p = {
        format: FORMAT_ID, version: FORMAT_VERSION,
        preview: deepMerge(d, raw.preview || {}),
        animations: Array.isArray(raw.animations) ? raw.animations : [],
        reusableClips: Array.isArray(raw.reusableClips) ? raw.reusableClips : [],
        packages: Array.isArray(raw.packages) ? raw.packages : [],
        editor: { lastAnimationId: ((_a = raw.editor) === null || _a === void 0 ? void 0 : _a.lastAnimationId) || null }
    };
    if (sourceVersion < 4) {
        p.preview.layout.leftWidth = Math.max(235, Number(p.preview.layout.leftWidth || 0));
        p.preview.layout.rightWidth = Math.max(450, Number(p.preview.layout.rightWidth || 0));
        p.preview.layout.timelineHeight = Math.max(390, Number(p.preview.layout.timelineHeight || 0));
    }
    if (sourceVersion < 5 && ["runtime", "script", "manual", "default"].includes(p.preview.contextMode))
        p.preview.contextMode = "auto";
    if (sourceVersion < 10) {
        (_b = p.preview).scene || (_b.scene = {});
        if (!p.preview.scene.background)
            p.preview.scene.background = "Graphics/Battlebacks/indoor1_bg.png";
        if (!p.preview.scene.playerBase)
            p.preview.scene.playerBase = "Graphics/Battlebacks/indoor1_base0.png";
        if (!p.preview.scene.enemyBase)
            p.preview.scene.enemyBase = "Graphics/Battlebacks/indoor1_base1.png";
    }
    for (const a of p.animations)
        normalizeAnimation(a);
    return p;
}
function normalizeAnimation(a) {
    a.id || (a.id = uid("anim"));
    a.name || (a.name = "Animation");
    a.fps = clampNumber(a.fps, 1, 120, 20);
    a.duration = clampNumber(a.duration, 1, 9999, 30);
    a.source = Object.assign({ type: "studio", move: null, version: 0, catalogType: "move", opposing: false }, (a.source || {}));
    a.battlers || (a.battlers = {});
    a.battlers.user = normalizeBattler(a.battlers.user, "user", a.duration);
    a.battlers.target = normalizeBattler(a.battlers.target, "target", a.duration);
    a.camera = normalizeCamera(a.camera, a.duration);
    if (!Array.isArray(a.tracks))
        a.tracks = [];
    const t = getEffectsTrack(a);
    if (!Array.isArray(t.clips))
        t.clips = [];
    for (const c of t.clips)
        normalizeClip(c, a.duration);
    a.events = Array.isArray(a.events) ? a.events : [];
    a.logic = Array.isArray(a.logic) ? a.logic : [];
    a.scene = Object.assign({ background: "Graphics/Battlebacks/indoor1_bg.png", playerBase: "Graphics/Battlebacks/indoor1_base0.png", enemyBase: "Graphics/Battlebacks/indoor1_base1.png", source: "project" }, (a.scene || {}));
    if (!a.scene.background)
        a.scene.background = "Graphics/Battlebacks/indoor1_bg.png";
    if (!a.scene.playerBase)
        a.scene.playerBase = "Graphics/Battlebacks/indoor1_base0.png";
    if (!a.scene.enemyBase)
        a.scene.enemyBase = "Graphics/Battlebacks/indoor1_base1.png";
}
function normalizeBattler(b, side, d) { const base = createBattlerTrack(side), out = deepMerge(base, b || {}); normalizeAnimatable(out, d); return out; }
function normalizeCamera(c, d) { const out = deepMerge(createCameraTrack(), c || {}); normalizeAnimatable(out, d); return out; }
function normalizeClip(c, d) {
    const base = createProjectile(), original = c || {}, out = deepMerge(base, original);
    Object.keys(c || {}).forEach(k => delete c[k]);
    Object.assign(c, out);
    normalizeAnimatable(c, d);
    c.type = original.type || c.type || "projectile";
    c.fxOps = Array.isArray(c.fxOps) ? c.fxOps : [];
    c.logic = Array.isArray(c.logic) ? c.logic : [];
}
function normalizeAnimatable(o, d) {
    var _a;
    o.id || (o.id = uid("obj"));
    o.name || (o.name = "Object");
    o.enabled = o.enabled !== false;
    o.visual || (o.visual = {});
    o.visual.size = clampNumber(o.visual.size, 1, 1600, 100);
    o.visual.scaleX = clampNumber(o.visual.scaleX, -1600, 1600, 100);
    o.visual.scaleY = clampNumber(o.visual.scaleY, -1600, 1600, 100);
    o.visual.opacity = clampNumber(o.visual.opacity, 0, 100, 100);
    o.visual.rotation = Number(o.visual.rotation || 0);
    o.visual.z = Number(o.visual.z || 0);
    o.visual.blend = Number(o.visual.blend || 0);
    o.visual.flip = Number(o.visual.flip || 0);
    o.valueKeys = Object.assign(Object.assign({}, defaultValueKeys()), (o.valueKeys || {}));
    o.visibleKeys = Array.isArray(o.visibleKeys) && o.visibleKeys.length ? o.visibleKeys : [{ id: uid("vkey"), frame: 0, value: true }];
    if (!Array.isArray(o.positionKeys) || !o.positionKeys.length)
        o.positionKeys = [{ id: uid("key"), frame: 0, easing: "ease_both", point: point("screen", 256, 192) }];
    for (const k of o.positionKeys) {
        k.id || (k.id = uid("key"));
        k.frame = clampNumber(k.frame, 0, d, 0);
        k.easing || (k.easing = "ease_both");
        k.point || (k.point = point());
        (_a = k.point).anchor || (_a.anchor = "screen");
    }
    o.fxOps = Array.isArray(o.fxOps) ? o.fxOps : [];
    o.logic = Array.isArray(o.logic) ? o.logic : [];
    recalcObjectBounds(o);
}
export function cloneClipForLibrary(clip, name = (clip === null || clip === void 0 ? void 0 : clip.name) || "Clip") {
    const c = structuredCloneSafe(clip);
    c.id = uid("cliplib");
    c.name = name;
    return c;
}
export function instantiateReusableClip(saved) {
    const c = structuredCloneSafe(saved);
    c.id = uid("clip");
    for (const k of c.positionKeys || [])
        k.id = uid("key");
    for (const arr of Object.values(c.valueKeys || {}))
        for (const k of arr || [])
            k.id = uid("pkey");
    for (const k of c.visibleKeys || [])
        k.id = uid("vkey");
    return c;
}
