// Ruby Marshal 4.8 reader specialised for RPG Maker XP / Pokémon Essentials
// animation data. It intentionally has no dependency on Ruby or the game runtime.
const td = new TextDecoder("utf-8", { fatal: false });
class MarshalReader {
    constructor(bytes) {
        this.b = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
        this.p = 0;
        this.symbols = [];
        this.objects = [];
    }
    byte() { if (this.p >= this.b.length)
        throw new Error("Unexpected end of Ruby Marshal data"); return this.b[this.p++]; }
    signedByte() { const n = this.byte(); return n >= 128 ? n - 256 : n; }
    bytes(n) { const end = this.p + n; if (end > this.b.length)
        throw new Error("Unexpected end of Ruby Marshal data"); const out = this.b.slice(this.p, end); this.p = end; return out; }
    fixnum() {
        const c = this.signedByte();
        if (c === 0)
            return 0;
        if (c > 4)
            return c - 5;
        if (c < -4)
            return c + 5;
        const n = Math.abs(c);
        let v = 0n;
        for (let i = 0; i < n; i++)
            v |= BigInt(this.byte()) << BigInt(8 * i);
        if (c < 0)
            v -= 1n << BigInt(8 * n);
        const num = Number(v);
        return Number.isSafeInteger(num) ? num : num;
    }
    rawString() { const n = this.fixnum(); if (n < 0)
        throw new Error("Invalid Ruby Marshal string length"); return td.decode(this.bytes(n)); }
    register(v) { this.objects.push(v); return v; }
    attachIvars(v, ivars) {
        if (v && (typeof v === "object" || typeof v === "function")) {
            const dst = v.__ivars || (v.__ivars = {});
            Object.assign(dst, ivars);
        }
        return v;
    }
    value() {
        const tag = String.fromCharCode(this.byte());
        switch (tag) {
            case "0": return null;
            case "T": return true;
            case "F": return false;
            case "i": return this.fixnum();
            case "f": {
                const s = this.rawString();
                const n = Number(s);
                const v = Number.isNaN(n) ? (s === "nan" ? NaN : s === "inf" ? Infinity : s === "-inf" ? -Infinity : 0) : n;
                this.register(v);
                return v;
            }
            case ":": {
                const s = this.rawString();
                this.symbols.push(s);
                return s;
            }
            case ";": {
                const i = this.fixnum();
                if (i < 0 || i >= this.symbols.length)
                    throw new Error(`Bad symbol link ${i}`);
                return this.symbols[i];
            }
            case "@": {
                const i = this.fixnum();
                if (i < 0 || i >= this.objects.length)
                    throw new Error(`Bad object link ${i}`);
                return this.objects[i];
            }
            case "\"": {
                const s = this.rawString();
                this.register(s);
                return s;
            }
            case "[": {
                const a = this.register([]), n = this.fixnum();
                for (let i = 0; i < n; i++)
                    a.push(this.value());
                return a;
            }
            case "{": {
                const m = this.register(new Map()), n = this.fixnum();
                for (let i = 0; i < n; i++)
                    m.set(this.value(), this.value());
                return m;
            }
            case "}": {
                const m = this.register(new Map()), n = this.fixnum();
                for (let i = 0; i < n; i++)
                    m.set(this.value(), this.value());
                m.__default = this.value();
                return m;
            }
            case "o": {
                const klass = this.value();
                const o = this.register({ __rubyClass: String(klass || "Object"), __ivars: {} });
                const n = this.fixnum();
                for (let i = 0; i < n; i++)
                    o.__ivars[String(this.value())] = this.value();
                return o;
            }
            case "I": {
                const v = this.value(), n = this.fixnum(), ivars = {};
                for (let i = 0; i < n; i++)
                    ivars[String(this.value())] = this.value();
                return this.attachIvars(v, ivars);
            }
            case "C": {
                const klass = String(this.value() || "");
                const v = this.value();
                if (v && typeof v === "object")
                    v.__rubyClass = klass;
                return v;
            }
            case "e": {
                const mod = String(this.value() || "");
                const v = this.value();
                if (v && typeof v === "object")
                    (v.__rubyExtensions || (v.__rubyExtensions = [])).push(mod);
                return v;
            }
            case "u": {
                const klass = String(this.value() || ""), n = this.fixnum();
                return this.register({ __rubyClass: klass, __raw: this.bytes(n) });
            }
            case "U": {
                const klass = String(this.value() || ""), data = this.value();
                return this.register({ __rubyClass: klass, __marshalData: data });
            }
            case "l": {
                const sign = String.fromCharCode(this.byte()), words = this.fixnum();
                let v = 0n;
                for (let i = 0; i < words * 2; i++)
                    v |= BigInt(this.byte()) << BigInt(8 * i);
                if (sign === "-")
                    v = -v;
                return Number(v);
            }
            case "/": {
                const source = this.rawString(), options = this.byte();
                return this.register({ __rubyClass: "Regexp", source, options });
            }
            default: throw new Error(`Unsupported Ruby Marshal tag ${JSON.stringify(tag)} at 0x${(this.p - 1).toString(16)}`);
        }
    }
    read() {
        const major = this.byte(), minor = this.byte();
        if (major !== 4 || minor !== 8)
            throw new Error(`Unsupported Ruby Marshal version ${major}.${minor}`);
        return this.value();
    }
}
function iv(o, name, fallback = null) {
    var _a, _b, _c;
    if (!o || typeof o !== "object")
        return fallback;
    const v = (_b = (_a = o.__ivars) === null || _a === void 0 ? void 0 : _a[name]) !== null && _b !== void 0 ? _b : (_c = o.__ivars) === null || _c === void 0 ? void 0 : _c[`@${String(name).replace(/^@/, "")}`];
    return v === undefined ? fallback : v;
}
function num(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }
function cleanName(v) { return String(v !== null && v !== void 0 ? v : "").replace(/\0/g, "").trim(); }
function rawArray(o) { return Array.isArray(iv(o, "@array")) ? iv(o, "@array") : (Array.isArray(o) ? o : []); }
function plainIvars(o) {
    const out = {};
    for (const [k, v] of Object.entries((o === null || o === void 0 ? void 0 : o.__ivars) || {}))
        out[String(k).replace(/^@/, "")] = v;
    return out;
}
function decodeFourDoubles(raw) {
    const b = raw === null || raw === void 0 ? void 0 : raw.__raw;
    if (!(b instanceof Uint8Array) || b.byteLength < 32)
        return null;
    const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
    return [0, 8, 16, 24].map(off => dv.getFloat64(off, true));
}
function normalizeTiming(t) {
    const h = plainIvars(t), color = decodeFourDoubles(h.flashColor);
    return {
        type: num(h.timingType, 0), frame: num(h.frame, 0), name: cleanName(h.name), volume: num(h.volume, 100), pitch: num(h.pitch, 100),
        flashScope: num(h.flashScope, 0), flashDuration: num(h.flashDuration, 0), flashColor: color,
        duration: num(h.duration, 0), opacity: num(h.opacity, 0), x: num(h.bgX, 0), y: num(h.bgY, 0),
        color: [num(h.colorRed, 0), num(h.colorGreen, 0), num(h.colorBlue, 0), num(h.colorAlpha, 0)]
    };
}
export const LEGACY_ANIMFRAME = Object.freeze({
    x: 0, y: 1, zoomx: 2, angle: 3, mirror: 4, blendtype: 5,
    pattern: 7, opacity: 8, zoomy: 11,
    colorred: 12, colorgreen: 13, colorblue: 14, coloralpha: 15,
    tonered: 16, tonegreen: 17, toneblue: 18, tonegray: 19,
    visible: 6, locked: 20, flashred: 21, flashgreen: 22, flashblue: 23, flashalpha: 24, priority: 25, focus: 26
});
export function parseRubyMarshal(bytes) { return new MarshalReader(bytes).read(); }
export function parseLegacyAnimationsRxdata(bytes, sourcePath = "PkmnAnimations.rxdata") {
    const top = parseRubyMarshal(bytes), source = rawArray(top), animations = [];
    for (let id = 0; id < source.length; id++) {
        const x = source[id];
        if (!x || typeof x !== "object")
            continue;
        const frames = rawArray(x);
        const name = cleanName(iv(x, "@name", ""));
        animations.push({
            id, name, animation_name: cleanName(iv(x, "@graphic", "")), graphic: cleanName(iv(x, "@graphic", "")),
            position: num(iv(x, "@position", 3), 3), hue: num(iv(x, "@hue", 0), 0), scope: num(iv(x, "@scope", 0), 0),
            frames, frame_max: frames.length, timing: (iv(x, "@timing", []) || []).map(normalizeTiming), _animframe: Object.assign({}, LEGACY_ANIMFRAME), sourcePath
        });
    }
    return animations;
}
export function parseMove2AnimDat(bytes) {
    const root = parseRubyMarshal(bytes);
    const normal = (root === null || root === void 0 ? void 0 : root[0]) instanceof Map ? root[0] : new Map();
    const opposing = (root === null || root === void 0 ? void 0 : root[1]) instanceof Map ? root[1] : new Map();
    return { normal, opposing };
}
function meaningfulLegacy(rec) {
    if (!(rec === null || rec === void 0 ? void 0 : rec.name) || !Array.isArray(rec.frames) || rec.frames.length <= 1)
        return false;
    return !/^~.*~$/.test(rec.name.trim());
}
function prefixedName(name) {
    const m = String(name || "").match(/^(Common|Move|OppMove)\s*:\s*(.+)$/i);
    if (!m)
        return null;
    return { prefix: m[1].toLowerCase(), value: m[2].trim() };
}
// Reproduces the legacy-to-new grouping used by New Animation Editor:
// Move/OppMove/Common prefixes begin a family; following bare names are versions.
export function buildLegacyCatalog(animations, move2anim = null) {
    const normalByIndex = new Map(), oppByIndex = new Map();
    for (const [move, idx] of (move2anim === null || move2anim === void 0 ? void 0 : move2anim.normal) || [])
        normalByIndex.set(Number(idx), String(move));
    for (const [move, idx] of (move2anim === null || move2anim === void 0 ? void 0 : move2anim.opposing) || [])
        oppByIndex.set(Number(idx), String(move));
    const moves = new Map(), common = new Map(), records = [];
    let last = null;
    for (const rec of animations || []) {
        if (!meaningfulLegacy(rec))
            continue;
        const p = prefixedName(rec.name);
        let type, move, version = 0, label;
        if (p) {
            type = p.prefix === "common" ? "common" : p.prefix === "oppmove" ? "opp_move" : "move";
            move = p.value;
            version = 0;
            last = { type, move, version: 0 };
            label = p.value;
        }
        else if (last) {
            type = last.type;
            move = last.move;
            version = ++last.version;
            label = rec.name;
        }
        else {
            // move2anim.dat can still identify old entries whose name has no prefix.
            const mappedOpp = oppByIndex.get(Number(rec.id)), mapped = normalByIndex.get(Number(rec.id));
            if (!mapped && !mappedOpp)
                continue;
            type = mappedOpp ? "opp_move" : "move";
            move = mappedOpp || mapped;
            version = 0;
            label = rec.name || move;
            last = { type, move, version };
        }
        const mappedMove = type === "opp_move" ? oppByIndex.get(Number(rec.id)) : normalByIndex.get(Number(rec.id));
        if (mappedMove && version === 0)
            move = mappedMove;
        const item = Object.assign(Object.assign({}, rec), { catalogType: type, move, version, label: label || move, opposing: type === "opp_move" });
        records.push(item);
        const target = type === "common" ? common : moves;
        const key = type === "common" ? move : move;
        if (!target.has(key))
            target.set(key, []);
        target.get(key).push(item);
    }
    const sortVersions = arr => arr.sort((a, b) => Number(a.opposing) - Number(b.opposing) || a.version - b.version || a.id - b.id);
    for (const arr of moves.values())
        sortVersions(arr);
    for (const arr of common.values())
        sortVersions(arr);
    return { moves, common, records };
}
export function catalogToSerializable(catalog) {
    const conv = map => [...map.entries()].map(([name, versions]) => ({ name, versions: versions.map(v => ({ id: v.id, name: v.name, label: v.label, version: v.version, opposing: v.opposing, move: v.move })) }));
    return { moves: conv(catalog.moves), common: conv(catalog.common) };
}
