# Battle Animation Studio v1.5.1

Iteración centrada en los gráficos de las animaciones importadas:

- **Localización de gráficos al importar**: tras importar una animación (PBS, RXDATA, Ruby, captura o .animpack), el Studio revisa cada gráfico referenciado (partículas, `setBitmap` switches y máscaras PBS). Los que no existan en el proyecto se ofrecen en un diálogo:
  - **Importar fuente**: copia el archivo exacto desde el juego de origen a `Graphics/` (con dedupe de nombres y carpeta raíz según el formato de origen).
  - **Usar similar**: enlaza un gráfico con nombre parecido que ya esté en el proyecto (con miniaturas de comparación y acciones masivas).
  - Los gráficos resueltos se guardan en `animations.json` y el preview siempre carga la copia local, sin depender del juego de origen.
- v1.5.1: la búsqueda de similar/nativo ya no agarra cualquier cosa: el emparejamiento se hace sobre el nombre de archivo (sin palabras genéricas de carpeta), prioriza la carpeta raíz correcta (`Battle animations` / `Animations` / `BattleParticlesAnimations`) y la raíz de origen, y descarta coincidencias de una sola palabra genérica. `resolveLegacyGraphic` también prefiere carpeta → raíz de origen → cualquier raíz.
- v1.4: quita duplicados de battlers en imports Ruby estáticos (`addSprite(us/ts)` queda como proxy no renderizado), Ctrl+Z/Ctrl+Y, dialecto EBDX/Luka, biblioteca Moves/Common separada y captura exacta.

## Instalación

1. Borra por completo la carpeta anterior `Battle Animation Studio`.
2. Copia la carpeta nueva.
3. Abre Maker Studio.
4. Instala el bridge desde **Contexto → Instalar/actualizar Preview Bridge v1.4**.
5. Reinicia el juego.

## Rutas

Editable del Studio: `PBS/AnimationStudio/animations.json`  
Compilado para el juego: `PBS/AnimationStudio/compiled_animations.json`  
Runtime: `Plugins/Battle Animation Studio Runtime/001_Runtime.rb`

## Límite honesto

El importador EBDX/Ruby estático ya interpreta más estructuras reales, pero EBDX y BattleAnimations son Ruby ejecutable. Cualquier animación que dependa de callbacks complejos, `rand`, `@vector`, `@scene`, wrappers o estado real de batalla solo puede igualarse bien con captura runtime, porque ahí se registra lo que ejecuta Essentials frame por frame.
