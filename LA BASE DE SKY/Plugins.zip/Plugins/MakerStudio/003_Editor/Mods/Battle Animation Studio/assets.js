const IMAGE_EXTS = new Set(["png", "bmp", "jpg", "jpeg", "webp", "gif"]);
export const ANIMATION_ASSET_ROOTS = [
    { id: "new", label: "New Animation Editor", projectPath: "Graphics/Battle animations" },
    { id: "legacy", label: "Vanilla / Legacy", projectPath: "Graphics/Animations" },
    { id: "code", label: "BattleAnimations / Code", projectPath: "Graphics/BattleParticlesAnimations" }
];
function norm(path) { return String(path || "").replace(/\\/g, "/").replace(/\/{2,}/g, "/").replace(/\/$/, ""); }
function join(...parts) { return norm(parts.filter(Boolean).join("/")); }
function extOf(name) { const m = String(name || "").match(/\.([^.]+)$/); return m ? m[1].toLowerCase() : ""; }
function stemOf(name) { return String(name || "").replace(/\.[^.]+$/, ""); }
function mimeFor(path) {
    const ext = extOf(path);
    if (ext === "jpg" || ext === "jpeg")
        return "image/jpeg";
    if (ext === "bmp")
        return "image/bmp";
    if (ext === "webp")
        return "image/webp";
    if (ext === "gif")
        return "image/gif";
    return "image/png";
}
export function absoluteProjectPath(ctx, projectPath) {
    var _a, _b;
    const root = norm(((_b = (_a = ctx.editor).gameRoot) === null || _b === void 0 ? void 0 : _b.call(_a)) || "");
    if (!root)
        return "";
    return join(root, projectPath);
}
async function invoke(name, args) {
    var _a, _b;
    const fn = (_b = (_a = window.__TAURI__) === null || _a === void 0 ? void 0 : _a.core) === null || _b === void 0 ? void 0 : _b.invoke;
    if (!fn)
        throw new Error("Tauri invoke is unavailable");
    return await fn(name, args);
}
export async function readAbsoluteText(path) {
    if (!path)
        throw new Error("Missing external file path");
    return await invoke("read_text_file", { path });
}
export async function readAbsoluteBinary(path) {
    if (!path)
        throw new Error("Missing external file path");
    const bytes = await invoke("read_binary_file", { path });
    return bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
}
export async function loadAbsoluteImageUrl(path) {
    if (!path)
        return null;
    let bytes;
    try {
        bytes = await invoke("read_binary_file", { path });
    }
    catch (_a) {
        return null;
    }
    if (!bytes || !bytes.length)
        return null;
    const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    return URL.createObjectURL(new Blob([arr], { type: mimeFor(path) }));
}
function dirname(path) {
    const p = norm(path);
    const i = p.lastIndexOf("/");
    return i >= 0 ? p.slice(0, i) : "";
}
export async function detectExternalGameRoot(filePath) {
    let dir = dirname(filePath);
    for (let depth = 0; depth < 12 && dir; depth++) {
        const hasGraphics = await existsAbsolute(join(dir, "Graphics"));
        const hasProjectMarker = (await existsAbsolute(join(dir, "Game.rxproj"))) ||
            (await existsAbsolute(join(dir, "Game.exe"))) ||
            (await existsAbsolute(join(dir, "Data"))) ||
            (await existsAbsolute(join(dir, "PBS"))) ||
            (await existsAbsolute(join(dir, "Plugins")));
        if (hasGraphics && hasProjectMarker)
            return dir;
        const parent = dirname(dir);
        if (!parent || parent === dir)
            break;
        dir = parent;
    }
    return "";
}
export async function resolveExternalGraphicPath(gameRoot, graphic = {}) {
    if (!gameRoot)
        return "";
    const exts = ["", ".png", ".bmp", ".jpg", ".jpeg", ".webp", ".gif"];
    const candidates = [];
    const add = (value) => {
        const v = String(value || "").trim().replace(/^\/+/, "").replace(/\\/g, "/");
        if (!v)
            return;
        candidates.push(v);
        const stripped = v.replace(/\[\s*bottom\s*\]\s*$/i, "").trim();
        if (stripped && stripped !== v)
            candidates.push(stripped);
    };
    for (const c of graphic.assetCandidates || [])
        add(c);
    add(graphic.projectPath || graphic.externalRelativePath || "");
    const hint = String(graphic.relativeHint || "").replace(/^\/+/, "").replace(/\\/g, "/").trim();
    const name = String(graphic.name || "").trim();
    const folder = String(graphic.folder || "");
    if (hint) {
        if (/^Graphics\//i.test(hint))
            add(hint);
        add(join("Graphics/Battle animations", hint));
        add(join("Graphics/Animations", hint));
        add(join("Graphics/BattleParticlesAnimations", hint));
    }
    if (name) {
        if (folder)
            add(join("Graphics", folder, name));
        add(join("Graphics/Battle animations", name));
        add(join("Graphics/Animations", name));
        add(join("Graphics/BattleParticlesAnimations", name));
    }
    const seen = new Set();
    for (const rel of candidates) {
        if (!rel || seen.has(rel.toLowerCase()))
            continue;
        seen.add(rel.toLowerCase());
        const alreadyExt = !!extOf(rel);
        for (const ext of alreadyExt ? [""] : exts) {
            const abs = join(gameRoot, rel + ext);
            if (await existsAbsolute(abs))
                return abs;
        }
    }
    return "";
}
async function listAbsolute(path) {
    return await invoke("list_directory", { path });
}
async function existsAbsolute(path) {
    try {
        return !!(await invoke("file_exists", { path }));
    }
    catch (_a) {
        return false;
    }
}
function entryFlags(entry) {
    var _a, _b, _c, _d, _e;
    const isDir = !!((_c = (_b = (_a = entry === null || entry === void 0 ? void 0 : entry.isDir) !== null && _a !== void 0 ? _a : entry === null || entry === void 0 ? void 0 : entry.is_dir) !== null && _b !== void 0 ? _b : entry === null || entry === void 0 ? void 0 : entry.isDirectory) !== null && _c !== void 0 ? _c : entry === null || entry === void 0 ? void 0 : entry.is_directory);
    const isFile = !!((_e = (_d = entry === null || entry === void 0 ? void 0 : entry.isFile) !== null && _d !== void 0 ? _d : entry === null || entry === void 0 ? void 0 : entry.is_file) !== null && _e !== void 0 ? _e : (!isDir && (entry === null || entry === void 0 ? void 0 : entry.name)));
    return { isDir, isFile };
}
export async function scanImageRoot(ctx, rootProjectPath, source = "custom", label = "Graphics", maxDepth = 12) {
    const rootAbs = absoluteProjectPath(ctx, rootProjectPath);
    if (!rootAbs || !(await existsAbsolute(rootAbs)))
        return [];
    const out = [];
    async function walk(absDir, relDir, depth) {
        if (depth > maxDepth)
            return;
        let entries = [];
        try {
            entries = await listAbsolute(absDir);
        }
        catch (_a) {
            return;
        }
        for (const entry of entries || []) {
            const name = (entry === null || entry === void 0 ? void 0 : entry.name) || norm(entry === null || entry === void 0 ? void 0 : entry.path).split("/").pop();
            if (!name)
                continue;
            const flags = entryFlags(entry);
            const abs = norm((entry === null || entry === void 0 ? void 0 : entry.path) || join(absDir, name));
            const rel = join(relDir, name);
            if (flags.isDir) {
                await walk(abs, rel, depth + 1);
            }
            else if (flags.isFile && IMAGE_EXTS.has(extOf(name))) {
                out.push({
                    source,
                    sourceLabel: label,
                    projectPath: join(rootProjectPath, rel),
                    rootProjectPath,
                    relativePath: rel,
                    name: stemOf(name),
                    filename: name,
                    extension: extOf(name)
                });
            }
        }
    }
    await walk(rootAbs, "", 0);
    out.sort((a, b) => a.relativePath.localeCompare(b.relativePath, undefined, { numeric: true, sensitivity: "base" }));
    return out;
}
export async function scanAnimationAssets(ctx) {
    const groups = await Promise.all(ANIMATION_ASSET_ROOTS.map((root) => scanImageRoot(ctx, root.projectPath, root.id, root.label)));
    return groups.flat();
}
export async function scanBattlerAssets(ctx, side) {
    const roots = side === "user"
        ? ["Graphics/Pokemon/Back", "Graphics/EBDX/Battlers/Back"]
        : ["Graphics/Pokemon/Front", "Graphics/EBDX/Battlers/Front"];
    const groups = [];
    for (const root of roots)
        groups.push(...await scanImageRoot(ctx, root, side === "user" ? "battler-user" : "battler-target", side === "user" ? "User battlers" : "Target battlers"));
    const seen = new Set(), out = [];
    for (const item of groups) {
        const key = String(item.projectPath || item.relativePath || "").toLowerCase();
        if (seen.has(key))
            continue;
        seen.add(key);
        out.push(item);
    }
    return out;
}
export async function scanUiAssets(ctx) {
    return await scanImageRoot(ctx, "Graphics/UI", "ui", "UI");
}
export async function loadProjectImageUrl(ctx, projectPath) {
    const abs = absoluteProjectPath(ctx, projectPath);
    if (!abs)
        return null;
    let bytes;
    try {
        bytes = await invoke("read_binary_file", { path: abs });
    }
    catch (_a) {
        return null;
    }
    if (!bytes || !bytes.length)
        return null;
    const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    return URL.createObjectURL(new Blob([arr], { type: mimeFor(projectPath) }));
}
export async function resolveImageByStem(ctx, rootProjectPath, stem) {
    if (!stem)
        return null;
    const files = await scanImageRoot(ctx, rootProjectPath, "resolve", rootProjectPath);
    const wanted = String(stem).toLowerCase();
    return files.find((item) => item.name.toLowerCase() === wanted) || null;
}
export async function resolveLegacyGraphic(ctx, graphic, cachedAssets = null) {
    if (!graphic)
        return null;
    if (graphic.projectPath)
        return { projectPath: graphic.projectPath, name: graphic.name || stemOf(graphic.projectPath), source: graphic.source || "custom" };
    const sourceRoot = ANIMATION_ASSET_ROOTS.find((root) => root.id === graphic.source)
        || ANIMATION_ASSET_ROOTS.find((root) => root.projectPath.toLowerCase().endsWith(`/${String(graphic.folder || "").toLowerCase()}`));
    const assets = cachedAssets || await scanAnimationAssets(ctx);
    const folder = String(graphic.folder || "").toLowerCase();
    const name = String(graphic.name || "").toLowerCase();
    const hintRaw = String(graphic.relativeHint || "").replace(/\\/g, "/").replace(/\.[^.]+$/, "").trim().toLowerCase();
    const hint = hintRaw;
    const hintStripped = hintRaw.replace(/\[\s*bottom\s*\]\s*$/i, "").trim();
    const hinted = hint ? assets.find((item) => { const rel = item.relativePath.replace(/\.[^.]+$/, "").trim().toLowerCase(); const proj = item.projectPath.replace(/^Graphics\/Battle animations\//i, "").replace(/\.[^.]+$/, "").trim().toLowerCase(); return rel === hint || proj === hint || rel === hintStripped || proj === hintStripped; }) : null;
    // Same-name assets exist in several roots; prefer the one in the graphic's
    // own folder, then its source root, and only then any other root.
    const byName = assets.filter((item) => item.name.toLowerCase() === name);
    const match = hinted
        || (folder ? byName.find((item) => item.rootProjectPath.toLowerCase().endsWith(`/${folder}`) || item.projectPath.toLowerCase().includes(`/${folder}/`)) : null)
        || (sourceRoot ? byName.find((item) => item.source === sourceRoot.id) : null)
        || byName[0] || null;
    return match || null;
}
export function compactProjectPath(path) {
    const p = norm(path);
    return p.startsWith("Graphics/") ? p.slice("Graphics/".length) : p;
}
// Generic recursive project scanner used by the animation importers.
export async function scanProjectFiles(ctx, rootProjectPath, extensions = ["txt"], maxDepth = 12) {
    const wanted = new Set((extensions || []).map((x) => String(x).replace(/^\./, "").toLowerCase()));
    const rootAbs = absoluteProjectPath(ctx, rootProjectPath);
    if (!rootAbs || !(await existsAbsolute(rootAbs)))
        return [];
    const out = [];
    async function walk(absDir, relDir, depth) {
        if (depth > maxDepth)
            return;
        let entries = [];
        try {
            entries = await listAbsolute(absDir);
        }
        catch (_a) {
            return;
        }
        for (const entry of entries || []) {
            const name = (entry === null || entry === void 0 ? void 0 : entry.name) || norm(entry === null || entry === void 0 ? void 0 : entry.path).split("/").pop();
            if (!name)
                continue;
            const flags = entryFlags(entry);
            const abs = norm((entry === null || entry === void 0 ? void 0 : entry.path) || join(absDir, name));
            const rel = join(relDir, name);
            if (flags.isDir)
                await walk(abs, rel, depth + 1);
            else if (flags.isFile && wanted.has(extOf(name)))
                out.push({ projectPath: join(rootProjectPath, rel), relativePath: rel, name: stemOf(name), filename: name, extension: extOf(name) });
        }
    }
    await walk(rootAbs, "", 0);
    return out.sort((a, b) => a.relativePath.localeCompare(b.relativePath, undefined, { numeric: true, sensitivity: "base" }));
}
// Recursive scanner for an arbitrary external folder selected by the user.
export async function scanAbsoluteFiles(rootPath, extensions = ["txt"], maxDepth = 14) {
    const wanted = new Set((extensions || []).map((x) => String(x).replace(/^\./, "").toLowerCase()));
    const root = norm(rootPath || "");
    if (!root || !(await existsAbsolute(root)))
        return [];
    const out = [];
    async function walk(absDir, relDir, depth) {
        if (depth > maxDepth)
            return;
        let entries = [];
        try {
            entries = await listAbsolute(absDir);
        }
        catch (_a) {
            return;
        }
        for (const entry of entries || []) {
            const name = (entry === null || entry === void 0 ? void 0 : entry.name) || norm(entry === null || entry === void 0 ? void 0 : entry.path).split("/").pop();
            if (!name)
                continue;
            const flags = entryFlags(entry);
            const abs = norm((entry === null || entry === void 0 ? void 0 : entry.path) || join(absDir, name));
            const rel = join(relDir, name);
            if (flags.isDir)
                await walk(abs, rel, depth + 1);
            else if (flags.isFile && wanted.has(extOf(name)))
                out.push({ absolutePath: abs, relativePath: rel, name: stemOf(name), filename: name, extension: extOf(name) });
        }
    }
    await walk(root, "", 0);
    return out.sort((a, b) => a.relativePath.localeCompare(b.relativePath, undefined, { numeric: true, sensitivity: "base" }));
}
// Battle scene backdrop/base browser. Essentials convention:
// <stem>_bg, <stem>_base0 and <stem>_base1 in Graphics/Battlebacks.
export async function scanBattlebackAssets(ctx) {
    const files = await scanImageRoot(ctx, "Graphics/Battlebacks", "battleback", "Battlebacks", 6);
    const groups = new Map();
    for (const file of files) {
        const stem = file.name;
        let key = stem, role = "other";
        if (/_bg$/i.test(stem)) {
            key = stem.replace(/_bg$/i, "");
            role = "background";
        }
        else if (/_base0$/i.test(stem)) {
            key = stem.replace(/_base0$/i, "");
            role = "playerBase";
        }
        else if (/_base1$/i.test(stem)) {
            key = stem.replace(/_base1$/i, "");
            role = "enemyBase";
        }
        if (!groups.has(key))
            groups.set(key, { key, label: key, background: null, playerBase: null, enemyBase: null, files: [] });
        const g = groups.get(key);
        g.files.push(file);
        if (role !== "other")
            g[role] = file;
    }
    return { files, groups: [...groups.values()].sort((a, b) => a.key.localeCompare(b.key, undefined, { numeric: true, sensitivity: "base" })) };
}
export async function scanAbsoluteImages(rootPath, maxDepth = 10) {
    const files = await scanAbsoluteFiles(rootPath, [...IMAGE_EXTS], maxDepth);
    return files.filter(f => IMAGE_EXTS.has(f.extension));
}
