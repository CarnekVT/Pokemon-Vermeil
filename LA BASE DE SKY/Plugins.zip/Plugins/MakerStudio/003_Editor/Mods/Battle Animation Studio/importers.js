import { createAnimation, createProjectile, getEffectsTrack, getBattlerTrack, setPositionKey, setValueKey, setVisibleKey, sortPositionKeys, sampleValue, uid } from "./model.js";
function splitCsv(line) {
    const out = [];
    let cur = "", q = false, quote = "";
    for (let i = 0; i < String(line || "").length; i++) {
        const c = line[i];
        if ((c === '"' || c === "'") && (!q || quote === c)) {
            q = !q;
            quote = q ? c : "";
            continue;
        }
        if (c === ',' && !q) {
            out.push(cur.trim());
            cur = "";
        }
        else
            cur += c;
    }
    out.push(cur.trim());
    return out;
}
function stripComment(line) { let q = false, quote = ""; for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if ((c === '"' || c === "'") && (!q || quote === c)) {
        q = !q;
        quote = q ? c : "";
    }
    if (c === "#" && !q)
        return line.slice(0, i);
} return line; }
function bool(v) { return /^(true|1|yes)$/i.test(String(v).trim()); }
function num(v, f = 0) { const n = Number(v); return Number.isFinite(n) ? n : f; }
function ease(v) { const s = String(v || "").toLowerCase().replace(/[^a-z]/g, ""); if (s === "none")
    return "linear"; if (s.includes("linear"))
    return "linear"; if (s.includes("easein"))
    return "ease_in"; if (s.includes("easeout"))
    return "ease_out"; return "ease_both"; }
function ease01(t, m) { const x = Math.max(0, Math.min(1, t)); if (m === "linear")
    return x; if (m === "ease_in")
    return x * x; if (m === "ease_out")
    return 1 - (1 - x) * (1 - x); return x < .5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2; }
// -----------------------------------------------------------------------------
// New Animation Editor / PBS
// -----------------------------------------------------------------------------
export function parsePbsFile(text, path = "Imported PBS") {
    const sections = [];
    let sec = null, particle = null, order = 0;
    for (const raw of String(text || "").replace(/^\uFEFF/, "").split(/\r?\n/)) {
        const line = stripComment(raw).trim();
        if (!line)
            continue;
        const sm = line.match(/^\[\s*(.+?)\s*\]$/);
        if (sm) {
            const bits = splitCsv(sm[1]);
            sec = { type: bits[0] || "Move", move: bits[1] || "UNKNOWN", version: num(bits[2], 0), name: bits[1] || path, props: {}, particles: [], path };
            sections.push(sec);
            particle = null;
            continue;
        }
        if (!sec)
            continue;
        const pm = line.match(/^<\s*(.+?)\s*>$/);
        if (pm) {
            particle = { name: pm[1].trim(), props: {}, commands: [] };
            sec.particles.push(particle);
            continue;
        }
        const kv = line.match(/^(\w+)\s*=\s*(.*)$/);
        if (!kv)
            continue;
        const key = kv[1], vals = splitCsv(kv[2]);
        if (particle) {
            if (/^(Set|Move|Play)/.test(key))
                particle.commands.push({ key, vals, order: order++ });
            else
                particle.props[key] = vals.length === 1 ? vals[0] : vals;
        }
        else
            sec.props[key] = vals.length === 1 ? vals[0] : vals;
    }
    return sections;
}
const PBS_FOCUS = {
    foreground: "foreground", midground: "midground", background: "background",
    user: "user", userposition: "user_position", target: "target", targetposition: "target_position",
    userandtarget: "user_and_target", userpositionandtarget: "user_position_and_target",
    userandtargetposition: "user_and_target_position", userpositionandtargetposition: "user_position_and_target_position",
    usersideforeground: "user_side_foreground", usersidebackground: "user_side_background",
    targetsideforeground: "target_side_foreground", targetsidebackground: "target_side_background"
};
function pbsFocus(v) { return PBS_FOCUS[String(v || "Foreground").replace(/[^A-Za-z]/g, "").toLowerCase()] || "foreground"; }
function cleanPbsGraphic(raw) { const s = String(raw || "").trim(); const bottom = /\[\s*bottom\s*\]\s*$/i.test(s), stripped = s.replace(/\[\s*bottom\s*\]\s*$/i, "").trim(); return { raw: s, path: s, stripped, bottom }; }
function commandsFor(p, prop, kind = "number") {
    const out = [];
    for (const c of p.commands || []) {
        if (c.key === `Set${prop}`) {
            let value = c.vals[1];
            if (kind === "number")
                value = num(value);
            else if (kind === "bool")
                value = bool(value);
            out.push({ frame: num(c.vals[0]), duration: 0, value, easing: "linear", order: c.order || 0 });
        }
        else if (c.key === `Move${prop}`) {
            let value = c.vals[2];
            if (kind === "number")
                value = num(value);
            else if (kind === "bool")
                value = bool(value);
            out.push({ frame: num(c.vals[0]), duration: Math.max(0, num(c.vals[1])), value, easing: ease(c.vals[3]), order: c.order || 0 });
        }
    }
    return out.sort((a, b) => a.frame - b.frame || a.order - b.order);
}
function commandFrames(cmds) { const s = new Set(); for (const c of cmds) {
    s.add(c.frame);
    s.add(c.frame + c.duration);
} return [...s].sort((a, b) => a - b); }
function sampleCommands(cmds, frame, def = 0) { let state = def; for (const c of cmds) {
    if (frame < c.frame)
        break;
    if (c.duration <= 0) {
        state = c.value;
        continue;
    }
    const end = c.frame + c.duration;
    if (frame < end) {
        const t = ease01((frame - c.frame) / Math.max(.0001, c.duration), c.easing);
        return typeof c.value === "number" ? state + (c.value - state) * t : c.value;
    }
    state = c.value;
} return state; }
function easingStartingAt(cmds, frame) { const c = cmds.find(x => x.frame === frame && x.duration > 0); return (c === null || c === void 0 ? void 0 : c.easing) || "linear"; }
function setValueTimeline(obj, prop, cmds, def = 0, transform = (x) => x) { for (const f of commandFrames(cmds)) {
    setValueKey(obj, prop, f, transform(sampleCommands(cmds, f, def)), easingStartingAt(cmds, f));
} }
function pointForPbsFocus(focus, x, y, p) { return { anchor: `pbs:${focus}`, x, y, offsetX: 0, offsetY: 0, foeInvertX: bool(p.props.FoeInvertX), foeInvertY: bool(p.props.FoeInvertY) }; }
function battlerGraphicSource(g) { const v = String(g || "").toUpperCase(); const map = { USER: "battler-user", USER_OPP: "battler-user-opp", USER_FRONT: "battler-user-front", USER_BACK: "battler-user-back", TARGET: "battler-target", TARGET_OPP: "battler-target-opp", TARGET_FRONT: "battler-target-front", TARGET_BACK: "battler-target-back" }; return map[v] || ""; }
function maxCommandFrame(p) { var _a, _b; let m = 0; for (const c of p.commands || []) {
    const f = num((_a = c.vals) === null || _a === void 0 ? void 0 : _a[0]), d = /^Move/.test(c.key) ? num((_b = c.vals) === null || _b === void 0 ? void 0 : _b[1]) : 0;
    m = Math.max(m, f + d);
} return m; }
export function animationFromPbsSection(section, sourcePath = "") {
    var _a;
    var _b, _c;
    const a = createAnimation(section.props.Name || section.move || "PBS Animation");
    a.tracks[0].clips = [];
    a.source = { type: "pbs", path: sourcePath, move: section.move, version: section.version, native: true, catalogType: /common/i.test(String(section.type || "")) ? "common" : "move", opposing: /opp|foe/i.test(String(section.type || "")) };
    a.fps = num(section.props.FPS, 20) || 20;
    a.events = [];
    a.noUser = bool(section.props.NoUser);
    a.noTarget = bool(section.props.NoTarget);
    a.hidesDataBoxes = bool(section.props.HidesDataBoxes);
    a.credit = String(section.props.Credit || "");
    let maxFrame = 1;
    for (const p of section.particles) {
        maxFrame = Math.max(maxFrame, maxCommandFrame(p));
        if (p.name === "SE") {
            for (const c of p.commands || []) {
                if (c.key === "Play") {
                    a.events.push({ type: "se", frame: num(c.vals[0]), name: String(c.vals[1] || ""), volume: num(c.vals[2], 100), pitch: num(c.vals[3], 100) });
                }
                else if (c.key === "PlayUserCry")
                    a.events.push({ type: "user_cry", frame: num(c.vals[0]) });
                else if (c.key === "PlayTargetCry")
                    a.events.push({ type: "target_cry", frame: num(c.vals[0]) });
            }
            continue;
        }
        const graphicInfo = cleanPbsGraphic(p.props.Graphic || (p.name === "User" ? "USER" : p.name === "Target" ? "TARGET" : ""));
        const isUser = p.name === "User", isTarget = p.name === "Target";
        const obj = isUser ? getBattlerTrack(a, "user") : isTarget ? getBattlerTrack(a, "target") : createProjectile({ id: uid("clip"), name: p.name, type: "pbs-particle" });
        obj.positionKeys = [];
        obj.visibleKeys = [];
        obj.imported = { format: "pbs", focus: pbsFocus(p.props.Focus || (isUser ? "User" : isTarget ? "Target" : "Foreground")), rawProps: Object.assign({}, p.props), pbsBattlerParticle: (isUser || isTarget), graphic: graphicInfo.path };
        obj.pbs = { focus: obj.imported.focus, foeInvertX: bool(p.props.FoeInvertX), foeInvertY: bool(p.props.FoeInvertY), foeFlip: bool(p.props.FoeFlip), tiled: bool(p.props.TiledGraphic), angleOverride: String(p.props.AngleOverride || "None"), secondLayer: bool(p.props.SecondLayer), maskGraphic: String(p.props.MaskGraphic || ""), emitter: String(p.props.Emitter || "None"), emitterRate: num(p.props.EmitterRate, 1), emitterIntensity: num(p.props.EmitterIntensity, 1), randomFrameMax: num(p.props.RandomFrameMax, 0), randomAngleRange: num(p.props.RandomAngleRange, 0), randomInvertAngle: bool(p.props.RandomInvertAngle), randomInvertFlip: bool(p.props.RandomInvertFlip), commands: {}, emitterCommands: {} };
        // Preserve every advanced PBS command. The preview understands mask, second-layer
        // and emitter command families, while unknown commands remain round-trippable.
        const camel = (x) => String(x || "").replace(/^./, m => m.toLowerCase());
        for (const c of p.commands || []) {
            const mm = c.key.match(/^(Set|Move)(.+)$/);
            if (!mm)
                continue;
            const moving = mm[1] === "Move", prop = camel(mm[2]), frame = num(c.vals[0]), duration = moving ? Math.max(0, num(c.vals[1])) : 0, vi = moving ? 2 : 1;
            let value = c.vals[vi];
            if (/Visible|Flip|Invert|Emitting|Clockwise/i.test(mm[2]))
                value = bool(value);
            else if (!/Color|Tone/i.test(mm[2]))
                value = num(value);
            const cmd = { frame, duration, value, easing: moving ? ease(c.vals[vi + 1]) : "linear" };
            // PBS has two timing domains for emitter particles: emitter controls
            // (global animation time) and spawned-particle controls (relative to each
            // emission). Keep that distinction instead of treating similarly named
            // Radius/Zoom commands as the same thing.
            const emitterSuffixMap = {
                Emitting: "emitting",
                EmitX: "emitX", EmitXRange: "emitXRange",
                EmitY: "emitY", EmitYRange: "emitYRange",
                EmitSpeed: "emitSpeed", EmitSpeedRange: "emitSpeedRange",
                EmitAngle: "emitAngle", EmitAngleRange: "emitAngleRange",
                EmitGravity: "emitGravity", EmitGravityRange: "emitGravityRange",
                PeriodX: "emitPeriodX", PeriodXRange: "emitPeriodXRange",
                PeriodY: "emitPeriodY", PeriodYRange: "emitPeriodYRange",
                PeriodZ: "emitPeriodZ", PeriodZRange: "emitPeriodZRange",
                RadiusXRange: "emitRadiusXRange", RadiusYRange: "emitRadiusYRange", RadiusZRange: "emitRadiusZRange",
                Clockwise: "emitClockwise",
                ZoomRange: "emitZoomRange", ZoomXRange: "emitZoomXRange", ZoomYRange: "emitZoomYRange"
            };
            const emitterKey = emitterSuffixMap[mm[2]];
            if (emitterKey) {
                (_b = obj.pbs.emitterCommands)[emitterKey] || (_b[emitterKey] = []);
                obj.pbs.emitterCommands[emitterKey].push(cmd);
            }
            else {
                (_c = obj.pbs.commands)[prop] || (_c[prop] = []);
                obj.pbs.commands[prop].push(cmd);
            }
        }
        for (const map of [obj.pbs.commands, obj.pbs.emitterCommands])
            for (const arr of Object.values(map))
                arr.sort((a, b) => a.frame - b.frame);
        if (!isUser && !isTarget) {
            const special = battlerGraphicSource(graphicInfo.path);
            obj.graphic.source = special || "new";
            obj.graphic.relativeHint = graphicInfo.path;
            obj.graphic.rawName = graphicInfo.raw;
            obj.graphic.assetCandidates = [graphicInfo.path, graphicInfo.stripped].filter(Boolean);
            obj.graphic.name = (graphicInfo.path.split("/").pop() || graphicInfo.path);
            obj.graphic.folder = "Battle animations";
            obj.graphic.projectPath = "";
            obj.graphic.spritesheet = "auto";
            obj.graphic.origin = graphicInfo.bottom ? "bottom" : "auto";
            obj.graphic.specialBattler = graphicInfo.path;
            obj.graphic.maskGraphic = obj.pbs.maskGraphic;
            getEffectsTrack(a).clips.push(obj);
        }
        const xcmd = commandsFor(p, "X"), ycmd = commandsFor(p, "Y");
        let frames = [...new Set([...commandFrames(xcmd), ...commandFrames(ycmd)])].sort((x, y) => x - y);
        if (!frames.length)
            frames = [0];
        const focus = obj.imported.focus;
        for (const f of frames) {
            const x = sampleCommands(xcmd, f, 0), y = sampleCommands(ycmd, f, 0);
            let pt;
            if (isUser)
                pt = { anchor: "user_battler", x: 0, y: 0, offsetX: x, offsetY: y };
            else if (isTarget)
                pt = { anchor: "target_battler", x: 0, y: 0, offsetX: x, offsetY: y };
            else
                pt = pointForPbsFocus(focus, x, y, p);
            setPositionKey(obj, f, pt, easingStartingAt(xcmd, f) !== "linear" ? easingStartingAt(xcmd, f) : easingStartingAt(ycmd, f), pt.anchor);
        }
        obj.fxOps = (p.commands || []).filter(c => /^(Set|Move)(Tone|Color)$/.test(c.key)).map(c => ({ name: c.key, args: c.vals }));
        const zx = commandsFor(p, "ZoomX"), zy = commandsFor(p, "ZoomY"), ang = commandsFor(p, "Angle"), opa = commandsFor(p, "Opacity"), z = commandsFor(p, "Z"), blend = commandsFor(p, "Blending"), flip = commandsFor(p, "Flip", "bool"), inv = commandsFor(p, "InvertColor", "bool"), gf = commandsFor(p, "Frame");
        setValueTimeline(obj, "scaleX", zx, 100);
        setValueTimeline(obj, "scaleY", zy, 100);
        setValueTimeline(obj, "rotation", ang, 0);
        setValueTimeline(obj, "opacity", opa, 255, x => x * 100 / 255);
        setValueTimeline(obj, "z", z, 0);
        setValueTimeline(obj, "blend", blend, 0);
        setValueTimeline(obj, "flip", flip, false, x => x ? 1 : 0);
        setValueTimeline(obj, "invert", inv, false, x => x ? 1 : 0);
        setValueTimeline(obj, "graphicFrame", gf, 0);
        const commandTimes = (p.commands || []).map(c => { var _a; return num((_a = c.vals) === null || _a === void 0 ? void 0 : _a[0], 0); });
        const firstCommand = commandTimes.length ? Math.min(...commandTimes) : 0;
        const isEmitter = String(((_a = obj.pbs) === null || _a === void 0 ? void 0 : _a.emitter) || "None").toLowerCase() !== "none";
        const emitterCommandSuffixes = new Set(["Emitting", "EmitX", "EmitXRange", "EmitY", "EmitYRange", "EmitSpeed", "EmitSpeedRange", "EmitAngle", "EmitAngleRange", "EmitGravity", "EmitGravityRange", "PeriodX", "PeriodXRange", "PeriodY", "PeriodYRange", "PeriodZ", "PeriodZRange", "RadiusXRange", "RadiusYRange", "RadiusZRange", "Clockwise", "ZoomRange", "ZoomXRange", "ZoomYRange"]);
        const hasParticleProcess = (p.commands || []).some(c => { const m = String(c.key || "").match(/^(?:Set|Move)(.+)$/); return m && !emitterCommandSuffixes.has(m[1]); });
        if (isUser || isTarget)
            setVisibleKey(obj, 0, true);
        else if (isEmitter) {
            setVisibleKey(obj, 0, hasParticleProcess);
        }
        else {
            setVisibleKey(obj, 0, false);
            setVisibleKey(obj, firstCommand, true);
        }
        for (const c of p.commands || [])
            if (c.key === "SetVisible")
                setVisibleKey(obj, num(c.vals[0]), bool(c.vals[1]));
        obj.startFrame = 0;
        obj.endFrame = Math.max(maxCommandFrame(p), firstCommand, 0);
    }
    a.duration = Math.max(1, Math.ceil(maxFrame));
    return a;
}
// -----------------------------------------------------------------------------
// Ruby / BattleAnimations static importer
// -----------------------------------------------------------------------------
export function discoverCodeMetadata(text, filename = "") {
    const src = String(text || ""), moves = [], seen = new Set(), add = (id) => { id = String(id || "").trim().replace(/^:/, "").toUpperCase(); if (id && /^[A-Z][A-Z0-9_]*$/.test(id) && !seen.has(id)) {
        seen.add(id);
        moves.push(id);
    } };
    // EBDX/Luka format: EliteBattle.defineMoveAnimation(:MOVE) do ... end
    for (const m of src.matchAll(/EliteBattle\.define(?:Move|Common)Animation\s*\(\s*:([A-Z][A-Z0-9_]*)/g))
        add(m[1]);
    // Newer VERMEIL classes declare their actual move set explicitly.
    for (const m of src.matchAll(/HANDLED_MOVES\s*=\s*\[([\s\S]*?)\]/g))
        for (const x of m[1].matchAll(/:([A-Z][A-Z0-9_]*)/g))
            add(x[1]);
    // Direct comparisons are reliable even outside a case block.
    for (const m of src.matchAll(/\b(?:mid|move_id|@move_id)\s*==\s*:([A-Z][A-Z0-9_]*)\b/g))
        add(m[1]);
    // Only treat `when :MOVE` as a move selector when it belongs to a move case.
    const lines = src.split(/\r?\n/);
    let inMoveCase = false, caseIndent = -1;
    for (const line of lines) {
        const indent = (line.match(/^\s*/) || [""])[0].length, t = line.trim();
        if (!inMoveCase && /^case\s+(?:@move_id|move_id|mid)\b/.test(t)) {
            inMoveCase = true;
            caseIndent = indent;
            continue;
        }
        if (inMoveCase && indent === caseIndent && t === "end") {
            inMoveCase = false;
            continue;
        }
        if (inMoveCase) {
            const m = t.match(/^when\s+:([A-Z][A-Z0-9_]*)\b/);
            if (m)
                add(m[1]);
        }
    }
    let behavior = (src.match(/\bBEHAVIOR\s*=\s*:([a-zA-Z0-9_]+)/) || [])[1] || "cinematic";
    const classes = [...src.matchAll(/^\s*class\s+(?:Battle::Scene::Animation::)?([A-Za-z0-9_:]+)/gm)].map(m => m[1].split("::").pop()).filter(Boolean);
    const signatures = [...src.matchAll(/def\s+initialize\s*\(([^\n)]*)\)/g)].map(m => m[1].split(",").map(x => x.trim()).filter(Boolean));
    // Legacy controller behavior fallbacks used by older VERMEIL files.
    const classText = classes.join(" ");
    if (behavior === "cinematic" && /MultiHit/i.test(classText))
        behavior = "multihit";
    if (behavior === "cinematic" && /(ToxicSpikesCast|SpikesCast|StealthRockCast|StickyWebCast)/i.test(classText))
        behavior = "hazard";
    if (behavior === "cinematic" && /(SelfTarget|Shield)/i.test(classText))
        behavior = "self_targeting";
    // Legacy single-file cinematics often encode the move in the class/file name.
    if (!moves.length) {
        const candidates = [...classes, String(filename || "").replace(/\.rb$/i, "")];
        for (const raw of candidates) {
            let x = String(raw).replace(/^Vermeil(?:Cinematic)?/i, "").replace(/Animation$/i, "").replace(/[^A-Za-z0-9]+/g, "");
            if (x && x.length > 2 && !/^(Common|MultiHit|Priority|Heavy|Ethereal|Elemental|Grass|Battle)$/i.test(x))
                add(x.toUpperCase());
        }
    }
    return { moves, behavior: String(behavior).toLowerCase(), classes, signatures, hasHandledMoves: /HANDLED_MOVES\s*=/.test(src), hasCallbacks: /setCallback\s*\(/.test(src), hasRandom: /\brand\s*\(/.test(src) };
}
export function discoverCodeVariants(text, filename = "") { return discoverCodeMetadata(text, filename).moves; }
// Parses the optional Cinematic Engine Controller dictionary so older animation
// classes can still be associated with every move they handle.
export function discoverCinematicControllerMappings(text) {
    const src = String(text || ""), byClass = new Map(), behaviorByClass = new Map();
    for (const m of src.matchAll(/:([A-Z][A-Z0-9_]*)\s*=>\s*["']([A-Za-z0-9_:]+)["']/g)) {
        const move = m[1], cls = m[2].split("::").pop();
        if (!byClass.has(cls))
            byClass.set(cls, []);
        if (!byClass.get(cls).includes(move))
            byClass.get(cls).push(move);
    }
    const behBlock = (src.match(/def\s+self\.get_behavior[\s\S]*?map\s*=\s*\{([\s\S]*?)\}\s*\n/) || [])[1] || "";
    for (const m of behBlock.matchAll(/["']([A-Za-z0-9_:]+)["']\s*=>\s*:([a-zA-Z0-9_]+)/g))
        behaviorByClass.set(m[1].split("::").pop(), m[2].toLowerCase());
    return { byClass, behaviorByClass };
}
function selectedCodeBranch(text, moveId) {
    if (!moveId)
        return String(text || "");
    const src = String(text || "");
    const marker = new RegExp("EliteBattle\\.define(?:Move|Common)Animation\\s*\\(\\s*:" + String(moveId).replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b", "i");
    const m0 = src.match(marker);
    if (m0) {
        const start = m0.index || 0;
        const chunk = src.slice(start);
        const lines0 = chunk.split(/\r?\n/);
        const out0 = [];
        let depth = 0, began = false;
        for (const line of lines0) {
            out0.push(line);
            const t = line.trim();
            if (/\bdo\b|\{\s*$/.test(t)) { depth++; began = true; }
            if (/^(?:for|if|unless|case|while|until|begin)\b/.test(t)) depth++;
            if (t === "end") {
                depth--;
                if (began && depth <= 0) break;
            }
        }
        return out0.join("\n");
    }
    const lines = src.split(/\r?\n/), out = [];
    let inMoveCase = false, caseIndent = -1, branchIndent = -1, keep = true;
    for (const line of lines) {
        const indent = (line.match(/^\s*/) || [""])[0].length, trim = line.trim();
        if (!inMoveCase && /^case\s+(?:@move_id|move_id|mid)\b/.test(trim)) {
            inMoveCase = true;
            caseIndent = indent;
            branchIndent = indent;
            out.push(line);
            continue;
        }
        if (inMoveCase && indent === branchIndent && /^when\s+:([A-Z][A-Z0-9_]*)\b/.test(trim)) {
            const id = trim.match(/^when\s+:([A-Z][A-Z0-9_]*)\b/)[1];
            keep = id === moveId;
            if (keep)
                out.push(line);
            continue;
        }
        if (inMoveCase && indent === caseIndent && trim === "end") {
            inMoveCase = false;
            keep = true;
            out.push(line);
            continue;
        }
        if (!inMoveCase || keep)
            out.push(line);
    }
    return out.join("\n");
}
function expandForLoops(text) {
    let lines = String(text || "").split(/\r?\n/), passes = 0;
    while (passes++ < 6) {
        let changed = false, out = [];
        for (let i = 0; i < lines.length; i++) {
            const m = lines[i].match(/^(\s*)for\s+([a-z_]\w*)\s+in\s+(-?\d+)\s*(\.\.\.|\.\.)\s*(-?\d+)\s*$/i);
            if (!m) { out.push(lines[i]); continue; }
            const indent = m[1].length, v = m[2], from = Number(m[3]), excl = m[4] === "...", toRaw = Number(m[5]);
            const to = excl ? toRaw - 1 : toRaw;
            let j = i + 1, end = -1, depth = 0;
            for (; j < lines.length; j++) {
                const t = lines[j].trim(), ind = (lines[j].match(/^\s*/) || [""])[0].length;
                if (ind === indent && t === "end" && depth === 0) { end = j; break; }
                if ((/^(?:for|case|if|unless|while|until|begin)\b/.test(t) || /\bdo\s*(?:\||$)/.test(t)) && ind >= indent) depth++;
                if (t === "end" && depth > 0) depth--;
            }
            if (end < 0) { out.push(lines[i]); continue; }
            const body = lines.slice(i + 1, end);
            const step = from <= to ? 1 : -1;
            let n = from, guard = 0;
            while ((step > 0 ? n <= to : n >= to) && guard++ < 160) {
                for (const bl of body) out.push(bl.replace(new RegExp(`\\b${v}\\b`, 'g'), String(n)));
                n += step;
            }
            i = end; changed = true;
        }
        lines = out; if (!changed) break;
    }
    return lines.join("\n");
}

function expandSimpleTimes(text) {
    text = String(text || "").replace(/^(\s*)(\d+)\.times\s*\{\s*\|\s*([a-z_]\w*)\s*\|\s*(.*?)\s*\}\s*$/gmi, (_, ind, count, v, body) => Array.from({ length: Math.min(80, Number(count)) }, (__, i) => ind + body.replace(new RegExp(`\\b${v}\\b`, 'g'), String(i))).join("\n"));
    let lines = String(text || "").split(/\r?\n/), passes = 0;
    while (passes++ < 5) {
        let changed = false, out = [];
        for (let i = 0; i < lines.length; i++) {
            const m = lines[i].match(/^(\s*)(\d+)\.times\s+do\s*\|\s*([a-z_]\w*)\s*\|\s*$/i);
            if (!m) {
                out.push(lines[i]);
                continue;
            }
            const indent = m[1].length, count = Math.min(80, Number(m[2])), v = m[3];
            let j = i + 1, depth = 0, end = -1;
            for (; j < lines.length; j++) {
                const t = lines[j].trim(), ind = (lines[j].match(/^\s*/) || [""])[0].length;
                if (ind === indent && t === "end" && depth === 0) {
                    end = j;
                    break;
                }
                if ((/^(?:case|if|unless|begin)\b/.test(t) || /\bdo\s*(?:\||$)/.test(t)) && ind >= indent)
                    depth++;
                if (t === "end" && depth > 0)
                    depth--;
            }
            if (end < 0) {
                out.push(lines[i]);
                continue;
            }
            const body = lines.slice(i + 1, end);
            for (let n = 0; n < count; n++)
                for (const bl of body)
                    out.push(bl.replace(new RegExp(`\\b${v}\\b`, 'g'), String(n)));
            i = end;
            changed = true;
        }
        lines = out;
        if (!changed)
            break;
    }
    return lines.join("\n");
}
function parseLiteralArrays(text) {
    const arrays = {};
    const src = String(text || "");
    const re = /^\s*([a-z_]\w*)\s*=\s*\[/gmi;
    let m;
    while ((m = re.exec(src))) {
        let i = m.index + m[0].length - 1, depth = 0, q = false, quote = "", end = -1;
        for (; i < src.length; i++) {
            const c = src[i], prev = src[i - 1];
            if ((c === '"' || c === "'") && prev !== "\\" && (!q || quote === c)) {
                q = !q;
                quote = q ? c : "";
            }
            if (q)
                continue;
            if (c === '[')
                depth++;
            else if (c === ']') {
                depth--;
                if (depth === 0) {
                    end = i;
                    break;
                }
            }
        }
        if (end < 0)
            continue;
        const body = src.slice(m.index + m[0].lastIndexOf('['), end + 1);
        try {
            if (!/[^0-9+\-.\[\],\s]/.test(body)) {
                const val = Function(`"use strict";return (${body})`)();
                if (Array.isArray(val))
                    arrays[m[1]] = val;
            }
        }
        catch (_a) { }
        re.lastIndex = end + 1;
    }
    return arrays;
}
function expandArrayLoops(text) {
    const arrays = parseLiteralArrays(text);
    let lines = String(text || "").split(/\r?\n/), passes = 0;
    const literal = (v) => Array.isArray(v) ? `[${v.join(",")}]` : String(v);
    while (passes++ < 8) {
        let changed = false, out = [];
        for (let i = 0; i < lines.length; i++) {
            const m = lines[i].match(/^(\s*)([a-z_]\w*)\.each(?:_with_index)?\s+do\s*\|\s*(?:\(([^\)]+)\)|([a-z_]\w*))(?:\s*,\s*([a-z_]\w*))?\s*\|\s*$/i);
            if (!m || !arrays[m[2]]) {
                out.push(lines[i]);
                continue;
            }
            const indent = m[1].length, arr = arrays[m[2]], tupleItems = m[3] ? m[3].split(',').map(x => x.trim()).filter(Boolean) : null, item = m[4] || (tupleItems ? null : m[3]), idx = m[5] || null;
            let j = i + 1, depth = 0, end = -1;
            for (; j < lines.length; j++) {
                const t = lines[j].trim(), ind = (lines[j].match(/^\s*/) || [""])[0].length;
                if (ind === indent && t === "end" && depth === 0) {
                    end = j;
                    break;
                }
                if ((/^(?:case|if|unless|begin)\b/.test(t) || /\bdo\s*(?:\||$)/.test(t)) && ind >= indent)
                    depth++;
                if (t === "end" && depth > 0)
                    depth--;
            }
            if (end < 0) {
                out.push(lines[i]);
                continue;
            }
            const body = lines.slice(i + 1, end);
            arr.slice(0, 96).forEach((value, n) => { for (let bl of body) {
                if (Array.isArray(value)) {
                    if (tupleItems) {
                        tupleItems.forEach((name, k) => { bl = bl.replace(new RegExp(`\\b${name}\\b`, 'g'), String(value[k] != null ? value[k] : 0)); });
                    }
                    else if (item) {
                        value.forEach((vv, k) => { bl = bl.replace(new RegExp(`\\b${item}\\s*\\[\\s*${k}\\s*\\]`, 'g'), String(vv)); });
                        bl = bl.replace(new RegExp(`\\b${item}\\b`, 'g'), literal(value));
                    }
                }
                else if (item)
                    bl = bl.replace(new RegExp(`\\b${item}\\b`, 'g'), String(value));
                if (idx)
                    bl = bl.replace(new RegExp(`\\b${idx}\\b`, 'g'), String(n));
                out.push(bl);
            } });
            i = end;
            changed = true;
        }
        lines = out;
        if (!changed)
            break;
    }
    return lines.join("\n");
}
function safeEval(expr, env = {}) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v;
    let s = String(expr || "").trim();
    s = s.replace(/(\d+)\.even\?/g, "($1%2===0)").replace(/(\d+)\.odd\?/g, "($1%2!==0)");
    s = s.replace(/\.to_f|\.to_i/g, "").replace(/\.round\b/g, "").replace(/([\w.()]+)\.floor\b/g, "Math.floor($1)").replace(/([\w.()]+)\.ceil\b/g, "Math.ceil($1)").replace(/([\w.()]+)\.abs\b/g, "Math.abs($1)");
    s = s.replace(/Graphics\.width/g, String((_a = env.width) !== null && _a !== void 0 ? _a : 512)).replace(/Graphics\.height/g, String((_b = env.height) !== null && _b !== void 0 ? _b : 384));
    s = s.replace(/@user\.index/g, String((_c = env.userIndex) !== null && _c !== void 0 ? _c : 0)).replace(/@target\.index/g, String((_d = env.targetIndex) !== null && _d !== void 0 ? _d : 1)).replace(/@hit_num/g, String((_e = env.hitNum) !== null && _e !== void 0 ? _e : 0)).replace(/@anchor_x|\banchor_x\b|\bax\b/g, String((_f = env.anchorX) !== null && _f !== void 0 ? _f : 0)).replace(/@anchor_y|\banchor_y\b|\bay\b/g, String((_g = env.anchorY) !== null && _g !== void 0 ? _g : 0)).replace(/@side_index|\bside_index\b/g, String((_h = env.sideIndex) !== null && _h !== void 0 ? _h : 0));
    s = s.replace(/user_sprite\.x|\bus\.x\b|\borig_ux\b/g, String((_j = env.userX) !== null && _j !== void 0 ? _j : 128)).replace(/user_sprite\.y|\bus\.y\b|\borig_uy\b/g, String((_k = env.userY) !== null && _k !== void 0 ? _k : 326)).replace(/target_sprite\.x|\bts\.x\b|\borig_tx\b/g, String((_l = env.targetX) !== null && _l !== void 0 ? _l : 390)).replace(/target_sprite\.y|\bts\.y\b|\borig_ty\b/g, String((_m = env.targetY) !== null && _m !== void 0 ? _m : 174));
    s = s.replace(/\bu_h\b/g, String(((_o = env.userH) !== null && _o !== void 0 ? _o : 96) / 2)).replace(/\bt_h\b/g, String(((_p = env.targetH) !== null && _p !== void 0 ? _p : 96) / 2)).replace(/\bu_w\b/g, String((_q = env.userW) !== null && _q !== void 0 ? _q : 96)).replace(/\bt_w\b/g, String((_r = env.targetW) !== null && _r !== void 0 ? _r : 96));
    s = s.replace(/(?:user_sprite|us)\.bitmap\.width|\buw\b/g, String((_s = env.userW) !== null && _s !== void 0 ? _s : 96)).replace(/(?:user_sprite|us)\.bitmap\.height|\buh\b/g, String((_t = env.userH) !== null && _t !== void 0 ? _t : 96)).replace(/(?:target_sprite|ts)\.bitmap\.width|\btw\b/g, String((_u = env.targetW) !== null && _u !== void 0 ? _u : 96)).replace(/(?:target_sprite|ts)\.bitmap\.height|\bth\b/g, String((_v = env.targetH) !== null && _v !== void 0 ? _v : 96));
    for (const [k, v] of Object.entries(env.vars || {}))
        if (typeof v === 'number')
            s = s.replace(new RegExp(`\\b${k}\\b`, `g`), String(v));
    for (let pass = 0; pass < 4; pass++)
        s = s.replace(/\[\s*([^,\[\]]+)\s*,\s*([^\[\]]+)\s*\]\.(min|max)/g, (_, aa, b, op) => `Math.${op}(${aa},${b})`);
    s = s.replace(/rand\s*\(\s*([^()]+)\s*\)/g, (_, n) => { const v = Number(n); return Number.isFinite(v) ? String(Math.max(0, Math.floor(v / 2))) : "0"; });
    s = s.replace(/Math::PI/g, "Math.PI").replace(/\btrue\b/g, "1").replace(/\bfalse\b/g, "0");
    if (/[^0-9+\-*/%&|().,\s?:<>=!A-Za-z]/.test(s))
        return null;
    if (/[A-Za-z_]/.test(s.replace(/Math\.(min|max|floor|ceil|abs|sqrt|atan2|cos|sin)|Math::PI|Math\.PI/g, "")))
        return null;
    try {
        const v = Function(`"use strict";return (${s})`)();
        return Number.isFinite(Number(v)) ? Number(v) : null;
    }
    catch (_w) {
        return null;
    }
}
function splitRubyStatements(text) { const out = []; for (const raw of String(text || "").split(/\r?\n/)) {
    let cur = "", depth = 0, q = false, quote = "";
    for (let i = 0; i < raw.length; i++) {
        const c = raw[i];
        if ((c === '"' || c === "'") && raw[i - 1] !== "\\" && (!q || quote === c)) {
            q = !q;
            quote = q ? c : "";
        }
        if (!q) {
            if (c === '(' || c === '[' || c === '{')
                depth++;
            if (c === ')' || c === ']' || c === '}')
                depth = Math.max(0, depth - 1);
            if (c === ';' && depth === 0) {
                if (cur.trim())
                    out.push(stripComment(cur).trim());
                cur = "";
                continue;
            }
        }
        cur += c;
    }
    if (cur.trim()) {
        let stmt = stripComment(cur).trim().replace(/\s+rescue\s+nil\s*$/i, "");
        const cond = stmt.match(/^(.*)\s+if\s+(.+)$/i);
        if (cond) {
            const ok = safeEval(cond[2]);
            if (ok === 0)
                stmt = "";
            else if (ok != null)
                stmt = cond[1].trim();
        }
        if (stmt)
            out.push(stmt);
    }
} return out.filter(Boolean); }
function splitArgs(s) { const out = []; let cur = "", depth = 0, q = false, quote = ""; for (let i = 0; i < String(s || "").length; i++) {
    const c = String(s)[i], prev = String(s)[i - 1];
    if ((c === '"' || c === "'") && prev !== "\\" && (!q || quote === c)) {
        q = !q;
        quote = q ? c : "";
        cur += c;
        continue;
    }
    if (!q) {
        if (c === '(' || c === '[' || c === '{')
            depth++;
        else if (c === ')' || c === ']' || c === '}')
            depth = Math.max(0, depth - 1);
        if (c === ',' && depth === 0) {
            out.push(cur.trim());
            cur = "";
            continue;
        }
    }
    cur += c;
} out.push(cur.trim()); return out; }
function collectCodeAssets(text) {
    const constants = {}, assetVars = {};
    for (const m of String(text).matchAll(/^\s*([A-Z][A-Z0-9_]+)\s*=\s*([^\r\n]+)$/gm)) {
        const strings = [...m[2].matchAll(/["']([^"']+)["']/g)].map(x => x[1]);
        if (strings.length)
            constants[m[1]] = strings;
    }
    for (const m of String(text).matchAll(/([A-Z][A-Z0-9_]+)\s*=\s*\[([\s\S]*?)\]/g)) {
        const strings = [...m[2].matchAll(/["']([^"']+)["']/g)].map(x => x[1]);
        if (strings.length)
            constants[m[1]] = strings;
    }
    for (const m of String(text).matchAll(/^\s*([a-z_]\w*)\s*=\s*[^\r\n]*(?:first_existing_asset|resolve_bitmap)\(([^\r\n]*)/gmi)) {
        const names = [...m[2].matchAll(/(?:[A-Za-z0-9_]+::)*([A-Z][A-Z0-9_]+)/g)].map(x => x[1]);
        for (const n of names)
            if (constants[n]) {
                assetVars[m[1]] = constants[n];
                break;
            }
        const direct = [...m[2].matchAll(/["'](Graphics\/[^"']+)["']/g)].map(x => x[1]);
        if (direct.length)
            assetVars[m[1]] = direct;
    }
    for (const m of String(text).matchAll(/^\s*([a-z_]\w*)\s*=\s*["'](Graphics\/[^"']+)["']/gmi))
        assetVars[m[1]] = [m[2]];
    return { constants, assetVars };
}
function codeAsset(expr, constants, assetVars = {}) { const raw = String(expr || "").trim(), direct = [...raw.matchAll(/["'](Graphics\/[^"']+?)["']/g)].map(x => x[1]); if (direct.length)
    return { path: direct[0], candidates: direct }; if (assetVars[raw])
    return { path: assetVars[raw][0], candidates: assetVars[raw] }; const c = raw.match(/(?:[A-Za-z0-9_]+::)*([A-Z][A-Z0-9_]+)/); if (c && constants[c[1]])
    return { path: constants[c[1]][0], candidates: constants[c[1]] }; return { path: "", candidates: [] }; }
function evalCodeString(expr, env = {}, constants = {}) {
    var _a;
    const raw = String(expr !== null && expr !== void 0 ? expr : "").trim();
    if (!raw)
        return "";
    const quoted = raw.match(/^["']([\s\S]*)["']$/);
    if (quoted)
        return quoted[1];
    const tern = raw.match(/^(.+?)\?\s*["']([^"']*)["']\s*:\s*["']([^"']*)["']$/);
    if (tern) {
        const cond = safeEval(tern[1], env);
        if (cond != null)
            return cond ? tern[2] : tern[3];
    }
    const cm = raw.match(/(?:[A-Za-z0-9_]+::)*([A-Z][A-Z0-9_]+)$/);
    if (cm && ((_a = constants[cm[1]]) === null || _a === void 0 ? void 0 : _a.length))
        return constants[cm[1]][0];
    return raw.replace(/^["']|["']$/g, "");
}
function mapCodeAsset(c, asset, name) { c.graphic.source = "code"; c.graphic.projectPath = asset.path; c.graphic.assetCandidates = asset.candidates; c.graphic.name = (asset.path.split("/").pop() || name).replace(/\.png$/i, ""); c.graphic.folder = asset.path.includes("BattleParticlesAnimations") ? "BattleParticlesAnimations" : asset.path.includes("Battle animations") ? "Battle animations" : "Animations"; c.graphic.spritesheet = "auto"; }
function helperDefaults(text) {
    const src = String(text || ""), out = { pras: { fw: 192, fh: 192, cols: 5, mode: "grid" }, frameGrid: { fw: 192, fh: 192, mode: "index", cellMode: "square-height", specialCells: [] } };
    const sig = src.match(/def\s+apply_pras_frame\(([^\n)]*)\)/i);
    if (sig) {
        if (/absolute_frame/i.test(sig[1]))
            out.pras.mode = "absolute";
        else if (/path/i.test(sig[1]))
            out.pras.mode = "path-grid";
        else
            out.pras.mode = "grid";
    }
    const block = src.match(/def\s+apply_pras_frame\([^\n]*\)[\s\S]{0,900}?\n\s*end/);
    if (block) {
        const fw = block[0].match(/\bfw\s*=\s*(\d+)/), fh = block[0].match(/\bfh\s*=\s*(\d+)/), cols = block[0].match(/\bcols\s*=\s*(\d+)/);
        if (fw)
            out.pras.fw = Number(fw[1]);
        if (fh)
            out.pras.fh = Number(fh[1]);
        if (cols)
            out.pras.cols = Math.max(1, Number(cols[1]));
    }
    const fsig = src.match(/def\s+apply_frame\(([^\n)]*)\)/i);
    if (fsig)
        out.frameGrid.mode = /\bcol\b[\s\S]*\brow\b/i.test(fsig[1]) ? "grid" : "index";
    const info = src.match(/def\s+get_frame_info\([^\n]*\)[\s\S]{0,1600}?\n\s*end/);
    if (info) {
        const fw = info[0].match(/\bfw\s*=\s*(\d+)/), fh = info[0].match(/\bfh\s*=\s*(\d+)/);
        if (fw && fh) {
            out.frameGrid.fw = Number(fw[1]);
            out.frameGrid.fh = Number(fh[1]);
            out.frameGrid.cellMode = "fixed";
        }
        if (/fw\s*=\s*bmp\.height/i.test(info[0]))
            out.frameGrid.cellMode = "square-height";
        for (const m of info[0].matchAll(/(?:if|elsif)\s+path\.include\?\(["']([^"']+)["']\)([\s\S]{0,180}?)(?=\n\s*(?:elsif|else|end)\b)/g)) {
            const fw2 = m[2].match(/\bfw\s*=\s*(\d+)/), fh2 = m[2].match(/\bfh\s*=\s*(\d+)/);
            if (fw2 && fh2)
                out.frameGrid.specialCells.push({ match: m[1], fw: Number(fw2[1]), fh: Number(fh2[1]) });
        }
    }
    else {
        const frameBlock = src.match(/def\s+apply_frame\([^\n]*\)[\s\S]{0,700}?\n\s*end/);
        if (frameBlock) {
            const fw = frameBlock[0].match(/fw\s*=\s*(\d+)/), fh = frameBlock[0].match(/fh\s*=\s*(\d+)/);
            if (fw)
                out.frameGrid.fw = Number(fw[1]);
            if (fh)
                out.frameGrid.fh = Number(fh[1]);
            if (fw && fh)
                out.frameGrid.cellMode = "fixed";
        }
    }
    out.hasPrasSequence = /def\s+play_pras_sequence\s*\(/i.test(src);
    const asig = src.match(/def\s+animate_sheet_fluid\(([^\n)]*)\)/i);
    out.animateSignature = asig ? asig[1] : "";
    return out;
}
function codeSheetCell(helper, clip) { var _a, _b, _c, _d; const path = String(((_a = clip === null || clip === void 0 ? void 0 : clip.graphic) === null || _a === void 0 ? void 0 : _a.projectPath) || ((_b = clip === null || clip === void 0 ? void 0 : clip.graphic) === null || _b === void 0 ? void 0 : _b.name) || ""); for (const s of ((_c = helper === null || helper === void 0 ? void 0 : helper.frameGrid) === null || _c === void 0 ? void 0 : _c.specialCells) || [])
    if (path.includes(s.match))
        return { fw: s.fw, fh: s.fh, mode: "fixed" }; if (((_d = helper === null || helper === void 0 ? void 0 : helper.frameGrid) === null || _d === void 0 ? void 0 : _d.cellMode) === "fixed")
    return { fw: helper.frameGrid.fw, fh: helper.frameGrid.fh, mode: "fixed" }; return { fw: 0, fh: 0, mode: "square-height" }; }
function clipFor(map, name) { return map.get(String(name || "").trim()) || null; }
function uniqueClipName(a, base) { const n = getEffectsTrack(a).clips.filter(c => c.name === base || c.name.startsWith(`${base} #`)).length; return n ? `${base} #${n + 1}` : base; }
function rubyFxValue(expr, env, kind = "color") {
    const raw = String(expr || "").trim();
    const m = raw.match(/(?:Color|Tone)\.new\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^\)]+)\)/i);
    if (m) {
        const vals = m.slice(1).map(x => { var _a; return (_a = safeEval(x, env)) !== null && _a !== void 0 ? _a : 0; });
        return kind === "tone" ? { red: vals[0], green: vals[1], blue: vals[2], gray: vals[3] } : { red: vals[0], green: vals[1], blue: vals[2], alpha: vals[3] };
    }
    // Common VERMEIL pattern: color_pool.sample. Deterministically use the first Tone/Color
    // so the static preview stays stable while runtime capture preserves true randomness.
    const first = String(env.__sourceText || "").match(new RegExp(`(?:${kind === "tone" ? "Tone" : "Color"})\\.new\\(([^\\)]*)\\)`, 'i'));
    if (/\.sample\b/.test(raw) && first) {
        const bits = splitArgs(first[1]);
        if (bits.length >= 4) {
            const vals = bits.slice(0, 4).map(x => { var _a; return (_a = safeEval(x, env)) !== null && _a !== void 0 ? _a : 0; });
            return kind === "tone" ? { red: vals[0], green: vals[1], blue: vals[2], gray: vals[3] } : { red: vals[0], green: vals[1], blue: vals[2], alpha: vals[3] };
        }
    }
    return raw.replace(/^['"]|['"]$/g, "");
}
function staticValueAt(o, prop, frame, fallback) { var _a, _b, _c; const arr = (((_a = o.valueKeys) === null || _a === void 0 ? void 0 : _a[prop]) || []).slice().sort((a, b) => a.frame - b.frame); let v = Number((_c = (_b = o.visual) === null || _b === void 0 ? void 0 : _b[prop]) !== null && _c !== void 0 ? _c : fallback); for (const k of arr) {
    if (k.frame > frame)
        break;
    v = Number(k.value);
} return v; }
function staticPosAt(o, frame, env) { var _a; const ks = sortPositionKeys(o).slice().sort((a, b) => a.frame - b.frame); let p = ((_a = ks[0]) === null || _a === void 0 ? void 0 : _a.point) || { x: o.side === "target" ? env.targetX : env.userX, y: o.side === "target" ? env.targetY : env.userY, anchor: "screen" }; for (const k of ks) {
    if (k.frame > frame)
        break;
    p = k.point;
} if (p.anchor === "screen")
    return { x: Number(p.x || 0), y: Number(p.y || 0) }; return { x: o.side === "target" ? env.targetX : env.userX, y: o.side === "target" ? env.targetY : env.userY }; }
export function animationFromCode(text, filename = "Code Animation", context = {}, options = {}) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
    const variant = options.moveId || null, metadata = options.metadata || discoverCodeMetadata(text, filename), behavior = String(options.behavior || metadata.behavior || "cinematic").toLowerCase(), sideContext = options.sideContext === "foe" ? "foe" : "player", selected = expandForLoops(expandArrayLoops(expandSimpleTimes(selectedCodeBranch(text, variant)))), a = createAnimation(variant || filename.replace(/\.rb$/i, ""));
    a.tracks[0].clips = [];
    const rawUser = context.user || {}, rawTarget = context.target || {}, foe = sideContext === "foe", u = foe ? rawTarget : rawUser, t0 = foe ? rawUser : rawTarget, ui = foe ? ((_a = context.targetIndex) !== null && _a !== void 0 ? _a : 1) : ((_b = context.userIndex) !== null && _b !== void 0 ? _b : 0), ti = foe ? ((_c = context.userIndex) !== null && _c !== void 0 ? _c : 0) : ((_d = context.targetIndex) !== null && _d !== void 0 ? _d : 1);
    const t = behavior === "self_targeting" ? u : t0, sideIndex = behavior === "hazard" ? (foe ? 0 : 1) : 0;
    const baseUser = (context.bases && context.bases.user) || u, baseTarget = (context.bases && context.bases.target) || t0;
    const hazardBase = sideIndex === 0 ? baseUser : baseTarget;
    const anchorX = Math.round(Number(hazardBase.x || (sideIndex === 0 ? ((context.width || 512) * .30) : ((context.width || 512) * .70))));
    const anchorY = Math.round(Number(hazardBase.y || (sideIndex === 0 ? ((context.height || 384) * .72) : ((context.height || 384) * .44))));
    a.source = { type: "code", path: filename, approximate: true, importMode: "static", move: variant, version: Number(options.version || 0), behavior, sideContext, opposing: foe, hitNum: Number(options.hitNum || 0), className: ((_e = metadata.classes) === null || _e === void 0 ? void 0 : _e[0]) || "", codeMetadata: { classes: metadata.classes || [], handledMoves: metadata.moves || [], hasCallbacks: !!metadata.hasCallbacks, hasRandom: !!metadata.hasRandom } };
    a.fps = 20;
    a.events = [];
    const { constants, assetVars } = collectCodeAssets(text), helper = helperDefaults(text), vars = {}, env = { __time: 0, width: context.width || 512, height: context.height || 384, userX: u.x || 128, userY: u.y || 326, targetX: t.x || 390, targetY: t.y || 174, userW: u.bitmapWidth || 96, userH: u.bitmapHeight || 96, targetW: t.bitmapWidth || 96, targetH: t.bitmapHeight || 96, userIndex: ui, targetIndex: ti, hitNum: Number(options.hitNum || 0), anchorX, anchorY, sideIndex, vars, __sourceText: selected };
    for (let pass = 0; pass < 4; pass++)
        for (const m of String(text).matchAll(/^\s*([A-Z][A-Z0-9_]*)\s*=\s*([^#\r\n]+)$/gm)) {
            const v = safeEval(m[2], env);
            if (v != null)
                env.vars[m[1]] = v;
        }
    const statements = splitRubyStatements(selected), map = new Map();
    let max = 1;
    const evalOr = (e, f) => { const v = safeEval(e, env); return v == null ? f : v; };
    for (const line of statements) {
        const pair = line.match(/^([a-z_]\w*)\s*,\s*([a-z_]\w*)\s*=\s*(.+)$/i);
        if (pair) {
            const rr = splitArgs(pair[3]);
            if (rr.length >= 2) {
                const va = safeEval(rr[0], env), vb = safeEval(rr[1], env);
                if (va != null)
                    env.vars[pair[1]] = va;
                if (vb != null)
                    env.vars[pair[2]] = vb;
            }
        }
        const assignNum = line.match(/^([a-z_]\w*)\s*=\s*([^#]+)$/i);
        if (assignNum && !/addNewSprite|addSprite|Sprite\.new/.test(assignNum[2])) {
            const v = safeEval(assignNum[2], env);
            if (v != null)
                env.vars[assignNum[1]] = v;
        }
        let m = line.match(/^([a-z_]\w*)\s*=\s*addNewSprite\((.*)\)(?:\s+rescue\s+nil)?$/i);
        if (m) {
            const args = splitArgs(m[2]), x = evalOr(args[0], env.width / 2), y = evalOr(args[1], env.height / 2), asset = codeAsset(args[2], constants, assetVars), base = m[1], c = createProjectile({ id: uid("clip"), name: uniqueClipName(a, base), type: "code-particle" });
            c.positionKeys = [];
            c.visibleKeys = [];
            mapCodeAsset(c, asset, base);
            const org = String(args[3] || "");
            c.graphic.origin = /BOTTOM/i.test(org) ? "bottom" : /TOP_LEFT/i.test(org) ? "top_left" : /CENTER/i.test(org) ? "center" : "auto";
            setPositionKey(c, 0, { x, y }, "linear");
            setVisibleKey(c, 0, true);
            getEffectsTrack(a).clips.push(c);
            map.set(base, c);
            continue;
        }
        m = line.match(/^([a-z_]\w*)\s*=\s*build_front_attacker_sprite\((.*)\)$/i);
        if (m) {
            const args = splitArgs(m[2]), c = createProjectile({ id: uid("clip"), name: uniqueClipName(a, m[1]), type: "battler-front-clone" });
            c.positionKeys = [];
            c.visibleKeys = [];
            c.graphic.source = "battler-user-front";
            c.graphic.name = "User front";
            c.graphic.origin = "bottom";
            setPositionKey(c, 0, { anchor: "screen", x: evalOr(args[1], env.width / 2), y: evalOr(args[2], env.height / 2) }, "linear", "screen");
            setVisibleKey(c, 0, true);
            getEffectsTrack(a).clips.push(c);
            map.set(m[1], c);
            continue;
        }
        m = line.match(/^([a-z_]\w*)\s*=\s*addSprite\((.*)\)(?:\s+rescue\s+nil)?$/i);
        if (m) {
            const rhs = m[2].toLowerCase(), side = /target|\bts\b|\btt\b/.test(rhs) ? "target" : "user";
            if (/create_battler_clone/.test(rhs)) {
                const c = createProjectile({ id: uid("clip"), name: uniqueClipName(a, m[1]), type: "battler-clone" });
                c.positionKeys = [];
                c.visibleKeys = [];
                c.graphic.source = side === "target" ? "battler-target" : "battler-user";
                c.graphic.name = side === "target" ? "Target clone" : "User clone";
                c.graphic.origin = "bottom";
                setPositionKey(c, 0, { anchor: "screen", x: side === "target" ? env.targetX : env.userX, y: side === "target" ? env.targetY : env.userY, offsetX: 0, offsetY: 0 }, "linear", "screen");
                setVisibleKey(c, 0, true);
                getEffectsTrack(a).clips.push(c);
                map.set(m[1], c);
            }
            else {
                // addSprite(us/ts) in VERMEIL/EBDX often means "operate on the live battler sprite".
                // Drawing another overlay is what caused the duplicated battlers. Static import now
                // keeps these variables as non-rendered proxies; use Code Capturado for exact live
                // battler movement/opacity when the original Ruby mutates the battler itself.
                const proxy = { id: `proxy_${m[1]}`, __basProxy: true, type: "battler-proxy", name: m[1], side, positionKeys: [], visibleKeys: [], valueKeys: {}, graphic: {}, visual: {} };
                map.set(m[1], proxy);
            }
            continue;
        }
        // EBDX/Luka sprite creation: fp["name"] = Sprite.new(@viewport)
        m = line.match(/^(?:fp\s*\[\s*["']([^"']+)["']\s*\]|([a-z_]\w*))\s*=\s*(?:Sprite\.new|TrailingSprite\.new)\((.*)\)$/i);
        if (m) {
            const id = m[1] || m[2];
            const asset = codeAsset(m[3], constants, assetVars);
            const c = createProjectile({ id: uid("clip"), name: uniqueClipName(a, id), type: "ebdx-sprite" });
            c.positionKeys = []; c.visibleKeys = []; c.valueKeys || (c.valueKeys = {});
            if (asset.path) mapCodeAsset(c, asset, id);
            setPositionKey(c, env.__time || 0, { anchor: "screen", x: env.width / 2, y: env.height / 2 }, "linear", "screen");
            setVisibleKey(c, env.__time || 0, true);
            getEffectsTrack(a).clips.push(c); map.set(id, c); continue;
        }
        // EBDX pbBitmap assignment
        m = line.match(/^(?:fp\s*\[\s*["']([^"']+)["']\s*\]|([a-z_]\w*))\.bitmap\s*=\s*pbBitmap\((.*)\)$/i);
        if (m) {
            const id = m[1] || m[2], o = clipFor(map, id);
            if (o && !o.__basProxy) {
                const asset = codeAsset(m[3], constants, assetVars);
                if (asset.path) mapCodeAsset(o, asset, id);
            }
            continue;
        }
        // EBDX direct property mutations over scene frames
        m = line.match(/^(?:fp\s*\[\s*["']([^"']+)["']\s*\]|([a-z_]\w*)|@(targetSprite|userSprite))\.([a-z_]+)(?:\.alpha)?\s*([+\-]?=)\s*(.+)$/i);
        if (m) {
            const id = m[1] || m[2] || (m[3] === "targetSprite" ? "__target" : "__user");
            const o = id === "__target" ? getBattlerTrack(a, "target") : id === "__user" ? getBattlerTrack(a, "user") : clipFor(map, id);
            if (!o || o.__basProxy) continue;
            const prop = m[4], opAssign = m[5], valueRaw = m[6];
            const now = Number(env.__time || 0);
            let val = evalOr(valueRaw, 0);
            const addVal = (track, v) => { const cur = sampleValue(o, track, now, track === "opacity" ? 100 : 0); setValueKey(o, track, now, opAssign === "+=" ? cur + v : opAssign === "-=" ? cur - v : v); };
            if (prop === "x" || prop === "y") {
                const p = staticPosAt(o, now, env);
                if (opAssign === "+=") val = (prop === "x" ? p.x : p.y) + val;
                if (opAssign === "-=") val = (prop === "x" ? p.x : p.y) - val;
                setPositionKey(o, now, { anchor: "screen", x: prop === "x" ? val : p.x, y: prop === "y" ? val : p.y }, "linear", "screen");
            }
            else if (prop === "zoom_x") addVal("scaleX", val * 100);
            else if (prop === "zoom_y") addVal("scaleY", val * 100);
            else if (prop === "angle") addVal("rotation", val);
            else if (prop === "opacity") addVal("opacity", val * (opAssign === "=" ? 100/255 : 1));
            else if (prop === "z") addVal("z", val);
            else if (prop === "visible") setVisibleKey(o, now, !!val);
            else if (prop === "color") { /* Color object handled below by alpha updates/runtime capture. */ }
            max = Math.max(max, now); continue;
        }
        m = line.match(/^pbSEPlay\(\s*["']([^"']+)["']\s*(?:,\s*([^,\)]+))?(?:,\s*([^,\)]+))?\s*\)$/i);
        if (m) { a.events.push({ type: "se", frame: Number(env.__time || 0), name: m[1], volume: evalOr(m[2] || "100", 100), pitch: evalOr(m[3] || "100", 100) }); continue; }
        m = line.match(/^@scene\.wait(?:\(\s*([^,\)]*)?[^)]*\))?/i);
        if (m) { env.__time = Number(env.__time || 0) + Math.max(1, Math.round(evalOr(m[1] || "1", 1))); max = Math.max(max, env.__time); continue; }
        // Direct PictureEx operations.
        m = line.match(/^([a-z_]\w*)\.((?:set|move)[A-Z]\w*|setCallback)\((.*)\)$/);
        if (m) {
            const o = clipFor(map, m[1]);
            if (!o)
                continue;
            const op = m[2], args = splitArgs(m[3]), t = evalOr(args[0], 0);
            max = Math.max(max, t);
            const end = (dur) => Math.max(0, t + dur);
            if (op === "setXY" || op === "moveXY") {
                const dur = op === "moveXY" ? evalOr(args[1], 0) : 0, ix = op === "moveXY" ? 2 : 1, iy = op === "moveXY" ? 3 : 2;
                if (dur > 0) {
                    const st = staticPosAt(o, t, env);
                    setPositionKey(o, t, { x: st.x, y: st.y }, "linear");
                }
                setPositionKey(o, end(dur), { x: evalOr(args[ix], env.width / 2), y: evalOr(args[iy], env.height / 2) }, "linear");
                max = Math.max(max, end(dur));
            }
            else if (op === "moveDelta") {
                const dur = evalOr(args[1], 0), dx = evalOr(args[2], 0), dy = evalOr(args[3], 0), base = staticPosAt(o, t, env);
                setPositionKey(o, t, { x: base.x, y: base.y }, "linear");
                setPositionKey(o, end(dur), { x: base.x + dx, y: base.y + dy }, "linear");
                max = Math.max(max, end(dur));
            }
            else if (op === "setZoom" || op === "moveZoom") {
                const dur = op === "moveZoom" ? evalOr(args[1], 0) : 0, v = evalOr(args[op === "moveZoom" ? 2 : 1], 100);
                if (dur > 0) {
                    setValueKey(o, "scaleX", t, staticValueAt(o, "scaleX", t, 100), "linear");
                    setValueKey(o, "scaleY", t, staticValueAt(o, "scaleY", t, 100), "linear");
                }
                setValueKey(o, "scaleX", end(dur), v, "linear");
                setValueKey(o, "scaleY", end(dur), v, "linear");
                max = Math.max(max, end(dur));
            }
            else if (op === "setZoomXY" || op === "moveZoomXY") {
                const moving = op === "moveZoomXY", dur = moving ? evalOr(args[1], 0) : 0, ix = moving ? 2 : 1, iy = moving ? 3 : 2;
                if (dur > 0) {
                    setValueKey(o, "scaleX", t, staticValueAt(o, "scaleX", t, 100), "linear");
                    setValueKey(o, "scaleY", t, staticValueAt(o, "scaleY", t, 100), "linear");
                }
                setValueKey(o, "scaleX", end(dur), evalOr(args[ix], 100), "linear");
                setValueKey(o, "scaleY", end(dur), evalOr(args[iy], 100), "linear");
                max = Math.max(max, end(dur));
            }
            else if (op === "setAngle" || op === "moveAngle") {
                const dur = op === "moveAngle" ? evalOr(args[1], 0) : 0;
                if (dur > 0)
                    setValueKey(o, "rotation", t, staticValueAt(o, "rotation", t, 0), "linear");
                setValueKey(o, "rotation", end(dur), evalOr(args[op === "moveAngle" ? 2 : 1], 0), "linear");
                max = Math.max(max, end(dur));
            }
            else if (op === "setOpacity" || op === "moveOpacity") {
                const dur = op === "moveOpacity" ? evalOr(args[1], 0) : 0;
                if (dur > 0)
                    setValueKey(o, "opacity", t, staticValueAt(o, "opacity", t, 100), "linear");
                setValueKey(o, "opacity", end(dur), evalOr(args[op === "moveOpacity" ? 2 : 1], 255) * 100 / 255, "linear");
                max = Math.max(max, end(dur));
            }
            else if (op === "setVisible")
                setVisibleKey(o, t, bool(args[1]));
            else if (op === "setZ")
                setValueKey(o, "z", t, evalOr(args[1], 0), "linear");
            else if (op === "setBlendType")
                setValueKey(o, "blend", t, evalOr(args[1], 0), "linear");
            else if (op === "setSrc") {
                setValueKey(o, "srcX", t, evalOr(args[1], 0), "linear");
                setValueKey(o, "srcY", t, evalOr(args[2], 0), "linear");
            }
            else if (op === "setSrcSize") {
                setValueKey(o, "srcW", t, evalOr(args[1], 0), "linear");
                setValueKey(o, "srcH", t, evalOr(args[2], 0), "linear");
                o.graphic.spritesheet = "code-grid";
                o.graphic.cellW = evalOr(args[1], 0);
                o.graphic.cellH = evalOr(args[2], 0);
            }
            else if (op === "setSE") {
                const resolved = evalCodeString(args[1], env, constants);
                a.events.push({ type: "se", frame: t, name: resolved, volume: evalOr(args[2], 100), pitch: evalOr(args[3], 100) });
            }
            else if (op === "setBitmap") {
                const asset = codeAsset((_f = args[1]) !== null && _f !== void 0 ? _f : args[0], constants, assetVars);
                if (asset.path)
                    mapCodeAsset(o, asset, o.name || "Particle");
                o.graphicSwitches || (o.graphicSwitches = []);
                o.graphicSwitches.push({ frame: t, value: asset.path || String((_h = (_g = args[1]) !== null && _g !== void 0 ? _g : args[0]) !== null && _h !== void 0 ? _h : "").replace(/^['"]|['"]$/g, "") });
            }
            else if (op === "setOrigin") {
                const raw = String((_k = (_j = args[1]) !== null && _j !== void 0 ? _j : args[0]) !== null && _k !== void 0 ? _k : "");
                o.graphic.origin = /BOTTOM/i.test(raw) ? "bottom" : /TOP_LEFT/i.test(raw) ? "top_left" : /CENTER/i.test(raw) ? "center" : o.graphic.origin || "auto";
            }
            else if (op === "setPokemonBitmap") {
                const raw = String(args.slice(1).join(","));
                o.graphic.source = /@target|target/i.test(raw) ? "battler-target" : "battler-user";
                o.graphic.origin = "bottom";
            }
            else if (op === "setCallback") {
                a.runtimeNotes || (a.runtimeNotes = []);
                a.runtimeNotes.push({ type: "callback", frame: t, source: "static" });
            }
            else if (op === "setTone" || op === "moveTone" || op === "setColor" || op === "moveColor") {
                const moving = op.startsWith("move"), dur = moving ? evalOr(args[1], 0) : 0, vi = moving ? 2 : 1, kind = /Tone/.test(op) ? "tone" : "color", value = rubyFxValue(args[vi], env, kind);
                o.fxOps || (o.fxOps = []);
                o.fxOps.push({ name: op, frame: t, duration: dur, value, [kind]: value, args: [t, dur, value] });
                max = Math.max(max, end(dur));
            }
            continue;
        }
        // VERMEIL Explosion-style dynamic sheet helper. The exact cell size is
        // resolved from the loaded bitmap in preview.js, using the same grid rules
        // as the Ruby helper instead of drawing the complete strip.
        m = line.match(/^apply_sheet_frame\((.*)\)$/i);
        if (m) {
            const args = splitArgs(m[1]), o = clipFor(map, args[0]);
            if (!o)
                continue;
            const asset = codeAsset(args[1], constants, assetVars);
            if (asset.path && !o.graphic.projectPath)
                mapCodeAsset(o, asset, o.name || "Particle");
            o.graphic.spritesheet = "code-dynamic-grid";
            o.graphic.sheetStyle = String(args[2] || ":default").replace(/^:/, "").replace(/["']/g, "");
            o.graphic.origin = "center";
            continue;
        }
        m = line.match(/^animate_sheet_frames\((.*)\)$/i);
        if (m) {
            const args = splitArgs(m[1]), o = clipFor(map, args[0]);
            if (!o)
                continue;
            const asset = codeAsset(args[1], constants, assetVars);
            if (asset.path && !o.graphic.projectPath)
                mapCodeAsset(o, asset, o.name || "Particle");
            o.graphic.spritesheet = "code-dynamic-grid";
            o.graphic.playSheet = true;
            o.graphic.playStart = evalOr(args[2], 0);
            o.graphic.playFrameCount = Math.max(1, Math.floor(evalOr(args[3], 1)));
            o.graphic.sheetStyle = String(args[4] || ":burst").replace(/^:/, "").replace(/["']/g, "");
            o.graphic.ticksPerFrame = 1;
            max = Math.max(max, o.graphic.playStart + o.graphic.playFrameCount);
            continue;
        }
        // Common PRAS spritesheet helpers. Handles both (sprite,path,col,row,time) and
        // the absolute-frame helper used by Ember/Vine Whip.
        m = line.match(/^apply_pras_frame\((.*)\)$/i);
        if (m) {
            const args = splitArgs(m[1]), o = clipFor(map, args[0]);
            if (!o)
                continue;
            if (helper.pras.mode === "absolute" && args.length <= 3) {
                const fr = Math.max(0, Math.floor(evalOr(args[1], 0))), t = evalOr(args[2], 0), fw = helper.pras.fw, fh = helper.pras.fh, cols = helper.pras.cols;
                const col = fr % cols, row = Math.floor(fr / cols);
                setValueKey(o, "srcX", t, col * fw, "linear");
                setValueKey(o, "srcY", t, row * fh, "linear");
                setValueKey(o, "srcW", t, fw, "linear");
                setValueKey(o, "srcH", t, fh, "linear");
                o.graphic.spritesheet = "code-grid";
                o.graphic.cellW = fw;
                o.graphic.cellH = fh;
                o.graphic.gridCols = cols;
                max = Math.max(max, t);
                continue;
            }
            const pathExpr = String(args[1] || "").trim(), pathAsset = codeAsset(pathExpr, constants, assetVars), offset = (helper.pras.mode === "path-grid" || args.length >= 5 || pathAsset.path) ? 2 : 1;
            if (pathAsset.path && !o.graphic.projectPath)
                mapCodeAsset(o, pathAsset, o.name || "Particle");
            const col = evalOr(args[offset], 0), row = evalOr(args[offset + 1], 0), t = evalOr(args[offset + 2], 0), fw = evalOr(args[offset + 3], helper.pras.fw), fh = evalOr(args[offset + 4], helper.pras.fh);
            setValueKey(o, "srcX", t, col * fw, "linear");
            setValueKey(o, "srcY", t, row * fh, "linear");
            setValueKey(o, "srcW", t, fw, "linear");
            setValueKey(o, "srcH", t, fh, "linear");
            o.graphic.spritesheet = "code-grid";
            o.graphic.cellW = fw;
            o.graphic.cellH = fh;
            max = Math.max(max, t);
            continue;
        }
        // Expands the PRAS sequence helper into visible source-rectangle keyframes.
        m = line.match(/^(?:([a-z_]\w*)\s*=\s*)?play_pras_sequence\((.*)\)$/i);
        if (m) {
            const args = splitArgs(m[2]), o = clipFor(map, args[0]);
            if (!o)
                continue;
            const start = evalOr(args[1], 0), first = Math.max(0, Math.floor(evalOr(args[2], 0))), count = Math.max(0, Math.floor(evalOr(args[3], 0))), ticks = Math.max(1, Math.floor(evalOr(args[4], 3))), fw = helper.pras.fw, fh = helper.pras.fh, cols = helper.pras.cols, duration = count * ticks;
            for (let j = 0; j < duration; j++) {
                const fr = first + Math.floor(j / ticks), t = start + j, col = fr % cols, row = Math.floor(fr / cols);
                setValueKey(o, "srcX", t, col * fw, "linear");
                setValueKey(o, "srcY", t, row * fh, "linear");
                setValueKey(o, "srcW", t, fw, "linear");
                setValueKey(o, "srcH", t, fh, "linear");
                max = Math.max(max, t);
            }
            if (m[1])
                env.vars[m[1]] = duration;
            o.graphic.spritesheet = "code-grid";
            o.graphic.cellW = fw;
            o.graphic.cellH = fh;
            o.graphic.gridCols = cols;
            continue;
        }
        // apply_frame helpers: either an explicit col/row grid or a sequential frame index.
        m = line.match(/^apply_frame\((.*)\)$/i);
        if (m) {
            const args = splitArgs(m[1]), o = clipFor(map, args[0]);
            if (!o)
                continue;
            const asset = codeAsset(args[1], constants, assetVars);
            if (asset.path && !o.graphic.projectPath)
                mapCodeAsset(o, asset, o.name || "Particle");
            if (helper.frameGrid.mode === "grid" && args.length >= 5) {
                const col = evalOr(args[2], 0), row = evalOr(args[3], 0), t = evalOr(args[4], 0), cell = codeSheetCell(helper, o), fw = cell.fw || helper.frameGrid.fw || 192, fh = cell.fh || helper.frameGrid.fh || 192;
                setValueKey(o, "srcX", t, col * fw, "linear");
                setValueKey(o, "srcY", t, row * fh, "linear");
                setValueKey(o, "srcW", t, fw, "linear");
                setValueKey(o, "srcH", t, fh, "linear");
                o.graphic.spritesheet = "code-grid";
                o.graphic.cellW = fw;
                o.graphic.cellH = fh;
                max = Math.max(max, t);
            }
            else if (args.length >= 4) {
                const fr = Math.max(0, Math.floor(evalOr(args[2], 0))), t = evalOr(args[3], 0), cell = codeSheetCell(helper, o);
                setValueKey(o, "graphicFrame", t, fr, "linear");
                o.graphic.spritesheet = "code-auto-grid";
                o.graphic.cellMode = cell.mode;
                o.graphic.cellW = cell.fw > 0 ? cell.fw : 0;
                o.graphic.cellH = cell.fh > 0 ? cell.fh : 0;
                max = Math.max(max, t);
            }
            continue;
        }
        // Fluid sheet helpers. Supports the common full-strip signature and the
        // (start_frame, num_frames, ticks) variant used by Stalk Cutter.
        m = line.match(/^(?:([a-z_]\w*)\s*=\s*)?animate_sheet_fluid\((.*)\)$/i);
        if (m) {
            const args = splitArgs(m[2]), o = clipFor(map, args[0]);
            if (!o)
                continue;
            const asset = codeAsset(args[1], constants, assetVars);
            if (asset.path && !o.graphic.projectPath)
                mapCodeAsset(o, asset, o.name || "Particle");
            const st = evalOr(args[2], 0), hasRange = args.length >= 6, startFrame = hasRange ? Math.max(0, Math.floor(evalOr(args[3], 0))) : 0, frameCount = hasRange ? Math.max(1, Math.floor(evalOr(args[4], 1))) : 0, ticks = Math.max(1, Math.floor(evalOr(args[hasRange ? 5 : 3], 2))), cell = codeSheetCell(helper, o);
            o.graphic.spritesheet = "code-auto-grid";
            o.graphic.cellMode = cell.mode;
            o.graphic.cellW = cell.fw > 0 ? cell.fw : 0;
            o.graphic.cellH = cell.fh > 0 ? cell.fh : 0;
            o.graphic.playSheet = true;
            o.graphic.playStart = st;
            o.graphic.playFirstFrame = startFrame;
            o.graphic.playFrameCount = frameCount;
            o.graphic.ticksPerFrame = ticks;
            if (m[1] && frameCount > 0)
                env.vars[m[1]] = frameCount * ticks;
            max = Math.max(max, st + (frameCount > 0 ? frameCount * ticks : ticks * 8));
            continue;
        }
    }
    const explicitEnd = [...String(selected || "").matchAll(/@end_frame\s*=\s*([^#\r\n]+)/g)].map(m => safeEval(m[1], env)).filter(v => v != null);
    if (explicitEnd.length)
        max = Math.max(max, ...explicitEnd);
    const endFrame = explicitEnd.length ? Math.max(...explicitEnd) : max;
    // Static Ruby import no longer hides or moves the contextual User/Target.
    // Direct battler mutations are represented by overlay battler-pictures when
    // they can be interpreted; otherwise Code Capturado is the exact path.
    // Keep base battlers anchored to the current battle context in static code imports.
    // Actual per-frame battler displacement is represented by battler-picture clones
    // above or by Code Capturado, not by moving the contextual base tracks.
    getBattlerTrack(a, "user").positionKeys = [{ id: uid("key"), frame: 0, easing: "linear", point: { anchor: "user_battler", x: 0, y: 0, offsetX: 0, offsetY: 0 } }];
    getBattlerTrack(a, "target").positionKeys = [{ id: uid("key"), frame: 0, easing: "linear", point: { anchor: "target_battler", x: 0, y: 0, offsetX: 0, offsetY: 0 } }];
    a.logic = [...(a.logic || []), { type: "code_dialect", behavior, sideContext, move: variant, source: filename, callbacks: metadata.hasCallbacks, random: metadata.hasRandom }];
    a.duration = Math.max(1, Math.ceil(max + 2));
    for (const clip of getEffectsTrack(a).clips)
        clip.endFrame = Math.max(Number(clip.endFrame || 0), a.duration);
    return a;
}
// -----------------------------------------------------------------------------
// Exact runtime capture importer for code animations
// -----------------------------------------------------------------------------
function decoded(v) { if (v && typeof v === "object" && v.__type)
    return v; return v; }
function argn(args, i, f = 0) { return num(decoded(args === null || args === void 0 ? void 0 : args[i]), f); }
function sampleAbsPosition(obj, frame, fallback = { x: 0, y: 0 }) { const ks = sortPositionKeys(obj); if (!ks.length)
    return fallback; const before = ks.filter(k => k.frame <= frame).at(-1) || ks[0], after = ks.find(k => k.frame >= frame) || ks.at(-1); const pa = before.point || fallback, pb = after.point || pa; if (pa.anchor !== "screen" || pb.anchor !== "screen")
    return { x: num(pa.x, fallback.x), y: num(pa.y, fallback.y) }; if (after.frame === before.frame)
    return { x: num(pa.x), y: num(pa.y) }; const t = (frame - before.frame) / (after.frame - before.frame); return { x: num(pa.x) + (num(pb.x) - num(pa.x)) * t, y: num(pa.y) + (num(pb.y) - num(pa.y)) * t }; }
function applyCapturedOp(a, obj, op) {
    var _a, _b, _c, _d;
    const name = String(op.name || op.op || ""), args = op.args || [], t = argn(args, 0, 0);
    let dur = 0, end = t;
    if (/^move/.test(name)) {
        dur = argn(args, 1, 0);
        end = t + dur;
    }
    if (name === "setXY" || name === "moveXY") {
        const ix = name === "moveXY" ? 2 : 1, iy = name === "moveXY" ? 3 : 2;
        const start = sampleAbsPosition(obj, t);
        setPositionKey(obj, t, { x: start.x, y: start.y }, "linear");
        setPositionKey(obj, end, { x: argn(args, ix, start.x), y: argn(args, iy, start.y) }, "linear");
    }
    else if (name === "moveDelta") {
        const start = sampleAbsPosition(obj, t);
        setPositionKey(obj, t, { x: start.x, y: start.y }, "linear");
        setPositionKey(obj, end, { x: start.x + argn(args, 2), y: start.y + argn(args, 3) }, "linear");
    }
    else if (name === "setZoom" || name === "moveZoom") {
        const v = argn(args, name === "moveZoom" ? 2 : 1, 100);
        if (dur > 0) {
            setValueKey(obj, "scaleX", t, staticValueAt(obj, "scaleX", t, 100), "linear");
            setValueKey(obj, "scaleY", t, staticValueAt(obj, "scaleY", t, 100), "linear");
        }
        setValueKey(obj, "scaleX", end, v, "linear");
        setValueKey(obj, "scaleY", end, v, "linear");
    }
    else if (name === "setZoomXY" || name === "moveZoomXY") {
        const ix = name === "moveZoomXY" ? 2 : 1, iy = name === "moveZoomXY" ? 3 : 2;
        if (dur > 0) {
            setValueKey(obj, "scaleX", t, staticValueAt(obj, "scaleX", t, 100), "linear");
            setValueKey(obj, "scaleY", t, staticValueAt(obj, "scaleY", t, 100), "linear");
        }
        setValueKey(obj, "scaleX", end, argn(args, ix, 100), "linear");
        setValueKey(obj, "scaleY", end, argn(args, iy, 100), "linear");
    }
    else if (name === "setAngle" || name === "moveAngle") {
        if (dur > 0)
            setValueKey(obj, "rotation", t, staticValueAt(obj, "rotation", t, 0), "linear");
        setValueKey(obj, "rotation", end, argn(args, name === "moveAngle" ? 2 : 1, 0), "linear");
    }
    else if (name === "setOpacity" || name === "moveOpacity") {
        if (dur > 0)
            setValueKey(obj, "opacity", t, staticValueAt(obj, "opacity", t, 100), "linear");
        setValueKey(obj, "opacity", end, argn(args, name === "moveOpacity" ? 2 : 1, 255) * 100 / 255, "linear");
    }
    else if (name === "setVisible")
        setVisibleKey(obj, t, !!args[1]);
    else if (name === "setZ")
        setValueKey(obj, "z", t, argn(args, 1, 0), "linear");
    else if (name === "setBlendType")
        setValueKey(obj, "blend", t, argn(args, 1, 0), "linear");
    else if (name === "setSrc") {
        setValueKey(obj, "srcX", t, argn(args, 1, 0), "linear");
        setValueKey(obj, "srcY", t, argn(args, 2, 0), "linear");
    }
    else if (name === "setSrcSize") {
        const sw = argn(args, 1, 0), sh = argn(args, 2, 0);
        setValueKey(obj, "srcW", t, sw, "linear");
        setValueKey(obj, "srcH", t, sh, "linear");
        obj.graphic || (obj.graphic = {});
        obj.graphic.spritesheet = "code-grid";
        if (sw > 0)
            obj.graphic.cellW = sw;
        if (sh > 0)
            obj.graphic.cellH = sh;
    }
    else if (name === "setBitmap") {
        obj.graphic || (obj.graphic = {});
        const v = decoded((_a = args[1]) !== null && _a !== void 0 ? _a : args[0]);
        const path = typeof v === "string" ? v : String((v === null || v === void 0 ? void 0 : v.value) || "");
        obj.graphicSwitches || (obj.graphicSwitches = []);
        obj.graphicSwitches.push({ frame: t, value: path });
        if (path && !obj.graphic.projectPath) {
            obj.graphic.source = "code";
            obj.graphic.projectPath = path;
            obj.graphic.externalRelativePath = path;
            obj.graphic.name = (path.split(/[\\/]/).pop() || obj.name || "").replace(/\.[^.]+$/g, "");
            obj.graphic.folder = path.includes("BattleParticlesAnimations") ? "BattleParticlesAnimations" : path.includes("Battle animations") ? "Battle animations" : "Animations";
        }
    }
    else if (name === "setOrigin") {
        obj.graphic || (obj.graphic = {});
        const v = decoded((_b = args[1]) !== null && _b !== void 0 ? _b : args[0]), s = String((_d = (_c = v === null || v === void 0 ? void 0 : v.value) !== null && _c !== void 0 ? _c : v) !== null && _d !== void 0 ? _d : "").toLowerCase();
        obj.graphic.origin = s.includes("bottom") ? "bottom" : s.includes("top_left") ? "top_left" : s.includes("center") ? "center" : obj.graphic.origin || "auto";
        obj.graphic.originCode = v;
    }
    else if (name === "setPokemonBitmap") {
        obj.graphic || (obj.graphic = {});
        const raw = JSON.stringify(args || []).toLowerCase();
        obj.graphic.source = raw.includes("target") ? "battler-target" : "battler-user";
        obj.graphic.origin = "bottom";
    }
    else if (name === "setTone" || name === "moveTone" || name === "setColor" || name === "moveColor") {
        obj.fxOps || (obj.fxOps = []);
        obj.fxOps.push({ name, args });
    }
    else if (name === "setSE")
        a.events.push({ type: "se", frame: t, name: String(args[1] || ""), volume: argn(args, 2, 100), pitch: argn(args, 3, 100) });
    else if (name === "setCallback") {
        a.runtimeNotes || (a.runtimeNotes = []);
        a.runtimeNotes.push({ type: "callback", frame: t });
    }
    return Math.max(t, end);
}
function addBattlerFrames(track, frames, side) { var _a, _b, _c, _d; if (!Array.isArray(frames) || !frames.length)
    return 0; track.positionKeys = []; track.visibleKeys = []; track.fxOps = []; for (const arr of Object.values(track.valueKeys || {}))
    arr.length = 0; const first = frames.map(f => f === null || f === void 0 ? void 0 : f[side]).find(Boolean) || {}, baseZX = Math.max(0.0001, num((_a = first.zoom_x) !== null && _a !== void 0 ? _a : first.zoomX, 1)), baseZY = Math.max(0.0001, num((_b = first.zoom_y) !== null && _b !== void 0 ? _b : first.zoomY, 1)), baseAngle = num(first.angle, 0); let max = 0, lastFx = ""; for (const f of frames) {
    const fr = num(f.frame, 0), s = f[side];
    if (!s)
        continue;
    setPositionKey(track, fr, { anchor: "screen", x: num(s.x), y: num(s.y), offsetX: 0, offsetY: 0 }, "linear", "screen");
    setVisibleKey(track, fr, s.visible !== false);
    if (s.zoom_x != null || s.zoomX != null)
        setValueKey(track, "scaleX", fr, num((_c = s.zoom_x) !== null && _c !== void 0 ? _c : s.zoomX, baseZX) / baseZX * 100, "linear");
    if (s.zoom_y != null || s.zoomY != null)
        setValueKey(track, "scaleY", fr, num((_d = s.zoom_y) !== null && _d !== void 0 ? _d : s.zoomY, baseZY) / baseZY * 100, "linear");
    if (s.angle != null)
        setValueKey(track, "rotation", fr, num(s.angle, baseAngle) - baseAngle, "linear");
    if (s.opacity != null)
        setValueKey(track, "opacity", fr, num(s.opacity, 255) * 100 / 255, "linear");
    if (s.z != null)
        setValueKey(track, "z", fr, num(s.z, 0), "linear");
    const fxKey = JSON.stringify([s.tone || null, s.color || null]);
    if (fxKey !== lastFx && (s.tone || s.color)) {
        track.fxOps.push({ name: "legacyFx", frame: fr, tone: s.tone || null, color: s.color || null });
        lastFx = fxKey;
    }
    max = Math.max(max, fr);
} track.importedBase = { zoomX: baseZX, zoomY: baseZY, angle: baseAngle }; return max; }
function shiftAnimatableFrames(obj, offset) { var _a, _b, _c; if (!obj || !offset)
    return; for (const k of obj.positionKeys || [])
    k.frame = Number(k.frame || 0) + offset; for (const k of obj.visibleKeys || [])
    k.frame = Number(k.frame || 0) + offset; for (const arr of Object.values(obj.valueKeys || {}))
    for (const k of arr || [])
        k.frame = Number(k.frame || 0) + offset; for (const op of obj.fxOps || [])
    op.frame = Number((_c = (_a = op.frame) !== null && _a !== void 0 ? _a : (_b = op.args) === null || _b === void 0 ? void 0 : _b[0]) !== null && _c !== void 0 ? _c : 0) + offset; for (const sw of obj.graphicSwitches || [])
    sw.frame = Number(sw.frame || 0) + offset; obj.startFrame = Number(obj.startFrame || 0) + offset; obj.endFrame = Number(obj.endFrame || 0) + offset; }
function applySceneEnvelope(a, envelope) { var _a, _b; if (!envelope || typeof envelope !== "object")
    return 0; const type = String(envelope.type || "").toLowerCase(); if (type !== "explosion")
    return 0; const pre = Math.max(0, Number(envelope.pre_frames || 0)); if (pre > 0) {
    shiftAnimatableFrames((_a = a.battlers) === null || _a === void 0 ? void 0 : _a.user, pre);
    shiftAnimatableFrames((_b = a.battlers) === null || _b === void 0 ? void 0 : _b.target, pre);
    for (const t of a.tracks || [])
        for (const c of t.clips || [])
            shiftAnimatableFrames(c, pre);
    for (const ev of a.events || [])
        ev.frame = Number(ev.frame || 0) + pre;
} const covered = Math.max(0, Number(envelope.covered_custom_frames || 0)), fadeIn = Math.max(1, Number(envelope.black_fade_in || 14)), hold = Math.max(0, Number(envelope.black_hold || 14)); a.events.push({ type: "screen_black_envelope", frame: 0, duration: pre + covered, fadeIn, hold }); const baseEnd = Number(a.duration || 0) + pre, wi = Math.max(1, Number(envelope.white_in || 6)), wh = Math.max(0, Number(envelope.white_hold || 12)), wo = Math.max(1, Number(envelope.white_out || 16)); a.events.push({ type: "screen_white_envelope", frame: baseEnd, duration: wi + wh + wo, fadeIn: wi, hold: wh, fadeOut: wo }); a.duration = Math.max(a.duration + pre, baseEnd + wi + wh + wo); a.source.sceneEnvelope = envelope; return pre; }
function applyResolvedPictureFrames(obj, frames) {
    var _a;
    if (!Array.isArray(frames) || !frames.length)
        return 0;
    obj.positionKeys = [];
    obj.visibleKeys = [];
    obj.graphicSwitches = [];
    obj.fxOps = [];
    let max = 0, lastName = null, lastOrigin = null;
    for (const state of frames) {
        const fr = Math.max(0, Math.round(num(state.frame, 0)));
        max = Math.max(max, fr);
        setPositionKey(obj, fr, { anchor: "screen", x: num(state.x), y: num(state.y), offsetX: 0, offsetY: 0 }, "linear", "screen");
        setVisibleKey(obj, fr, state.visible !== false);
        setValueKey(obj, "scaleX", fr, num(state.zoom_x, 100), "linear");
        setValueKey(obj, "scaleY", fr, num(state.zoom_y, 100), "linear");
        setValueKey(obj, "rotation", fr, num(state.angle, 0), "linear");
        setValueKey(obj, "opacity", fr, num(state.opacity, 255) * 100 / 255, "linear");
        setValueKey(obj, "z", fr, num(state.z, 0), "linear");
        setValueKey(obj, "blend", fr, num(state.blend_type, 0), "linear");
        const src = state.src || {};
        if (Number(src.width) > 0 && Number(src.height) > 0) {
            setValueKey(obj, "srcX", fr, num(src.x, 0), "linear");
            setValueKey(obj, "srcY", fr, num(src.y, 0), "linear");
            setValueKey(obj, "srcW", fr, num(src.width, 0), "linear");
            setValueKey(obj, "srcH", fr, num(src.height, 0), "linear");
            obj.graphic || (obj.graphic = {});
            obj.graphic.spritesheet = "code-grid";
            obj.graphic.cellW = Number(src.width);
            obj.graphic.cellH = Number(src.height);
        }
        const name = String(state.name || "");
        if (name && name !== lastName) {
            obj.graphicSwitches.push({ frame: fr, value: name });
            lastName = name;
            if (!((_a = obj.graphic) === null || _a === void 0 ? void 0 : _a.projectPath)) {
                obj.graphic || (obj.graphic = {});
                obj.graphic.source = "code";
                obj.graphic.projectPath = name;
                obj.graphic.externalRelativePath = name;
                obj.graphic.name = (name.split(/[\\/]/).pop() || obj.name || "").replace(/\.[^.]+$/g, "");
                obj.graphic.folder = name.includes("BattleParticlesAnimations") ? "BattleParticlesAnimations" : name.includes("Battle animations") ? "Battle animations" : "Animations";
            }
        }
        const origin = String(state.origin || "").toLowerCase();
        if (origin && origin !== lastOrigin) {
            obj.graphic || (obj.graphic = {});
            obj.graphic.origin = origin.includes("bottom") ? "bottom" : origin.includes("center") ? "center" : origin.includes("top_left") ? "top_left" : obj.graphic.origin || "auto";
            lastOrigin = origin;
        }
        if (state.tone || state.color)
            obj.fxOps.push({ name: "legacyFx", frame: fr, tone: state.tone || null, color: state.color || null });
    }
    return max;
}
export function animationFromCodeCapture(raw) {
    var _a;
    const cap = (raw === null || raw === void 0 ? void 0 : raw.capture) || raw;
    if (!cap || typeof cap !== "object")
        return null;
    const name = cap.move || cap.class_name || cap.className || "Captured Code Animation", a = createAnimation(name);
    a.tracks[0].clips = [];
    a.source = { type: "code", path: cap.source_file || "", className: cap.class_name || "", approximate: false, importMode: "runtime_resolved_frames", capturedAt: cap.captured_at || null, move: cap.move || null, behavior: cap.behavior || "cinematic", sideContext: cap.side_context || ((Number(cap.user_index || 0) % 2 === 1) ? "foe" : "player"), opposing: (cap.side_context === "foe") || (Number(cap.user_index || 0) % 2 === 1), hitNum: Number(cap.hit_num || 0), captureMode: cap.capture_mode || "ops" };
    a.fps = Math.max(1, Number(cap.fps || 40));
    a.events = [];
    let max = 0;
    // The live battler snapshots are authoritative for the original battlers.
    // This prevents addSprite(us)/clones from being drawn on top of a base battler
    // that the Ruby code has already hidden or faded out.
    max = Math.max(max, addBattlerFrames(getBattlerTrack(a, "user"), cap.battler_frames, "user"), addBattlerFrames(getBattlerTrack(a, "target"), cap.battler_frames, "target"));
    for (const pic of cap.pictures || []) {
        const role = String(pic.role || ""), isLive = role === "user" || role === "target";
        // SE/callback operations aren't visual state, so retain them even when the
        // picture itself is represented by resolved per-frame snapshots.
        for (const op of pic.ops || []) {
            const n = String(op.name || op.op || "");
            if (n === "setSE") {
                const args = op.args || [], pictureFps = Math.max(1, Number(cap.picture_fps || 20)), eventFrame = argn(args, 0, 0) * (a.fps / pictureFps);
                a.events.push({ type: "se", frame: eventFrame, name: String((_a = decoded(args[1])) !== null && _a !== void 0 ? _a : ""), volume: argn(args, 2, 100), pitch: argn(args, 3, 100) });
            }
            else if (n === "setCallback")
                a.runtimeNotes || (a.runtimeNotes = []);
        }
        if (isLive)
            continue;
        const obj = createProjectile({ id: uid("clip"), name: pic.name || `Picture ${pic.id}`, type: role.includes("clone") ? "battler-clone" : "code-capture" });
        obj.positionKeys = [];
        obj.visibleKeys = [];
        const init = pic.initial || {};
        setPositionKey(obj, 0, { anchor: "screen", x: num(init.x), y: num(init.y) }, "linear", "screen");
        setVisibleKey(obj, 0, init.visible !== false);
        if (role.includes("user_front")) {
            obj.graphic.source = "battler-user-front";
            obj.graphic.origin = "bottom";
        }
        else if (role.includes("target_front")) {
            obj.graphic.source = "battler-target-front";
            obj.graphic.origin = "bottom";
        }
        else if (role.includes("user")) {
            obj.graphic.source = "battler-user";
            obj.graphic.origin = "bottom";
        }
        else if (role.includes("target")) {
            obj.graphic.source = "battler-target";
            obj.graphic.origin = "bottom";
        }
        else {
            const asset = String(pic.asset || init.name || "");
            obj.graphic.source = "code";
            obj.graphic.projectPath = asset;
            obj.graphic.externalRelativePath = asset;
            obj.graphic.name = (asset.split(/[\\/]/).pop() || pic.name || "").replace(/\.[^.]+$/g, "");
            obj.graphic.folder = asset.includes("BattleParticlesAnimations") ? "BattleParticlesAnimations" : asset.includes("Battle animations") ? "Battle animations" : "Animations";
            const origin = String(pic.origin || init.origin || "").toLowerCase();
            obj.graphic.origin = origin.includes("bottom") ? "bottom" : origin.includes("center") ? "center" : origin.includes("top_left") ? "top_left" : "auto";
        }
        getEffectsTrack(a).clips.push(obj);
        let picMax = 0;
        if (Array.isArray(pic.frames) && pic.frames.length) {
            picMax = applyResolvedPictureFrames(obj, pic.frames);
        }
        else {
            for (const op of pic.ops || []) {
                const n = String(op.name || op.op || "");
                if (n === "setSE" || n === "setCallback")
                    continue;
                const m = applyCapturedOp(a, obj, op);
                picMax = Math.max(picMax, m);
            }
        }
        max = Math.max(max, picMax);
        obj.startFrame = 0;
        obj.endFrame = Math.max(picMax, 0);
    }
    // De-duplicate SEs recorded on multiple views of the same PictureEx.
    const seen = new Set();
    a.events = a.events.filter(ev => { const k = `${ev.type}|${Math.round(num(ev.frame))}|${ev.name}|${ev.volume}|${ev.pitch}`; if (seen.has(k))
        return false; seen.add(k); return true; });
    max = Math.max(max, num(cap.frame_count, 0));
    a.duration = Math.max(1, Math.ceil(max));
    for (const clip of getEffectsTrack(a).clips)
        clip.endFrame = Math.max(Number(clip.endFrame || 0), a.duration);
    applySceneEnvelope(a, cap.scene_envelope);
    return a;
}
// -----------------------------------------------------------------------------
// Vanilla / PkmnAnimations.rxdata importer
// -----------------------------------------------------------------------------
const LEGACY_NO_USER_COMMON = new Set(["Hail", "HarshSun", "HeavyRain", "Rain", "Sandstorm", "Sun", "ShadowSky", "Rainbow", "RainbowOpp", "SeaOfFire", "SeaOfFireOpp", "Swamp", "SwampOpp"]);
const LEGACY_HAS_TARGET_COMMON = new Set(["LeechSeed", "ParentalBond"]);
function legacyParticipation(rec, options = {}) {
    var _a;
    const move = String(rec.move || String(rec.name || "").replace(/^(Common|Move|OppMove)\s*:\s*/i, ""));
    const common = (rec.catalogType === "common") || /^Common\s*:/i.test(String(rec.name || ""));
    let hasUser = true, hasTarget = true;
    if (common) {
        if (LEGACY_NO_USER_COMMON.has(move)) {
            hasUser = false;
            hasTarget = false;
        }
        else if (!LEGACY_HAS_TARGET_COMMON.has(move))
            hasTarget = false;
    }
    const target = String(options.moveTarget || ((_a = options.moveInfo) === null || _a === void 0 ? void 0 : _a.target) || "").replace(/[^A-Za-z]/g, "").toLowerCase();
    if (!common && target && ["user", "userside", "bothsides", "none", "allbattlers", "foeside"].includes(target))
        hasTarget = false;
    return { hasUser, hasTarget, move };
}
export function animationFromLegacy(rec, options = {}) {
    var _a, _b, _c, _d, _e, _f, _g;
    const display = rec.move || String(rec.name || `Animation ${rec.id}`).replace(/^(Common|Move|OppMove)\s*:\s*/i, "");
    const a = createAnimation(display);
    a.tracks[0].clips = [];
    a.source = { type: "vanilla", id: rec.id, move: rec.move || display, version: Number(rec.version || 0), opposing: !!rec.opposing, catalogType: rec.catalogType || (/common/i.test(rec.name || "") ? "common" : "move"), path: rec.sourcePath || options.sourcePath || "", native: true };
    a.fps = 20;
    a.duration = Math.max(1, Number(rec.frame_max || ((_a = rec.frames) === null || _a === void 0 ? void 0 : _a.length) || 1));
    a.events = [];
    const participation = legacyParticipation(rec, options);
    a.noUser = !participation.hasUser;
    a.noTarget = !participation.hasTarget;
    const frames = rec.frames || [], idx = rec._animframe || {};
    const at = (cell, name, fallback) => { var _a, _b; const raw = (_b = (_a = idx[name]) !== null && _a !== void 0 ? _a : idx[String(name).toUpperCase()]) !== null && _b !== void 0 ? _b : fallback, i = Number(raw); return Number.isInteger(i) ? cell === null || cell === void 0 ? void 0 : cell[i] : undefined; };
    const oldUser = { x: 128, y: 224 }, oldTarget = { x: 384, y: 96 };
    const normalizeFocus = (focus) => { focus = Number(focus); return [0, 1, 2, 3, 4].includes(focus) ? focus : 4; };
    const effectiveFocus = (focus) => { let f = normalizeFocus(focus); if ((f === 1 || f === 3) && a.noTarget)
        f = 2; if ((f === 2 || f === 3) && a.noUser)
        f = 0; return f; };
    const graphicSig = (cell) => { const pat = num(at(cell, "pattern", 7), 0); return pat === -1 ? "USER" : pat === -2 ? "TARGET" : `SHEET:${rec.graphic || rec.animation_name || ""}`; };
    const positionFor = (x, y, rawFocus, isUser, isTarget) => {
        if (isUser)
            return { anchor: "user_battler", x: 0, y: 0, offsetX: x - oldUser.x, offsetY: y - oldUser.y };
        if (isTarget)
            return { anchor: "target_battler", x: 0, y: 0, offsetX: x - oldTarget.x, offsetY: y - oldTarget.y };
        let focus = effectiveFocus(rawFocus), valX = x, valY = y;
        if (rawFocus === 1) {
            valX -= oldTarget.x;
            valY -= oldTarget.y;
        }
        else if (rawFocus === 2) {
            valX -= oldUser.x;
            valY -= oldUser.y;
        }
        else if (rawFocus === 3) {
            let ux = oldUser.x, uy = oldUser.y, tx = oldTarget.x, ty = oldTarget.y;
            if (rec.opposing) {
                [ux, tx] = [tx, ux];
                [uy, ty] = [ty, uy];
            }
            valX = ((x - ux) / (tx - ux)) * 200;
            valY = ((y - uy) / (ty - uy)) * (-200);
        }
        // Official converter preserves screen coordinates when user/target participation
        // removes a legacy focus. Apply the same pseudo-focus correction.
        if (rawFocus !== focus) {
            let pseudo = rawFocus;
            if ((pseudo === 1 || pseudo === 3) && a.noTarget)
                pseudo = 2;
            if ((pseudo === 2 || pseudo === 3) && a.noUser) {
                valX += oldUser.x;
                valY += oldUser.y;
            }
        }
        if (focus === 1)
            return { anchor: "pbs:target", x: valX, y: valY, offsetX: 0, offsetY: 0 };
        if (focus === 2)
            return { anchor: "pbs:user", x: valX, y: valY, offsetX: 0, offsetY: 0 };
        if (focus === 3)
            return { anchor: "pbs:user_and_target", x: valX, y: valY, offsetX: 0, offsetY: 0 };
        return { anchor: "screen", x: valX, y: valY, offsetX: 0, offsetY: 0 };
    };
    const zFor = (v, ci) => { v = Number(v || 0); if (v === 0)
        return -50 + ci; if (v === 1)
        return 25 + ci; if (v === 2)
        return -25 + ci; if (v === 3)
        return ci; return v; };
    const propState = new WeakMap();
    const setStepped = (obj, prop, frame, value) => {
        let st = propState.get(obj);
        if (!st) {
            st = {};
            propState.set(obj, st);
        }
        const prev = st[prop];
        if (prev !== undefined && Object.is(prev, value))
            return;
        if (prev !== undefined && frame > 0 && !sortValueKeysCompat(obj, prop).some(k => k.frame === frame - 1))
            setValueKey(obj, prop, frame - 1, prev, "linear");
        setValueKey(obj, prop, frame, value, "linear");
        st[prop] = value;
    };
    function sortValueKeysCompat(obj, prop) { var _a; obj.valueKeys || (obj.valueKeys = {}); (_a = obj.valueKeys)[prop] || (_a[prop] = []); return obj.valueKeys[prop]; }
    const applyCell = (obj, cell, f, ci, isUser, isTarget) => {
        const rawFocus = normalizeFocus(at(cell, "focus", 26)), focus = effectiveFocus(rawFocus), x = num(at(cell, "x", 0), 0), y = num(at(cell, "y", 1), 0), pt = positionFor(x, y, rawFocus, isUser, isTarget);
        // A position change in legacy is instantaneous at the frame boundary; preserve the old value until f-1.
        const ks = sortPositionKeys(obj), last = ks.at(-1);
        if (last && f > 0 && last.frame < f - 1)
            setPositionKey(obj, f - 1, last.point, "linear", last.point.anchor);
        setPositionKey(obj, f, pt, "linear", pt.anchor);
        setStepped(obj, "scaleX", f, num(at(cell, "zoomx", 2), 100));
        setStepped(obj, "scaleY", f, num(at(cell, "zoomy", 11), num(at(cell, "zoomx", 2), 100)));
        setStepped(obj, "rotation", f, num(at(cell, "angle", 3), 0));
        setStepped(obj, "opacity", f, num(at(cell, "opacity", 8), 255) * 100 / 255);
        setStepped(obj, "blend", f, num(at(cell, "blendtype", 5), 0));
        setStepped(obj, "flip", f, num(at(cell, "mirror", 4), 0) ? 1 : 0);
        if (!isUser && !isTarget)
            setStepped(obj, "z", f, zFor(at(cell, "priority", 25), ci));
        const pat = num(at(cell, "pattern", 7), 0);
        if (!isUser && !isTarget && pat >= 0)
            setStepped(obj, "graphicFrame", f, pat);
        const tone = { red: num(at(cell, "tonered", 16), 0), green: num(at(cell, "tonegreen", 17), 0), blue: num(at(cell, "toneblue", 18), 0), gray: num(at(cell, "tonegray", 19), 0) };
        const color = { red: num(at(cell, "colorred", 12), 0), green: num(at(cell, "colorgreen", 13), 0), blue: num(at(cell, "colorblue", 14), 0), alpha: num(at(cell, "coloralpha", 15), 0) };
        obj.fxOps || (obj.fxOps = []);
        const lfx = obj.fxOps.at(-1);
        if (!lfx || lfx.frame !== f || JSON.stringify(lfx.tone) !== JSON.stringify(tone) || JSON.stringify(lfx.color) !== JSON.stringify(color))
            obj.fxOps.push({ name: "legacyFx", frame: f, tone, color });
    };
    // User and target are persistent tracks.
    for (const [ci, side] of [[0, "user"], [1, "target"]]) {
        const obj = getBattlerTrack(a, side);
        obj.positionKeys = [];
        obj.visibleKeys = [];
        const present = side === "user" ? participation.hasUser : participation.hasTarget;
        if (!present) {
            setVisibleKey(obj, 0, false);
            continue;
        }
        for (let f = 0; f < frames.length; f++) {
            const cell = (_b = frames[f]) === null || _b === void 0 ? void 0 : _b[ci];
            if (!Array.isArray(cell)) {
                setVisibleKey(obj, f, false);
                continue;
            }
            setVisibleKey(obj, f, num(at(cell, "visible", 6), 1) === 1);
            applyCell(obj, cell, f, ci, side === "user", side === "target");
        }
    }
    // Non-battler cells must split into a new particle when focus or graphic changes,
    // exactly like New Animation Editor's official old->new converter.
    const maxCells = Math.max(0, ...frames.map(f => Array.isArray(f) ? f.length : 0));
    for (let ci = 2; ci < maxCells; ci++) {
        let current = null, signature = null, part = 0;
        const close = (f) => { if (current) {
            setVisibleKey(current, f, false);
            current.endFrame = Math.max(current.startFrame, f);
            current = null;
            signature = null;
        } };
        for (let f = 0; f < frames.length; f++) {
            const cell = (_c = frames[f]) === null || _c === void 0 ? void 0 : _c[ci];
            if (!Array.isArray(cell)) {
                close(f);
                continue;
            }
            const focus = effectiveFocus(at(cell, "focus", 26)), gs = graphicSig(cell), sig = `${focus}|${gs}`;
            if (!current || sig !== signature) {
                close(f);
                part++;
                current = createProjectile({ id: uid("clip"), name: `Cell ${ci + 1}${part > 1 ? ` · ${part}` : ""}`, type: "vanilla-cell" });
                current.positionKeys = [];
                current.visibleKeys = [];
                current.valueKeys = Object.assign({}, current.valueKeys);
                current.startFrame = f;
                current.imported = { format: "vanilla", cellIndex: ci, focus, locked: num(at(cell, "locked", 20), 0) === 1 };
                const pat = num(at(cell, "pattern", 7), 0);
                if (pat === -1) {
                    current.graphic.source = "battler-user";
                    current.graphic.origin = "bottom";
                }
                else if (pat === -2) {
                    current.graphic.source = "battler-target";
                    current.graphic.origin = "bottom";
                }
                else {
                    current.graphic.source = "legacy";
                    current.graphic.name = String(rec.graphic || rec.animation_name || "").replace(/\.png$/i, "");
                    current.graphic.folder = "Animations";
                    current.graphic.projectPath = `Graphics/Animations/${String(rec.graphic || rec.animation_name || "").replace(/^Graphics[\\/]Animations[\\/]/i, "")}`;
                    current.graphic.spritesheet = "rmxp";
                    current.graphic.cellW = 192;
                    current.graphic.cellH = 192;
                    current.graphic.cols = 5;
                    current.graphic.hue = Number(rec.hue || 0);
                    if (options.sourceRoot)
                        current.graphic.externalGameRoot = options.sourceRoot;
                }
                getEffectsTrack(a).clips.push(current);
                signature = sig;
                setVisibleKey(current, 0, false);
                setVisibleKey(current, f, true);
            }
            setVisibleKey(current, f, num(at(cell, "visible", 6), 1) === 1);
            applyCell(current, cell, f, ci, false, false);
            current.endFrame = f;
        }
        close(frames.length);
    }
    // Legacy BG/FG timing commands become actual screen particles.
    let bg = null, fg = null;
    const screenParticle = (kind, t) => { let obj = kind === "background" ? bg : fg; if (obj)
        return obj; obj = createProjectile({ id: uid("clip"), name: kind === "background" ? "Legacy Background" : "Legacy Foreground", type: `legacy-${kind}` }); obj.positionKeys = []; obj.visibleKeys = []; obj.positionKeys.push({ id: uid("key"), frame: 0, easing: "linear", point: { anchor: "screen", x: 0, y: 0, offsetX: 0, offsetY: 0 } }); obj.visual.z = kind === "background" ? -10000 : 10000; obj.pbs = { focus: kind, tiled: true }; obj.graphic.origin = "top_left"; setVisibleKey(obj, 0, false); getEffectsTrack(a).clips.push(obj); if (kind === "background")
        bg = obj;
    else
        fg = obj; return obj; };
    for (const t of rec.timing || []) {
        const fr = Math.max(0, Number(t.frame || 0)), type = Number(t.type || 0);
        if (type === 0) {
            if (t.name) {
                let se = String(t.name).replace(/\.(wav|ogg|mp3)$/i, "");
                if (!/[\/]/.test(se))
                    se = `Anim/${se}`;
                a.events.push({ type: "se", frame: fr, name: se, volume: Number(t.volume || 100), pitch: Number(t.pitch || 100) });
            }
            else
                a.events.push({ type: "user_cry", frame: fr, volume: Number(t.volume || 100), pitch: Number(t.pitch || 100) });
            continue;
        }
        if (type >= 1 && type <= 4) {
            const kind = type <= 2 ? "background" : "foreground", obj = screenParticle(kind, t);
            const dur = (type === 2 || type === 4) ? Math.max(0, Number(t.duration || 0)) : 0;
            setVisibleKey(obj, fr, true);
            if (t.name) {
                obj.graphic.source = "legacy";
                obj.graphic.folder = "Animations";
                obj.graphic.name = String(t.name).replace(/\.png$/i, "");
                obj.graphic.projectPath = `Graphics/Animations/${t.name}`;
                obj.graphic.spritesheet = "single";
                if (options.sourceRoot)
                    obj.graphic.externalGameRoot = options.sourceRoot;
            }
            else
                obj.graphic.syntheticColor = true;
            const end = fr + dur, setK = (prop, val, transform = x => x) => { if (val == null)
                return; if (dur > 0) {
                const old = sampleLegacyValue(obj, prop, fr, prop === "opacity" ? 0 : 0);
                setValueKey(obj, prop, fr, old, "linear");
            } setValueKey(obj, prop, end, transform(Number(val)), "linear"); };
            setK("opacity", t.opacity, x => x * 100 / 255); /* Legacy bgX/bgY are stored as the negative sprite origin; screen draw position is therefore +bgX/+bgY. */
            const p0 = { anchor: "screen", x: Number(t.x || 0), y: Number(t.y || 0), offsetX: 0, offsetY: 0 };
            setPositionKey(obj, end, p0, "linear", "screen");
            obj.fxOps.push({ name: "legacyBgFg", frame: fr, duration: dur, color: { red: Number(((_d = t.color) === null || _d === void 0 ? void 0 : _d[0]) || 0), green: Number(((_e = t.color) === null || _e === void 0 ? void 0 : _e[1]) || 0), blue: Number(((_f = t.color) === null || _f === void 0 ? void 0 : _f[2]) || 0), alpha: Number(((_g = t.color) === null || _g === void 0 ? void 0 : _g[3]) || 0) } });
            a.duration = Math.max(a.duration, end);
        }
    }
    function sampleLegacyValue(o, prop, f, def) { var _a; const ks = (((_a = o.valueKeys) === null || _a === void 0 ? void 0 : _a[prop]) || []).slice().sort((x, y) => x.frame - y.frame); let v = def; for (const k of ks) {
        if (k.frame > f)
            break;
        v = k.value;
    } return v; }
    a.duration = Math.max(a.duration, frames.length);
    return a;
}
