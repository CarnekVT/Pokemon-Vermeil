import { scanProjectFiles } from "./assets.js";
import { fallbackBattleContext } from "./context.js";
function stripRubyComment(line) {
    let q = false, quote = "";
    for (let i = 0; i < String(line || "").length; i++) {
        const c = line[i];
        if ((c === '"' || c === "'") && line[i - 1] !== "\\" && (!q || quote === c)) {
            q = !q;
            quote = q ? c : "";
            continue;
        }
        if (c === "#" && !q)
            return line.slice(0, i);
    }
    return line;
}
function basename(p) { return String(p || "").replace(/\\/g, "/").split("/").pop() || ""; }
function lower(p) { return String(p || "").replace(/\\/g, "/").toLowerCase(); }
function scoreSettingsCandidate(path, kind, source) {
    const p = lower(path);
    let score = 0;
    // Plugin overrides are loaded after base Essentials scripts and therefore win.
    if (source === "plugin")
        score += 400;
    if (p.includes("carnek project settings"))
        score += 500;
    if (/\/settings\/settings\.rb$/.test(p))
        score += 220;
    if (/settings\.rb$/.test(p))
        score += 100;
    if (p.includes("resolution") || p.includes("screen"))
        score += 60;
    if (kind === "resize_screen")
        score += 35;
    if (source === "script" && p.includes("scripts/001_settings/002_settings.rb"))
        score -= 100;
    return score;
}
function evalDimExpr(expr, width, height) {
    let s = String(expr || "").trim();
    s = s.replace(/Settings::SCREEN_WIDTH/g, String(width)).replace(/Settings::SCREEN_HEIGHT/g, String(height));
    if (!/^[\d\s()+\-*/.]+$/.test(s))
        return null;
    try {
        const v = Function(`"use strict"; return (${s});`)();
        return Number.isFinite(Number(v)) ? Number(v) : null;
    }
    catch (_a) {
        return null;
    }
}
async function scanBattleSceneGeometry(ctx, width, height) {
    let files = [];
    try {
        files = await scanProjectFiles(ctx, "Scripts", ["rb"], 8);
    }
    catch (_a) {
        return null;
    }
    const likely = files.filter(f => /battle_scene\.rb$/i.test(f.filename) || /scene[\\/]002_battle_scene\.rb/i.test(f.projectPath));
    for (const file of likely) {
        let text = "";
        try {
            text = await ctx.fs.readProjectFile(file.projectPath);
        }
        catch (_b) {
            continue;
        }
        const clean = text.split(/\r?\n/).map(stripRubyComment).join("\n");
        const c = {};
        for (const name of ["PLAYER_BASE_X", "FOCUSUSER_X", "FOCUSUSER_Y", "FOCUSTARGET_X", "FOCUSTARGET_Y"]) {
            const m = clean.match(new RegExp(`\\b${name}\\s*=\\s*([^\\n;]+)`));
            if (m)
                c[name] = evalDimExpr(m[1], width, height);
        }
        const methodExpr = (name) => {
            const m = clean.match(new RegExp(`def\\s+self\\.${name}\\s*;\\s*([^;]+);\\s*end`));
            if (m)
                return evalDimExpr(m[1], width, height);
            const m2 = clean.match(new RegExp(`def\\s+self\\.${name}[^\\n]*\\n([\\s\\S]{0,200}?)\\n\\s*end`));
            if (m2) {
                const ret = m2[1].match(/(?:return\s+)?([^\n#]+)/);
                if (ret)
                    return evalDimExpr(ret[1], width, height);
            }
            return null;
        };
        c.PLAYER_BASE_Y = methodExpr("PLAYER_BASE_Y");
        c.FOE_BASE_X = methodExpr("FOE_BASE_X");
        c.FOE_BASE_Y = methodExpr("FOE_BASE_Y");
        if (Number.isFinite(c.PLAYER_BASE_X) && Number.isFinite(c.PLAYER_BASE_Y) && Number.isFinite(c.FOE_BASE_X) && Number.isFinite(c.FOE_BASE_Y))
            return Object.assign(Object.assign({}, c), { path: file.projectPath });
    }
    return null;
}

async function scanEbdxMetrics(ctx, width, height) {
    const paths = ["PBS/EBDX/metrics.txt", "PBS/metrics.txt"];
    let text = "", foundPath = "";
    for (const path of paths) {
        try {
            if (await ctx.fs.projectExists(path)) {
                text = await ctx.fs.readProjectFile(path);
                foundPath = path;
                break;
            }
        }
        catch (_a) { }
    }
    if (!text)
        return null;
    function section(name) {
        const m = text.match(new RegExp("^\\s*\\[" + name.replace(/[.*+?^${}()|[\\]\\]/g, "\\$&") + "\\]\\s*([\\s\\S]*?)(?=^\\s*\\[|\\s*$)", "mi"));
        return m ? m[1] : "";
    }
    function xyz(sec) {
        const body = section(sec);
        const m = body.match(/SINGLE[\s\S]*?XYZ\s*=\s*([-+]?\d+(?:\.\d+)?)\s*,\s*([-+]?\d+(?:\.\d+)?)\s*,\s*([-+]?\d+(?:\.\d+)?)/i) || body.match(/XYZ\s*=\s*([-+]?\d+(?:\.\d+)?)\s*,\s*([-+]?\d+(?:\.\d+)?)\s*,\s*([-+]?\d+(?:\.\d+)?)/i);
        if (!m)
            return null;
        return { x: Number(m[1]), y: Number(m[2]), z: Number(m[3]) };
    }
    const u = xyz("BATTLERPOS-0"), t = xyz("BATTLERPOS-1");
    if (!u || !t)
        return null;
    return { path: foundPath, user: u, target: t };
}

export async function detectProjectBattleContext(ctx) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const candidates = [];
    const add = (width, height, path, kind, source = "other") => {
        width = Number(width);
        height = Number(height);
        if (!Number.isFinite(width) || !Number.isFinite(height) || width < 160 || height < 120)
            return;
        candidates.push({ width, height, path, kind, source, score: scoreSettingsCandidate(path, kind, source) });
    };
    try {
        if (await ctx.fs.projectExists("mkxp.json")) {
            const j = JSON.parse(await ctx.fs.readProjectFile("mkxp.json"));
            add((_b = (_a = j.defScreenW) !== null && _a !== void 0 ? _a : j.screenWidth) !== null && _b !== void 0 ? _b : j.width, (_d = (_c = j.defScreenH) !== null && _c !== void 0 ? _c : j.screenHeight) !== null && _d !== void 0 ? _d : j.height, "mkxp.json", "mkxp.json", "config");
        }
    }
    catch (_j) { }
    const roots = [{ path: "Scripts", source: "script" }, { path: "Plugins", source: "plugin" }];
    for (const root of roots) {
        let files = [];
        try {
            files = await scanProjectFiles(ctx, root.path, ["rb"], 18);
        }
        catch (_k) { }
        for (const file of files) {
            let text = "";
            try {
                text = await ctx.fs.readProjectFile(file.projectPath);
            }
            catch (_l) {
                continue;
            }
            const clean = text.split(/\r?\n/).map(stripRubyComment).join("\n");
            const wm = [...clean.matchAll(/(?:Settings::)?SCREEN_WIDTH\s*=\s*(\d+)/g)];
            const hm = [...clean.matchAll(/(?:Settings::)?SCREEN_HEIGHT\s*=\s*(\d+)/g)];
            if (wm.length && hm.length)
                add(wm.at(-1)[1], hm.at(-1)[1], file.projectPath, "Settings", root.source);
            for (const m of clean.matchAll(/Graphics\.resize_screen\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)/g))
                add(m[1], m[2], file.projectPath, "resize_screen", root.source);
        }
    }
    if (!candidates.length)
        return null;
    // Highest load priority first. Equal-priority candidates prefer the largest explicit canvas.
    candidates.sort((a, b) => b.score - a.score || (b.width * b.height) - (a.width * a.height));
    const best = candidates[0];
    const c = fallbackBattleContext(best.width, best.height, "project");
    c.captureKind = `${best.kind} · ${basename(best.path)}`;
    c.projectPath = best.path;
    c.detectedCandidates = candidates.slice(0, 20);
    const geom = await scanBattleSceneGeometry(ctx, best.width, best.height);
    if (geom) {
        c.scriptGeometryPath = geom.path;
        c.scriptUser = { x: geom.PLAYER_BASE_X, y: geom.PLAYER_BASE_Y };
        c.scriptTarget = { x: geom.FOE_BASE_X, y: geom.FOE_BASE_Y };
        c.user.x = c.scriptUser.x;
        c.user.y = c.scriptUser.y;
        c.user.focusX = c.scriptUser.x;
        c.user.focusY = c.scriptUser.y - 40;
        c.target.x = c.scriptTarget.x;
        c.target.y = c.scriptTarget.y;
        c.target.focusX = c.scriptTarget.x;
        c.target.focusY = c.scriptTarget.y - 40;
        // Legacy focus constants are kept for RXDATA conversion; actual sprite focus is refined once a battler image/runtime capture exists.
        c.legacyFocus = {
            userX: (_e = geom.FOCUSUSER_X) !== null && _e !== void 0 ? _e : 128, userY: (_f = geom.FOCUSUSER_Y) !== null && _f !== void 0 ? _f : 224,
            targetX: (_g = geom.FOCUSTARGET_X) !== null && _g !== void 0 ? _g : 384, targetY: (_h = geom.FOCUSTARGET_Y) !== null && _h !== void 0 ? _h : 96
        };
    }
    const ebdx = await scanEbdxMetrics(ctx, best.width, best.height);
    if (ebdx) {
        // EBDX stores battle positions in its own metrics. They are loaded after
        // the base scene constants, so prefer them for the editor's project
        // preview if the plugin/PBS data exists. Runtime capture still wins while
        // a real battle is open.
        c.ebdxMetricsPath = ebdx.path;
        c.captureKind = `Settings + EBDX · ${basename(ebdx.path)}`;
        c.scriptUser = { x: ebdx.user.x, y: ebdx.user.y };
        c.scriptTarget = { x: ebdx.target.x, y: ebdx.target.y };
        c.user.x = ebdx.user.x;
        c.user.y = ebdx.user.y;
        c.user.z = ebdx.user.z;
        c.user.focusX = ebdx.user.x;
        c.user.focusY = ebdx.user.y - 40;
        c.target.x = ebdx.target.x;
        c.target.y = ebdx.target.y;
        c.target.z = ebdx.target.z;
        c.target.focusX = ebdx.target.x;
        c.target.focusY = ebdx.target.y - 40;
    }
    return c;
}
function parseMovesText(text, map, orderRef) {
    let id = null, name = null, target = null;
    const flush = () => { var _a; if (!id)
        return; const old = map.get(id); map.set(id, { id, name: name || (old === null || old === void 0 ? void 0 : old.name) || id, target: target || (old === null || old === void 0 ? void 0 : old.target) || null, order: (_a = old === null || old === void 0 ? void 0 : old.order) !== null && _a !== void 0 ? _a : orderRef.value++ }); };
    for (const raw of String(text || "").split(/\r?\n/)) {
        const line = stripRubyComment(raw).trim();
        if (!line)
            continue;
        const sec = line.match(/^\[\s*([^\]]+)\s*\]$/);
        if (sec) {
            flush();
            id = sec[1].trim().toUpperCase();
            name = null;
            target = null;
            continue;
        }
        if (id) {
            const m = line.match(/^Name\s*=\s*(.+)$/i);
            if (m)
                name = m[1].trim();
            const tm = line.match(/^Target\s*=\s*(.+)$/i);
            if (tm)
                target = tm[1].trim();
        }
    }
    flush();
}
export async function loadProjectMoveCatalog(ctx) {
    var _a, _b, _c;
    const map = new Map(), orderRef = { value: 0 }, paths = [];
    try {
        if (await ctx.fs.projectExists("PBS/moves.txt"))
            paths.push("PBS/moves.txt");
    }
    catch (_d) { }
    try {
        const files = await scanProjectFiles(ctx, "Plugins", ["txt"], 16);
        for (const f of files)
            if (/^moves\.txt$/i.test(f.filename))
                paths.push(f.projectPath);
    }
    catch (_e) { }
    for (const path of paths) {
        try {
            parseMovesText(await ctx.fs.readProjectFile(path), map, orderRef);
        }
        catch (_f) { }
    }
    try {
        const rows = ((_b = (_a = ctx.projectData).moves) === null || _b === void 0 ? void 0 : _b.call(_a)) || [];
        for (const r of rows) {
            const id = String((r === null || r === void 0 ? void 0 : r.id) || (r === null || r === void 0 ? void 0 : r.internal_name) || (r === null || r === void 0 ? void 0 : r.key) || "").toUpperCase();
            if (!id)
                continue;
            const old = map.get(id);
            map.set(id, { id, name: (r === null || r === void 0 ? void 0 : r.name) || (old === null || old === void 0 ? void 0 : old.name) || id, order: (_c = old === null || old === void 0 ? void 0 : old.order) !== null && _c !== void 0 ? _c : orderRef.value++ });
        }
    }
    catch (_g) { }
    return map;
}
// -----------------------------------------------------------------------------
// Battler rendering compatibility (Essentials metrics + DBK animated battlers)
// -----------------------------------------------------------------------------
let _battlerCompatCache = null;
function parseMetricsFiles(text, out) {
    let id = null;
    const flushLine = (line) => {
        if (!id)
            return;
        const m = String(line || "").match(/^([^=]+?)\s*=\s*(.*)$/);
        if (!m)
            return;
        const key = m[1].trim().toLowerCase();
        const vals = m[2].split(",").map(x => x.trim()).filter(Boolean).map(Number);
        const rec = out.get(id) || { id, back: [0, 0, null], front: [0, 0, null], altitude: 0, speed: [2, 2] };
        if (key === "backsprite" && vals.length >= 2)
            rec.back = [vals[0] || 0, vals[1] || 0, Number.isFinite(vals[2]) ? vals[2] : null];
        else if (key === "frontsprite" && vals.length >= 2)
            rec.front = [vals[0] || 0, vals[1] || 0, Number.isFinite(vals[2]) ? vals[2] : null];
        else if (key === "frontspritealtitude" && vals.length)
            rec.altitude = vals[0] || 0;
        else if (key === "animationspeed" && vals.length)
            rec.speed = [vals[0] || 2, vals[1] || vals[0] || 2];
        out.set(id, rec);
    };
    for (const raw of String(text || "").split(/\r?\n/)) {
        const line = stripRubyComment(raw).trim();
        if (!line)
            continue;
        const sec = line.match(/^\[\s*([^\]]+)\s*\]$/);
        if (sec) {
            id = sec[1].trim().toUpperCase();
            continue;
        }
        flushLine(line);
    }
}
async function loadBattlerCompatDatabase(ctx) {
    if (_battlerCompatCache)
        return _battlerCompatCache;
    const metrics = new Map();
    let dbk = false, backScale = 1, frontScale = 1, frameDelay = 60;
    try {
        const files = await scanProjectFiles(ctx, "PBS", ["txt"], 5);
        for (const file of files.filter(f => /^pokemon_metrics.*\.txt$/i.test(f.filename))) {
            try {
                parseMetricsFiles(await ctx.fs.readProjectFile(file.projectPath), metrics);
            }
            catch (_a) { }
        }
    }
    catch (_b) { }
    try {
        const files = await scanProjectFiles(ctx, "Plugins", ["rb"], 18);
        for (const file of files) {
            const p = lower(file.projectPath);
            if (p.includes("sprites animados dbk") || p.includes("animated pokemon") || p.includes("deluxe bitmap"))
                dbk = true;
            if (!/(settings\.rb$|game data\.rb$)/i.test(file.filename))
                continue;
            let text = "";
            try {
                text = await ctx.fs.readProjectFile(file.projectPath);
            }
            catch (_c) {
                continue;
            }
            let m = text.match(/BACK_BATTLER_SPRITE_SCALE\s*=\s*(\d+(?:\.\d+)?)/);
            if (m)
                backScale = Number(m[1]);
            m = text.match(/FRONT_BATTLER_SPRITE_SCALE\s*=\s*(\d+(?:\.\d+)?)/);
            if (m)
                frontScale = Number(m[1]);
            m = text.match(/ANIMATION_FRAME_DELAY\s*=\s*(\d+(?:\.\d+)?)/);
            if (m)
                frameDelay = Number(m[1]);
        }
    }
    catch (_d) { }
    _battlerCompatCache = { metrics, dbk, backScale, frontScale, frameDelay };
    return _battlerCompatCache;
}
function candidateSpeciesIds(config = {}) {
    const raw = String(config.name || config.projectPath || "").replace(/\\/g, "/").split("/").pop().replace(/\.[^.]+$/, "").toUpperCase();
    if (!raw)
        return [];
    const ret = [raw];
    // Essentials battler filenames may append form/gender/shiny suffixes. Prefer
    // the exact section, then fall back to the base species ID.
    const pieces = raw.split(/[_-]/);
    if (pieces.length > 1)
        ret.push(pieces[0]);
    return [...new Set(ret)];
}
export async function loadBattlerRenderingInfo(ctx, config = {}, side = "user") {
    var _a, _b, _c;
    const db = await loadBattlerCompatDatabase(ctx);
    const projectPath = String((config && config.projectPath) || "").replace(/\\/g, "/");
    const lowerPath = lower(projectPath);
    const isPokemonSprite = /graphics\/(?:pokemon\/(back|front)|ebdx\/battlers\/(back|front))\//.test(lowerPath);
    const speciesCandidates = candidateSpeciesIds(config);
    let rec = null, speciesId = speciesCandidates[0] || "";
    for (const id of speciesCandidates) {
        if (db.metrics.has(id)) {
            rec = db.metrics.get(id);
            speciesId = id;
            break;
        }
    }
    const back = side === "user";
    const metric = back ? ((rec && rec.back) || [0, 0, null]) : ((rec && rec.front) || [0, 0, null]);
    // DBK only scales real Pokemon battler sheets. UI test sprites such as
    // AnimBackTest/AnimFrontTest are already editor-ready and must not receive
    // FRONT/BACK_BATTLER_SPRITE_SCALE, otherwise they explode out of frame.
    const metricScale = Number(metric && metric[2]);
    const scale = isPokemonSprite
        ? (Number.isFinite(metricScale) ? metricScale : (db.dbk ? (back ? db.backScale : db.frontScale) : 1))
        : 1;
    const uiAnimTest = /graphics\/ui\/anim(?:back|front)test/i.test(lowerPath);
    const finalScale = uiAnimTest ? 0.35 : scale;
    const speed = Number((_c = (back ? (_a = rec && rec.speed) === null || _a === void 0 ? void 0 : _a[0] : (_b = rec && rec.speed) === null || _b === void 0 ? void 0 : _b[1])) !== null && _c !== void 0 ? _c : 2) || 2;
    return {
        dbk: !!db.dbk && isPokemonSprite,
        speciesId,
        projectPath,
        metricX: isPokemonSprite ? Number((metric && metric[0]) || 0) * 2 : 0,
        metricY: isPokemonSprite ? (Number((metric && metric[1]) || 0) * 2 - (!back ? Number((rec && rec.altitude) || 0) * 2 : 0)) : 0,
        scale: Math.max(0.05, finalScale || 1),
        animationSpeed: speed,
        frameDelayMs: Math.max(16, ((speed / 2) * Number(db.frameDelay || 60))),
        source: rec ? "pokemon_metrics" : (isPokemonSprite && db.dbk ? "dbk-default" : (lowerPath.includes("graphics/ui/anim") ? "anim-test" : "editor-default"))
    };
}
export function clearBattlerRenderingCache() { _battlerCompatCache = null; }
