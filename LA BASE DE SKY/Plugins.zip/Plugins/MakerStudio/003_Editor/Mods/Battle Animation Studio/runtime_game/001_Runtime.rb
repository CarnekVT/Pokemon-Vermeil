#===============================================================================
# Battle Animation Studio Runtime v1.2
# Plays animations exported by the Maker Studio Battle Animation Studio.
# Source data: PBS/AnimationStudio/compiled_animations.json
#===============================================================================
begin
  require "json"
rescue LoadError
end

module BattleAnimationStudioRuntime
  DATA_FILE = File.join("PBS", "AnimationStudio", "compiled_animations.json")
  VERSION = 11
  @cache = nil
  @mtime = nil

  module_function

  def log(msg)
    echoln("[Battle Animation Studio Runtime] #{msg}") if defined?(echoln)
  rescue
  end

  def normalize_move_id(move)
    return move.id.to_s.upcase if move.respond_to?(:id)
    return move.to_s.sub(/^:/, "").upcase
  rescue
    move.to_s.upcase
  end

  def load_data
    return nil if !File.exist?(DATA_FILE)
    mtime = File.mtime(DATA_FILE).to_i rescue 0
    return @cache if @cache && @mtime == mtime
    if !defined?(JSON)
      log("Ruby JSON is unavailable; cannot read #{DATA_FILE}.")
      return nil
    end
    @cache = JSON.parse(File.binread(DATA_FILE))
    @mtime = mtime
    @cache
  rescue => e
    log("#{e.class}: #{e.message}")
    @cache = nil
  end

  def animations
    data = load_data
    arr = data && data["animations"]
    arr.is_a?(Array) ? arr : []
  end

  def source_of(anim)
    s = anim["source"]
    s.is_a?(Hash) ? s : {}
  end

  def matching(move_id, version, user_index, common = false)
    mid = normalize_move_id(move_id)
    list = animations.select do |anim|
      src = source_of(anim)
      cat = src["catalogType"].to_s.downcase
      is_common = (cat == "common")
      next false if is_common != common
      wanted = (src["move"] || anim["name"]).to_s.upcase
      next false if wanted != mid
      next false if src.key?("runtimeEnabled") && !src["runtimeEnabled"]
      true
    end
    return nil if list.empty?
    ver = version.to_i
    exact_version = list.select { |a| source_of(a)["version"].to_i == ver }
    list = exact_version unless exact_version.empty?
    opposing = user_index.to_i.odd?
    exact_side = list.find { |a| !!source_of(a)["opposing"] == opposing }
    exact_side || list.find { |a| !source_of(a)["opposing"] } || list.first
  end

  def common_matching(name, user_index)
    matching(name, 0, user_index || 0, true)
  end

  def deep_number(value, fallback = 0.0)
    n = value.to_f
    n.finite? ? n : fallback
  rescue
    fallback
  end

   DEFAULT_BATTLER_WIDTH  = 96
   DEFAULT_BATTLER_HEIGHT = 96
   class Player
     def initialize(sprites, viewport, user, target, data)
      @sprites = sprites || {}
      @viewport = viewport
      @user = user
      @target = target || user
      @data = data || {}
      @frame = 0.0
      @previous_event_frame = nil
      @done = false
      @effect_sprites = {}
      @effect_bitmap_names = {}
      @overlay_sprites = []
      @original = {}
      capture_original_battlers
      create_effect_sprites
    end

    def animDone?; @done; end

    def duration
      [1.0, (@data["duration"] || 1).to_f].max
    end

    # Studio animations can use 20 FPS (PBS, legacy and static PictureEx code)
    # or the game's actual frame rate (resolved runtime captures). The battle
    # scene itself still updates at Graphics.frame_rate, so advance the Studio
    # timeline by the proper fractional amount instead of assuming 1 Studio
    # frame == 1 game update.
    def animation_fps
      [1.0, (@data["fps"] || 20).to_f].max
    end

    def game_fps
      fps = Graphics.frame_rate.to_f rescue 40.0
      [1.0, fps].max
    end

    def frame_step
      animation_fps / game_fps
    end

    def user_sprite
      @user ? @sprites["pokemon_#{@user.index}"] : nil
    end

    def target_sprite
      @target ? @sprites["pokemon_#{@target.index}"] : nil
    end

    def capture_sprite(sprite)
      return nil if !sprite
      { x: sprite.x, y: sprite.y, zoom_x: sprite.zoom_x, zoom_y: sprite.zoom_y,
        angle: sprite.angle, opacity: sprite.opacity, visible: sprite.visible,
        z: sprite.z, mirror: (sprite.mirror rescue false), tone: (sprite.tone.clone rescue nil),
        color: (sprite.color.clone rescue nil) }
    end

    def capture_original_battlers
      @original[:user] = capture_sprite(user_sprite)
      @original[:target] = capture_sprite(target_sprite)
    end

    def restore_sprite(sprite, st)
      return if !sprite || !st
      st.each do |key, value|
        next if [:tone, :color].include?(key)
        writer = "#{key}="
        sprite.send(writer, value) if sprite.respond_to?(writer)
      end
      sprite.tone = st[:tone] if st[:tone] && sprite.respond_to?(:tone=)
      sprite.color = st[:color] if st[:color] && sprite.respond_to?(:color=)
    rescue
    end

    def dispose
      restore_sprite(user_sprite, @original[:user])
      restore_sprite(target_sprite, @original[:target]) if target_sprite != user_sprite
      @effect_sprites.each_value { |s| s.dispose if s && !s.disposed? }
      @overlay_sprites.each { |s| s.dispose if s && !s.disposed? }
      @effect_sprites.clear
      @overlay_sprites.clear
    end

    def tracks
      @data["tracks"].is_a?(Array) ? @data["tracks"] : []
    end

    def clips
      tracks.flat_map { |t| t["clips"].is_a?(Array) ? t["clips"] : [] }
    end

    def battler_track(side)
      h = @data["battlers"]
      h.is_a?(Hash) ? h[side.to_s] : nil
    end

    def create_front_battler(side)
      battler = side == :target ? @target : @user
      return nil if !battler
      begin
        side_size = battler.battle.pbSideSize(battler.index) rescue 1
        sprite = Battle::Scene::BattlerSprite.new(@viewport, side_size, battler.index, [])
        pkmn = battler.respond_to?(:visiblePokemon) ? battler.visiblePokemon : nil
        pkmn ||= battler.pokemon if battler.respond_to?(:pokemon)
        begin
          sprite.setPokemonBitmap(pkmn, battler, false)
        rescue
          sprite.setPokemonBitmap(pkmn, false) if pkmn
        end
        # Ensure default size if the battler sprite ended up without a bitmap.
        if !sprite.bitmap || sprite.bitmap.disposed? || sprite.bitmap.width == 0 || sprite.bitmap.height == 0
          sprite.bitmap = Bitmap.new(DEFAULT_BATTLER_WIDTH, DEFAULT_BATTLER_HEIGHT)
          sprite.ox = DEFAULT_BATTLER_WIDTH / 2
          sprite.oy = DEFAULT_BATTLER_HEIGHT
        end
        return sprite
      rescue
        return nil
      end
    end

    def create_effect_sprites
      clips.each do |clip|
        id = clip["id"].to_s
        graphic = clip["graphic"].is_a?(Hash) ? clip["graphic"] : {}
        source = graphic["source"].to_s
        sprite = nil
        if source.start_with?("battler-")
          side = source.include?("target") ? :target : :user
          if source.include?("front")
            sprite = create_front_battler(side)
          end
          if !sprite
            original = side == :target ? target_sprite : user_sprite
            if original
              sprite = Sprite.new(@viewport)
              sprite.bitmap = original.bitmap
              sprite.src_rect.set(original.src_rect.x, original.src_rect.y, original.src_rect.width, original.src_rect.height) if original.respond_to?(:src_rect) && original.src_rect
              sprite.ox = original.ox; sprite.oy = original.oy
              sprite.mirror = original.mirror if sprite.respond_to?(:mirror=) && original.respond_to?(:mirror)
            end
          end
        else
          sprite = IconSprite.new(0, 0, @viewport)
        end
        next if !sprite
        sprite.visible = false
        @effect_sprites[id] = sprite
      end
    end

    def ease01(t, mode)
      x = [[t.to_f, 0.0].max, 1.0].min
      case mode.to_s
      when "linear" then x
      when "ease_in" then x * x
      when "ease_out" then 1.0 - ((1.0 - x) * (1.0 - x))
      else
        x < 0.5 ? 2.0 * x * x : 1.0 - (((-2.0 * x + 2.0) ** 2) / 2.0)
      end
    end

    def sample_value(obj, prop, frame, fallback)
      keys = (((obj["valueKeys"] || {})[prop] rescue nil) || []).sort_by { |k| k["frame"].to_f }
      base = ((obj["visual"] || {})[prop] rescue nil)
      base = fallback if base.nil?
      return base.to_f if keys.empty?
      return keys.first["value"].to_f if frame <= keys.first["frame"].to_f
      return keys.last["value"].to_f if frame >= keys.last["frame"].to_f
      (0...(keys.length - 1)).each do |i|
        a = keys[i]; b = keys[i + 1]
        next if frame < a["frame"].to_f || frame > b["frame"].to_f
        span = [0.0001, b["frame"].to_f - a["frame"].to_f].max
        t = ease01((frame - a["frame"].to_f) / span, a["easing"])
        return a["value"].to_f + ((b["value"].to_f - a["value"].to_f) * t)
      end
      base.to_f
    rescue
      fallback.to_f
    end

    def sample_visible(obj, frame)
      value = obj["enabled"] != false
      ((obj["visibleKeys"] || []).sort_by { |k| k["frame"].to_f }).each do |k|
        break if k["frame"].to_f > frame
        value = !!k["value"]
      end
      value
    rescue
      true
    end

    def base_anchor(side, focus = false)
      sprite = side == :target ? target_sprite : user_sprite
      original = @original[side]
      return [Graphics.width / 2.0, Graphics.height / 2.0] if !sprite || !original
      x = original[:x].to_f
      y = original[:y].to_f
      if focus
        h = (sprite.bitmap && !sprite.bitmap.disposed?) ? sprite.bitmap.height : 80
        y -= h / 2.0
      end
      [x, y]
    end

    def script_anchor(side)
      battler = side == :target ? @target : @user
      return base_anchor(side, false) if !battler
      size = battler.battle.pbSideSize(battler.index) rescue 1
      p = Battle::Scene.pbBattlerPosition(battler.index, size) rescue Battle::Scene.pbBattlerPosition(battler.index)
      [p[0].to_f, p[1].to_f]
    rescue
      base_anchor(side, false)
    end

    def resolve_point(point)
      p = point.is_a?(Hash) ? point : {}
      anchor = p["anchor"].to_s
      ox = p["offsetX"].to_f; oy = p["offsetY"].to_f
      x = p["x"].to_f; y = p["y"].to_f
      uf = base_anchor(:user, true); tf = base_anchor(:target, true)
      ub = base_anchor(:user, false); tb = base_anchor(:target, false)
      us = script_anchor(:user); ts = script_anchor(:target)
      if anchor.start_with?("pbs:") && !anchor.include?("_and_")
        idx = anchor.include?("target") ? (@target.index rescue 1) : (@user.index rescue 0)
        if idx.to_i.odd?
          x *= -1 if p["foeInvertX"]
          y *= -1 if p["foeInvertY"]
        end
      end
      case anchor
      when "user", "pbs:user" then [uf[0] + x + ox, uf[1] + y + oy]
      when "pbs:user_position" then [uf[0] + x + ox, us[1] + y + oy]
      when "target", "pbs:target" then [tf[0] + x + ox, tf[1] + y + oy]
      when "pbs:target_position" then [tf[0] + x + ox, ts[1] + y + oy]
      when "user_battler" then [ub[0] + ox, ub[1] + oy]
      when "target_battler" then [tb[0] + ox, tb[1] + oy]
      when "user_target", "pbs:user_and_target"
        [uf[0] + ((x / 200.0) * (tf[0] - uf[0])).to_i + ox,
         uf[1] + ((y / -200.0) * (tf[1] - uf[1])).to_i + oy]
      when "pbs:user_position_and_target"
        [uf[0] + ((x / 200.0) * (tf[0] - uf[0])).to_i + ox,
         us[1] + ((y / -200.0) * (tf[1] - us[1])).to_i + oy]
      when "pbs:user_and_target_position"
        [uf[0] + ((x / 200.0) * (tf[0] - uf[0])).to_i + ox,
         uf[1] + ((y / -200.0) * (ts[1] - uf[1])).to_i + oy]
      when "pbs:user_position_and_target_position"
        [uf[0] + ((x / 200.0) * (tf[0] - uf[0])).to_i + ox,
         us[1] + ((y / -200.0) * (ts[1] - us[1])).to_i + oy]
      when "pbs:user_side_foreground", "pbs:user_side_background" then [us[0] + x + ox, us[1] + y + oy]
      when "pbs:target_side_foreground", "pbs:target_side_background" then [ts[0] + x + ox, ts[1] + y + oy]
      else [x + ox, y + oy]
      end
    end

    def pbs_battler_baseline_offset(obj)
      imported = obj.is_a?(Hash) ? (obj["imported"] || {}) : {}
      return 0.0 if obj["type"].to_s != "battler" || imported["format"].to_s != "pbs" || !imported["pbsBattlerParticle"]
      side = obj["side"].to_s == "target" ? :target : :user
      sprite = side == :target ? target_sprite : user_sprite
      original = @original[side] || {}
      return 0.0 if !sprite || !sprite.bitmap || sprite.bitmap.disposed?
      sprite.bitmap.height.to_f / 2.0
    rescue
      0.0
    end

    def resolve_object_point(obj, point)
      ret = resolve_point(point)
      imported = obj.is_a?(Hash) ? (obj["imported"] || {}) : {}
      if obj["type"].to_s == "battler" && imported["pbsBattlerParticle"] && point.is_a?(Hash) && point["anchor"].to_s.start_with?("pbs:")
        ret = [ret[0], ret[1] + pbs_battler_baseline_offset(obj)]
      end
      ret
    end

    def sample_position(obj, frame)
      keys = (obj["positionKeys"] || []).sort_by { |k| k["frame"].to_f }
      return [Graphics.width / 2.0, Graphics.height / 2.0] if keys.empty?
      return resolve_object_point(obj, keys.first["point"]) if frame <= keys.first["frame"].to_f
      return resolve_object_point(obj, keys.last["point"]) if frame >= keys.last["frame"].to_f
      (0...(keys.length - 1)).each do |i|
        a = keys[i]; b = keys[i + 1]
        next if frame < a["frame"].to_f || frame > b["frame"].to_f
        pa = resolve_object_point(obj, a["point"]); pb = resolve_object_point(obj, b["point"])
        span = [0.0001, b["frame"].to_f - a["frame"].to_f].max
        t = ease01((frame - a["frame"].to_f) / span, a["easing"])
        return [pa[0] + (pb[0] - pa[0]) * t, pa[1] + (pb[1] - pa[1]) * t]
      end
      resolve_object_point(obj, keys.first["point"])
    end

    def latest_graphic(clip, frame)
      value = ((clip["graphic"] || {})["projectPath"] || "").to_s
      (clip["graphicSwitches"] || []).sort_by { |s| s["frame"].to_f }.each do |sw|
        break if sw["frame"].to_f > frame
        value = sw["value"].to_s unless sw["value"].to_s.empty?
      end
      value
    end

    def update_bitmap(sprite, clip, frame)
      return if !sprite || !sprite.respond_to?(:setBitmap)
      name = latest_graphic(clip, frame)
      id = clip["id"].to_s
      return if name.empty? || @effect_bitmap_names[id] == name
      sprite.setBitmap(name)
      @effect_bitmap_names[id] = name
    rescue
    end

    def apply_origin(sprite, clip)
      return if !sprite || !sprite.bitmap || sprite.bitmap.disposed?
      g = clip["graphic"] || {}
      origin = g["origin"].to_s
      w = sprite.src_rect && sprite.src_rect.width > 0 ? sprite.src_rect.width : sprite.bitmap.width
      h = sprite.src_rect && sprite.src_rect.height > 0 ? sprite.src_rect.height : sprite.bitmap.height
      case origin
      when "top_left" then sprite.ox = 0; sprite.oy = 0
      when "bottom" then sprite.ox = w / 2; sprite.oy = h
      else sprite.ox = w / 2; sprite.oy = h / 2
      end
    rescue
    end

    def fx_at(clip, kind, frame)
      value = nil
      (clip["fxOps"] || []).sort_by { |op| (op["frame"] || 0).to_f }.each do |op|
        f = (op["frame"] || 0).to_f
        break if f > frame
        next if op["name"].to_s != "legacyFx"
        value = op[kind]
      end
      value
    end

    def to_tone(raw)
      return nil if !raw.is_a?(Hash)
      Tone.new(raw["red"].to_f, raw["green"].to_f, raw["blue"].to_f, raw["gray"].to_f)
    rescue
      nil
    end

    def to_color(raw)
      return nil if !raw.is_a?(Hash)
      Color.new(raw["red"].to_f, raw["green"].to_f, raw["blue"].to_f, raw["alpha"].to_f)
    rescue
      nil
    end

    def rgss_angle_between(x1, y1, x2, y2)
      diff_x = x1.to_f - x2.to_f
      diff_y = y1.to_f - y2.to_f
      return diff_x >= 0 ? 90.0 : -90.0 if diff_y.abs < 0.0000001
      ret = Math.atan(diff_x / diff_y) * 180.0 / Math::PI
      ret += 180.0 if diff_y < 0
      ret
    end

    def pbs_initial_command_value(clip, prop)
      pbs = clip["pbs"].is_a?(Hash) ? clip["pbs"] : {}
      commands = pbs["commands"].is_a?(Hash) ? (pbs["commands"][prop] || []) : []
      first = commands[0]
      return 0.0 if !first || first["duration"].to_f > 0
      first["value"].to_f
    rescue
      0.0
    end

    def pbs_initial_angle_origin(clip)
      pbs = clip["pbs"].is_a?(Hash) ? clip["pbs"] : {}
      point = {
        "anchor" => "pbs:#{pbs["focus"] || "foreground"}",
        "x" => pbs_initial_command_value(clip, "x"),
        "y" => pbs_initial_command_value(clip, "y"),
        "offsetX" => 0, "offsetY" => 0,
        "foeInvertX" => false, "foeInvertY" => false
      }
      resolve_point(point)
    end

    def pbs_focus_target(clip)
      pbs = clip["pbs"].is_a?(Hash) ? clip["pbs"] : {}
      focus = pbs["focus"].to_s
      uf = base_anchor(:user, true); tf = base_anchor(:target, true)
      us = script_anchor(:user); ts = script_anchor(:target)
      return [tf[0], ts[1]] if focus.include?("and_target_position")
      return tf if focus.include?("and_target")
      return [tf[0], ts[1]] if focus.start_with?("target_position")
      return tf if focus.start_with?("target")
      return [uf[0], us[1]] if focus.start_with?("user_position")
      uf
    end

    def apply_pbs_angle_override(sprite, clip, frame)
      pbs = clip["pbs"].is_a?(Hash) ? clip["pbs"] : {}
      mode = pbs["angleOverride"].to_s.downcase
      return if !mode.include?("focus")
      target = pbs_focus_target(clip).dup
      initial = mode.include?("initial")
      origin = initial ? pbs_initial_angle_origin(clip) : sample_position(clip, frame)
      origin = origin.dup
      graphic = clip["graphic"].is_a?(Hash) ? clip["graphic"] : {}
      special = graphic["source"].to_s.start_with?("battler-")
      offset = (special && sprite.bitmap && !sprite.bitmap.disposed?) ? sprite.bitmap.height / 2.0 : 0.0
      # AnimationPlayer::Helper#get_xy_offset participates in both the current
      # sprite coordinate and the focus target used by the angle override.
      origin[1] += offset
      target[1] += offset
      sprite.angle = sample_value(clip, "rotation", frame, 0) + rgss_angle_between(origin[0], origin[1], target[0], target[1])
    rescue
    end

    def apply_object(sprite, obj, frame, battler = false)
      return if !sprite || !obj
      pos = sample_position(obj, frame)
      sprite.x = pos[0]; sprite.y = pos[1]
      size = sample_value(obj, "size", frame, 100) / 100.0
      sx = sample_value(obj, "scaleX", frame, 100) / 100.0 * size
      sy = sample_value(obj, "scaleY", frame, 100) / 100.0 * size
      if battler
        base = sprite.equal?(target_sprite) ? @original[:target] : @original[:user]
        sprite.zoom_x = (base && base[:zoom_x] ? base[:zoom_x] : 1.0) * sx
        sprite.zoom_y = (base && base[:zoom_y] ? base[:zoom_y] : 1.0) * sy
        sprite.angle = (base && base[:angle] ? base[:angle] : 0).to_f + sample_value(obj, "rotation", frame, 0)
      else
        sprite.zoom_x = sx; sprite.zoom_y = sy
        sprite.angle = sample_value(obj, "rotation", frame, 0)
      end
      sprite.opacity = [[(sample_value(obj, "opacity", frame, 100) * 2.55).round, 0].max, 255].min
      sprite.visible = sample_visible(obj, frame)
      sprite.z = sample_value(obj, "z", frame, sprite.z).round
      sprite.blend_type = sample_value(obj, "blend", frame, 0).round if sprite.respond_to?(:blend_type=)
      sprite.mirror = sample_value(obj, "flip", frame, 0) >= 0.5 if sprite.respond_to?(:mirror=)
    rescue => e
      BattleAnimationStudioRuntime.log("apply_object #{e.class}: #{e.message}")
    end

    def apply_battlers
      u = battler_track(:user); t = battler_track(:target)
      apply_object(user_sprite, u, @frame, true) if u && user_sprite
      apply_object(target_sprite, t, @frame, true) if t && target_sprite && target_sprite != user_sprite
    end

    def apply_clip(clip)
      sprite = @effect_sprites[clip["id"].to_s]
      return if !sprite
      start_f = (clip["startFrame"] || 0).to_f; end_f = (clip["endFrame"] || duration).to_f
      active = @frame >= start_f && @frame <= end_f && sample_visible(clip, @frame)
      sprite.visible = false if !active
      return if !active
      update_bitmap(sprite, clip, @frame)
      apply_object(sprite, clip, @frame, false)
      apply_pbs_angle_override(sprite, clip, @frame)
      sw = sample_value(clip, "srcW", @frame, 0).round
      sh = sample_value(clip, "srcH", @frame, 0).round
      if sprite.respond_to?(:src_rect) && sprite.src_rect && sw > 0 && sh > 0
        sx = sample_value(clip, "srcX", @frame, 0).round
        sy = sample_value(clip, "srcY", @frame, 0).round
        sprite.src_rect.set(sx, sy, sw, sh)
      end
      apply_origin(sprite, clip)
      tone = to_tone(fx_at(clip, "tone", @frame)); color = to_color(fx_at(clip, "color", @frame))
      sprite.tone = tone if tone && sprite.respond_to?(:tone=)
      sprite.color = color if color && sprite.respond_to?(:color=)
    end

    def play_events(previous_frame, current_frame)
      (@data["events"] || []).each do |ev|
        next if ev["type"].to_s.downcase != "se"
        ef = (ev["frame"] || 0).to_f
        crossed = if previous_frame.nil?
                    ef <= current_frame + 0.0001
                  else
                    ef > previous_frame + 0.0001 && ef <= current_frame + 0.0001
                  end
        next if !crossed
        name = ev["name"].to_s
        next if name.empty?
        pbSEPlay(name, (ev["volume"] || 100).to_i, (ev["pitch"] || 100).to_i)
      end
    rescue => e
      BattleAnimationStudioRuntime.log("SE playback #{e.class}: #{e.message}")
    end

    def envelope_alpha(ev)
      start = (ev["frame"] || 0).to_f; local = @frame - start
      dur = [(ev["duration"] || 1).to_f, 1.0].max
      return 0.0 if local < 0 || local > dur
      fi = [(ev["fadeIn"] || 1).to_f, 1.0].max
      hold = [(ev["hold"] || 0).to_f, 0.0].max
      fo = [(ev["fadeOut"] || [dur - fi - hold, 1].max).to_f, 1.0].max
      return [[local / fi, 0.0].max, 1.0].min if local < fi
      return 1.0 if local <= fi + hold
      [[1.0 - ((local - fi - hold) / fo), 0.0].max, 1.0].min
    end

    def update_screen_events
      screen_events = (@data["events"] || []).select { |e| ["screen_black_envelope", "screen_white_envelope"].include?(e["type"].to_s) }
      screen_events.each_with_index do |ev, i|
        sprite = @overlay_sprites[i]
        if !sprite
          sprite = Sprite.new(@viewport)
          sprite.bitmap = Bitmap.new(Graphics.width, Graphics.height)
          @overlay_sprites[i] = sprite
        end
        color = ev["type"].to_s == "screen_black_envelope" ? Color.new(0,0,0,255) : Color.new(255,255,255,255)
        sprite.bitmap.clear
        sprite.bitmap.fill_rect(0,0,Graphics.width,Graphics.height,color)
        sprite.z = 9999 + i
        sprite.opacity = (envelope_alpha(ev) * 255).round
        sprite.visible = sprite.opacity > 0
      end
    rescue
    end

    def update
      return if @done

      # Render the current Studio frame first. This guarantees that frame 0
      # (including its SE/events) is actually shown and that the final frame is
      # not skipped. Fractional frames are intentional and are interpolated by
      # sample_position/sample_value.
      play_events(@previous_event_frame, @frame)
      apply_battlers
      clips.each { |clip| apply_clip(clip) }
      update_screen_events

      if @frame >= duration - 0.0001
        @done = true
        return
      end

      @previous_event_frame = @frame
      @frame = [@frame + frame_step, duration].min
    end
  end

  module SceneHook
    def pbPlayBattleAnimationStudio(move_id, user, targets, version = 0, common = false)
      idx = user && user.respond_to?(:index) ? user.index : 0
      data = common ? BattleAnimationStudioRuntime.common_matching(move_id, idx) : BattleAnimationStudioRuntime.matching(move_id, version, idx, false)
      return false if !data
      target = targets.is_a?(Array) ? targets[0] : targets
      player = BattleAnimationStudioRuntime::Player.new(@sprites, @viewport, user, target, data)
      begin
        loop do
          player.update
          pbUpdate
          break if player.animDone?
        end
      ensure
        player.dispose
      end
      true
    rescue => e
      BattleAnimationStudioRuntime.log("Playback failed for #{move_id}: #{e.class}: #{e.message}")
      false
    end

    def pbAnimation(move_id, user, targets, version = 0)
      return if pbPlayBattleAnimationStudio(move_id, user, targets, version, false)
      super
    end

    def pbCommonAnimation(anim_name, user = nil, target = nil)
      return if pbPlayBattleAnimationStudio(anim_name, user, target, 0, true)
      super
    end
  end
end

if defined?(Battle::Scene)
  Battle::Scene.prepend(BattleAnimationStudioRuntime::SceneHook) unless Battle::Scene.ancestors.include?(BattleAnimationStudioRuntime::SceneHook)
end

# VERMEIL and other plugins can override Battle#pbAnimation before the request
# reaches Battle::Scene. Prepending here lets an explicitly exported Studio
# animation win; all other moves fall through untouched to the existing stack.
if defined?(Battle)
  module BattleAnimationStudioRuntimeBattleHook
    def pbAnimation(move, user, targets, hit_num = 0)
      if @showAnims && @scene && @scene.respond_to?(:pbPlayBattleAnimationStudio)
        return if @scene.pbPlayBattleAnimationStudio(move, user, targets, hit_num, false)
      end
      super
    end
  end
  Battle.prepend(BattleAnimationStudioRuntimeBattleHook) unless Battle.ancestors.include?(BattleAnimationStudioRuntimeBattleHook)
end
