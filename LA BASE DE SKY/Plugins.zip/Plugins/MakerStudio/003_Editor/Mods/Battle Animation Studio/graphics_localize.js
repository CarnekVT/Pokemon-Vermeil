// Graphic localization helpers for imported animations.
// Collects every graphic referenced by an animation (particle bitmaps,
// mid-animation setBitmap switches and PBS mask graphics), checks which ones
// already exist in the current project, finds similar project assets by name
// and can copy the exact source files from the source game into the project.
import { getAllClips } from "./model.js";
import { absoluteProjectPath, resolveExternalGraphicPath, resolveLegacyGraphic } from "./assets.js";
const IMAGE_EXT_RE = /\.(png|bmp|jpg|jpeg|webp|gif)$/i;
const ASSET_ROOTS = [
    { id: "new", projectPath: "Graphics/Battle animations" },
    { id: "legacy", projectPath: "Graphics/Animations" },
    { id: "code", projectPath: "Graphics/BattleParticlesAnimations" }
];
export function basename(path) { return String(path || "").replace(/[\\/]+$/, "").split(/[\\/]/).pop() || ""; }
export function stemOf(path) { return basename(path).replace(/\.[^.]+$/, ""); }
async function invoke(name, args) {
    var _a, _b;
    const fn = (_b = (_a = window.__TAURI__) === null || _a === void 0 ? void 0 : _a.core) === null || _b === void 0 ? void 0 : _b.invoke;
    if (!fn)
        throw new Error("Tauri invoke is unavailable");
    return await fn(name, args);
}
async function projectFileExists(ctx, projectPath) {
    if (!projectPath)
        return false;
    try {
        return !!(await invoke("file_exists", { path: absoluteProjectPath(ctx, projectPath) }));
    }
    catch (_a) {
        return false;
    }
}
// -----------------------------------------------------------------------------
// Collecting every graphic the animation references
// -----------------------------------------------------------------------------
export function collectAnimationGraphics(animation) {
    const items = [];
    const seen = new Set();
    for (const clip of getAllClips(animation)) {
        const g = clip.graphic || {};
        const src = String(g.source || "");
        if (src.startsWith("battler-"))
            continue;
        const hasReference = !!(g.projectPath || g.relativeHint || g.name || (g.assetCandidates || []).length);
        if (hasReference) {
            items.push({
                key: `main:${clip.id}`,
                kind: "main",
                label: clip.name || "Partícula",
                clip,
                desc: g,
                apply(projectPath) {
                    g.projectPath = projectPath;
                    g.name = stemOf(projectPath);
                    delete g.externalGameRoot;
                    g.localized = true;
                }
            });
        }
        for (const sw of clip.graphicSwitches || []) {
            const raw = String(sw.value || "");
            if (!raw || !/(Graphics|\.(?:png|bmp|jpg|jpeg|webp|gif)$)/i.test(raw))
                continue;
            const key = `switch:${clip.id}:${raw}`;
            if (seen.has(key))
                continue;
            seen.add(key);
            items.push({
                key,
                kind: "switch",
                label: `Switch bitmap · ${clip.name || "Partícula"}`,
                clip,
                sw,
                desc: {
                    source: "code",
                    projectPath: raw,
                    externalRelativePath: raw,
                    relativeHint: raw,
                    name: stemOf(raw),
                    folder: raw.includes("BattleParticlesAnimations") ? "BattleParticlesAnimations" : raw.includes("Battle animations") ? "Battle animations" : raw.includes("Animations") ? "Animations" : ""
                },
                apply(projectPath) {
                    sw.value = projectPath;
                    clip.graphic.localized = true;
                }
            });
        }
        if (clip.pbs && clip.pbs.maskGraphic) {
            const raw = String(clip.pbs.maskGraphic);
            const key = `mask:${clip.id}:${raw}`;
            items.push({
                key,
                kind: "mask",
                label: `Máscara · ${clip.name || "Partícula"}`,
                clip,
                desc: { source: "new", folder: "Battle animations", name: stemOf(raw), relativeHint: raw },
                apply(projectPath) {
                    clip.pbs.maskGraphic = basename(projectPath);
                    clip.graphic.localized = true;
                }
            });
        }
    }
    return items;
}
// -----------------------------------------------------------------------------
// Similar-graphic search inside the current project
// -----------------------------------------------------------------------------
function normKey(s) {
    return String(s || "").toLowerCase()
        .replace(IMAGE_EXT_RE, "")
        .replace(/\[\s*bottom\s*\]/g, "")
        .replace(/[^a-z0-9]+/g, " ")
        .trim();
}
function wordsOf(k) { return k.split(/\s+/).filter(Boolean); }
export function similarProjectAssets(assets, desc) {
    // Match on the file's leaf name only. The full path may contain generic
    // folder words ("graphics", "battle", "animations") that would match every
    // asset and drown out the actual name comparison.
    const raw = String(desc.relativeHint || desc.externalRelativePath || desc.projectPath || desc.name || "").replace(/\\/g, "/");
    const folder = String(desc.folder || "").toLowerCase();
    const leafRaw = raw.split("/").pop() || raw;
    const want = normKey(leafRaw), wantFull = normKey(raw);
    if (!want)
        return [];
    const wanted = wordsOf(want), wantStripped = want.replace(/\s*\d+$/, "");
    const wantNum = (leafRaw.match(/(\d+)\s*$/) || [])[1] || "";
    const scored = [];
    for (const a of assets || []) {
        const key = normKey(a.name), proj = normKey(a.projectPath);
        if (!key && !proj)
            continue;
        // Folder affinity: same animation root is much more likely to be the
        // intended graphic than a same-named asset living elsewhere.
        const pathL = String(a.projectPath || "").toLowerCase();
        const inFolder = !!folder && (pathL.includes(`/${folder}/`) || pathL.endsWith(`/${folder}`));
        const inOtherRoot = !!folder && !inFolder;
        if (proj === wantFull || key === want || proj.endsWith(`/${want}`)) {
            scored.push({ asset: a, score: 100 + (inFolder ? 5 : 0) });
            continue;
        }
        const ka = wordsOf(key);
        // Strongest signal: the wanted name appears as a whole word in the
        // asset name ("ember" -> "ember fire"). Assets are usually more
        // specific than the bare hint, e.g. numbered PBS particles.
        const prefixHit = key === wantStripped || key.startsWith(wantStripped + " ")
            || key.includes(" " + wantStripped + " ") || key.endsWith(" " + wantStripped);
        // Weakest acceptable signal: the asset is a truncation of the wanted
        // name ("ember fire" -> "ember"). Easily confused with unrelated
        // graphics, so it barely qualifies.
        const truncationHit = !prefixHit && wantStripped.length > 2 && wantStripped.startsWith(key);
        let common = 0;
        for (const kw of wanted)
            for (const ak of ka)
                if (kw === ak) { common++; break; }
        let score = 0;
        if (prefixHit) {
            score = 78 + Math.min(10, common * 3);
        }
        else if (truncationHit) {
            score = 46;
        }
        else if (common > 0) {
            // Missing wanted words hurt: "fire punch hit" must not match
            // "fire slash" as well as "fire punch".
            score = Math.round((common / wanted.length) * 70);
            if (ka.length === 1 && common === 1 && wanted.length > 1)
                score = Math.min(score, 42);
        }
        if (score >= 45) {
            // Close numbered variants are a plus ("ember 2" vs "ember 3").
            const an = (a.name.match(/(\d+)\s*$/) || [])[1] || "";
            if (wantNum && an && Math.abs(Number(wantNum) - Number(an)) <= 1)
                score += 5;
            score += inFolder ? 14 : (inOtherRoot ? -16 : 0);
            if (score >= 45)
                scored.push({ asset: a, score });
        }
    }
    scored.sort((x, y) => y.score - x.score || x.asset.projectPath.localeCompare(y.asset.projectPath));
    return scored.slice(0, 4).map((s) => s.asset);
}
// -----------------------------------------------------------------------------
// Planning: what exists / what can be imported / what is similar
// -----------------------------------------------------------------------------
export async function planGraphicItems(ctx, items, externalRoot, assets) {
    const out = [];
    for (const item of items) {
        const desc = item.desc;
        let existing = null;
        const candidates = [];
        const direct = String(desc.projectPath || desc.externalRelativePath || "");
        if (direct)
            candidates.push(direct);
        const byName = await resolveLegacyGraphic(ctx, Object.assign(Object.assign({}, desc), { projectPath: "" }), assets);
        if (byName && byName.projectPath)
            candidates.push(byName.projectPath);
        for (const c of candidates)
            if (c && (await projectFileExists(ctx, c))) {
                existing = c;
                break;
            }
        let sourcePath = "";
        if (externalRoot)
            sourcePath = await resolveExternalGraphicPath(externalRoot, desc);
        let similars = [];
        if (!existing)
            similars = similarProjectAssets(assets, desc).filter((a) => a.projectPath !== existing);
        out.push(Object.assign(Object.assign({}, item), { plan: { existing, sourcePath, similars } }));
    }
    return out;
}
// -----------------------------------------------------------------------------
// Importing the source file into the project
// -----------------------------------------------------------------------------
function rootFor(desc) {
    const folder = String(desc.folder || "").toLowerCase();
    let root = ASSET_ROOTS.find((r) => r.projectPath.toLowerCase().endsWith(`/${folder}`));
    if (!root) {
        const p = String(desc.projectPath || desc.externalRelativePath || "").replace(/\\/g, "/");
        root = ASSET_ROOTS.find((r) => p.toLowerCase().startsWith(r.projectPath.toLowerCase()))
            || (String(desc.source || "") === "legacy" ? ASSET_ROOTS[1] : String(desc.source || "") === "code" ? ASSET_ROOTS[2] : ASSET_ROOTS[0]);
    }
    return root;
}
export function destinationForImport(desc, filename) { return `${rootFor(desc).projectPath}/${filename}`; }
export async function importGraphicIntoProject(ctx, desc, sourcePath) {
    if (!sourcePath)
        return "";
    let bytes;
    try {
        bytes = await invoke("read_binary_file", { path: sourcePath });
    }
    catch (_a) {
        return "";
    }
    if (!bytes || !bytes.length)
        return "";
    // Some projects lack e.g. Graphics/BattleParticlesAnimations; pick the first
    // asset root that exists, preferring the graphic's natural folder.
    const preferred = rootFor(desc);
    let root = preferred;
    for (const r of [preferred, ...ASSET_ROOTS.filter((x) => x !== preferred)])
        if (await projectFileExists(ctx, r.projectPath)) {
            root = r;
            break;
        }
    const filename = basename(sourcePath), dot = filename.lastIndexOf(".");
    let dest = `${root.projectPath}/${filename}`, n = 1;
    while (await projectFileExists(ctx, dest)) {
        const base = dot > 0 ? filename.slice(0, dot) : filename, ext = dot > 0 ? filename.slice(dot) : "";
        dest = `${root.projectPath}/${base}_${++n}${ext}`;
    }
    try {
        await invoke("write_binary_file", { path: absoluteProjectPath(ctx, dest), data: Array.from(bytes) });
    }
    catch (e) {
        console.error("Graphic import failed", e);
        return "";
    }
    return dest;
}
export function localizeGraphic(item, projectPath) {
    if (!item || !projectPath)
        return false;
    item.apply(projectPath);
    return true;
}
