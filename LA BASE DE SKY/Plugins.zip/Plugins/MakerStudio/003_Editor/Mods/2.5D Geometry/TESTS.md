# 2.5D Geometry v2.7.0 — Region Mesh test checklist

1. Abre 2.5D/SPLIT y déjalo acoplado. Pinta/borra tiles en Maker Studio: la mitad MAP y la escena deben actualizarse sin cerrar el panel.
2. Haz un stroke largo con Geometry Paint/Height/Borrar: el cursor no debe bloquearse por compilaciones completas por celda.
3. Borrar: prueba clic, arrastre, Alt+arrastre, Delete/Backspace y menú contextual. Ninguna ruta debe borrar el tile de Maker Studio.
4. Extended layer: coloca un tile de otro tileset; SPLIT debe usar su fuente real, no la misma posición del atlas base.
5. Abre Elegir gráfico: debe ocupar casi toda la pantalla (98vw × 95vh), permitir scroll/zoom y selección rectangular.
6. Abre Model Workshop: debe ocupar casi toda la pantalla. En Forma y Altura, pinta varias celdas arrastrando sin una pausa fuerte por cada celda.
7. Mantén preview viva abierta mientras editas un modelo: cambios agrupados deben reflejarse en el mapa/preview.
8. Cierra/reabre el proyecto y verifica que Geometry/Models persistan.


## Region Mesh
- [ ] A 4×4 flat mountain with identical materials reports 16 cells -> 5 visible faces.
- [ ] Removing a center/edge cell updates the model shape without blanking the previous preview first.
- [ ] A lower neighbouring cell produces only the exposed height-difference side strip.
- [ ] TOP/NORTH/SOUTH/EAST/WEST can come from different tilesets.
- [ ] Rotating an instance 90° rotates its footprint and directional face assignments.
- [ ] Runtime renders `mesh_faces`; collision still follows invisible `model_objects`.
- [ ] Large merged faces repeat the tile texture instead of stretching one tile across the entire face.
