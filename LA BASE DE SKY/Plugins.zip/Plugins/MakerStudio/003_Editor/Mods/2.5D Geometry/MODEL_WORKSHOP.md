# Model Studio v2.9

The Model Builder was replaced by a primitive-part modeler inspired by the provided DramaticShape reference workflow.

## Layout
- Left: reusable model/group list.
- Center top: embedded tileset palette. Drag to select one or several tiles.
- Center bottom: large live 3D preview. Drag to orbit, wheel to zoom, click a visible part to select it.
- Right: group info, primitive creation, part list and transform/material inspector.

## Parts
BOX, BILLBOARD, SPHERE, RELIEF, CYLINDER, PRISM, DOME and WEDGE.

Every part has Position XYZ, Size XYZ, Angle XYZ, axis/segments where relevant, collision, and face materials. Materials preserve their actual tileset id and source rectangle.

## Runtime
Primitive parts compile to generic textured quad faces (`mesh_faces`) shared by Maker Studio preview and MKXP-Z. Collision is rasterized separately so rendering does not need to become a cube-per-tile system.

Legacy cell/region models remain readable for compatibility.
