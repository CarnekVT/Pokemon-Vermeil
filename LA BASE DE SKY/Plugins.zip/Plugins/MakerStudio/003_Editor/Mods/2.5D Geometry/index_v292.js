/**
 * 2.5D Geometry v2.9.2 — Dark Studio + Texture Footprint
 * Maker Studio Mod API 1.0.0
 *
 * V2 goals:
 * - exact cross-tileset source resolution via readTileData().tilesetId
 * - map-first beginner workflow inspired by Luka's visual editor philosophy
 * - visual Used Graphics browser + native graphic picker
 * - large 2.5D and SPLIT viewports
 * - direct elevation cues and source-driven Geometry compilation
 * - one runtime material identity for editor preview and MKXP-Z
 * - reusable models compiled into connected top/perimeter region meshes
 * - collision proxies separated from render meshes
 * - keep-last-mesh behaviour while edits are rebuilt on the next animation frame
 */

import { parseMapRxdata, parseTilesetsRxdata } from "./rxdata_reader.js";

const MOD_ID = "com.carnek.geometry-2p5d";
const TOOL_ID = "geometry-2p5d.height";
const PANEL_ID = "geometry-2p5d.panel";
const PREVIEW_PANEL_ID = "geometry-2p5d.preview";
const FORMAT = 4;
const SCENE_COMPILER_VERSION = 1;
const COMPILED_OBJECT_ID_BASE = 100000;
const DEFAULT_STEP = 32;
const TILE_SIZE = 32;
const RUNTIME_SETTINGS_PATH = "Plugins/[VERMEIL] Visual 2.5D/001_Settings.rb";

// RPG Maker XP 48-pattern autotile quarter table. Each value indexes a 16x16
// quarter in the first 96x128 frame of an autotile sheet.
const AUTOTILE_PARTS = [
  [27,28,33,34],[5,28,33,34],[27,6,33,34],[5,6,33,34],
  [27,28,33,12],[5,28,33,12],[27,6,33,12],[5,6,33,12],
  [27,28,11,34],[5,28,11,34],[27,6,11,34],[5,6,11,34],
  [27,28,11,12],[5,28,11,12],[27,6,11,12],[5,6,11,12],
  [25,26,31,32],[25,6,31,32],[25,26,31,12],[25,6,31,12],
  [15,16,21,22],[15,16,21,12],[15,16,11,22],[15,16,11,12],
  [29,30,35,36],[29,30,11,36],[5,30,35,36],[5,30,11,36],
  [39,40,45,46],[5,40,45,46],[39,6,45,46],[5,6,45,46],
  [25,30,31,36],[15,16,31,32],[15,16,35,36],[25,30,11,36],
  [37,38,43,44],[37,6,43,44],[13,14,19,20],[13,14,19,12],
  [25,26,43,44],[37,38,31,32],[13,14,43,44],[37,6,31,32],
  [13,14,19,44],[13,14,43,20],[13,38,43,44],[37,14,43,44],
];

const TAG = {
  FLOOR: 19,
  WALL: 20,
  ROOF: 21,
  BILLBOARD: 22,
  VOLUME: 23,
  STRUCTURE: 24,
  INDOOR_WALL: 25,
  INDOOR_PROP: 26,
  INDOOR_BORDER: 27,
  INDOOR_BLACK: 28,
  MOUNTAIN_TOP: 29,
  MOUNTAIN_WALL: 30,
  ROOF_HIGH: 31,
  VOLUME_HIGH: 32,
  OVERLAY: 33,
  ROOF_PLANE: 34,
  WALL_PLANE: 35,
  MOUNTAIN_WALL_PLANE: 36,
  STAIR: 37,
};

const BILLBOARD_TAGS = new Set([TAG.BILLBOARD, TAG.STRUCTURE, TAG.INDOOR_PROP, TAG.OVERLAY]);
const WALL_ART_TAGS = new Set([TAG.WALL, TAG.INDOOR_WALL, TAG.MOUNTAIN_WALL, TAG.WALL_PLANE, TAG.MOUNTAIN_WALL_PLANE]);
const TOP_SURFACE_TAGS = new Set([TAG.FLOOR, TAG.VOLUME, TAG.MOUNTAIN_TOP, TAG.VOLUME_HIGH, TAG.STAIR, TAG.ROOF_PLANE, TAG.INDOOR_BORDER, TAG.INDOOR_BLACK]);
const ROOF_BILLBOARD_TAGS = new Set([TAG.ROOF, TAG.ROOF_HIGH]);
const PLANE_WALL_TAGS = new Set([TAG.WALL_PLANE]);
const MOUNTAIN_MATERIAL_TAGS = new Set([TAG.MOUNTAIN_WALL, TAG.MOUNTAIN_WALL_PLANE]);

const TAG_NAMES = new Map([
  [19, "NDSFloor"], [20, "NDSWall"], [21, "NDSRoof"], [22, "NDSBillboard"],
  [23, "NDSVolume"], [24, "NDSStructure"], [25, "NDSIndoorWall"], [26, "NDSIndoorProp"],
  [27, "NDSIndoorBorder"], [28, "NDSIndoorBlack"], [29, "NDSMountainTop"],
  [30, "NDSMountainWall"], [31, "NDSRoofHigh"], [32, "NDSVolumeHigh"], [33, "NDSOverlay"],
  [34, "NDSRoofPlane"], [35, "NDSWallPlane"], [36, "NDSMountainWallPlane"], [37, "NDSStair"],
]);

const runtimeConfig = {
  outdoorDefaultAlpha: 25,
  indoorDefaultAlpha: 24,
  distanceH: 640,
  roofHeight: 48,
  roofHighHeight: 72,
  mountainHeight: 32,
  volumeDefaultHeight: 8,
  volumeHighHeight: 24,
  stairHeight: 32,
  surfaceGeometryHeightStep: 32,
};

function numberConst(text, name, fallback) {
  const re = new RegExp(`${name}\\s*=\\s*([0-9.]+)`);
  const m = String(text || "").match(re);
  return m ? Number(m[1]) || fallback : fallback;
}

function tilesetInfo(ctx, tilesetId) {
  const id = Number(tilesetId) || 0;
  let out = null;
  try { out = ctx.tileset.info?.(id) || null; } catch (_) {}
  const lists = [];
  try { lists.push(ctx.tileset.list?.()); } catch (_) {}
  try { lists.push(ctx.projectData?.tilesets); } catch (_) {}
  try { lists.push(ctx.projectData?.tilesets?.()); } catch (_) {}
  try { lists.push(ctx.projectData?.getTilesets?.()); } catch (_) {}
  try { lists.push(ctx.projectData?.listTilesets?.()); } catch (_) {}
  for (const list of lists) {
    if (!Array.isArray(list)) continue;
    const hit = list.find((t, i) => Number(firstDefined(t?.id, t?.ID, t?.index, i)) === id);
    if (hit) out = { ...(out || {}), ...hit };
  }
  return out;
}

function tilesetGraphicName(info) {
  return String(firstDefined(
    info?.tilesetName,
    info?.tileset_name,
    info?.graphicName,
    info?.graphic_name,
    info?.imageName,
    info?.image_name,
    info?.filename,
    info?.fileName,
    info?.graphic,
    info?.image,
    ""
  )).replace(/\.[^.]+$/, "").trim();
}

async function loadRuntimeConfig(ctx) {
  try {
    const text = await ctx.fs.readProjectFile(RUNTIME_SETTINGS_PATH);
    runtimeConfig.outdoorDefaultAlpha = numberConst(text, "OUTDOOR_DEFAULT_ALPHA", runtimeConfig.outdoorDefaultAlpha);
    runtimeConfig.indoorDefaultAlpha = numberConst(text, "INDOOR_DEFAULT_ALPHA", runtimeConfig.indoorDefaultAlpha);
    runtimeConfig.distanceH = numberConst(text, "DISTANCE_H", runtimeConfig.distanceH);
    runtimeConfig.roofHeight = numberConst(text, "NDS_ROOF_HEIGHT", runtimeConfig.roofHeight);
    runtimeConfig.roofHighHeight = numberConst(text, "NDS_ROOF_HIGH_HEIGHT", runtimeConfig.roofHighHeight);
    runtimeConfig.mountainHeight = numberConst(text, "NDS_MOUNTAIN_HEIGHT", runtimeConfig.mountainHeight);
    runtimeConfig.volumeDefaultHeight = numberConst(text, "NDS_VOLUME_DEFAULT_HEIGHT", runtimeConfig.volumeDefaultHeight);
    runtimeConfig.volumeHighHeight = numberConst(text, "NDS_VOLUME_HIGH_HEIGHT", runtimeConfig.volumeHighHeight);
    runtimeConfig.stairHeight = numberConst(text, "NDS_STAIR_HEIGHT", runtimeConfig.stairHeight);
    runtimeConfig.surfaceGeometryHeightStep = numberConst(text, "SURFACE_GEOMETRY_HEIGHT_STEP", runtimeConfig.surfaceGeometryHeightStep);
  } catch (err) {
    ctx.log.warn("2.5D Geometry: runtime settings not readable; using built-in defaults", err);
  }
}

function tagName(tag) {
  return TAG_NAMES.get(Number(tag) || 0) || (Number(tag) ? `Terrain ${Number(tag)}` : "Normal");
}

function tagHeightOffset(tag) {
  tag = Number(tag) || 0;
  if (tag === TAG.ROOF) return runtimeConfig.roofHeight;
  if (tag === TAG.ROOF_HIGH) return runtimeConfig.roofHighHeight;
  if (tag === TAG.ROOF_PLANE) return runtimeConfig.roofHeight;
  return 0;
}

const OBJECT_COLLISIONS = ["none", "solid", "climb", "one-way"];
const FOOTPRINT_MODES = ["inherit", "solid", "none", "climb", "one-way", "void"];
const OBJECT_CATEGORIES = [
  ["floor", "Floor"], ["wall", "Wall"], ["border", "Border"],
  ["mountain", "Mountain"], ["prop", "Prop"], ["roof", "Roof"], ["custom", "Custom"],
];

// Luka/Kyanite philosophy: each category owns its defaults (geometry + gameplay),
// so picking a category stamps independent properties without touching other
// objects. The runtime reads only per-object values, never these presets.
const OBJECT_CATEGORY_PRESETS = {
  floor:    { type: "plane", height: 0, anchor_z: 0, collision: "none" },
  wall:     { type: "cube",  height: 2, anchor_z: 0, collision: "solid" },
  border:   { type: "cube",  height: 2, anchor_z: 0, collision: "solid" },
  mountain: { type: "cube",  height: 3, anchor_z: 0, collision: "climb" },
  prop:     { type: "cube",  height: 1, anchor_z: 0, collision: "none" },
  roof:     { type: "plane", height: 0, anchor_z: 2, collision: "one-way" },
  custom:   { type: "cube",  height: 1, anchor_z: 0, collision: "solid" },
};

// Scene Compiler presets are source-driven rather than object-driven. A definition
// is analogous to a lightweight prefab: it describes how every placed occurrence
// of one real tile source should become 2.5D geometry. Individual occurrences can
// then override these values through instance_overrides.
const SCENE_GEOMETRY_PRESETS = {
  floor: { category: "floor", type: "plane", height: 0, anchor_z: 0, collision: "none", enabled: true,
           components: { extrude: false, cap: true, connect_neighbors: true, slope: false, billboard: false, occlusion: "auto" } },
  wall: { category: "wall", type: "cube", height: 2, anchor_z: 0, collision: "solid", enabled: true,
          components: { extrude: true, cap: true, connect_neighbors: true, slope: false, billboard: false, occlusion: "auto" } },
  border: { category: "border", type: "cube", height: 1, anchor_z: 0, collision: "solid", enabled: true,
            components: { extrude: true, cap: true, connect_neighbors: true, slope: false, billboard: false, occlusion: "auto" } },
  mountain: { category: "mountain", type: "cube", height: 3, anchor_z: 0, collision: "climb", enabled: true,
              components: { extrude: true, cap: true, connect_neighbors: true, slope: false, billboard: false, occlusion: "auto" } },
  prop: { category: "prop", type: "cube", height: 1, anchor_z: 0, collision: "none", enabled: true,
          components: { extrude: true, cap: true, connect_neighbors: false, slope: false, billboard: false, occlusion: "auto" } },
  roof: { category: "roof", type: "plane", height: 0, anchor_z: 2, collision: "one-way", enabled: true,
          components: { extrude: false, cap: true, connect_neighbors: true, slope: false, billboard: false, occlusion: "auto" } },
  custom: { category: "custom", type: "cube", height: 1, anchor_z: 0, collision: "solid", enabled: true,
            components: { extrude: true, cap: true, connect_neighbors: false, slope: false, billboard: false, occlusion: "auto" } },
  ignore: { category: "custom", type: "plane", height: 0, anchor_z: 0, collision: "none", enabled: false,
            components: { extrude: false, cap: false, connect_neighbors: false, slope: false, billboard: false, occlusion: "auto" } },
};

// Matches the runtime fallback for objects without material
// (026_NDSGeometryObjects.rb -> nds_object_category_color).
const CATEGORY_FALLBACK_COLORS = {
  wall: "rgba(96,78,58,0.92)",
  border: "rgba(108,100,92,0.92)",
  mountain: "rgba(92,63,42,0.92)",
  roof: "rgba(120,105,125,0.92)",
  custom: "rgba(128,96,128,0.92)",
  plane: "rgba(108,96,120,0.92)",
  floor: "rgba(148,128,186,0.92)",
  prop: "rgba(148,128,186,0.92)",
};

function collisionColor(collision) {
  switch (collision) {
    case "solid": return "rgba(255,74,74,0.92)";
    case "climb": return "rgba(255,190,75,0.92)";
    case "one-way": return "rgba(80,220,255,0.92)";
    default: return "rgba(120,220,120,0.85)";
  }
}

function nextObjectId(geo) {
  let max = 0;
  for (const o of geo?.objects || []) if (Number(o.id) > max) max = Number(o.id);
  return max + 1;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function normalizeRotation(value) {
  const n = Math.round((Number(value) || 0) / 90) * 90;
  return ((n % 360) + 360) % 360;
}

function normalizeFootprint(raw, w, h) {
  const out = {};
  if (!raw || typeof raw !== "object") return out;
  for (const [key, value] of Object.entries(raw)) {
    const m = /^(\d+),(\d+)$/.exec(String(key));
    if (!m) continue;
    const dx = Number(m[1]), dy = Number(m[2]);
    if (dx < 0 || dy < 0 || dx >= w || dy >= h) continue;
    const mode = typeof value === "string" ? value : value?.collision;
    if (FOOTPRINT_MODES.includes(mode) && mode !== "inherit") out[`${dx},${dy}`] = mode;
  }
  return out;
}

function footprintMode(obj, dx, dy) {
  return obj?.footprint?.[`${dx},${dy}`] || "inherit";
}

function objectCoversCell(obj, x, y) {
  const dx = x - Number(obj.x || 0), dy = y - Number(obj.y || 0);
  if (dx < 0 || dy < 0 || dx >= Number(obj.w || 1) || dy >= Number(obj.h || 1)) return false;
  return footprintMode(obj, dx, dy) !== "void";
}

function rotateFootprint90(obj) {
  const oldW = Math.max(1, Number(obj.w) || 1);
  const oldH = Math.max(1, Number(obj.h) || 1);
  const next = {};
  for (let dy = 0; dy < oldH; dy++) {
    for (let dx = 0; dx < oldW; dx++) {
      const mode = footprintMode(obj, dx, dy);
      if (mode === "inherit") continue;
      const nx = oldH - 1 - dy;
      const ny = dx;
      next[`${nx},${ny}`] = mode;
    }
  }
  obj.w = oldH;
  obj.h = oldW;
  obj.footprint = next;
  obj.rotation = normalizeRotation((obj.rotation || 0) + 90);
  obj.anchor_row = Math.min(obj.h - 1, Math.max(0, Number(obj.anchor_row) || 0));
}

function normalizeObject(raw, fallbackId) {
  const w = Math.max(1, Math.round(Number(raw?.w) || 1));
  const h = Math.max(1, Math.round(Number(raw?.h) || 1));
  const obj = {
    id: Number(raw?.id) || fallbackId,
    name: String(raw?.name || `Object ${Number(raw?.id) || fallbackId}`),
    type: raw?.type === "plane" ? "plane" : "cube",
    x: Math.max(0, Math.round(Number(raw?.x) || 0)),
    y: Math.max(0, Math.round(Number(raw?.y) || 0)),
    w,
    h,
    height: Math.max(0, Number(raw?.height) || 0),
    anchor_z: Math.max(0, Number(raw?.anchor_z) || 0),
    anchor_row: Math.min(h - 1, Math.max(0, Math.round(raw?.anchor_row == null ? h - 1 : Number(raw.anchor_row) || 0))),
    rotation: normalizeRotation(raw?.rotation),
    collision: OBJECT_COLLISIONS.includes(raw?.collision) ? raw.collision : "solid",
    category: OBJECT_CATEGORIES.some(([id]) => id === raw?.category) ? raw.category : "prop",
    characters_in_front: raw?.characters_in_front === true,
    footprint: normalizeFootprint(raw?.footprint, w, h),
  };
  if (raw?.material && typeof raw.material === "object") obj.material = raw.material;
  // Preserve canonical Scene Compiler metadata. These fields are deliberately
  // ignored by the manual-object inspector but consumed by preview/runtime.
  if (raw?.compiled === true) obj.compiled = true;
  if (raw?.source_key != null) obj.source_key = String(raw.source_key);
  if (raw?.instance_key != null) obj.instance_key = String(raw.instance_key);
  if (raw?.source && typeof raw.source === "object") obj.source = { ...raw.source };
  if (raw?.components && typeof raw.components === "object") obj.components = { ...raw.components };
  if (raw?.face_materials && typeof raw.face_materials === "object") obj.face_materials = normalizeFaceMaterialMap(raw.face_materials);
  if (raw?.model_id != null) obj.model_id = String(raw.model_id);
  if (raw?.model_instance_id != null) obj.model_instance_id = Number(raw.model_instance_id) || 0;
  if (raw?.render === false) obj.render = false;
  return obj;
}

function normalizeObjects(rawList) {
  const out = [];
  for (const raw of rawList || []) {
    if (!raw || typeof raw !== "object") continue;
    out.push(normalizeObject(raw, out.length ? nextObjectId({ objects: out }) : 1));
  }
  return out;
}

function objectRect(obj) {
  return { x0: obj.x, y0: obj.y, x1: obj.x + obj.w - 1, y1: obj.y + obj.h - 1 };
}

function objectsOverlappingCell(geo, x, y) {
  const found = [];
  for (const obj of geo?.objects || []) {
    if (objectCoversCell(obj, x, y)) found.push(obj);
  }
  return found;
}

function sceneObjects(geo) {
  // Manual Luka-style objects and source-compiled instances share one canonical
  // renderer path. Hierarchy editing still targets only geo.objects.
  return [...(geo?.objects || []), ...(geo?.compiled_objects || []), ...(geo?.model_objects || [])];
}

// Topmost object covering a cell (last in array wins), for click-to-select.
function findObjectAt(geo, x, y) {
  const found = objectsOverlappingCell(geo, x, y);
  return found.length ? found[found.length - 1] : null;
}

function objFieldTarget(geo) {
  if (state.objSelected == null || !geo) return null;
  return (geo.objects || []).find((o) => Number(o.id) === Number(state.objSelected)) || null;
}

function currentGeo(ctx) {
  const id = ctx?.editor?.activeMapId?.();
  if (id == null) return null;
  return state.maps.get(id) || null;
}

const state = {
  level: 1,
  mode: "set", // set | raise | lower | erase | inherit
  objTool: false,
  objType: "cube", // cube | plane
  objHeight: 2,
  objAnchorZ: 0,
  objCollision: "solid",
  objCategory: "prop",
  objMaterial: null,
  objFootprintMode: "solid",
  objSelected: null, // object id being edited in the panel, or null for brush mode
  workspaceMode: "scene", // backend compatibility; amateur UI stays in scene mode
  sceneTool: "select", // select | paint | raise | lower | eyedropper | erase
  sceneScope: "this", // this | connected | all
  viewMode: "2d", // 2d = work on Maker Studio map, 2.5d = large live preview
  brushPreset: "wall",
  brushHeight: 2,
  sourceSelection: null,
  // V2 visual workflow state. These are intentionally human-facing concepts;
  // source/instance compiler details remain internal.
  visualSource: null,       // graphic explicitly picked from the Tilesets selector
  visualSourcePreviewUrl: null,
  visualSourceFootprint: { w: 1, h: 1 },
  // V2.5 Model Workshop: reusable geometry models made from arbitrary grid cells.
  modelTool: false,
  modelSelectedId: null,
  modelBrushId: null,
  modelScaleX: 1,
  modelScaleY: 1,
  modelHeightScale: 1,
  modelRotation: 0,
  modelEraseMode: false,
  panelMode: "edit",       // edit | browser
  largeViewOpen: false,
  largeViewKind: "2.5d",   // 2.5d | split
  topDownCanvas: null,
  sourcePreset: "wall",
  sourceUsage: null,
  sourceUsageByMap: new Map(),
  compilerBusy: false,
  compilerTimer: 0,
  simpleEditTimer: 0,
  compilerReason: "",
  panelRaf: 0,
  previewPanelRefresh: null,
  assetRefreshTimer: 0,
  sourceRefreshTimer: 0,
  modelSaveTimer: 0,
  modelCompileRaf: 0,
  modelCompilePending: null,
  objStart: null,
  objCurrent: null,
  showOverlay: true,
  showLabels: true,
  show2DRefs: false,
  dragging: false,
  visited: new Set(),
  maps: new Map(),
  legacyHeights: new Map(),
  panelRefresh: null,
  preview: {
    canvas: null,
    status: null,
    angle: runtimeConfig.outdoorDefaultAlpha || 25,
    yaw: 0,
    zoom: 1.0,
    radius: 10,
    focusX: null,
    focusY: null,
    followHover: false,
    showCollision: true,
    showWire: false,
    showPlayer: true,
    showEvents: false,
    showTags: false,
    fullMap: false,
    hovered: null,
    hitCells: [],
    dragging: false,
    objJustDown: false,
    visited: new Set(),
    raf: 0,
    topDownRaf: 0,
    tilesetLoading: new Map(),
    rendering: false,
    rerender: false,
    tilesetId: null,
    tilesetImage: null,
    tilesetImages: new Map(),
    autotileImages: [],
    autotileImagesByTileset: new Map(),
    autotileImagesByName: new Map(),
    autotileUrls: [],
    autotileCache: new Map(),
    tileProps: new Map(),
    transformedSourceCache: new Map(),
    characterImages: new Map(),
    characterUrls: [],
    orbiting: false,
    orbitStartX: 0,
    orbitStartY: 0,
    orbitStartYaw: 0,
    orbitStartPitch: 25,
    cliffSource: null,
    lastMapId: null,
    warning: "",
    assetStats: { standardAutotiles: 0, extraAutotiles: 0, missingSources: 0, groundCells: 0, groundTextured: 0, groundMissing: 0, regularTilesets: 0 },
    layerStats: { native: 3, extended: 0 },
    usedAssetsByMap: new Map(),
    colorModel: "auto",
    ignoreColorTransforms: true,
    cellEntryCache: new Map(),
    legacyHeightTimer: 0,
    canvasPool: [],
    extendedDataByMap: new Map(),
    rxMaps: new Map(),
    rxTilesets: null,
  },
};

function pad3(value) {
  return String(Number(value) || 0).padStart(3, "0");
}

function geometryPath(mapId) {
  return `Data/VERMEIL2_5D/Map${pad3(mapId)}.json`;
}

function rxdataPath(mapId) {
  return `Data/Map${pad3(mapId)}.rxdata`;
}

function absoluteProjectPath(ctx, relPath) {
  const root = ctx.editor.gameRoot?.();
  if (!root) return null;
  const sep = root.includes("\\") ? "\\" : "/";
  return `${root}${root.endsWith("\\") || root.endsWith("/") ? "" : sep}${String(relPath).replaceAll("/", sep)}`;
}

async function readProjectBinary(ctx, relPath) {
  const invoke = window.__TAURI__?.core?.invoke;
  const abs = absoluteProjectPath(ctx, relPath);
  if (!invoke || !abs) return null;
  const bytes = await invoke("read_binary_file", { path: abs });
  return bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
}

async function ensureRxTilesets(ctx, force = false) {
  if (!force && state.preview.rxTilesets) return state.preview.rxTilesets;
  try {
    state.preview.rxTilesets = parseTilesetsRxdata(await readProjectBinary(ctx, "Data/Tilesets.rxdata"));
  } catch (err) {
    ctx.log.warn("2.5D Geometry: no se pudo leer Data/Tilesets.rxdata", err);
    state.preview.rxTilesets = [];
  }
  return state.preview.rxTilesets;
}

async function ensureRxMap(ctx, mapId, force = false) {
  if (!force && state.preview.rxMaps.has(mapId)) return state.preview.rxMaps.get(mapId);
  try {
    const parsed = parseMapRxdata(await readProjectBinary(ctx, rxdataPath(mapId)));
    state.preview.rxMaps.set(mapId, parsed);
    return parsed;
  } catch (err) {
    ctx.log.warn(`2.5D Geometry: no se pudo parsear ${rxdataPath(mapId)}`, err);
    state.preview.rxMaps.set(mapId, null);
    return null;
  }
}

function mapTilesetId(info, mapId = null) {
  const rx = mapId == null ? null : state.preview.rxMaps.get(mapId);
  return Number(firstDefined(rx?.tilesetId, info?.tilesetId, info?.tileset_id, info?.tileset?.id, info?.tileset)) || 0;
}

function normalizeExtendedData(raw) {
  if (!raw) return null;
  if (typeof raw === "string") {
    try { raw = JSON.parse(raw); } catch (_) { return null; }
  }
  if (Array.isArray(raw)) return { layers: raw };
  if (raw.extendedData) return normalizeExtendedData(raw.extendedData);
  if (raw.extended_data) return normalizeExtendedData(raw.extended_data);
  if (raw.extendedLayers) return { ...(raw || {}), layers: raw.extendedLayers };
  if (raw.extended_layers) return normalizeExtendedData(raw.extended_layers);
  if (raw.layers || raw.nativeProperties || raw.native_properties) {
    return {
      ...raw,
      layers: raw.layers || [],
      nativeProperties: raw.nativeProperties || raw.native_properties || null,
    };
  }
  return null;
}

function extractJsonObjectAt(text, start) {
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === "\"") inString = false;
      continue;
    }
    if (ch === "\"") inString = true;
    else if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return null;
}

function findEmbeddedExtendedData(text) {
  const markers = ["\"nativeProperties\"", "\"native_properties\"", "\"layers\""];
  for (const marker of markers) {
    let pos = text.indexOf(marker);
    while (pos >= 0) {
      const start = text.lastIndexOf("{", pos);
      if (start >= 0) {
        const json = extractJsonObjectAt(text, start);
        const data = normalizeExtendedData(json);
        if (data && (data.nativeProperties || (data.layers || []).length)) return data;
      }
      pos = text.indexOf(marker, pos + marker.length);
    }
  }
  return null;
}

async function loadEmbeddedExtendedData(ctx, mapId) {
  if (state.preview.extendedDataByMap.has(mapId)) return state.preview.extendedDataByMap.get(mapId);
  let data = null;
  // Preferred: the JSON is already decoded by the Marshal parser (rxMaps fills
  // this from RPG::Map#@extended_layers). Avoids a fragile text-scan of binary.
  const rxRow = state.preview.rxMaps.get(mapId);
  const rawJson = rxRow?.extendedLayers;
  if (rawJson) data = normalizeExtendedData(rawJson);
  if (!data) {
    // Fallback: text-scan the raw rxdata for an embedded object.
    const invoke = window.__TAURI__?.core?.invoke;
    const root = ctx.editor.gameRoot?.();
    try {
      if (invoke && root) {
        const sep = root.includes("\\") ? "\\" : "/";
        const path = `${root}${root.endsWith("\\") || root.endsWith("/") ? "" : sep}${rxdataPath(mapId).replaceAll("/", sep)}`;
        const bytes = await invoke("read_binary_file", { path });
        const text = new TextDecoder("utf-8", { fatal: false }).decode(new Uint8Array(bytes || []));
        data = findEmbeddedExtendedData(text);
      }
    } catch (err) {
      ctx.log.warn(`2.5D Geometry: no se pudo leer ${rxdataPath(mapId)} para @extended_layers`, err);
    }
  }
  state.preview.extendedDataByMap.set(mapId, data || null);
  return data || null;
}

function mapExtendedData(ctx, mapId) {
  try {
    const direct = firstDefined(
      ctx.map.extendedData?.(mapId),
      ctx.map.getExtendedData?.(mapId),
      ctx.map.getExtendedLayers?.(mapId),
      ctx.map.extendedLayers?.(mapId)
    );
    const normalized = normalizeExtendedData(direct);
    if (normalized) return normalized;
  } catch (_) {}
  try {
    const info = ctx.map.info(mapId);
    const normalized = normalizeExtendedData(firstDefined(
      info?.extendedData,
      info?.extended_data,
      info?.extendedLayers,
      info?.extended_layers,
      info?.makerStudio,
      info?.maker_studio
    ));
    if (normalized) return normalized;
  } catch (_) {
  }
  if (state.preview.extendedDataByMap.has(mapId)) return state.preview.extendedDataByMap.get(mapId);
  return null;
}

function normalizeComponentSet(raw) {
  const base = { extrude: true, cap: true, connect_neighbors: false, slope: false, billboard: false, occlusion: "auto" };
  if (!raw || typeof raw !== "object") return base;
  return {
    extrude: raw.extrude !== false,
    cap: raw.cap !== false,
    connect_neighbors: raw.connect_neighbors === true,
    slope: raw.slope === true,
    billboard: raw.billboard === true,
    occlusion: ["auto", "front", "behind", "none"].includes(raw.occlusion) ? raw.occlusion : "auto",
  };
}

function normalizeSourceDefinition(raw, sourceKey = "") {
  const preset = SCENE_GEOMETRY_PRESETS[raw?.category] || SCENE_GEOMETRY_PRESETS.custom;
  return {
    source_key: String(raw?.source_key || sourceKey),
    label: String(raw?.label || sourceKey || "Source"),
    enabled: raw?.enabled !== false,
    category: OBJECT_CATEGORIES.some(([id]) => id === raw?.category) ? raw.category : preset.category,
    type: raw?.type === "plane" ? "plane" : "cube",
    height: Math.max(0, Number(raw?.height ?? preset.height) || 0),
    anchor_z: Math.max(0, Number(raw?.anchor_z ?? preset.anchor_z) || 0),
    collision: OBJECT_COLLISIONS.includes(raw?.collision) ? raw.collision : preset.collision,
    characters_in_front: raw?.characters_in_front === true,
    components: normalizeComponentSet(raw?.components || preset.components),
  };
}

function normalizeSourceDefinitions(raw) {
  const out = {};
  if (!raw || typeof raw !== "object") return out;
  for (const [key, value] of Object.entries(raw)) {
    if (!key || !value || typeof value !== "object") continue;
    out[key] = normalizeSourceDefinition(value, key);
  }
  return out;
}

function normalizeInstanceOverrides(raw) {
  const out = {};
  if (!raw || typeof raw !== "object") return out;
  for (const [key, value] of Object.entries(raw)) {
    if (!key || !value || typeof value !== "object") continue;
    const row = {};
    if (value.disabled != null) row.disabled = !!value.disabled;
    if (value.category && OBJECT_CATEGORIES.some(([id]) => id === value.category)) row.category = value.category;
    if (value.type === "cube" || value.type === "plane") row.type = value.type;
    if (value.height != null) row.height = Math.max(0, Number(value.height) || 0);
    if (value.anchor_z != null) row.anchor_z = Math.max(0, Number(value.anchor_z) || 0);
    if (OBJECT_COLLISIONS.includes(value.collision)) row.collision = value.collision;
    if (value.characters_in_front != null) row.characters_in_front = !!value.characters_in_front;
    if (value.components && typeof value.components === "object") row.components = normalizeComponentSet(value.components);
    out[key] = row;
  }
  return out;
}

function normalizeCompilerMeta(raw, geo) {
  const stats = raw?.stats && typeof raw.stats === "object" ? raw.stats : {};
  return {
    version: SCENE_COMPILER_VERSION,
    auto_compile: raw?.auto_compile !== false,
    last_compile: raw?.last_compile || null,
    stats: {
      placed_tiles: Number(stats.placed_tiles) || 0,
      unique_sources: Number(stats.unique_sources) || Object.keys(geo?.definitions || {}).length,
      defined_sources: Number(stats.defined_sources) || Object.keys(geo?.definitions || {}).length,
      compiled_objects: Number(stats.compiled_objects) || (geo?.compiled_objects || []).length,
    },
  };
}

function newGeometry(mapId, info) {
  return {
    format: FORMAT,
    map_id: mapId,
    width: info?.width ?? 0,
    height: info?.height ?? 0,
    height_step: runtimeConfig.surfaceGeometryHeightStep || DEFAULT_STEP,
    inherit_legacy: true,
    cells: {},
    ramps: [],
    objects: [],
    // Source-driven scene compiler. Definitions are prefab-like rules keyed by
    // the REAL tile source, instance_overrides are per placed occurrence, and
    // compiled_objects is the canonical runtime/preview output.
    definitions: {},
    instance_overrides: {},
    compiled_objects: [],
    // Reusable visual models (mountains/buildings/etc.) and their map instances.
    models: {},
    model_instances: [],
    model_objects: [],
    // Region-meshed render output shared by editor preview and MKXP-Z runtime.
    // model_objects remain lightweight collision proxies; mesh_faces are the
    // visible top/perimeter surfaces and are kept while a dirty rebuild runs.
    mesh_faces: [],
    mesh_compiler: { version: 1, last_build: null, stats: { cells: 0, faces: 0, top_faces: 0, side_faces: 0 } },
    compiler: {
      version: SCENE_COMPILER_VERSION,
      auto_compile: true,
      last_compile: null,
      stats: { placed_tiles: 0, unique_sources: 0, defined_sources: 0, compiled_objects: 0 },
    },
    editor_preview: {
      angle: runtimeConfig.outdoorDefaultAlpha || 25,
      yaw: 0,
      zoom: 1.0,
      radius: 10,
    },
  };
}


function normalizeFaceMaterialMap(raw) {
  const out = { top: null, north: null, south: null, east: null, west: null };
  if (!raw || typeof raw !== "object") return out;
  for (const key of Object.keys(out)) out[key] = raw[key] && typeof raw[key] === "object" ? raw[key] : null;
  return out;
}


// Model Builder v2.9 ---------------------------------------------------------
// Models are authored as editable primitive parts (similar to the reference
// workflow) and compiled to generic textured quads. Legacy cell models remain
// supported and are still used as collision proxies where appropriate.
const MODEL_PART_TYPES = ["box","billboard","sphere","relief","cylinder","prism","dome","wedge"];

function normalizeLegacyGeometryCell(raw, fallbackHeight = 1) {
  const value = raw && typeof raw === "object" ? raw : {};
  return {
    enabled: value.enabled !== false,
    height: Math.max(.25, Number(value.height ?? fallbackHeight) || fallbackHeight || 1),
    anchor_z: Math.max(0, Number(value.anchor_z) || 0),
    face_materials: normalizeFaceMaterialMap(value.face_materials),
  };
}

function normalizeVec3(raw, fallback = {x:0,y:0,z:0}) {
  const v = raw && typeof raw === "object" ? raw : {};
  return {
    x: Number(v.x ?? fallback.x) || 0,
    y: Number(v.y ?? fallback.y) || 0,
    z: Number(v.z ?? fallback.z) || 0,
  };
}

function normalizeModelPart(raw, index = 0) {
  const type = MODEL_PART_TYPES.includes(String(raw?.type || "").toLowerCase()) ? String(raw.type).toLowerCase() : "box";
  const size = normalizeVec3(raw?.size, {x:1,y:1,z:1});
  size.x = Math.max(.05, Math.abs(size.x) || 1);
  size.y = Math.max(.05, Math.abs(size.y) || 1);
  size.z = Math.max(.05, Math.abs(size.z) || 1);
  const angle = normalizeVec3(raw?.angle, {x:0,y:0,z:0});
  return {
    id: String(raw?.id || `part_${index+1}`),
    name: String(raw?.name || `${type.toUpperCase()} ${index+1}`),
    type,
    position: normalizeVec3(raw?.position, {x:.5,y:.5,z:0}),
    size,
    angle,
    axis: ["x","y","z"].includes(String(raw?.axis)) ? String(raw.axis) : "x",
    segments: Math.max(4, Math.min(24, Math.round(Number(raw?.segments) || 8))),
    visible: raw?.visible !== false,
    collision: raw?.collision === false ? false : true,
    repeat: raw?.repeat !== false,
    material: raw?.material && typeof raw.material === "object" ? raw.material : null,
    face_materials: normalizeFaceMaterialMap(raw?.face_materials),
  };
}

function normalizeModelParts(raw) {
  if (!Array.isArray(raw)) return [];
  const used = new Set();
  return raw.filter(Boolean).map((part, i) => {
    const p = normalizeModelPart(part, i);
    let id = p.id, n = 2;
    while (used.has(id)) id = `${p.id}_${n++}`;
    p.id = id; used.add(id); return p;
  });
}

function nextModelPartId(model, type = "part") {
  const used = new Set((model?.parts || []).map(p => String(p.id)));
  let n = 1, id = `${type}_${n}`;
  while (used.has(id)) id = `${type}_${++n}`;
  return id;
}

function modelPartFaceMaterial(part, edge) {
  return cloneMaterial(part?.face_materials?.[edge] || part?.material || part?.face_materials?.top || null);
}

function rotateXYZPoint(p, angle, pivot) {
  let x=p[0]-pivot[0], y=p[1]-pivot[1], z=p[2]-pivot[2];
  const ax=(Number(angle?.x)||0)*Math.PI/180, ay=(Number(angle?.y)||0)*Math.PI/180, az=(Number(angle?.z)||0)*Math.PI/180;
  let c=Math.cos(ax), sn=Math.sin(ax); let y1=y*c-z*sn, z1=y*sn+z*c; y=y1;z=z1;
  c=Math.cos(ay);sn=Math.sin(ay); let x1=x*c+z*sn;z1=-x*sn+z*c;x=x1;z=z1;
  c=Math.cos(az);sn=Math.sin(az);x1=x*c-y*sn;y1=x*sn+y*c;x=x1;y=y1;
  return [x+pivot[0],y+pivot[1],z+pivot[2]];
}

function partLocalQuads(part) {
  if (!part || part.visible === false) return [];
  const pos=part.position||{x:.5,y:.5,z:0}, sz=part.size||{x:1,y:1,z:1};
  const hx=sz.x/2, hy=sz.y/2, z0=pos.z, z1=pos.z+sz.z;
  const cx=pos.x, cy=pos.y, pivot=[cx,cy,z0];
  const P=(x,y,z)=>rotateXYZPoint([x,y,z],part.angle,pivot);
  const q=[];
  const add=(edge,verts,surface=edge==="top"?"top":"side")=>q.push({edge,surface,vertices:verts.map(v=>P(...v)),material:modelPartFaceMaterial(part,edge),part_id:part.id,material_repeat:part.repeat!==false});
  const x0=cx-hx,x1=cx+hx,y0=cy-hy,y1=cy+hy;
  if(part.type==="box" || part.type==="relief"){
    add("top",[[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]],"top");
    add("north",[[x0,y0,z1],[x1,y0,z1],[x1,y0,z0],[x0,y0,z0]]);
    add("south",[[x1,y1,z1],[x0,y1,z1],[x0,y1,z0],[x1,y1,z0]]);
    add("west",[[x0,y1,z1],[x0,y0,z1],[x0,y0,z0],[x0,y1,z0]]);
    add("east",[[x1,y0,z1],[x1,y1,z1],[x1,y1,z0],[x1,y0,z0]]);
  } else if(part.type==="billboard"){
    if(part.axis==="y") add("south",[[cx,y0,z1],[cx,y1,z1],[cx,y1,z0],[cx,y0,z0]],"billboard");
    else add("south",[[x0,cy,z1],[x1,cy,z1],[x1,cy,z0],[x0,cy,z0]],"billboard");
  } else if(part.type==="wedge"){
    if(part.axis==="y"){
      add("top",[[x0,y0,z0],[x1,y0,z0],[x1,y1,z1],[x0,y1,z1]],"top");
      add("south",[[x1,y1,z1],[x0,y1,z1],[x0,y1,z0],[x1,y1,z0]]);
      add("west",[[x0,y1,z1],[x0,y0,z0],[x0,y0,z0],[x0,y1,z0]]);
      add("east",[[x1,y0,z0],[x1,y1,z1],[x1,y1,z0],[x1,y0,z0]]);
    }else{
      add("top",[[x0,y0,z0],[x1,y0,z1],[x1,y1,z1],[x0,y1,z0]],"top");
      add("east",[[x1,y0,z1],[x1,y1,z1],[x1,y1,z0],[x1,y0,z0]]);
      add("north",[[x0,y0,z0],[x1,y0,z1],[x1,y0,z0],[x0,y0,z0]]);
      add("south",[[x1,y1,z1],[x0,y1,z0],[x0,y1,z0],[x1,y1,z0]]);
    }
  } else if(part.type==="prism"){
    // Triangular prism approximated with degenerate quads, preserving texture.
    if(part.axis==="y"){
      const a=[x0,cy,z0],b=[x1,cy,z0],t=[cx,cy,z1];
      add("north",[[a[0],y0,a[2]],[b[0],y0,b[2]],[t[0],y0,t[2]],[t[0],y0,t[2]]]);
      add("south",[[b[0],y1,b[2]],[a[0],y1,a[2]],[t[0],y1,t[2]],[t[0],y1,t[2]]]);
      add("west",[[a[0],y1,a[2]],[a[0],y0,a[2]],[t[0],y0,t[2]],[t[0],y1,t[2]]]);
      add("east",[[b[0],y0,b[2]],[b[0],y1,b[2]],[t[0],y1,t[2]],[t[0],y0,t[2]]]);
    } else {
      const a=[cx,y0,z0],b=[cx,y1,z0],t=[cx,cy,z1];
      add("west",[[x0,a[1],a[2]],[x0,b[1],b[2]],[x0,t[1],t[2]],[x0,t[1],t[2]]]);
      add("east",[[x1,b[1],b[2]],[x1,a[1],a[2]],[x1,t[1],t[2]],[x1,t[1],t[2]]]);
      add("north",[[x1,a[1],a[2]],[x0,a[1],a[2]],[x0,t[1],t[2]],[x1,t[1],t[2]]]);
      add("south",[[x0,b[1],b[2]],[x1,b[1],b[2]],[x1,t[1],t[2]],[x0,t[1],t[2]]]);
    }
  } else if(part.type==="cylinder" || part.type==="sphere" || part.type==="dome"){
    const seg=Math.max(4,Number(part.segments)||8), rings=part.type==="cylinder"?1:Math.max(3,Math.round(seg/2));
    if(part.type==="cylinder"){
      for(let i=0;i<seg;i++){
        const a=i*Math.PI*2/seg,b=(i+1)*Math.PI*2/seg;
        const p0=[cx+Math.cos(a)*hx,cy+Math.sin(a)*hy,z0],p1=[cx+Math.cos(b)*hx,cy+Math.sin(b)*hy,z0],p2=[p1[0],p1[1],z1],p3=[p0[0],p0[1],z1];
        add(i<seg/4?"east":i<seg/2?"south":i<seg*3/4?"west":"north",[p3,p2,p1,p0]);
      }
      // Top as a compact set of wedges (degenerate quads).
      for(let i=0;i<seg;i++){const a=i*Math.PI*2/seg,b=(i+1)*Math.PI*2/seg;add("top",[[cx,cy,z1],[cx+Math.cos(a)*hx,cy+Math.sin(a)*hy,z1],[cx+Math.cos(b)*hx,cy+Math.sin(b)*hy,z1],[cx,cy,z1]],"top");}
    }else{
      const start=part.type==="dome"?0:-Math.PI/2, end=Math.PI/2;
      const rr=part.type==="dome"?rings:Math.max(4,rings*2);
      for(let j=0;j<rr;j++){
        const v0=start+(end-start)*j/rr,v1=start+(end-start)*(j+1)/rr;
        for(let i=0;i<seg;i++){
          const u0=i*Math.PI*2/seg,u1=(i+1)*Math.PI*2/seg;
          const vv=(u,v)=>[cx+Math.cos(v)*Math.cos(u)*hx,cy+Math.cos(v)*Math.sin(u)*hy,z0+sz.z*(part.type==="dome"?Math.sin(v):(.5+.5*Math.sin(v)))];
          const verts=[vv(u0,v1),vv(u1,v1),vv(u1,v0),vv(u0,v0)];
          const mid=(u0+u1)/2,edge=Math.cos(mid)>.5?"east":Math.cos(mid)<-.5?"west":Math.sin(mid)>.0?"south":"north";
          add(v1>1.2?"top":edge,verts,v1>1.2?"top":"side");
        }
      }
    }
  }
  return q;
}

function modelPartBounds(model) {
  const pts=[];
  for(const p of model?.parts||[]) for(const f of partLocalQuads(p)) pts.push(...f.vertices);
  if(!pts.length)return{x0:0,y0:0,z0:0,x1:Math.max(1,Number(model?.width)||1),y1:Math.max(1,Number(model?.height)||1),z1:1};
  return{x0:Math.min(...pts.map(p=>p[0])),y0:Math.min(...pts.map(p=>p[1])),z0:Math.min(...pts.map(p=>p[2])),x1:Math.max(...pts.map(p=>p[0])),y1:Math.max(...pts.map(p=>p[1])),z1:Math.max(...pts.map(p=>p[2]))};
}

function transformModelVertexForInstance(v, inst, model) {
  const sx=Math.max(.01,Number(inst?.scale_x)||1),sy=Math.max(.01,Number(inst?.scale_y)||1),hs=Math.max(.01,Number(inst?.height_scale)||1),rot=normalizeRotation(inst?.rotation);
  const b=modelPartBounds(model), w=(b.x1-b.x0)*sx, h=(b.y1-b.y0)*sy;
  let x=(v[0]-b.x0)*sx,y=(v[1]-b.y0)*sy,z=v[2]*hs,rx=x,ry=y;
  if(rot===90){rx=h-y;ry=x;}else if(rot===180){rx=w-x;ry=h-y;}else if(rot===270){rx=y;ry=w-x;}
  return[(Number(inst?.x)||0)+rx,(Number(inst?.y)||0)+ry,z];
}

function modelPartMeshFacesForInstance(inst, model, startId=400000) {
  const faces=[];let id=startId;
  for(const part of model?.parts||[]){
    if(part.visible===false)continue;
    for(const f of partLocalQuads(part)){
      const vertices=f.vertices.map(v=>transformModelVertexForInstance(v,inst,model));
      const xs=vertices.map(v=>v[0]),ys=vertices.map(v=>v[1]),zs=vertices.map(v=>v[2]);
      faces.push({id:id++,kind:"quad",surface:f.surface||"side",edge:f.edge||null,vertices,x0:Math.min(...xs),y0:Math.min(...ys),x1:Math.max(...xs),y1:Math.max(...ys),z0:Math.min(...zs),z1:Math.max(...zs),material:f.material,material_repeat:f.material_repeat!==false,category:model.category||"mountain",model_id:model.id,model_instance_id:inst.id,part_id:part.id,chunk_key:`${Math.floor(Math.min(...xs)/8)},${Math.floor(Math.min(...ys)/8)}`});
    }
  }
  const cells=expandedPartCollisionCells(inst,model);
  return{faces,nextId:id,cells};
}

function expandedPartCollisionCells(inst, model) {
  const out=new Map();
  for(const part of model?.parts||[]){
    if(part.visible===false || part.collision===false || part.type==="billboard")continue;
    const verts=partLocalQuads(part).flatMap(f=>f.vertices).map(v=>transformModelVertexForInstance(v,inst,model));
    if(!verts.length)continue;
    const x0=Math.floor(Math.min(...verts.map(v=>v[0]))),x1=Math.ceil(Math.max(...verts.map(v=>v[0])))-1;
    const y0=Math.floor(Math.min(...verts.map(v=>v[1]))),y1=Math.ceil(Math.max(...verts.map(v=>v[1])))-1;
    const z0=Math.max(0,Math.min(...verts.map(v=>v[2]))),z1=Math.max(...verts.map(v=>v[2]));
    const mats={top:modelPartFaceMaterial(part,"top"),north:modelPartFaceMaterial(part,"north"),south:modelPartFaceMaterial(part,"south"),east:modelPartFaceMaterial(part,"east"),west:modelPartFaceMaterial(part,"west")};
    for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
      const key=`${x-(Number(inst?.x)||0)},${y-(Number(inst?.y)||0)}`;
      const prev=out.get(key);const h=Math.max(.25,z1-z0);
      if(!prev||prev.base+prev.height<z1)out.set(key,{x,y,lx:x-(Number(inst?.x)||0),ly:y-(Number(inst?.y)||0),height:h,base:z0,materials:mats});
    }
  }
  return out;
}

function normalizeMeshFaces(raw) {
  if (!Array.isArray(raw)) return [];
  return raw.filter(Boolean).map((f, i) => ({
    id: Number(f.id) || (400000 + i),
    kind: f.kind === "top" ? "top" : (f.kind === "quad" ? "quad" : "side"),
    surface: ["top","side","billboard"].includes(f.surface) ? f.surface : null,
    edge: ["north","south","east","west"].includes(f.edge) ? f.edge : null,
    vertices: Array.isArray(f.vertices) && f.vertices.length === 4 ? f.vertices.map(v => [Number(v?.[0])||0, Number(v?.[1])||0, Math.max(0,Number(v?.[2])||0)]) : null,
    x0: Number(f.x0) || 0, y0: Number(f.y0) || 0,
    x1: Number(f.x1) || 0, y1: Number(f.y1) || 0,
    z0: Math.max(0, Number(f.z0) || 0),
    z1: Math.max(0, Number(f.z1) || 0),
    material: f.material && typeof f.material === "object" ? f.material : null,
    material_repeat: f.material_repeat !== false,
    category: String(f.category || "mountain"),
    model_id: f.model_id != null ? String(f.model_id) : "",
    model_instance_id: Number(f.model_instance_id) || 0,
    part_id: f.part_id != null ? String(f.part_id) : "",
    chunk_key: String(f.chunk_key || ""),
  })).filter(f => f.kind === "quad" ? !!f.vertices : (f.kind === "top" ? (f.x1 > f.x0 && f.y1 > f.y0) : (f.z1 > f.z0 && (Math.abs(f.x1-f.x0) > 0 || Math.abs(f.y1-f.y0) > 0))));
}

function materialSignature(mat) {
  if (!mat) return "none";
  const r = mat.src_rect || {};
  return [mat.kind||"", Number(mat.tileset_id)||0, mat.graphic||"", Number(mat.tile_id)||0,
    Number(mat.autotile_tid)||0, Number(mat.autotile_pattern)||0,
    Number(r.x)||0, Number(r.y)||0, Number(r.w)||0, Number(r.h)||0,
    normalizeRotation(mat.rotation), mat.flip_h?1:0, mat.flip_v?1:0,
    Number(mat.hue)||0, mat.saturation==null?100:Number(mat.saturation), Number(mat.lighting)||0].join("|");
}

function deepClone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
function cloneMaterial(mat) { return mat ? deepClone(mat) : null; }

function rotatedEdge(edge, rotation) {
  const order = ["north","east","south","west"];
  const i = order.indexOf(edge); if (i < 0) return edge;
  return order[(i + Math.round(normalizeRotation(rotation)/90)) % 4];
}

function expandedModelCells(inst, model) {
  if (Array.isArray(model?.parts) && model.parts.length) return expandedPartCollisionCells(inst, model);
  const sx = Math.max(1, Math.round(Number(inst.scale_x)||1));
  const sy = Math.max(1, Math.round(Number(inst.scale_y)||1));
  const hs = Math.max(.25, Number(inst.height_scale)||1);
  const rot = normalizeRotation(inst.rotation);
  const baseW = Math.max(1, model.width * sx), baseH = Math.max(1, model.height * sy);
  const out = new Map();
  for (const [key, cell] of Object.entries(model.cells || {})) {
    if (!cell || cell.enabled === false) continue;
    const [cx,cy] = key.split(',').map(Number);
    const localMats = {};
    for (const edge of ["top","north","south","east","west"]) localMats[edge] = modelMaterialForCell(model, cell, edge);
    const worldMats = { top: cloneMaterial(localMats.top), north:null, south:null, east:null, west:null };
    for (const edge of ["north","south","east","west"]) worldMats[rotatedEdge(edge, rot)] = cloneMaterial(localMats[edge]);
    for (let yy=0; yy<sy; yy++) for (let xx=0; xx<sx; xx++) {
      const lx = cx*sx+xx, ly = cy*sy+yy;
      let rx=lx, ry=ly;
      if (rot===90) { rx=baseH-1-ly; ry=lx; }
      else if (rot===180) { rx=baseW-1-lx; ry=baseH-1-ly; }
      else if (rot===270) { rx=ly; ry=baseW-1-lx; }
      out.set(`${rx},${ry}`, {
        x: (Number(inst.x)||0) + rx, y: (Number(inst.y)||0) + ry,
        lx:rx, ly:ry,
        height: Math.max(.25, Number(cell.height || model.default_height || 2) * hs),
        base: Math.max(0, Number(cell.anchor_z)||0) * hs,
        materials: worldMats,
      });
    }
  }
  return out;
}

function greedyTopRects(cells) {
  const remaining = new Set(cells.keys()), out=[];
  while (remaining.size) {
    const first=[...remaining][0], c0=cells.get(first); if(!c0){remaining.delete(first);continue;}
    const sig = `${c0.base}|${c0.height}|${materialSignature(c0.materials.top)}`;
    let w=1;
    while (true) {
      const c=cells.get(`${c0.lx+w},${c0.ly}`);
      if (!c || !remaining.has(`${c0.lx+w},${c0.ly}`) || `${c.base}|${c.height}|${materialSignature(c.materials.top)}`!==sig) break;
      w++;
    }
    let h=1;
    outer: while (true) {
      for(let xx=0;xx<w;xx++){
        const k=`${c0.lx+xx},${c0.ly+h}`, c=cells.get(k);
        if(!c || !remaining.has(k) || `${c.base}|${c.height}|${materialSignature(c.materials.top)}`!==sig) break outer;
      }
      h++;
    }
    for(let yy=0;yy<h;yy++)for(let xx=0;xx<w;xx++)remaining.delete(`${c0.lx+xx},${c0.ly+yy}`);
    out.push({x0:c0.x,y0:c0.y,x1:c0.x+w,y1:c0.y+h,z:c0.base+c0.height,material:cloneMaterial(c0.materials.top)});
  }
  return out;
}

function modelMeshFacesForInstance(inst, model, startId=400000) {
  if (Array.isArray(model?.parts) && model.parts.length) return modelPartMeshFacesForInstance(inst, model, startId);
  const cells=expandedModelCells(inst,model), faces=[], tops=greedyTopRects(cells); let id=startId;
  for(const r of tops) faces.push({id:id++,kind:"top",x0:r.x0,y0:r.y0,x1:r.x1,y1:r.y1,z0:r.z,z1:r.z,material:r.material,material_repeat:true,category:model.category||"mountain",model_id:model.id,model_instance_id:inst.id,chunk_key:`${Math.floor(r.x0/8)},${Math.floor(r.y0/8)}`});
  const segments=[];
  const dirs={north:[0,-1],south:[0,1],east:[1,0],west:[-1,0]};
  for(const c of cells.values()){
    const top=c.base+c.height;
    for(const [edge,[dx,dy]] of Object.entries(dirs)){
      const n=cells.get(`${c.lx+dx},${c.ly+dy}`);
      const nTop=n ? n.base+n.height : -Infinity;
      if(n && nTop>=top-1e-6) continue;
      const z0=Math.max(c.base, n ? nTop : c.base), z1=top;
      if(z1<=z0+1e-6) continue;
      let x0=c.x,y0=c.y,x1=c.x+1,y1=c.y+1;
      if(edge==="north") y1=y0;
      else if(edge==="south") y0=y1;
      else if(edge==="west") x1=x0;
      else if(edge==="east") x0=x1;
      segments.push({edge,x0,y0,x1,y1,z0,z1,material:cloneMaterial(c.materials[edge]),sig:`${edge}|${z0}|${z1}|${materialSignature(c.materials[edge])}`});
    }
  }
  // Merge collinear neighbouring side segments with identical height/material.
  const used=new Set();
  for(let i=0;i<segments.length;i++){
    if(used.has(i))continue; const a={...segments[i]}; used.add(i);
    let changed=true;
    while(changed){changed=false;for(let j=0;j<segments.length;j++){
      if(used.has(j))continue;const b=segments[j];if(b.sig!==a.sig)continue;
      if((a.edge==="north"||a.edge==="south") && Math.abs(a.y0-b.y0)<1e-6 && Math.abs(a.y1-b.y1)<1e-6){
        if(Math.abs(a.x1-b.x0)<1e-6){a.x1=b.x1;used.add(j);changed=true;break;}
        if(Math.abs(b.x1-a.x0)<1e-6){a.x0=b.x0;used.add(j);changed=true;break;}
      } else if((a.edge==="east"||a.edge==="west") && Math.abs(a.x0-b.x0)<1e-6 && Math.abs(a.x1-b.x1)<1e-6){
        if(Math.abs(a.y1-b.y0)<1e-6){a.y1=b.y1;used.add(j);changed=true;break;}
        if(Math.abs(b.y1-a.y0)<1e-6){a.y0=b.y0;used.add(j);changed=true;break;}
      }
    }}
    faces.push({id:id++,kind:"side",edge:a.edge,x0:a.x0,y0:a.y0,x1:a.x1,y1:a.y1,z0:a.z0,z1:a.z1,material:a.material,material_repeat:true,category:model.category||"mountain",model_id:model.id,model_instance_id:inst.id,chunk_key:`${Math.floor(Math.min(a.x0,a.x1)/8)},${Math.floor(Math.min(a.y0,a.y1)/8)}`});
  }
  return {faces,nextId:id,cells};
}

function normalizeModelTemplate(raw, id = "model") {
  const w = Math.max(1, Math.min(64, Math.round(Number(raw?.width) || 4)));
  const h = Math.max(1, Math.min(64, Math.round(Number(raw?.height) || 4)));
  const cells = {};
  const input = raw?.cells && typeof raw.cells === "object" ? raw.cells : {};
  for (const [key, val] of Object.entries(input)) {
    const m = /^(\d+),(\d+)$/.exec(key); if (!m) continue;
    const x = Number(m[1]), y = Number(m[2]);
    if (x < 0 || y < 0 || x >= w || y >= h) continue;
    const cell=normalizeLegacyGeometryCell(val, raw?.default_height ?? 2);
    if(cell.enabled!==false)cells[key]=cell;
  }
  const parts=normalizeModelParts(raw?.parts);
  const explicitEmpty = raw?.allow_empty === true || Number(raw?.builder_version) >= 3 || Array.isArray(raw?.parts);
  if (!Object.keys(cells).length && !parts.length && !explicitEmpty) {
    for (let y=0;y<h;y++) for(let x=0;x<w;x++) cells[`${x},${y}`] = normalizeLegacyGeometryCell({enabled:true,height:Math.max(.25,Number(raw?.default_height)||2)}, Number(raw?.default_height)||2);
  }
  return {
    id: String(raw?.id || id),
    name: String(raw?.name || "Modelo"),
    category: String(raw?.category || "mountain"),
    width: w, height: h,
    default_height: Math.max(.25, Number(raw?.default_height) || 2),
    collision: OBJECT_COLLISIONS.includes(raw?.collision) ? raw.collision : "solid",
    connect_neighbors: raw?.connect_neighbors !== false,
    face_materials: normalizeFaceMaterialMap(raw?.face_materials),
    builder_version: Math.max(3, Number(raw?.builder_version)||0),
    parts,
    cells,
  };
}

function normalizeModels(raw) {
  const out = {};
  if (!raw || typeof raw !== "object") return out;
  for (const [id, model] of Object.entries(raw)) out[id] = normalizeModelTemplate(model, id);
  return out;
}

function normalizeModelInstances(raw) {
  if (!Array.isArray(raw)) return [];
  return raw.filter(Boolean).map((r, i) => ({
    id: Number(r.id) || (i + 1),
    model_id: String(r.model_id || r.modelId || ""),
    x: Math.round(Number(r.x) || 0), y: Math.round(Number(r.y) || 0),
    scale_x: Math.max(1, Math.min(8, Math.round(Number(r.scale_x) || 1))),
    scale_y: Math.max(1, Math.min(8, Math.round(Number(r.scale_y) || 1))),
    height_scale: Math.max(.25, Math.min(8, Number(r.height_scale) || 1)),
    rotation: normalizeRotation(r.rotation),
  })).filter(r => r.model_id);
}

function modelMaterialForCell(model, cell, edge) {
  const local = cell?.face_materials?.[edge];
  if (local) return JSON.parse(JSON.stringify(local));
  const shared = model?.face_materials?.[edge];
  if (shared) return JSON.parse(JSON.stringify(shared));
  if (edge !== "top") {
    const fallback = model?.face_materials?.south || model?.face_materials?.north || model?.face_materials?.east || model?.face_materials?.west;
    if (fallback) return JSON.parse(JSON.stringify(fallback));
  }
  return model?.face_materials?.top ? JSON.parse(JSON.stringify(model.face_materials.top)) : null;
}

function buildModelInstanceObjects(geo, inst, model, startId = 300000) {
  // Collision proxies only. Rendering uses mesh_faces so connected mountains do
  // not become hundreds of independently projected cubes.
  const out=[]; let oid=startId;
  const cells=expandedModelCells(inst,model);
  for(const c of cells.values()){
    out.push(normalizeObject({id:oid++,name:`${model.name} ${inst.id}:${c.lx},${c.ly}`,model_instance_id:inst.id,model_id:model.id,compiled:true,render:false,
      type:"cube",x:c.x,y:c.y,w:1,h:1,height:c.height,anchor_z:c.base,anchor_row:0,rotation:0,
      collision:model.collision||"solid",category:model.category||"mountain",characters_in_front:false,footprint:{},
      components:{extrude:false,cap:false,connect_neighbors:false,slope:false,billboard:false,occlusion:"auto"},
      material:c.materials.top||c.materials.south||null,face_materials:c.materials},oid-1));
  }
  return {objects:out,nextId:oid,cells};
}

function rebuildModelMeshFaces(geo, onlyModelId=null) {
  if(!geo)return [];
  const keep = onlyModelId ? (geo.mesh_faces||[]).filter(f=>String(f.model_id)!==String(onlyModelId)) : [];
  let id=Math.max(400000,...keep.map(f=>Number(f.id)||0))+1, fresh=[], cellCount=0;
  for(const inst of geo.model_instances||[]){
    if(onlyModelId && String(inst.model_id)!==String(onlyModelId))continue;
    const model=geo.models?.[inst.model_id];if(!model)continue;
    const built=modelMeshFacesForInstance(inst,model,id);fresh.push(...built.faces);id=built.nextId;cellCount+=built.cells.size;
  }
  geo.mesh_faces=[...keep,...fresh];
  const faces=geo.mesh_faces||[];
  geo.mesh_compiler={version:1,last_build:new Date().toISOString(),stats:{cells:cellCount,faces:faces.length,top_faces:faces.filter(f=>f.kind==="top").length,side_faces:faces.filter(f=>f.kind==="side").length}};
  return fresh;
}

function compileModelObjects(geo) {
  if (!geo) return [];
  const out=[]; let oid=300000;
  for(const inst of geo.model_instances||[]){const model=geo.models?.[inst.model_id];if(!model)continue;const built=buildModelInstanceObjects(geo,inst,model,oid);out.push(...built.objects);oid=built.nextId;}
  geo.model_objects=out;
  rebuildModelMeshFaces(geo);
  return out;
}

function compileModelTemplateInstances(geo, modelId) {
  if (!geo || !modelId) return [];
  const keep=(geo.model_objects||[]).filter(o=>String(o?.model_id)!==String(modelId));
  let oid=Math.max(300000,...keep.map(o=>Number(o.id)||0))+1;const fresh=[];const model=geo.models?.[modelId];
  if(model){for(const inst of geo.model_instances||[]){if(String(inst.model_id)!==String(modelId))continue;const built=buildModelInstanceObjects(geo,inst,model,oid);fresh.push(...built.objects);oid=built.nextId;}}
  geo.model_objects=[...keep,...fresh];
  rebuildModelMeshFaces(geo,modelId);
  return fresh;
}

function normalizeGeometry(mapId, info, raw) {
  const out = newGeometry(mapId, info);
  if (raw && typeof raw === "object") {
    out.format = Number(raw.format) || FORMAT;
    out.map_id = mapId;
    out.width = info?.width ?? Number(raw.width) ?? 0;
    out.height = info?.height ?? Number(raw.height) ?? 0;
    out.height_step = Number(raw.height_step) || DEFAULT_STEP;
    out.inherit_legacy = raw.inherit_legacy !== false;
    out.cells = raw.cells && typeof raw.cells === "object" ? raw.cells : {};
    out.ramps = Array.isArray(raw.ramps) ? raw.ramps : [];
    out.objects = normalizeObjects(raw.objects);
    out.definitions = normalizeSourceDefinitions(raw.definitions);
    out.instance_overrides = normalizeInstanceOverrides(raw.instance_overrides);
    out.compiled_objects = normalizeObjects(raw.compiled_objects).map((o) => ({ ...o, compiled: true }));
    out.models = normalizeModels(raw.models);
    out.model_instances = normalizeModelInstances(raw.model_instances);
    out.model_objects = normalizeObjects(raw.model_objects).map((o) => ({ ...o, compiled: true }));
    out.mesh_faces = normalizeMeshFaces(raw.mesh_faces);
    out.mesh_compiler = raw.mesh_compiler && typeof raw.mesh_compiler === "object" ? raw.mesh_compiler : out.mesh_compiler;
    compileModelObjects(out);
    out.compiler = normalizeCompilerMeta(raw.compiler, out);
    out.editor_preview = raw.editor_preview && typeof raw.editor_preview === "object"
      ? raw.editor_preview
      : out.editor_preview;
    // Keep future fields so this alpha does not destroy later metadata.
    for (const [k, v] of Object.entries(raw)) {
      if (!(k in out)) out[k] = v;
    }
  }
  return out;
}

function applyPreviewPrefsFromGeometry(geo) {
  const p = geo?.editor_preview || {};
  if (Number.isFinite(Number(p.angle))) state.preview.angle = Math.max(5, Math.min(70, Number(p.angle)));
  if (Number.isFinite(Number(p.yaw))) state.preview.yaw = ((Number(p.yaw) % 360) + 360) % 360;
  if (Number.isFinite(Number(p.zoom))) state.preview.zoom = Math.max(0.45, Math.min(2.5, Number(p.zoom)));
  if (Number.isFinite(Number(p.radius))) state.preview.radius = Math.max(5, Math.min(30, Math.round(Number(p.radius))));
  if (Number.isFinite(Number(p.focus_x))) state.preview.focusX = Number(p.focus_x);
  if (Number.isFinite(Number(p.focus_y))) state.preview.focusY = Number(p.focus_y);
  if (p.cliff_source && typeof p.cliff_source === "object") state.preview.cliffSource = p.cliff_source;
  if (p.full_map != null) state.preview.fullMap = !!p.full_map;
  if (p.show_events != null) state.preview.showEvents = !!p.show_events;
  if (p.show_tags != null) state.preview.showTags = !!p.show_tags;
}

function persistPreviewPrefs(geo) {
  if (!geo) return;
  geo.editor_preview = {
    ...(geo.editor_preview || {}),
    angle: state.preview.angle,
    yaw: state.preview.yaw,
    zoom: state.preview.zoom,
    radius: state.preview.radius,
    focus_x: state.preview.focusX,
    focus_y: state.preview.focusY,
    cliff_source: state.preview.cliffSource || null,
    full_map: !!state.preview.fullMap,
    show_events: !!state.preview.showEvents,
    show_tags: !!state.preview.showTags,
  };
}

function cellKey(x, y) {
  return `${x},${y}`;
}

function cellCacheKey(mapId, x, y) {
  return `${mapId}:${x},${y}`;
}

// Canvas pool for composeGroundSource – avoids per-cell createElement overhead.
function getCanvas(w, h) {
  const c = state.preview.canvasPool.pop() || document.createElement("canvas");
  c.width = w; c.height = h; return c;
}
function releaseCanvas(c) {
  if (state.preview.canvasPool.length < 50) state.preview.canvasPool.push(c);
}

// Incremental legacy height update: only recalculate (x,y) and its 4 neighbours.
function updateLegacyHeightForCell(ctx, mapId, x, y) {
  const info = ctx.map.info(mapId);
  if (!info) return;
  const height = state.legacyHeights.get(mapId);
  if (!height) return;
  const storedLayers = state.legacyHeightLayers?.get(mapId);
  const layers = storedLayers || visibleLayers(ctx, mapId);
  const tagAt = (tx, ty) => {
    if (tx < 0 || ty < 0 || tx >= info.width || ty >= info.height) return [];
    return mapCellTags(ctx, mapId, tx, ty, layers, mapTilesetId(info, mapId));
  };
  const hasTag = (tx, ty, tag) => tagAt(tx, ty).includes(tag);
  // Recalculate the cell and its 4 neighbours.
  const cells = [[x, y], [x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]];
  for (const [cx, cy] of cells) {
    if (cx < 0 || cy < 0 || cx >= info.width || cy >= info.height) continue;
    const key = cellKey(cx, cy);
    const ts = tagAt(cx, cy);
    let h = 0;
    if (ts.includes(TAG.VOLUME)) h = Math.max(h, runtimeConfig.volumeDefaultHeight);
    if (ts.includes(TAG.VOLUME_HIGH)) h = Math.max(h, runtimeConfig.volumeHighHeight);
    // MountainTop component: check if this cell is part of a connected top.
    if (hasTag(cx, cy, TAG.MOUNTAIN_TOP)) {
      let levels = 0;
      let wy = cy + 1;
      while (wy < info.height && (hasTag(cx, wy, TAG.MOUNTAIN_WALL) || hasTag(cx, wy, TAG.MOUNTAIN_WALL_PLANE))) {
        levels++; wy++;
      }
      levels = Math.max(1, levels);
      h = Math.max(h, levels * runtimeConfig.mountainHeight);
    }
    if (h > 0) height.set(key, h); else height.delete(key);
  }
}

// Invalidate cellEntryCache for a cell and its 4 neighbours.
function invalidateCellCache(mapId, x, y) {
  const cache = state.preview.cellEntryCache;
  if (!cache || cache.size === 0) return;
  for (const [cx, cy] of [[x, y], [x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]]) {
    cache.delete(cellCacheKey(mapId, cx, cy));
  }
}

// Trim cellEntryCache to max 5000 entries (simple FIFO eviction).
function trimCellEntryCache() {
  const cache = state.preview.cellEntryCache;
  if (cache.size <= 5000) return;
  const keys = cache.keys();
  let toDelete = cache.size - 5000;
  for (let i = 0; i < toDelete; i++) {
    const next = keys.next();
    if (next.done) break;
    cache.delete(next.value);
  }
}

function cellLevel(geo, x, y) {
  const cell = geo?.cells?.[cellKey(x, y)];
  if (cell == null) return 0;
  if (typeof cell === "number") return Number(cell) || 0;
  if (typeof cell === "object") {
    if (cell.height != null) {
      const step = Number(geo.height_step) || DEFAULT_STEP;
      return Math.round((Number(cell.height) || 0) / step);
    }
    return Number(cell.level) || 0;
  }
  return 0;
}

function cellHeight(geo, x, y) {
  return cellLevel(geo, x, y) * (Number(geo?.height_step) || DEFAULT_STEP);
}

function hasExplicitCell(geo, x, y) {
  return !!geo?.cells && Object.prototype.hasOwnProperty.call(geo.cells, cellKey(x, y));
}

function legacyHeightAt(mapId, x, y) {
  return Number(state.legacyHeights.get(mapId)?.get(cellKey(x, y))) || 0;
}

function effectiveHeight(geo, mapId, x, y) {
  if (hasExplicitCell(geo, x, y)) return cellHeight(geo, x, y);
  if (geo?.inherit_legacy !== false) return legacyHeightAt(mapId, x, y);
  return 0;
}

function effectiveLevel(geo, mapId, x, y) {
  const step = Number(geo?.height_step) || DEFAULT_STEP;
  return Math.max(0, Math.round(effectiveHeight(geo, mapId, x, y) / step));
}

function mapCellTags(ctx, mapId, x, y, layers, tilesetId) {
  const tags = [];
  for (const layer of layers) {
    const data = readTileVisualData(ctx, mapId, layer, x, y);
    const tileId = Number(data?.tileId) || 0;
    if (!tileId) continue;
    const sourceTilesetId = Number(data?.tilesetId) || Number(tilesetId) || 0;
    const tag = Number(tileProps(ctx, sourceTilesetId, tileId)?.terrainTag) || 0;
    if (tag) tags.push(tag);
  }
  return tags;
}

function rebuildLegacyHeights(ctx, mapId) {
  const info = ctx.map.info(mapId);
  if (!info) return;
  const layers = ctx.map.layers(mapId).filter((l) => l.kind !== "shadow");
  // Store layers reference for incremental updates.
  if (!state.legacyHeightLayers) state.legacyHeightLayers = new Map();
  state.legacyHeightLayers.set(mapId, layers);
  const tags = new Map();
  const height = new Map();
  const tagAt = (x, y) => {
    if (x < 0 || y < 0 || x >= info.width || y >= info.height) return [];
    const key = cellKey(x, y);
    if (!tags.has(key)) tags.set(key, mapCellTags(ctx, mapId, x, y, layers, mapTilesetId(info, mapId)));
    return tags.get(key);
  };
  const hasTag = (x, y, tag) => tagAt(x, y).includes(tag);

  // NDSVolume / NDSVolumeHigh physical fallback.
  for (let y = 0; y < info.height; y++) {
    for (let x = 0; x < info.width; x++) {
      const ts = tagAt(x, y);
      let h = 0;
      if (ts.includes(TAG.VOLUME)) h = Math.max(h, runtimeConfig.volumeDefaultHeight);
      if (ts.includes(TAG.VOLUME_HIGH)) h = Math.max(h, runtimeConfig.volumeHighHeight);
      if (h > 0) height.set(cellKey(x, y), h);
    }
  }

    // Mirror the runtime legacy mountain rule: connected MountainTop
  // cells share the maximum number of MountainWall rows on their south edge.
  const top = new Set();
  for (let y = 0; y < info.height; y++) {
    for (let x = 0; x < info.width; x++) if (hasTag(x, y, TAG.MOUNTAIN_TOP)) top.add(cellKey(x, y));
  }
  const visited = new Set();
  for (const start of top) {
    if (visited.has(start)) continue;
    const [sx, sy] = start.split(",").map(Number);
    const queue = [[sx, sy]];
    const component = [];
    visited.add(start);
    while (queue.length) {
      const [cx, cy] = queue.shift();
      component.push([cx, cy]);
      for (const [nx, ny] of [[cx-1,cy],[cx+1,cy],[cx,cy-1],[cx,cy+1]]) {
        const k = cellKey(nx, ny);
        if (!top.has(k) || visited.has(k)) continue;
        visited.add(k); queue.push([nx, ny]);
      }
    }
    const compSet = new Set(component.map(([x,y]) => cellKey(x,y)));
    let levels = 0;
    for (const [cx, cy] of component) {
      if (compSet.has(cellKey(cx, cy + 1))) continue;
      let count = 0;
      let wy = cy + 1;
      while (wy < info.height && (hasTag(cx, wy, TAG.MOUNTAIN_WALL) || hasTag(cx, wy, TAG.MOUNTAIN_WALL_PLANE))) {
        count++; wy++;
      }
      levels = Math.max(levels, count);
    }
    levels = Math.max(1, levels);
    for (const [cx, cy] of component) height.set(cellKey(cx, cy), levels * runtimeConfig.mountainHeight);
  }
  state.legacyHeights.set(mapId, height);
}

function setCellLevel(geo, x, y, level) {
  const infoWidth = Number(geo.width) || 0;
  const infoHeight = Number(geo.height) || 0;
  if (x < 0 || y < 0 || x >= infoWidth || y >= infoHeight) return;
  const key = cellKey(x, y);
  const next = Math.max(0, Math.round(Number(level) || 0));
  const old = geo.cells[key];
  if (next <= 0) {
    // Explicit zero overrides legacy height. Use the Inherit mode to remove the
    // override and return this cell to Terrain Tag fallback.
    geo.cells[key] = { level: 0 };
    return;
  }
  const material = old && typeof old === "object" ? old.material : undefined;
  geo.cells[key] = material ? { level: next, material } : { level: next };
}

async function ensureMap(ctx, mapId, forceReload = false) {
  if (mapId == null) return null;
  if (!forceReload && state.maps.has(mapId)) return state.maps.get(mapId);
  const info = ctx.map.info(mapId);
  if (!info) return null;
  const path = geometryPath(mapId);
  let geo = newGeometry(mapId, info);
  try {
    if (await ctx.fs.projectExists(path)) {
      const text = await ctx.fs.readProjectFile(path);
      geo = normalizeGeometry(mapId, info, JSON.parse(text));
    }
  } catch (err) {
    ctx.log.error(err);
    ctx.ui.showToast({ message: `2.5D Geometry: no se pudo leer ${path}`, level: "error" });
  }
  state.maps.set(mapId, geo);
  // Parse the real RPG::Map / RPG::Tileset rdata so native layers resolve the
  // same tile ids (including cross-tileset autotiles) the runtime plugin sees.
  await ensureRxTilesets(ctx, forceReload);
  await ensureRxMap(ctx, mapId, forceReload);
  await loadEmbeddedExtendedData(ctx, mapId);
  rebuildLegacyHeights(ctx, mapId);
  if (mapId === ctx.editor.activeMapId()) {
    applyPreviewPrefsFromGeometry(geo);
    ensurePreviewFocus(ctx, mapId);
    await scanGeometrySources(ctx, mapId, true);
    void ensurePreviewResources(ctx, mapId, false);
  }
  ctx.editor.requestRedraw();
  state.panelRefresh?.();
  schedulePreview(ctx);
  return geo;
}

async function saveMap(ctx, mapId, options = {}) {
  const geo = state.maps.get(mapId);
  if (!geo) return;
  if (!options.skipModelCompile) compileModelObjects(geo);
  if (!options.skipCompile && geo.compiler?.auto_compile !== false && Object.keys(geo.definitions || {}).length) {
    await compileGeometryScene(ctx, mapId, geo, { forceScan: false, reason: "save" });
  }
  const info = ctx.map.info(mapId);
  if (info) {
    geo.map_id = mapId;
    geo.width = info.width;
    geo.height = info.height;
  }
  if (mapId === ctx.editor.activeMapId()) persistPreviewPrefs(geo);
  try {
    await ctx.fs.projectMkdir("Data/VERMEIL2_5D");
  } catch (_) {
    // Existing directory is fine.
  }
  try {
    await ctx.fs.writeProjectFile(geometryPath(mapId), `${JSON.stringify(geo, null, 2)}\n`);
    ctx.editor.setStatusBarText?.(`2.5D Geometry: Map${pad3(mapId)} guardado`);
  } catch (err) {
    ctx.log.error(err);
    ctx.ui.showToast({ message: `2.5D Geometry: error al guardar Map${pad3(mapId)}`, level: "error" });
  }
}

function resolvePaintMode(ev) {
  if (ev.altKey) return "erase";
  if (ev.shiftKey) return "raise";
  if (ev.ctrlKey) return "lower";
  return state.mode;
}

function applyBrushToCell(ctx, geo, mapId, x0, y0, mode) {
  const brush = Math.max(1, Number(ctx.editor.brushSize()) || 1);
  const half = Math.floor((brush - 1) / 2);
  for (let oy = 0; oy < brush; oy++) {
    for (let ox = 0; ox < brush; ox++) {
      const x = x0 + ox - half;
      const y = y0 + oy - half;
      if (x < 0 || y < 0 || x >= geo.width || y >= geo.height) continue;
      const old = effectiveLevel(geo, mapId, x, y);
      let next = old;
      if (mode === "set") next = state.level;
      else if (mode === "raise") next = old + 1;
      else if (mode === "lower") next = Math.max(0, old - 1);
      else if (mode === "erase") next = 0;
      else if (mode === "inherit") {
        delete geo.cells[cellKey(x, y)];
        continue;
      }
      setCellLevel(geo, x, y, next);
    }
  }
}

async function paintAt(ctx, ev) {
  const geo = await ensureMap(ctx, ev.mapId);
  if (!geo) return;
  const mode = resolvePaintMode(ev);
  const strokeKey = `${ev.mapId}:${ev.tileX},${ev.tileY}:${mode}`;
  if (state.visited.has(strokeKey)) return;
  state.visited.add(strokeKey);
  applyBrushToCell(ctx, geo, ev.mapId, ev.tileX, ev.tileY, mode);
  ctx.editor.requestRedraw();
  state.panelRefresh?.();
  schedulePreview(ctx);
}

function commitObjectFromRect(ctx, geo, mapId, x0, y0, x1, y1) {
  const ax = Math.min(x0, x1), ay = Math.min(y0, y1);
  const bx = Math.max(x0, x1), by = Math.max(y0, y1);
  const w = bx - ax + 1;
  const h = by - ay + 1;
  if (ax < 0 || ay < 0 || bx >= geo.width || by >= geo.height) return null;
  const id = nextObjectId(geo);
  const obj = {
    id,
    name: `Object ${id}`,
    type: state.objType,
    x: ax, y: ay, w, h,
    height: Math.max(0, Math.round(Number(state.objHeight) || 0)),
    anchor_z: Math.max(0, Math.round(Number(state.objAnchorZ) || 0)),
    anchor_row: h - 1,
    rotation: 0,
    collision: state.objCollision,
    category: state.objCategory,
    characters_in_front: false,
    footprint: {},
  };
  if (state.objMaterial && typeof state.objMaterial === "object") obj.material = state.objMaterial;
  geo.objects.push(obj);
  state.objSelected = Number(obj.id);
  state.objStart = null;
  state.objCurrent = null;
  ctx.editor.requestRedraw();
  state.panelRefresh?.();
  schedulePreview(ctx);
  return obj;
}

function selectObject(ctx, geo, obj, mapId) {
  state.objSelected = Number(obj.id);
  state.objStart = null;
  state.objCurrent = null;
  if (mapId != null) {
    const mid = Number(obj?.material?.tileset_id);
    if (mid) void ensureSceneTilesetResources(ctx, mapId, false);
  }
  ctx.editor.requestRedraw();
  state.panelRefresh?.();
  schedulePreview(ctx);
}

function objEditChanged(ctx) {
  const id = ctx.editor.activeMapId?.();
  if (id != null) void saveMap(ctx, id);
  ctx.editor.requestRedraw();
  state.panelRefresh?.();
  schedulePreview(ctx);
}

function moveSelectedObject(ctx, dx, dy) {
  const geo = currentGeo(ctx), obj = objFieldTarget(geo);
  if (!geo || !obj) return;
  obj.x = Math.max(0, Math.min(geo.width - obj.w, obj.x + dx));
  obj.y = Math.max(0, Math.min(geo.height - obj.h, obj.y + dy));
  objEditChanged(ctx);
}

function rotateSelectedObject(ctx, clockwise = true) {
  const geo = currentGeo(ctx), obj = objFieldTarget(geo);
  if (!geo || !obj) return;
  if (clockwise) rotateFootprint90(obj);
  else { rotateFootprint90(obj); rotateFootprint90(obj); rotateFootprint90(obj); }
  obj.x = Math.max(0, Math.min(geo.width - obj.w, obj.x));
  obj.y = Math.max(0, Math.min(geo.height - obj.h, obj.y));
  objEditChanged(ctx);
}

function duplicateSelectedObject(ctx) {
  const geo = currentGeo(ctx), obj = objFieldTarget(geo);
  if (!geo || !obj) return;
  const copy = JSON.parse(JSON.stringify(obj));
  copy.id = nextObjectId(geo);
  copy.name = `${obj.name || `Object ${obj.id}`} Copy`;
  copy.x = Math.min(Math.max(0, geo.width - copy.w), obj.x + 1);
  copy.y = Math.min(Math.max(0, geo.height - copy.h), obj.y + 1);
  geo.objects.push(copy);
  state.objSelected = copy.id;
  objEditChanged(ctx);
}

function deleteSelectedObject(ctx) {
  const geo = currentGeo(ctx), obj = objFieldTarget(geo);
  if (!geo || !obj) return;
  geo.objects = geo.objects.filter((o) => Number(o.id) !== Number(obj.id));
  state.objSelected = null;
  objEditChanged(ctx);
}

function fitSelectedObjectToMaterial(ctx) {
  const geo = currentGeo(ctx), obj = objFieldTarget(geo);
  if (!geo || !obj?.material?.src_rect) return;
  const r = obj.material.src_rect;
  const w = Math.max(1, Math.round((Number(r.w) || TILE_SIZE) / TILE_SIZE));
  const h = Math.max(1, Math.round((Number(r.h) || TILE_SIZE) / TILE_SIZE));
  obj.w = Math.min(w, geo.width - obj.x);
  obj.h = Math.min(h, geo.height - obj.y);
  obj.anchor_row = Math.min(obj.h - 1, Math.max(0, obj.anchor_row ?? obj.h - 1));
  obj.footprint = normalizeFootprint(obj.footprint, obj.w, obj.h);
  objEditChanged(ctx);
}

function setFootprintCell(ctx, obj, dx, dy, mode) {
  if (!obj || dx < 0 || dy < 0 || dx >= obj.w || dy >= obj.h) return;
  obj.footprint ||= {};
  const key = `${dx},${dy}`;
  if (!mode || mode === "inherit") delete obj.footprint[key];
  else obj.footprint[key] = mode;
  objEditChanged(ctx);
}

function removeObjectsAt(ctx, geo, mapId, x, y) {
  const before = (geo.objects || []).length;
  geo.objects = (geo.objects || []).filter((o) => {
    return !objectCoversCell(o, x, y);
  });
  if (state.objSelected != null &&
      !(geo.objects || []).some((o) => Number(o.id) === Number(state.objSelected))) {
    state.objSelected = null;
  }
  if (geo.objects.length !== before) {
    ctx.editor.requestRedraw();
    state.panelRefresh?.();
    schedulePreview(ctx);
    return true;
  }
  return false;
}

async function objectEraseAt(ctx, ev) {
  const geo = await ensureMap(ctx, ev.mapId);
  if (!geo) return;
  const key = `${ev.mapId}:${ev.tileX},${ev.tileY}`;
  if (state.visited.has(key)) return;
  state.visited.add(key);
  removeObjectsAt(ctx, geo, ev.mapId, ev.tileX, ev.tileY);
  schedulePreview(ctx);
}

function levelColor(level, alpha = 0.28) {
  if (level <= 0) return "rgba(0,0,0,0)";
  const hue = (205 + level * 37) % 360;
  return `hsla(${hue}, 88%, 58%, ${alpha})`;
}

function overlayMarkerForTags(tags, explicit, level) {
  const set = new Set(tags || []);
  if (set.has(TAG.MOUNTAIN_TOP)) return { role: "mountain", text: `MT${level > 0 ? ` L${level}` : ""}`, icon: "▲" };
  if (set.has(TAG.STAIR)) return { role: "stair", text: "STAIR", icon: "↗" };
  if (set.has(TAG.STRUCTURE)) return { role: "structure", text: "STRUCT", icon: "◆" };
  if (set.has(TAG.BILLBOARD) || set.has(TAG.INDOOR_PROP)) return { role: "billboard", text: "BILL", icon: "◆" };
  if (set.has(TAG.WALL_PLANE) || set.has(TAG.MOUNTAIN_WALL_PLANE)) return { role: "wall3d", text: "WALL3D", icon: "▥" };
  if (set.has(TAG.MOUNTAIN_WALL)) return { role: "cliff", text: "CLIFF", icon: "▥" };
  if (set.has(TAG.WALL) || set.has(TAG.INDOOR_WALL)) return { role: "wall", text: "WALL", icon: "▥" };
  if (set.has(TAG.ROOF_PLANE)) return { role: "roof3d", text: "ROOF3D", icon: "▱" };
  if (set.has(TAG.ROOF) || set.has(TAG.ROOF_HIGH)) return { role: "roof", text: "ROOF", icon: "⌂" };
  if (set.has(TAG.VOLUME) || set.has(TAG.VOLUME_HIGH)) return { role: "volume", text: `VOL${level > 0 ? ` L${level}` : ""}`, icon: "▣" };
  if (set.has(TAG.OVERLAY)) return { role: "overlay", text: "OVER", icon: "◇" };
  if (explicit && level > 0) return { role: `geometry-${level}`, text: `L${level}*`, icon: "▦" };
  return null;
}


function renderOverlay(ctx, c2d, info) {
  if (!state.showOverlay) return;
  const geo = state.maps.get(info.mapId);
  if (!geo) { void ensureMap(ctx, info.mapId); return; }
  const mapInfo = ctx.map.info(info.mapId);
  if (!mapInfo) return;
  const layers = visibleLayers(ctx, info.mapId);
  const tile = info.tileSize * info.zoom;
  const minX = Math.max(0, Math.floor(info.viewportX / info.tileSize) - 1);
  const minY = Math.max(0, Math.floor(info.viewportY / info.tileSize) - 1);
  const maxX = Math.min(geo.width - 1, Math.ceil((info.viewportX + info.canvasWidth / info.zoom) / info.tileSize) + 1);
  const maxY = Math.min(geo.height - 1, Math.ceil((info.viewportY + info.canvasHeight / info.zoom) / info.tileSize) + 1);

  const refs = new Map();
  for (let y = minY; y <= maxY; y++) {
    for (let x = minX; x <= maxX; x++) {
      const legacyVisible = state.workspaceMode !== "scene";
      const level = legacyVisible ? effectiveLevel(geo, info.mapId, x, y) : 0;
      const explicit = legacyVisible && hasExplicitCell(geo, x, y);
      const tags = legacyVisible ? mapCellTags(ctx, info.mapId, x, y, layers, mapTilesetId(mapInfo, info.mapId)) : [];
      refs.set(cellKey(x, y), { x, y, level, explicit, marker: legacyVisible && state.show2DRefs ? overlayMarkerForTags(tags, explicit, level) : null });
    }
  }
  const sameRole = (a, b) => !!a?.marker && !!b?.marker && a.marker.role === b.marker.role && a.level === b.level;

  c2d.save();
  c2d.textBaseline = "middle";
  for (const ref of refs.values()) {
    const { x, y, level, explicit, marker } = ref;
    if (level <= 0 && !marker) continue;
    const px = (x * info.tileSize - info.viewportX) * info.zoom;
    const py = (y * info.tileSize - info.viewportY) * info.zoom;

    if (level > 0) {
      c2d.fillStyle = levelColor(level, explicit ? 0.17 : 0.09);
      c2d.fillRect(px, py, tile, tile);
      const left = refs.get(cellKey(x - 1, y));
      const up = refs.get(cellKey(x, y - 1));
      if (state.showLabels && tile >= 26 && (!left || left.level !== level) && (!up || up.level !== level)) {
        const label = `L${level}${explicit ? "*" : ""}`;
        const h = Math.max(11, Math.min(14, tile * 0.27));
        c2d.font = `${Math.max(8, Math.min(10, h * 0.75))}px sans-serif`;
        const w = Math.max(20, c2d.measureText(label).width + 7);
        c2d.fillStyle = "rgba(8,12,18,0.72)"; c2d.fillRect(px + 2, py + 2, w, h);
        c2d.fillStyle = "rgba(225,250,255,0.94)"; c2d.textAlign = "left"; c2d.fillText(label, px + 5, py + 2 + h / 2);
      }
    }

    if (marker) {
      const cyan = marker.role === "billboard" || marker.role === "structure";
      c2d.strokeStyle = cyan ? "rgba(80,220,255,0.62)" : "rgba(255,190,75,0.58)";
      c2d.lineWidth = Math.max(1, info.zoom * 0.8);
      c2d.strokeRect(px + 1, py + 1, Math.max(1, tile - 2), Math.max(1, tile - 2));
      if (cyan) {
        const ax = px + tile / 2, ay = py + tile - Math.max(4, tile * 0.10);
        const r = Math.max(2, Math.min(4, tile * 0.09));
        c2d.save(); c2d.translate(ax, ay); c2d.rotate(Math.PI / 4);
        c2d.fillStyle = "rgba(80,220,255,0.90)"; c2d.fillRect(-r, -r, r * 2, r * 2); c2d.restore();
      }
      const left = refs.get(cellKey(x - 1, y));
      const up = refs.get(cellKey(x, y - 1));
      if (tile >= 24 && !sameRole(ref, left) && !sameRole(ref, up)) {
        const text = marker.text;
        const h = Math.max(11, Math.min(14, tile * 0.27));
        c2d.font = `${Math.max(8, Math.min(10, h * 0.75))}px sans-serif`;
        const w = Math.min(tile * 1.45, Math.max(20, c2d.measureText(text).width + 7));
        c2d.fillStyle = "rgba(8,12,18,0.72)"; c2d.fillRect(px + 2, py + 2, w, h);
        c2d.fillStyle = "rgba(225,250,255,0.94)"; c2d.textAlign = "left"; c2d.fillText(text, px + 5, py + 2 + h / 2);
      }
    }
  }

  // Height transitions = physical collision/cliff border.
  c2d.strokeStyle = "rgba(255,74,74,0.76)";
  c2d.lineWidth = Math.max(1, 1.25 * info.zoom);
  c2d.beginPath();
  for (const ref of refs.values()) {
    const { x, y, level } = ref;
    const right = refs.get(cellKey(x + 1, y));
    const down = refs.get(cellKey(x, y + 1));
    if (right && right.level !== level) {
      const sx = ((x + 1) * info.tileSize - info.viewportX) * info.zoom;
      const sy = (y * info.tileSize - info.viewportY) * info.zoom;
      c2d.moveTo(sx, sy); c2d.lineTo(sx, sy + tile);
    }
    if (down && down.level !== level) {
      const sx = (x * info.tileSize - info.viewportX) * info.zoom;
      const sy = ((y + 1) * info.tileSize - info.viewportY) * info.zoom;
      c2d.moveTo(sx, sy); c2d.lineTo(sx + tile, sy);
    }
  }
  c2d.stroke();

  // Geometry objects (cubes/planes): footprint + collision outline.
  for (const obj of sceneObjects(geo)) {
    const r = objectRect(obj);
    if (r.x1 < minX || r.x0 > maxX || r.y1 < minY || r.y0 > maxY) continue;
    const px = (r.x0 * info.tileSize - info.viewportX) * info.zoom;
    const py = (r.y0 * info.tileSize - info.viewportY) * info.zoom;
    const w = (r.x1 - r.x0 + 1) * tile;
    const h = (r.y1 - r.y0 + 1) * tile;
    c2d.save();
    const manualSelected = state.objSelected != null && Number(obj.id) === Number(state.objSelected);
    const sourceSelected = state.workspaceMode === "scene" && !!obj.compiled &&
      state.sourceSelection?.instance_key === obj.instance_key;
    const selected = manualSelected || sourceSelected;
    for (let dy = 0; dy < obj.h; dy++) {
      for (let dx = 0; dx < obj.w; dx++) {
        const mode = footprintMode(obj, dx, dy);
        if (mode === "void") continue;
        const collision = mode === "inherit" ? obj.collision : mode;
        c2d.fillStyle = collisionColor(collision).replace(/[\d.]+\)$/, "0.10)");
        c2d.fillRect(px + dx * tile, py + dy * tile, tile, tile);
      }
    }
    // Model Workshop objects also paint a translucent version of their TOP
    // material onto Maker Studio's normal map. This keeps the model's chosen
    // cross-tileset texture visible without replacing the underlying map tile.
    if (obj.model_id) {
      const topSource = objectMaterialSource(ctx, obj, obj.face_materials?.top || obj.material || null);
      if (topSource?.img) {
        c2d.save();
        c2d.globalAlpha = 0.46;
        c2d.imageSmoothingEnabled = false;
        c2d.drawImage(topSource.img, topSource.sx, topSource.sy, topSource.sw, topSource.sh, px, py, w, h);
        c2d.restore();
      }
    }
    // Region-meshed model cells are collision proxies. Keep only their top
    // material overlay on the normal Maker Studio map; the model outline below
    // communicates the group without drawing hundreds of per-cell boxes.
    if (obj.render === false && obj.model_id) { c2d.restore(); continue; }
    c2d.strokeStyle = collisionColor(obj.collision);
    c2d.lineWidth = Math.max(1.5, 2 * info.zoom);
    c2d.strokeRect(px, py, w, h);
    // V2 elevation cue: show a lightweight pseudo-extrusion directly on the
    // normal Maker Studio map. A maker should see at a glance that H3 is not a
    // flat tile, without opening Debug or reading numeric source ids.
    const visualHeight = Number(obj.height) || 0;
    if (visualHeight > 0 && ["mountain", "wall", "border"].includes(String(obj.category || ""))) {
      const lift = Math.min(tile * 0.38, Math.max(3, visualHeight * 2.3 * info.zoom));
      c2d.save();
      c2d.strokeStyle = "rgba(90,225,255,0.66)";
      c2d.lineWidth = Math.max(1, 1.2 * info.zoom);
      c2d.strokeRect(px - lift, py - lift, w, h);
      c2d.beginPath();
      c2d.moveTo(px, py); c2d.lineTo(px - lift, py - lift);
      c2d.moveTo(px + w, py); c2d.lineTo(px + w - lift, py - lift);
      c2d.moveTo(px, py + h); c2d.lineTo(px - lift, py + h - lift);
      c2d.moveTo(px + w, py + h); c2d.lineTo(px + w - lift, py + h - lift);
      c2d.stroke();
      c2d.restore();
    }
    const anchorY = py + (Math.min(obj.h - 1, Math.max(0, Number(obj.anchor_row) || 0)) + 1) * tile;
    c2d.save();
    c2d.setLineDash([3, 3]);
    c2d.strokeStyle = "rgba(255,210,80,0.9)";
    c2d.beginPath(); c2d.moveTo(px, anchorY); c2d.lineTo(px + w, anchorY); c2d.stroke();
    c2d.restore();
    if (selected) {
      c2d.setLineDash([6, 3]);
      c2d.strokeStyle = "rgba(80,220,255,0.95)";
      c2d.lineWidth = Math.max(2, 3 * info.zoom);
      c2d.strokeRect(px - 1, py - 1, w + 2, h + 2);
      c2d.setLineDash([]);
    }
    const label = obj.compiled
      ? `${selected ? "▸ " : ""}${simplePresetLabel(obj.category)} · ${Number(obj.height) || 0} tiles`
      : `${selected ? "▸ " : ""}${obj.name || `#${obj.id}`} · ${obj.type.toUpperCase()} · H${obj.height}`;
    if (tile >= 22 && (!obj.compiled || selected)) {
      c2d.font = `${Math.max(8, Math.min(10, tile * 0.30))}px sans-serif`;
      c2d.fillStyle = "rgba(8,12,18,0.75)";
      const lw = Math.min(w - 2, Math.max(20, c2d.measureText(label).width + 7));
      c2d.fillRect(px + 2, py + 2, lw, 14);
      c2d.fillStyle = "rgba(235,225,255,0.96)";
      c2d.textAlign = "left";
      c2d.fillText(label, px + 5, py + 9);
    }
    c2d.restore();
  }


  // Model Workshop instances: one readable outline per reusable model, on top of
  // the per-cell compiled geometry. This is what makes the normal Maker Studio
  // map itself reflect the model's shape/height instead of requiring preview.
  for (const inst of geo.model_instances || []) {
    const model = geo.models?.[inst.model_id]; if (!model) continue;
    const worldCells=[...expandedModelCells(inst,model).values()]; if(!worldCells.length)continue;
    const x0=Math.min(...worldCells.map(c=>c.x)),y0=Math.min(...worldCells.map(c=>c.y)),x1=Math.max(...worldCells.map(c=>c.x))+1,y1=Math.max(...worldCells.map(c=>c.y))+1;
    if(x1<minX||x0>maxX||y1<minY||y0>maxY)continue;
    const px=(x0*info.tileSize-info.viewportX)*info.zoom,py=(y0*info.tileSize-info.viewportY)*info.zoom,w=(x1-x0)*tile,h=(y1-y0)*tile;
    c2d.save();c2d.setLineDash([7,3]);c2d.strokeStyle='rgba(120,245,170,.95)';c2d.lineWidth=Math.max(2,2.5*info.zoom);c2d.strokeRect(px,py,w,h);c2d.setLineDash([]);
    if(tile>=20){c2d.font=`${Math.max(9,Math.min(11,tile*.32))}px sans-serif`;const txt=`▣ ${model.name}`;const lw=Math.min(w,Math.max(40,c2d.measureText(txt).width+8));c2d.fillStyle='rgba(8,18,14,.82)';c2d.fillRect(px+2,py+2,lw,15);c2d.fillStyle='rgba(165,255,205,.98)';c2d.textAlign='left';c2d.fillText(txt,px+5,py+10);}
    c2d.restore();
  }

  // Scene source selection must remain visible even before the user assigns a
  // definition (there may be no compiled object to outline yet).
  if (state.workspaceMode === "scene" && state.sourceSelection && Number(state.sourceSelection.map_id) === Number(info.mapId)) {
    const sx = Number(state.sourceSelection.x), sy = Number(state.sourceSelection.y);
    if (sx >= minX && sx <= maxX && sy >= minY && sy <= maxY) {
      const px = (sx * info.tileSize - info.viewportX) * info.zoom;
      const py = (sy * info.tileSize - info.viewportY) * info.zoom;
      c2d.save();
      c2d.setLineDash([5, 3]);
      c2d.strokeStyle = "rgba(80,220,255,0.98)";
      c2d.lineWidth = Math.max(2, 3 * info.zoom);
      c2d.strokeRect(px + 1, py + 1, Math.max(2, tile - 2), Math.max(2, tile - 2));
      c2d.setLineDash([]);
      if (tile >= 24) {
        const geoDef = geo.definitions?.[state.sourceSelection.key];
        const geoRule = geoDef ? effectiveSourceRule(geoDef, geo.instance_overrides?.[state.sourceSelection.instance_key]) : null;
        const txt = geoRule && geoRule.enabled !== false ? `${simplePresetLabel(geoRule.category)} · H${Number(geoRule.height) || 0}` : "Seleccionado";
        c2d.font = `${Math.max(8, Math.min(10, tile * 0.30))}px sans-serif`;
        const lw = Math.min(tile * 2.2, c2d.measureText(txt).width + 8);
        c2d.fillStyle = "rgba(8,12,18,0.82)"; c2d.fillRect(px + 2, py + tile - 15, lw, 13);
        c2d.fillStyle = "rgba(150,245,255,0.98)"; c2d.textAlign = "left"; c2d.fillText(txt, px + 5, py + tile - 8);
      }
      c2d.restore();
    }
  }

  // Object placement draft rectangle.
  if (state.objTool && state.objStart && state.objCurrent) {
    const ax = Math.min(state.objStart.x, state.objCurrent.x);
    const ay = Math.min(state.objStart.y, state.objCurrent.y);
    const bx = Math.max(state.objStart.x, state.objCurrent.x);
    const by = Math.max(state.objStart.y, state.objCurrent.y);
    const px = (ax * info.tileSize - info.viewportX) * info.zoom;
    const py = (ay * info.tileSize - info.viewportY) * info.zoom;
    const w = (bx - ax + 1) * tile;
    const h = (by - ay + 1) * tile;
    c2d.save();
    c2d.setLineDash([6, 4]);
    c2d.strokeStyle = "rgba(235,235,120,0.95)";
    c2d.lineWidth = Math.max(1.5, 2 * info.zoom);
    c2d.strokeRect(px, py, w, h);
    c2d.restore();
  }
  c2d.restore();
}


// -----------------------------------------------------------------------------
// 2.5D preview renderer
// -----------------------------------------------------------------------------

function ensurePreviewFocus(ctx, mapId) {
  const info = ctx.map.info(mapId);
  if (!info) return;
  if (!Number.isFinite(state.preview.focusX)) state.preview.focusX = Math.floor(info.width / 2);
  if (!Number.isFinite(state.preview.focusY)) state.preview.focusY = Math.floor(info.height / 2);
  state.preview.focusX = Math.max(0, Math.min(info.width - 1, Math.round(state.preview.focusX)));
  state.preview.focusY = Math.max(0, Math.min(info.height - 1, Math.round(state.preview.focusY)));
}

function disposeAutotileUrls() {
  for (const url of state.preview.autotileUrls) {
    try { URL.revokeObjectURL(url); } catch (_) {}
  }
  for (const url of state.preview.characterUrls || []) {
    try { URL.revokeObjectURL(url); } catch (_) {}
  }
  state.preview.autotileUrls = [];
  state.preview.autotileImages = [];
  state.preview.autotileImagesByTileset.clear();
  state.preview.autotileImagesByName.clear();
  state.preview.tilesetImages.clear();
  state.preview.tilesetImage = null;
  state.preview.autotileCache.clear();
  state.preview.transformedSourceCache.clear();
  state.preview.characterUrls = [];
  state.preview.characterImages.clear();
}

function loadImage(url) {
  return new Promise((resolve) => {
    if (!url) { resolve(null); return; }
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = url;
  });
}

function mimeForName(name) {
  const lower = String(name || "").toLowerCase();
  if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
  if (lower.endsWith(".webp")) return "image/webp";
  if (lower.endsWith(".gif")) return "image/gif";
  if (lower.endsWith(".bmp")) return "image/bmp";
  return "image/png";
}

async function imageFromBytes(bytes, mime = "image/png", urlBucket = state.preview.autotileUrls) {
  if (!bytes || !bytes.length) return null;
  const blob = new Blob([new Uint8Array(bytes)], { type: mime });
  const url = URL.createObjectURL(blob);
  urlBucket.push(url);
  return await loadImage(url);
}

function autotileCacheName(name) {
  return String(name || "").replace(/\.[^.]+$/, "").trim().toLowerCase();
}

function firstDefined(...values) {
  for (const value of values) if (value !== undefined && value !== null) return value;
  return undefined;
}

function layerRef(layer) {
  return firstDefined(layer?.index, layer?.id, layer);
}

function layerSortValue(layer) {
  return Number(firstDefined(layer?.index, layer?.order, layer?.z, layer?.id, 0)) || 0;
}

function normalizedTileData(raw, fallbackTileId = 0, layer = null) {
  const out = raw && typeof raw === "object" ? { ...raw } : {};
  const tileId = Number(firstDefined(out.tileId, out.tile_id, fallbackTileId)) || 0;
  const tilesetId = Number(firstDefined(
    out.tilesetId, out.tileset_id, out.sourceTilesetId, out.source_tileset_id,
    layer?.tilesetId, layer?.tileset_id, layer?.sourceTilesetId, layer?.source_tileset_id
  )) || 0;
  const autotileName = String(firstDefined(out.autotileName, out.autotile_name, "")).trim();
  const autotilePattern = firstDefined(out.autotilePattern, out.autotile_pattern);
  const terrainTag = firstDefined(out.terrainTag, out.terrain_tag);

  out.tileId = tileId;
  if (tilesetId) out.tilesetId = tilesetId;
  if (autotileName) out.autotileName = autotileName;
  if (autotilePattern !== undefined) out.autotilePattern = Number(autotilePattern) || 0;
  if (terrainTag !== undefined) out.terrainTag = Number(terrainTag) || 0;
  out.flipH = !!firstDefined(out.flipH, out.flip_h, false);
  out.flipV = !!firstDefined(out.flipV, out.flip_v, false);
  return out;
}

async function loadAutotileByName(ctx, rawName) {
  const name = String(rawName || "").replace(/\.[^.]+$/, "").trim();
  if (!name) return null;
  const key = autotileCacheName(name);
  if (state.preview.autotileImagesByName.has(key)) return state.preview.autotileImagesByName.get(key);
  // Mark as pending so repeated scans don't issue duplicate backend reads.
  state.preview.autotileImagesByName.set(key, null);
  const root = ctx.editor.gameRoot?.();
  const invoke = window.__TAURI__?.core?.invoke;
  if (!root || !invoke) return null;
  try {
    const bytes = await invoke("get_graphic_image", { gameRoot: root, folder: "Autotiles", name });
    const img = await imageFromBytes(bytes, "image/png");
    state.preview.autotileImagesByName.set(key, img || null);
    return img || null;
  } catch (err) {
    // Case/extension-safe fallback through the public general file commands.
    try {
      const files = await invoke("list_autotile_files", { gameRoot: root });
      const wanted = key;
      const hit = (files || []).find((f) => autotileCacheName(f) === wanted);
      if (hit) {
        const imgName = String(hit).replace(/\.[^.]+$/, "");
        const bytes = await invoke("get_graphic_image", { gameRoot: root, folder: "Autotiles", name: imgName });
        const img = await imageFromBytes(bytes, "image/png");
        state.preview.autotileImagesByName.set(key, img || null);
        return img || null;
      }
    } catch (_) {}
    ctx.log.warn(`2.5D Geometry: autotile '${name}' unavailable`, err);
    state.preview.autotileImagesByName.set(key, null);
    return null;
  }
}

async function loadAutotilesViaTauri(ctx, names) {
  if (!Array.isArray(names)) return [];
  const out = [];
  for (const rawName of names.slice(0, 7)) {
    const name = String(rawName || "").replace(/\.[^.]+$/, "").trim();
    if (!name) { out.push(null); continue; }
    out.push(await loadAutotileByName(ctx, name));
  }
  return out;
}

async function loadTilesetFallback(ctx, tilesetId) {
  const root = ctx.editor.gameRoot?.();
  const invoke = window.__TAURI__?.core?.invoke;
  const ts = tilesetInfo(ctx, tilesetId) || null;
  let tilesetName = tilesetGraphicName(ts);
  // Editor may not report the cross-tileset this map references (e.g. tileset 5
  // used only by MapXXX while 1 is open). Read the name straight from Tilesets.rxdata.
  if (!tilesetName) tilesetName = state.preview.rxTilesets?.[Number(tilesetId)]?.tilesetName || "";
  if (!root || !invoke || !tilesetName) return null;
  try {
    const bytes = await invoke("get_tileset_image", { gameRoot: root, tilesetName });
    return await imageFromBytes(bytes, "image/png");
  } catch (_) {}
  try {
    const bytes = await invoke("get_graphic_image", { gameRoot: root, folder: "Tilesets", name: tilesetName });
    return await imageFromBytes(bytes, "image/png");
  } catch (_) {}
  return null;
}

async function loadCharacterImage(ctx, name) {
  name = String(name || "");
  if (!name) return null;
  if (state.preview.characterImages.has(name)) return state.preview.characterImages.get(name);
  state.preview.characterImages.set(name, null); // prevent duplicate loads
  const root = ctx.editor.gameRoot?.();
  const invoke = window.__TAURI__?.core?.invoke;
  if (!root || !invoke) return null;
  try {
    const bytes = await invoke("get_graphic_image", { gameRoot: root, folder: "Characters", name });
    const img = await imageFromBytes(bytes, "image/png", state.preview.characterUrls);
    state.preview.characterImages.set(name, img);
    schedulePreview(ctx);
    return img;
  } catch (_) {
    return null;
  }
}

async function preloadEventGraphics(ctx, mapId) {
  if (!state.preview.showEvents || !ctx.events?.list || !ctx.events?.getFull) return;
  const events = ctx.events.list(mapId) || [];
  const jobs = [];
  for (const ev of events) {
    try {
      const full = ctx.events.getFull(mapId, ev.id);
      const page = full?.pages?.[0];
      const name = page?.graphic?.character_name;
      if (name && !state.preview.characterImages.has(name)) jobs.push(loadCharacterImage(ctx, name));
    } catch (_) {}
  }
  if (jobs.length) await Promise.allSettled(jobs);
}

async function ensureTilesetResourceSet(ctx, tilesetId) {
  tilesetId = Number(tilesetId) || 0;
  if (!tilesetId) return null;
  if (state.preview.tilesetImages.has(tilesetId)) {
    return {
      image: state.preview.tilesetImages.get(tilesetId),
      autotiles: state.preview.autotileImagesByTileset.get(tilesetId) || [],
    };
  }
  if (state.preview.tilesetLoading.has(tilesetId)) return state.preview.tilesetLoading.get(tilesetId);

  const job = (async () => {
  // Source of truth: the editor tileset API. Maker Studio can paint cross-tileset
  // tiles on extended layers, so load by source tileset id, not the open palette.
  let image = null;
  try {
    const url = await ctx.tileset.getImageBlobUrl?.(tilesetId);
    if (url) image = await loadImage(url);
  } catch (err) {
    ctx.log.warn(`2.5D Geometry: getImageBlobUrl failed for tileset ${tilesetId}`, err);
  }
  if (!image) {
    image = await loadTilesetFallback(ctx, tilesetId);
  }
  if (!image) {
    const ts = tilesetInfo(ctx, tilesetId);
    ctx.log.warn(`2.5D Geometry: tileset ${tilesetId} unavailable (${tilesetGraphicName(ts) || ts?.name || "sin nombre"})`);
  }

  let autotiles = [];
  try {
    const ts = tilesetInfo(ctx, tilesetId);
    let names = firstDefined(ts?.autotileNames, ts?.autotile_names, ts?.autotiles, []);
    if (!names?.length) names = state.preview.rxTilesets?.[tilesetId]?.autotileNames || [];
    autotiles = await loadAutotilesViaTauri(ctx, names);
  } catch (err) {
    ctx.log.warn(`2.5D Geometry: autotiles ${tilesetId} unavailable`, err);
  }
  state.preview.tilesetImages.set(tilesetId, image || null);
  state.preview.autotileImagesByTileset.set(tilesetId, autotiles || []);
  return { image, autotiles };
  })();
  state.preview.tilesetLoading.set(tilesetId, job);
  try { return await job; }
  finally { state.preview.tilesetLoading.delete(tilesetId); }
}

function previewBounds(ctx, mapId) {
  const info = ctx.map.info(mapId);
  if (!info) return null;
  const fx = Math.round(state.preview.focusX ?? info.width / 2);
  const fy = Math.round(state.preview.focusY ?? info.height / 2);
  const radius = state.preview.radius;
  return {
    minX: state.preview.fullMap ? 0 : Math.max(0, fx - radius),
    maxX: state.preview.fullMap ? info.width - 1 : Math.min(info.width - 1, fx + radius),
    minY: state.preview.fullMap ? 0 : Math.max(0, fy - radius),
    maxY: state.preview.fullMap ? info.height - 1 : Math.min(info.height - 1, fy + radius),
  };
}

async function scanMapUsedAssets(ctx, mapId, force = false) {
  const info = ctx.map.info(mapId);
  if (!info) return { tilesetIds: new Set(), extraAutotiles: new Set() };
  if (!force && state.preview.usedAssetsByMap.has(mapId)) return state.preview.usedAssetsByMap.get(mapId);

  const result = {
    tilesetIds: new Set([mapTilesetId(info, mapId)]),
    extraAutotiles: new Set(),
  };
  const layers = visibleLayers(ctx, mapId);

  // Cross-tileset source information lives on each extended tile. Native layers
  // still use the map tileset, but may contain extra autotiles, so scan both.
  for (let y = 0; y < info.height; y++) {
    for (let x = 0; x < info.width; x++) {
      for (const layer of layers) {
        const data = readTileVisualData(ctx, mapId, layer, x, y);
        if (!data) continue;
        const sourceId = Number(data.tilesetId) || 0;
        if (sourceId) result.tilesetIds.add(sourceId);
        const extra = String(data.autotileName || "").trim();
        if (extra) result.extraAutotiles.add(extra);
      }
    }
  }
  result.tilesetIds.delete(0);
  state.preview.usedAssetsByMap.set(mapId, result);
  return result;
}

async function ensureSceneTilesetResources(ctx, mapId, force = false) {
  const info = ctx.map.info(mapId);
  const bounds = previewBounds(ctx, mapId);
  if (!info || !bounds) return;

  // Load every source tileset actually referenced anywhere in the map. This is
  // what makes a tile painted from another Maker Studio palette render with its
  // own atlas instead of the map's native tileset.
  const used = await scanMapUsedAssets(ctx, mapId, force);
  const ids = new Set(used.tilesetIds || []);
  const extraAutotiles = new Set(used.extraAutotiles || []);

  // Small local safety pass: catches an edit immediately before the global asset
  // inventory is invalidated/rebuilt.
  const layers = visibleLayers(ctx, mapId);
  for (let y = bounds.minY; y <= bounds.maxY; y++) {
    for (let x = bounds.minX; x <= bounds.maxX; x++) {
      for (const layer of layers) {
        const data = readTileVisualData(ctx, mapId, layer, x, y);
        if (!data) continue;
        const sourceId = Number(data.tilesetId) || mapTilesetId(info, mapId);
        if (sourceId) ids.add(sourceId);
        const extra = String(data.autotileName || "").trim();
        if (extra) extraAutotiles.add(extra);
      }
    }
  }

  await Promise.allSettled([...ids].map((id) => ensureTilesetResourceSet(ctx, id)));
  if (extraAutotiles.size) await Promise.allSettled([...extraAutotiles].map((name) => loadAutotileByName(ctx, name)));
  // Object material textures may reference tilesets that are not painted on the map.
  const geo = state.maps.get(mapId);
  for (const obj of sceneObjects(geo)) {
    const mats=[obj?.material,...Object.values(obj?.face_materials||{})].filter(Boolean);
    for(const mat of mats){
      const mid=Number(mat?.tileset_id);
      if(mid&&!ids.has(mid)){ids.add(mid);await ensureTilesetResourceSet(ctx,mid);}
    }
  }
  const active = state.preview.tilesetImages.get(mapTilesetId(info, mapId));
  if (active !== undefined) state.preview.tilesetImage = active;
  state.preview.autotileImages = state.preview.autotileImagesByTileset.get(mapTilesetId(info, mapId)) || [];
  state.preview.assetStats.usedTilesets = ids.size;
  state.preview.assetStats.usedTilesetIds = [...ids].sort((a, b) => Number(a) - Number(b)).join(",");
}

async function ensureVisiblePreviewResources(ctx, mapId) {
  const info = ctx.map.info(mapId);
  const bounds = previewBounds(ctx, mapId);
  if (!info || !bounds) return;
  const ids = new Set([mapTilesetId(info, mapId)]);
  const extras = new Set();
  const layers = visibleLayers(ctx, mapId);
  for (let y = bounds.minY; y <= bounds.maxY; y++) {
    for (let x = bounds.minX; x <= bounds.maxX; x++) {
      for (const layer of layers) {
        const data = readTileVisualData(ctx, mapId, layer, x, y);
        if (!data) continue;
        const sid = Number(data.tilesetId) || (layer?.kind === "native" ? mapTilesetId(info, mapId) : 0);
        if (sid) ids.add(sid);
        const extra = String(data.autotileName || "").trim();
        if (extra) extras.add(extra);
      }
    }
  }
  const geo = state.maps.get(mapId);
  for (const obj of sceneObjects(geo)) {
    for (const mat of [obj?.material, ...Object.values(obj?.face_materials || {})].filter(Boolean)) {
      const sid = Number(mat?.tileset_id) || 0;
      if (sid) ids.add(sid);
    }
  }
  ids.delete(0);
  await Promise.allSettled([...ids].map(id => ensureTilesetResourceSet(ctx, id)));
  if (extras.size) await Promise.allSettled([...extras].map(name => loadAutotileByName(ctx, name)));
  state.preview.assetStats.usedTilesets = ids.size;
  state.preview.assetStats.usedTilesetIds = [...ids].sort((a,b)=>a-b).join(",");
}

async function ensureChangedCellResources(ctx, mapId, x, y, preferredLayer = null) {
  const info = ctx.map.info(mapId);
  if (!info) return;
  const layers = authoritativeLayers(ctx, mapId, false);
  const ordered = [...layers].sort((a,b)=>layerSortValue(b)-layerSortValue(a));
  if (preferredLayer != null) {
    const idx = ordered.findIndex(l => Number(layerRef(l)) === Number(preferredLayer));
    if (idx > 0) ordered.unshift(...ordered.splice(idx, 1));
  }
  const jobs = [];
  for (const layer of ordered) {
    const data = readTileVisualData(ctx, mapId, layer, x, y);
    if (!data) continue;
    const sid = Number(data.tilesetId) || (layer?.kind === "native" ? mapTilesetId(info, mapId) : 0);
    if (sid && !state.preview.tilesetImages.has(sid)) jobs.push(ensureTilesetResourceSet(ctx, sid));
    const extra = String(data.autotileName || "").trim();
    if (extra && !state.preview.autotileImagesByName.has(extra.toLowerCase())) jobs.push(loadAutotileByName(ctx, extra));
  }
  if (jobs.length) await Promise.allSettled(jobs);
}

function scheduleBackgroundMapRefresh(ctx, mapId, delay = 420) {
  clearTimeout(state.sourceRefreshTimer);
  state.sourceRefreshTimer = setTimeout(async () => {
    state.sourceRefreshTimer = 0;
    if (!state.maps.has(mapId)) return;
    try {
      await scanGeometrySources(ctx, mapId, true);
      await ensureVisiblePreviewResources(ctx, mapId);
      schedulePreview(ctx);
      schedulePanelRefresh();
    } catch (err) { ctx.log.warn("2.5D Geometry: background map refresh failed", err); }
  }, delay);
}

async function ensurePreviewResources(ctx, mapId, force = false) {
  const info = ctx.map.info(mapId);
  if (!info) return;
  if (force) {
    state.preview.tileProps.clear();
    state.preview.autotileCache.clear();
    state.preview.transformedSourceCache.clear();
    state.preview.usedAssetsByMap.delete(mapId);
    state.preview.cellEntryCache.clear();
    state.preview.extendedDataByMap.delete(mapId);
    state.preview.rxMaps.delete(mapId);
    disposeAutotileUrls();
  }
  await ensureRxTilesets(ctx);
  await ensureRxMap(ctx, mapId);
  await loadEmbeddedExtendedData(ctx, mapId);
  const tilesetId = mapTilesetId(info, mapId);
  state.preview.tilesetId = tilesetId;
  await ensureTilesetResourceSet(ctx, tilesetId);
  state.preview.tilesetImage = state.preview.tilesetImages.get(tilesetId) || null;
  state.preview.autotileImages = state.preview.autotileImagesByTileset.get(tilesetId) || [];
  await ensureSceneTilesetResources(ctx, mapId, force);
  if (state.preview.showEvents) void preloadEventGraphics(ctx, mapId);
  schedulePreview(ctx);
}

function tileProps(ctx, tilesetId, tileId) {
  const key = `${tilesetId}:${tileId}`;
  if (state.preview.tileProps.has(key)) return state.preview.tileProps.get(key);
  let value = null;
  try { value = ctx.tileset.resolveTileProperties?.(tileId, tilesetId) || null; } catch (_) {}
  if (!value) { try { value = ctx.tileset.getTileProperties(tilesetId, tileId); } catch (_) {} }
  value ||= rxTilesetProps(ctx, tilesetId, tileId);
  value ||= { passage: 0, priority: 0, terrainTag: 0 };
  state.preview.tileProps.set(key, value);
  return value;
}

// Fallback tile properties straight from RPG::Tileset (terrain_tags/passages/
// priorities). Used when the editor cannot resolve a cross-tileset tile id.
function rxTilesetProps(ctx, tilesetId, tileId) {
  const ts = state.preview.rxTilesets?.[Number(tilesetId) || 0];
  if (!ts) return null;
  tileId = Number(tileId) || 0;
  if (tileId >= 384) {
    const index = tileId - 384;
    const tx = index % 8;
    const ty = Math.floor(index / 8);
    return {
      passage: Number(ts.passages?.get(tx, ty)) || 0,
      priority: Number(ts.priorities?.get(tx, ty)) || 0,
      terrainTag: Number(ts.terrainTags?.get(tx, ty)) || 0,
    };
  }
  return { passage: 0, priority: 0, terrainTag: 0 };
}

function autotileCanvasFromImage(img, pattern, keyPrefix) {
  if (!img) return null;
  pattern = Math.max(0, Math.min(47, Number(pattern) || 0));
  const key = `${keyPrefix}:${pattern}`;
  if (state.preview.autotileCache.has(key)) return state.preview.autotileCache.get(key);
  const parts = AUTOTILE_PARTS[pattern] || AUTOTILE_PARTS[0];
  const canvas = document.createElement("canvas");
  canvas.width = 32;
  canvas.height = 32;
  const c = canvas.getContext("2d");
  c.imageSmoothingEnabled = false;
  // RMXP autotiles are 96x128 per animation frame. Use the first frame for the
  // geometry preview; the editor's animation counter can be wired later.
  for (let i = 0; i < 4; i++) {
    const part = parts[i];
    const sx = (part % 6) * 16;
    const sy = Math.floor(part / 6) * 16;
    const dx = (i % 2) * 16;
    const dy = Math.floor(i / 2) * 16;
    c.drawImage(img, sx, sy, 16, 16, dx, dy, 16, 16);
  }
  state.preview.autotileCache.set(key, canvas);
  return canvas;
}

function autotileCanvas(tilesetId, index, pattern) {
  const images = state.preview.autotileImagesByTileset.get(Number(tilesetId)) || [];
  return autotileCanvasFromImage(images[index], pattern, `std:${tilesetId}:${index}`);
}

function extraAutotileCanvas(name, pattern) {
  const key = autotileCacheName(name);
  const img = state.preview.autotileImagesByName.get(key) || null;
  return autotileCanvasFromImage(img, pattern, `extra:${key}`);
}

function sourceForTile(tileId, tilesetId = state.preview.tilesetId) {
  const id = Number(tileId) || 0;
  const tsId = Number(tilesetId) || Number(state.preview.tilesetId) || 0;
  if (id <= 0 || !tsId) return null;
  if (id >= 384) {
    const img = state.preview.tilesetImages.get(tsId) || (tsId === Number(state.preview.tilesetId) ? state.preview.tilesetImage : null);
    if (!img) return null;
    const index = id - 384;
    return {
      img,
      sx: (index % 8) * 32,
      sy: Math.floor(index / 8) * 32,
      sw: 32,
      sh: 32,
    };
  }
  if (id >= 48 && id < 384) {
    const autotileIndex = Math.floor(id / 48) - 1;
    const pattern = id % 48;
    const img = autotileCanvas(tsId, autotileIndex, pattern);
    if (!img) return null;
    return { img, sx: 0, sy: 0, sw: 32, sh: 32 };
  }
  return null;
}



function embeddedTileVisualData(ctx, mapId, layer, x, y) {
  const ext = mapExtendedData(ctx, mapId);
  if (!ext) return null;
  const ref = Number(layerRef(layer));
  const key = cellKey(x,y);
  if (layer?.kind === "extended" || ref >= 3) {
    const row = (ext.layers || []).find(l => Number(firstDefined(l?.id,l?.index)) === ref);
    const td = row?.tiles?.[key];
    return td && typeof td === "object" ? td : null;
  }
  const np = ext.nativeProperties || ext.native_properties;
  const td = np?.[ref]?.[key] || np?.[String(ref)]?.[key];
  return td && typeof td === "object" ? td : null;
}

function readTileVisualData(ctx, mapId, layer, x, y) {
  const ref = Number(layerRef(layer));
  const xyKey = cellKey(x, y);

  // V2 SOURCE RESOLVER RULE:
  // Extended layers are authoritative through map.readTileData().  Maker Studio
  // stores the real cross-tileset source in PublicTileData.tilesetId there.
  // The old editor sometimes consumed layer.tiles first; those cached rows can
  // contain tileId without tilesetId, which made the preview sample the same atlas
  // position from the map's default tileset.  Always read the public API and let
  // it win over internal/cached layer data.
  let cachedRaw = null;
  if (layer?.tiles && typeof layer.tiles === "object") {
    cachedRaw = firstDefined(layer.tiles[xyKey], layer.tiles[y * (ctx.map.info(mapId)?.width || 0) + x]);
  }
  let apiRaw = null;
  try { apiRaw = ctx.map.readTileData?.(mapId, ref, x, y) || null; } catch (_) {}
  // The embedded @extended_layers JSON is the exact data used by MakerStudio's
  // in-game renderer. Merge it as a second authoritative source so the preview
  // still gets tileset_id when a Studio build returns a reduced PublicTileData.
  const embeddedRaw = embeddedTileVisualData(ctx, mapId, layer, x, y);

  const isExtended = layer?.kind === "extended" || ref >= 3;
  let raw = null;
  if (isExtended) {
    raw = {};
    if (cachedRaw && typeof cachedRaw === "object") Object.assign(raw, cachedRaw);
    if (embeddedRaw && typeof embeddedRaw === "object") Object.assign(raw, embeddedRaw);
    if (apiRaw && typeof apiRaw === "object") Object.assign(raw, apiRaw);
    if (!Object.keys(raw).length) raw = null;
  } else {
    raw = {};
    if (embeddedRaw && typeof embeddedRaw === "object") Object.assign(raw, embeddedRaw);
    if (cachedRaw && typeof cachedRaw === "object") Object.assign(raw, cachedRaw);
    if (apiRaw && typeof apiRaw === "object") Object.assign(raw, apiRaw);
    if (!Object.keys(raw).length) raw = null;
  }

  let data = normalizedTileData(raw, 0, layer);
  let tileId = Number(data?.tileId) || 0;
  if (!tileId) {
    try { tileId = Number(ctx.map.readTile(mapId, ref, x, y)) || 0; } catch (_) {}
    data = normalizedTileData(raw, tileId, layer);
  }
  if (layer.kind === "native") {
    // Source of truth for the base RMB/RMXP tile id is the raw RPG::Map table;
    // the editor API can report 0 or remapped ids for cross-tileset builds.
    const rxMapRow = mapId != null ? state.preview.rxMaps.get(mapId) : null;
    if (rxMapRow?.data) {
      let rxTile = 0;
      try { rxTile = Number(rxMapRow.data.get(x, y, ref)) || 0; } catch (_) {}
      if (rxTile) {
        tileId = rxTile;
        // Force the raw table value over whatever the editor reported; native
        // tiles must match the in-game RPG::Map table exactly.
        data = normalizedTileData({ ...(data || {}), tileId: rxTile }, rxTile, layer);
      }
    }
    let native = null;
    const extData = mapExtendedData(ctx, mapId);
    const nativeProps = extData?.nativeProperties;
    if (nativeProps) native = nativeProps[ref]?.[xyKey] || nativeProps[String(ref)]?.[xyKey] || null;
    let apiNative = null;
    try { apiNative = ctx.map.getNativeTileProperties?.(mapId, ref, x, y) || null; } catch (_) {}
    data = normalizedTileData({ ...(native || {}), ...(apiNative || {}), ...(data || {}) }, tileId, layer);
  } else {
    data = normalizedTileData(data, tileId, layer);
  }
  // Maker Studio extra autotiles can live on native/extended layers with an
  // autotileName even when the normal RMXP tile id is 0/reserved. Do not drop
  // those cells before the preview has a chance to resolve their graphic.
  if (!tileId && !String(data?.autotileName || "").trim()) return null;
  return data;
}


function detectColorModel(ctx) {
  if (state.preview.colorModel && state.preview.colorModel !== "auto") return state.preview.colorModel;
  try {
    const brush = ctx?.editor?.brushTileProperties?.() || {};
    const sat = Number(brush.saturation);
    const light = Number(brush.lighting);
    // Maker Studio builds that expose colour controls as deltas use 0 as the
    // neutral point. Older/alternate builds can expose percentages (100 neutral).
    if (Number.isFinite(sat) && Number.isFinite(light)) {
      if (Math.abs(sat) <= 1 && Math.abs(light) <= 1) return "delta";
      if (sat >= 50 || light >= 50) return "percent";
    }
  } catch (_) {}
  return "delta";
}

function normalizedColorProps(ctx, data) {
  if (state.preview.ignoreColorTransforms) return { hue: 0, saturation: 100, lighting: 100 };
  const model = detectColorModel(ctx);
  const hue = Number(data?.hue) || 0;
  const rawSat = data?.saturation == null ? (model === "delta" ? 0 : 100) : Number(data.saturation);
  const rawLight = data?.lighting == null ? (model === "delta" ? 0 : 100) : Number(data.lighting);
  if (model === "delta") {
    return {
      hue,
      saturation: Math.max(0, Math.min(300, 100 + (Number.isFinite(rawSat) ? rawSat : 0))),
      lighting: Math.max(5, Math.min(300, 100 + (Number.isFinite(rawLight) ? rawLight : 0))),
    };
  }
  return {
    hue,
    saturation: Math.max(0, Math.min(300, Number.isFinite(rawSat) ? rawSat : 100)),
    lighting: Math.max(5, Math.min(300, Number.isFinite(rawLight) ? rawLight : 100)),
  };
}

function transformedSource(ctx, source, data, cacheKey) {
  if (!source) return null;
  const rotation = ((Number(data?.rotation) || 0) % 360 + 360) % 360;
  const flipH = !!data?.flipH;
  const flipV = !!data?.flipV;
  const color = normalizedColorProps(ctx, data);
  const hue = color.hue;
  const saturation = color.saturation;
  const lighting = color.lighting;
  if (!rotation && !flipH && !flipV && !hue && saturation === 100 && lighting === 100) return source;
  const key = `${cacheKey}|r${rotation}|h${flipH?1:0}|v${flipV?1:0}|u${hue}|s${saturation}|l${lighting}`;
  if (state.preview.transformedSourceCache.has(key)) return state.preview.transformedSourceCache.get(key);
  const canvas = document.createElement("canvas");
  canvas.width = 32;
  canvas.height = 32;
  const c = canvas.getContext("2d");
  c.imageSmoothingEnabled = false;
  c.save();
  c.translate(16, 16);
  c.rotate(rotation * Math.PI / 180);
  c.scale(flipH ? -1 : 1, flipV ? -1 : 1);
  c.filter = `hue-rotate(${hue}deg) saturate(${Math.max(0, saturation)}%) brightness(${Math.max(0, lighting)}%)`;
  c.drawImage(source.img, source.sx, source.sy, source.sw, source.sh, -16, -16, 32, 32);
  c.restore();
  const out = { img: canvas, sx: 0, sy: 0, sw: 32, sh: 32 };
  state.preview.transformedSourceCache.set(key, out);
  return out;
}

function sourceForTileData(ctx, tileId, data, layer, tilesetId) {
  let source = null;
  const extraName = String(data?.autotileName || "").trim();
  if (extraName) {
    const pattern = Number.isFinite(Number(data?.autotilePattern))
      ? Number(data.autotilePattern)
      : ((Number(tileId) || 0) % 48);
    const img = extraAutotileCanvas(extraName, pattern);
    if (img) source = { img, sx: 0, sy: 0, sw: 32, sh: 32 };
  }
  if (!source) {
    const extended = layer?.kind === "extended" || Number(layerRef(layer)) >= 3;
    // Never sample a regular extended-layer tile from the map's base atlas when
    // its source tileset is unknown. Wrong graphics are worse than an explicit
    // unresolved cell; current Maker Studio exposes the real id via readTileData.
    if (extended && Number(tileId) >= 384 && !Number(tilesetId)) return null;
    source = sourceForTile(tileId, tilesetId);
  }
  return transformedSource(ctx, source, data, `${tilesetId}:${tileId}:${layerRef(layer)}:${extraName}`);
}


// -----------------------------------------------------------------------------
// Geometry Scene Compiler
// -----------------------------------------------------------------------------

function authoritativeLayers(ctx, mapId, includeHidden = false) {
  let layers = [];
  try { layers = (ctx.map.layers(mapId) || []).filter((l) => l && l.kind !== "shadow"); } catch (_) {}
  const byRef = new Map(layers.map((l) => [Number(layerRef(l)), l]));
  // Also union the embedded @extended_layers list used by MakerStudio runtime.
  // This covers projects/builds where a deferred layer exists in the map data
  // but is not fully surfaced by map.layers() yet.
  const ext = mapExtendedData(ctx, mapId);
  for (const row of ext?.layers || []) {
    const ref = Number(firstDefined(row?.id,row?.index));
    if (!Number.isFinite(ref) || byRef.has(ref)) continue;
    const layer = { ...row, id: ref, index: ref, kind: ref >= 3 ? "extended" : "native", visible: row.visible !== false, opacity: row.opacity ?? 1 };
    layers.push(layer); byRef.set(ref, layer);
  }
  for (let i = 0; i < 3; i++) if (!byRef.has(i)) layers.push({ index: i, id: i, kind: "native", name: `Layer ${i + 1}`, visible: true, opacity: 1 });
  return layers.filter((l) => includeHidden || l.visible !== false).sort((a, b) => layerSortValue(a) - layerSortValue(b));
}

function standardAutotileName(ctx, tilesetId, tileId) {
  const index = Math.floor((Number(tileId) || 0) / 48) - 1;
  if (index < 0) return "";
  const info = tilesetInfo(ctx, tilesetId);
  const names = info?.autotileNames || info?.autotile_names || state.preview.rxTilesets?.[Number(tilesetId)]?.autotileNames || [];
  return String(names?.[index] || "").trim();
}

function sourceDescriptor(ctx, mapId, layer, x, y, data = null) {
  const info = ctx.map.info(mapId);
  if (!info) return null;
  data ||= readTileVisualData(ctx, mapId, layer, x, y);
  if (!data) return null;
  const tileId = Number(data.tileId) || 0;
  const extended = layer?.kind === "extended" || Number(layerRef(layer)) >= 3;
  const sourceTilesetId = Number(data.tilesetId) || (extended ? 0 : mapTilesetId(info, mapId));
  const extraName = String(data.autotileName || "").trim();
  let kind = "tile", key = "", graphic = "", pattern = 0, autotileIndex = -1;
  if (extraName) {
    kind = "autotile";
    graphic = extraName;
    pattern = Number.isFinite(Number(data.autotilePattern)) ? Number(data.autotilePattern) : (tileId % 48);
    key = `extra:${extraName.toLowerCase()}`;
  } else if (tileId > 0 && tileId < 384) {
    kind = "autotile";
    autotileIndex = Math.floor(tileId / 48) - 1;
    pattern = tileId % 48;
    graphic = standardAutotileName(ctx, sourceTilesetId, tileId);
    key = `ts:${sourceTilesetId}:autotile:${autotileIndex}`;
  } else if (tileId >= 384) {
    if (!sourceTilesetId) return null;
    kind = "tile";
    graphic = tilesetGraphicName(tilesetInfo(ctx, sourceTilesetId));
    key = `ts:${sourceTilesetId}:tile:${tileId}`;
  } else {
    return null;
  }
  const ref = Number(layerRef(layer));
  const instanceKey = `L${ref}@${x},${y}|${key}`;
  const transform = {
    rotation: normalizeRotation(data.rotation),
    flip_h: !!data.flipH,
    flip_v: !!data.flipV,
    opacity: data.opacity == null ? 255 : Number(data.opacity),
    hue: Number(data.hue) || 0,
    saturation: data.saturation == null ? 100 : Number(data.saturation),
    lighting: data.lighting == null ? 0 : Number(data.lighting),
  };
  const descriptor = {
    key,
    instance_key: instanceKey,
    kind,
    map_id: mapId,
    layer: ref,
    layer_name: String(layer.name || `Layer ${ref}`),
    layer_kind: layer.kind || (ref < 3 ? "native" : "extended"),
    x, y,
    tile_id: tileId,
    tileset_id: sourceTilesetId,
    graphic,
    autotile_index: autotileIndex,
    autotile_pattern: pattern,
    transform,
  };
  descriptor.label = kind === "autotile"
    ? `${graphic || `Autotile ${autotileIndex}`} · TS ${sourceTilesetId || "extra"}`
    : `${graphic || `Tileset ${sourceTilesetId}`} · tile ${tileId}`;
  return descriptor;
}

function materialFromSourceDescriptor(desc) {
  if (!desc) return null;
  const t = desc.transform || {};
  if (desc.kind === "autotile") {
    // Runtime uses its expanded autotile strip. Standard RMXP autotiles keep
    // their real tile id; Maker Studio named/extra autotiles use the virtual
    // slot 8 (same convention as 012_MakerStudioBridge.rb).
    const tid = desc.graphic && String(desc.key).startsWith("extra:")
      ? 8 * 48 + (Number(desc.autotile_pattern) || 0)
      : Number(desc.tile_id) || (Number(desc.autotile_pattern) || 0);
    return {
      kind: "autotile",
      source_key: String(desc.key || ""),
      tileset_id: Number(desc.tileset_id) || 0,
      graphic: String(desc.graphic || ""),
      tile_id: Number(desc.tile_id) || 0,
      autotile_tid: tid,
      autotile_pattern: Number(desc.autotile_pattern) || 0,
      rotation: Number(t.rotation) || 0,
      flip_h: !!t.flip_h,
      flip_v: !!t.flip_v,
      opacity: Number.isFinite(Number(t.opacity)) ? Number(t.opacity) : 255,
      hue: Number(t.hue) || 0,
      saturation: Number.isFinite(Number(t.saturation)) ? Number(t.saturation) : 100,
      lighting: Number(t.lighting) || 0,
    };
  }
  const index = Math.max(0, (Number(desc.tile_id) || 384) - 384);
  return {
    kind: "tileset",
    source_key: String(desc.key || ""),
    tileset_id: Number(desc.tileset_id) || 0,
    graphic: String(desc.graphic || ""),
    tile_id: Number(desc.tile_id) || 0,
    src_rect: { x: (index % 8) * TILE_SIZE, y: Math.floor(index / 8) * TILE_SIZE, w: TILE_SIZE, h: TILE_SIZE },
    rotation: Number(t.rotation) || 0,
    flip_h: !!t.flip_h,
    flip_v: !!t.flip_v,
    opacity: Number.isFinite(Number(t.opacity)) ? Number(t.opacity) : 255,
    hue: Number(t.hue) || 0,
    saturation: Number.isFinite(Number(t.saturation)) ? Number(t.saturation) : 100,
    lighting: Number(t.lighting) || 0,
  };
}

function definitionFromPreset(sourceKey, label, presetName = "wall") {
  const preset = SCENE_GEOMETRY_PRESETS[presetName] || SCENE_GEOMETRY_PRESETS.wall;
  return normalizeSourceDefinition({ ...preset, source_key: sourceKey, label, components: { ...preset.components } }, sourceKey);
}

function effectiveSourceRule(def, override) {
  if (!def) return null;
  const out = { ...def, components: { ...(def.components || {}) } };
  if (override && typeof override === "object") {
    for (const key of ["category", "type", "height", "anchor_z", "collision", "characters_in_front"]) {
      if (override[key] != null) out[key] = override[key];
    }
    if (override.components) out.components = { ...out.components, ...override.components };
    if (override.disabled === true) out.enabled = false;
    if (override.disabled === false) out.enabled = true;
  }
  return out;
}

function compiledObjectFromDescriptor(desc, rule, id) {
  const material = materialFromSourceDescriptor(desc);
  return {
    id,
    name: `${rule.label || desc.label} @ ${desc.x},${desc.y} L${desc.layer}`,
    compiled: true,
    source_key: desc.key,
    instance_key: desc.instance_key,
    source: {
      map_id: desc.map_id, layer: desc.layer, x: desc.x, y: desc.y,
      tileset_id: desc.tileset_id, tile_id: desc.tile_id,
      autotile_name: desc.kind === "autotile" ? desc.graphic : undefined,
      autotile_pattern: desc.kind === "autotile" ? desc.autotile_pattern : undefined,
    },
    type: rule.type === "plane" ? "plane" : "cube",
    x: desc.x, y: desc.y, w: 1, h: 1,
    height: Math.max(0, Number(rule.height) || 0),
    anchor_z: Math.max(0, Number(rule.anchor_z) || 0),
    anchor_row: 0,
    rotation: 0,
    collision: OBJECT_COLLISIONS.includes(rule.collision) ? rule.collision : "solid",
    category: rule.category || "custom",
    characters_in_front: rule.characters_in_front === true || rule.components?.occlusion === "behind",
    footprint: {},
    components: { ...(rule.components || {}) },
    material,
  };
}

async function scanGeometrySources(ctx, mapId, force = false) {
  if (!force && state.sourceUsageByMap.has(mapId)) return state.sourceUsageByMap.get(mapId);
  const info = ctx.map.info(mapId);
  if (!info) return null;
  const layers = authoritativeLayers(ctx, mapId, false);
  const sources = new Map();
  const placements = [];
  const usedTilesetIds = new Set([mapTilesetId(info, mapId)]);
  const usedExtraAutotiles = new Set();
  let placed = 0;
  for (let y = 0; y < info.height; y++) {
    for (let x = 0; x < info.width; x++) {
      for (const layer of layers) {
        const data = readTileVisualData(ctx, mapId, layer, x, y);
        if (!data) continue;
        const desc = sourceDescriptor(ctx, mapId, layer, x, y, data);
        if (!desc) continue;
        placed++;
        placements.push(desc);
        if (desc.tileset_id) usedTilesetIds.add(Number(desc.tileset_id));
        if (desc.kind === "autotile" && String(desc.key).startsWith("extra:") && desc.graphic) usedExtraAutotiles.add(desc.graphic);
        let row = sources.get(desc.key);
        if (!row) {
          row = { key: desc.key, label: desc.label, kind: desc.kind, tileset_id: desc.tileset_id, graphic: desc.graphic, count: 0, examples: [] };
          sources.set(desc.key, row);
        }
        row.count++;
        if (row.examples.length < 6) row.examples.push({ map_id: mapId, layer: desc.layer, x, y, tile_id: desc.tile_id, instance_key: desc.instance_key });
      }
    }
  }
  const usage = { map_id: mapId, placed_tiles: placed, sources, placements, scanned_at: new Date().toISOString() };
  state.sourceUsageByMap.set(mapId, usage);
  usedTilesetIds.delete(0);
  state.preview.usedAssetsByMap.set(mapId, { tilesetIds: usedTilesetIds, extraAutotiles: usedExtraAutotiles });
  if (mapId === ctx.editor.activeMapId()) {
    state.sourceUsage = usage;
    schedulePanelRefresh();
  }
  return usage;
}

async function compileGeometryScene(ctx, mapId, geo, { forceScan = false, reason = "manual" } = {}) {
  if (!geo || state.compilerBusy) return geo?.compiled_objects || [];
  state.compilerBusy = true;
  state.compilerReason = reason;
  try {
    const info = ctx.map.info(mapId);
    if (!info) return [];
    await ensureRxTilesets(ctx, false);
    await ensureRxMap(ctx, mapId, false);

    // One scanner, one source of truth. Geometry editing reuses this placement
    // cache; map.tile.changed/map.batch.changed invalidate it. This prevents a
    // full width×height×layers walk for every inspector tweak.
    const usage = await scanGeometrySources(ctx, mapId, forceScan);
    const placements = usage?.placements || [];
    const definitions = geo.definitions || {};
    const overrides = geo.instance_overrides || {};
    const compiled = [];
    let nextId = COMPILED_OBJECT_ID_BASE;
    for (const desc of placements) {
      const def = definitions[desc.key];
      if (!def) continue;
      const rule = effectiveSourceRule(def, overrides[desc.instance_key]);
      if (!rule || rule.enabled === false) continue;
      compiled.push(compiledObjectFromDescriptor(desc, rule, nextId++));
    }
    geo.compiled_objects = compiled;
    geo.compiler ||= {};
    geo.compiler.version = SCENE_COMPILER_VERSION;
    geo.compiler.auto_compile = geo.compiler.auto_compile !== false;
    geo.compiler.last_compile = new Date().toISOString();
    geo.compiler.stats = {
      placed_tiles: Number(usage?.placed_tiles) || placements.length,
      unique_sources: Number(usage?.sources?.size) || 0,
      defined_sources: Object.keys(definitions).length,
      compiled_objects: compiled.length,
    };
    if (mapId === ctx.editor.activeMapId()) {
      state.sourceUsage = usage;
      await ensureSceneTilesetResources(ctx, mapId, false);
      ctx.editor.requestRedraw();
      schedulePanelRefresh();
      schedulePreview(ctx);
    }
    return compiled;
  } finally {
    state.compilerBusy = false;
    state.compilerReason = "";
  }
}


function scheduleSceneCompile(ctx, mapId, reason = "map-change", delay = 120) {
  const geo = state.maps.get(mapId);
  if (!geo || geo.compiler?.auto_compile === false || !Object.keys(geo.definitions || {}).length) return;
  clearTimeout(state.compilerTimer);
  state.compilerTimer = setTimeout(() => {
    state.compilerTimer = 0;
    void compileGeometryScene(ctx, mapId, geo, { forceScan: false, reason }).then(() => saveMap(ctx, mapId, { skipCompile: true }));
  }, delay);
}

function sourceDescriptorAt(ctx, mapId, x, y, preferredLayer = null) {
  const layers = authoritativeLayers(ctx, mapId, false);
  const ordered = [...layers].sort((a, b) => layerSortValue(b) - layerSortValue(a));
  if (preferredLayer != null) {
    const idx = ordered.findIndex((l) => Number(layerRef(l)) === Number(preferredLayer));
    if (idx > 0) ordered.unshift(...ordered.splice(idx, 1));
  }
  for (const layer of ordered) {
    const data = readTileVisualData(ctx, mapId, layer, x, y);
    if (!data) continue;
    const desc = sourceDescriptor(ctx, mapId, layer, x, y, data);
    if (desc) return desc;
  }
  return null;
}

function sourceDescriptorsAtAllLayers(ctx, mapId, x, y) {
  const out = [];
  for (const layer of authoritativeLayers(ctx, mapId, false)) {
    const data = readTileVisualData(ctx, mapId, layer, x, y);
    if (!data) continue;
    const desc = sourceDescriptor(ctx, mapId, layer, x, y, data);
    if (desc) out.push(desc);
  }
  return out;
}

function refreshCompiledDescriptors(geo, descriptors) {
  if (!geo || !Array.isArray(descriptors) || !descriptors.length) return;
  geo.compiled_objects ||= [];
  const keys = new Set(descriptors.map(d => d?.instance_key).filter(Boolean));
  geo.compiled_objects = geo.compiled_objects.filter(o => !keys.has(o?.instance_key));
  let nextId = Math.max(COMPILED_OBJECT_ID_BASE, ...geo.compiled_objects.map(o => Number(o.id) || 0)) + 1;
  for (const desc of descriptors) {
    if (!desc?.instance_key) continue;
    const def = geo.definitions?.[desc.key];
    if (!def) continue;
    const rule = effectiveSourceRule(def, geo.instance_overrides?.[desc.instance_key]);
    if (!rule || rule.enabled === false) continue;
    geo.compiled_objects.push(compiledObjectFromDescriptor(desc, rule, nextId++));
  }
}

function refreshCompiledCell(ctx, mapId, x, y) {
  const geo = state.maps.get(mapId);
  if (!geo) return;
  const live = sourceDescriptorsAtAllLayers(ctx, mapId, x, y);
  const liveKeys = new Set(live.map(d => d.instance_key));
  geo.compiled_objects = (geo.compiled_objects || []).filter(o => {
    if (Number(o?.source?.map_id) !== Number(mapId)) return true;
    if (Number(o?.source?.x) !== Number(x) || Number(o?.source?.y) !== Number(y)) return true;
    return liveKeys.has(o?.instance_key);
  });
  refreshCompiledDescriptors(geo, live);
}

function selectSourceAt(ctx, mapId, x, y, preferredLayer = null) {
  const desc = sourceDescriptorAt(ctx, mapId, x, y, preferredLayer);
  if (desc) {
    state.sourceSelection = desc;
    const geo = state.maps.get(mapId);
    if (geo?.definitions?.[desc.key]) state.sourcePreset = geo.definitions[desc.key].enabled === false ? "ignore" : geo.definitions[desc.key].category;
    state.objSelected = null;
    state.preview.focusX = x;
    state.preview.focusY = y;
    schedulePanelRefresh();
    if (desc.tileset_id) void ensureTilesetResourceSet(ctx, desc.tileset_id).then(() => { schedulePanelRefresh(); schedulePreview(ctx); });
    ctx.editor.requestRedraw();
    schedulePreview(ctx);
    return desc;
  }
  state.sourceSelection = null;
  schedulePanelRefresh();
  ctx.editor.requestRedraw();
  return null;
}

function applyPresetToSelectedSource(ctx, presetName) {
  const geo = currentGeo(ctx);
  const sel = state.sourceSelection;
  if (!geo || !sel) return;
  state.sourcePreset = presetName;
  geo.definitions ||= {};
  const existing = geo.definitions[sel.key];
  const fresh = definitionFromPreset(sel.key, sel.label, presetName);
  geo.definitions[sel.key] = existing ? { ...fresh, label: existing.label || fresh.label } : fresh;
  void compileGeometryScene(ctx, sel.map_id, geo, { reason: `preset:${presetName}` }).then(() => saveMap(ctx, sel.map_id, { skipCompile: true }));
  state.panelRefresh?.();
}

function updateSelectedSourceDefinition(ctx, patch) {
  const geo = currentGeo(ctx), sel = state.sourceSelection;
  if (!geo || !sel) return;
  geo.definitions ||= {};
  const base = geo.definitions[sel.key] || definitionFromPreset(sel.key, sel.label, state.sourcePreset || "wall");
  geo.definitions[sel.key] = normalizeSourceDefinition({ ...base, ...patch, source_key: sel.key, label: base.label || sel.label,
    components: patch?.components ? { ...(base.components || {}), ...patch.components } : base.components }, sel.key);
  scheduleSceneCompile(ctx, sel.map_id, "definition", 80);
  state.panelRefresh?.();
}

function updateSelectedInstanceOverride(ctx, patch) {
  const geo = currentGeo(ctx), sel = state.sourceSelection;
  if (!geo || !sel) return;
  geo.instance_overrides ||= {};
  const old = geo.instance_overrides[sel.instance_key] || {};
  geo.instance_overrides[sel.instance_key] = { ...old, ...patch };
  scheduleSceneCompile(ctx, sel.map_id, "instance-override", 80);
  state.panelRefresh?.();
}

function clearSelectedInstanceOverride(ctx) {
  const geo = currentGeo(ctx), sel = state.sourceSelection;
  if (!geo || !sel) return;
  delete geo.instance_overrides?.[sel.instance_key];
  scheduleSceneCompile(ctx, sel.map_id, "instance-clear", 80);
  state.panelRefresh?.();
}

const SIMPLE_PRESET_LABELS = {
  floor: "Suelo",
  wall: "Pared",
  mountain: "Montaña",
  prop: "Prop",
  roof: "Techo",
  border: "Borde",
  custom: "Personalizado",
  ignore: "Sin Geometry",
};

function simplePresetLabel(name) {
  return SIMPLE_PRESET_LABELS[name] || name || "Geometry";
}

function simplePresetIcon(name) {
  return ({ floor: "▱", wall: "▥", mountain: "▰", prop: "♟", roof: "⌂", border: "▤", custom: "◆", ignore: "∅" })[name] || "◆";
}

function simplePresetRule(presetName, height = null) {
  const preset = SCENE_GEOMETRY_PRESETS[presetName] || SCENE_GEOMETRY_PRESETS.wall;
  const out = {
    category: preset.category,
    type: preset.type,
    height: height == null ? Number(preset.height) || 0 : Math.max(0, Number(height) || 0),
    anchor_z: Number(preset.anchor_z) || 0,
    collision: preset.collision,
    characters_in_front: !!preset.characters_in_front,
    components: { ...(preset.components || {}) },
  };
  return out;
}

function forgetOverridesForSource(geo, sourceKey) {
  if (!geo?.instance_overrides) return;
  for (const key of Object.keys(geo.instance_overrides)) {
    if (key.endsWith(`|${sourceKey}`)) delete geo.instance_overrides[key];
  }
}

function connectedSourceDescriptors(ctx, sel, limit = 4096) {
  if (!sel) return [];
  const info = ctx.map.info(sel.map_id);
  if (!info) return [sel];
  const layer = authoritativeLayers(ctx, sel.map_id, true).find((l) => Number(layerRef(l)) === Number(sel.layer));
  if (!layer) return [sel];
  const geo = state.maps.get(sel.map_id);
  const seedDef = geo?.definitions?.[sel.key] || null;
  const seedRule = seedDef ? effectiveSourceRule(seedDef, geo?.instance_overrides?.[sel.instance_key]) : null;
  const out = [];
  const seen = new Set();
  const queue = [[sel.x, sel.y]];
  while (queue.length && out.length < limit) {
    const [x, y] = queue.shift();
    if (x < 0 || y < 0 || x >= info.width || y >= info.height) continue;
    const k = `${x},${y}`;
    if (seen.has(k)) continue;
    seen.add(k);
    const data = readTileVisualData(ctx, sel.map_id, layer, x, y);
    if (!data) continue;
    const desc = sourceDescriptor(ctx, sel.map_id, layer, x, y, data);
    if (!desc) continue;

    // V2 smart connected scope. Before Geometry exists we retain the safe
    // same-source behavior. Once the seed has Geometry, adjacent tiles may use
    // different cliff/mountain graphics and still belong to the same connected
    // elevation if their effective category and height match.
    let compatible = desc.key === sel.key;
    if (seedRule && seedRule.enabled !== false) {
      const d = geo?.definitions?.[desc.key];
      const r = d ? effectiveSourceRule(d, geo?.instance_overrides?.[desc.instance_key]) : null;
      compatible = !!r && r.enabled !== false &&
        String(r.category || '') === String(seedRule.category || '') &&
        Math.abs((Number(r.height) || 0) - (Number(seedRule.height) || 0)) < 0.001;
    }
    if (!compatible) continue;
    out.push(desc);
    queue.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
  }
  return out.length ? out : [sel];
}

function scopedSourceDescriptors(ctx, sel) {
  if (state.sceneScope === "connected") return connectedSourceDescriptors(ctx, sel);
  return [sel];
}

function affectedSourceDescriptors(ctx, sel) {
  if (!sel) return [];
  if (state.sceneScope === "all") {
    const usage = state.sourceUsageByMap.get(sel.map_id) || state.sourceUsage;
    const rows = (usage?.placements || []).filter(d => d.key === sel.key);
    return rows.length ? rows : [sel];
  }
  return scopedSourceDescriptors(ctx, sel);
}

async function finishSimpleSceneEdit(ctx, mapId, reason) {
  const geo = state.maps.get(mapId);
  if (!geo) return;
  schedulePanelRefresh();
  ctx.editor.requestRedraw();
  schedulePreview(ctx);
  // Live editing already updates affected compiled instances in-place. Persist
  // the lightweight data shortly after input, and rebuild the complete scene
  // later in the background. This keeps brush/height/erase gestures responsive.
  if (state.dragging || state.preview.dragging) return;
  clearTimeout(state.simpleEditTimer);
  state.simpleEditTimer = setTimeout(async () => {
    state.simpleEditTimer = 0;
    await saveMap(ctx, mapId, { skipCompile: true, skipModelCompile: true });
    scheduleSceneCompile(ctx, mapId, reason, 360);
  }, 110);
}

function applySimpleGeometry(ctx, sel, presetName = state.brushPreset, height = state.brushHeight) {
  const geo = state.maps.get(sel?.map_id);
  if (!geo || !sel) return;
  presetName = SCENE_GEOMETRY_PRESETS[presetName] ? presetName : "wall";
  state.brushPreset = presetName;
  state.sourcePreset = presetName;
  const patch = simplePresetRule(presetName, height);
  geo.definitions ||= {};
  geo.instance_overrides ||= {};

  const affected = affectedSourceDescriptors(ctx, sel);
  if (state.sceneScope === "all") {
    const fresh = definitionFromPreset(sel.key, sel.label, presetName);
    geo.definitions[sel.key] = normalizeSourceDefinition({
      ...fresh,
      ...patch,
      enabled: true,
      source_key: sel.key,
      label: geo.definitions[sel.key]?.label || sel.label,
      components: { ...patch.components },
    }, sel.key);
    forgetOverridesForSource(geo, sel.key);
  } else {
    if (!geo.definitions[sel.key]) {
      const fresh = definitionFromPreset(sel.key, sel.label, presetName);
      geo.definitions[sel.key] = normalizeSourceDefinition({ ...fresh, ...patch, enabled: false, components: { ...patch.components } }, sel.key);
    }
    for (const desc of affected) {
      const old = geo.instance_overrides[desc.instance_key] || {};
      geo.instance_overrides[desc.instance_key] = {
        ...old,
        ...patch,
        disabled: false,
        components: { ...(old.components || {}), ...patch.components },
      };
    }
  }
  refreshCompiledDescriptors(geo, affected);
  void finishSimpleSceneEdit(ctx, sel.map_id, `simple-paint:${presetName}`);
}

function eraseSimpleGeometry(ctx, sel) {
  const geo = state.maps.get(sel?.map_id);
  if (!geo || !sel) return;
  // One eraser for everything Geometry owns. Never touches Maker Studio tiles.
  geo.objects = (geo.objects || []).filter(o => !objectCoversCell(o, sel.x, sel.y));
  geo.model_instances = (geo.model_instances || []).filter(inst => !modelInstanceCoversCell(geo, inst, sel.x, sel.y));
  compileModelObjects(geo);
  geo.definitions ||= {};
  geo.instance_overrides ||= {};
  if (state.sceneScope === "all") {
    if (geo.definitions[sel.key]) geo.definitions[sel.key].enabled = false;
    forgetOverridesForSource(geo, sel.key);
  } else {
    if (geo.definitions[sel.key]) for (const desc of scopedSourceDescriptors(ctx, sel)) {
      geo.instance_overrides[desc.instance_key] = { ...(geo.instance_overrides[desc.instance_key] || {}), disabled: true };
    }
  }
  void finishSimpleSceneEdit(ctx, sel.map_id, "simple-erase");
}

function eraseGeometryAtCell(ctx, mapId, x, y, preferredLayer = null) {
  const geo = state.maps.get(mapId);
  if (!geo) return false;
  let changed = false;

  // Models: erase the whole placed instance when any occupied cell is touched.
  const modelIds = new Set((geo.model_instances || []).filter(inst => modelInstanceCoversCell(geo, inst, x, y)).map(inst => Number(inst.id)));
  if (modelIds.size) {
    geo.model_instances = (geo.model_instances || []).filter(inst => !modelIds.has(Number(inst.id)));
    geo.model_objects = (geo.model_objects || []).filter(obj => !modelIds.has(Number(obj.model_instance_id)));
    changed = true;
  }

  // Manually placed Geometry objects.
  const beforeObjects = (geo.objects || []).length;
  geo.objects = (geo.objects || []).filter(obj => !objectCoversCell(obj, x, y));
  if ((geo.objects || []).length !== beforeObjects) changed = true;

  // Source-driven Geometry is erased locally, independent of the current scope.
  // This makes the eraser behave like Maker Studio's normal eraser: drag over
  // exactly what you want gone, without unexpectedly disabling every matching tile.
  geo.instance_overrides ||= {};
  const descriptors = sourceDescriptorsAtAllLayers(ctx, mapId, x, y);
  const affected = [];
  for (const desc of descriptors) {
    if (!geo.definitions?.[desc.key]) continue;
    geo.instance_overrides[desc.instance_key] = {
      ...(geo.instance_overrides[desc.instance_key] || {}),
      disabled: true,
    };
    affected.push(desc);
    changed = true;
  }
  if (affected.length) refreshCompiledDescriptors(geo, affected);

  if (state.sourceSelection && Number(state.sourceSelection.map_id) === Number(mapId) &&
      Number(state.sourceSelection.x) === Number(x) && Number(state.sourceSelection.y) === Number(y)) {
    state.sourceSelection = null;
  }
  if (changed) {
    ctx.editor.requestRedraw();
    schedulePreview(ctx);
    schedulePanelRefresh();
  }
  return changed;
}

function adjustSimpleGeometryHeight(ctx, sel, delta) {
  const geo = state.maps.get(sel?.map_id);
  if (!geo || !sel) return;
  geo.definitions ||= {};
  geo.instance_overrides ||= {};
  let def = geo.definitions[sel.key];
  if (!def) {
    const preset = state.brushPreset || "wall";
    const fresh = definitionFromPreset(sel.key, sel.label, preset);
    fresh.height = Math.max(0, Number(state.brushHeight) || Number(fresh.height) || 0);
    fresh.enabled = state.sceneScope === "all";
    geo.definitions[sel.key] = def = normalizeSourceDefinition(fresh, sel.key);
  }
  const affected = affectedSourceDescriptors(ctx, sel);
  if (state.sceneScope === "all") {
    def.enabled = true;
    def.height = Math.max(0, (Number(def.height) || 0) + delta);
    state.brushHeight = def.height;
  } else {
    for (const desc of affected) {
      const old = geo.instance_overrides[desc.instance_key] || {};
      const effective = effectiveSourceRule(def, old) || def;
      const next = Math.max(0, (Number(effective.height) || 0) + delta);
      geo.instance_overrides[desc.instance_key] = { ...old, height: next, disabled: false };
      if (desc.instance_key === sel.instance_key) state.brushHeight = next;
    }
  }
  refreshCompiledDescriptors(geo, affected);
  void finishSimpleSceneEdit(ctx, sel.map_id, `simple-height:${delta}`);
}

function patchSimpleGeometry(ctx, sel, patch) {
  const geo = state.maps.get(sel?.map_id);
  if (!geo || !sel) return;
  geo.definitions ||= {};
  geo.instance_overrides ||= {};
  let def = geo.definitions[sel.key];
  if (!def) {
    const fresh = definitionFromPreset(sel.key, sel.label, state.brushPreset || "wall");
    fresh.height = Math.max(0, Number(state.brushHeight) || Number(fresh.height) || 0);
    fresh.enabled = state.sceneScope === "all";
    geo.definitions[sel.key] = def = normalizeSourceDefinition(fresh, sel.key);
  }
  const affected = affectedSourceDescriptors(ctx, sel);
  if (state.sceneScope === "all") {
    const merged = { ...def, ...patch };
    if (patch.components) merged.components = { ...(def.components || {}), ...patch.components };
    merged.enabled = true;
    geo.definitions[sel.key] = normalizeSourceDefinition(merged, sel.key);
  } else {
    for (const desc of affected) {
      const old = geo.instance_overrides[desc.instance_key] || {};
      geo.instance_overrides[desc.instance_key] = {
        ...old,
        ...patch,
        disabled: false,
        components: patch.components ? { ...(old.components || {}), ...patch.components } : old.components,
      };
    }
  }
  refreshCompiledDescriptors(geo, affected);
  void finishSimpleSceneEdit(ctx, sel.map_id, "simple-patch");
}

function setSimpleGeometryHeight(ctx, sel, height) {
  const next = Math.max(0, Number(height) || 0);
  state.brushHeight = next;
  patchSimpleGeometry(ctx, sel, { height: next });
}

function eyedropSimpleGeometry(ctx, sel) {
  const geo = state.maps.get(sel?.map_id);
  const def = geo?.definitions?.[sel?.key];
  if (!geo || !sel || !def) {
    try { ctx.ui.showToast?.({ message: "Ese tile todavía no tiene Geometry para copiar.", level: "info" }); } catch (_) {}
    return;
  }
  const rule = effectiveSourceRule(def, geo.instance_overrides?.[sel.instance_key]);
  if (!rule || rule.enabled === false) {
    try { ctx.ui.showToast?.({ message: "Ese tile tiene Geometry desactivado.", level: "info" }); } catch (_) {}
    return;
  }
  state.brushPreset = rule.category || "custom";
  state.sourcePreset = state.brushPreset;
  state.brushHeight = Number(rule.height) || 0;
  state.sceneTool = "paint";
  state.panelRefresh?.();
  try { ctx.ui.showToast?.({ message: `Copiado: ${simplePresetLabel(state.brushPreset)}, altura ${state.brushHeight}.`, level: "info" }); } catch (_) {}
}

function runSimpleSceneTool(ctx, mapId, x, y, preferredLayer = null) {
  if (state.sceneTool === "model-place") { placeModelInstance(ctx, mapId, x, y); return; }
  if (state.sceneTool === "model-erase") { eraseGeometryAtCell(ctx, mapId, x, y, preferredLayer); return; }
  if (state.sceneTool === "place") { v2PlacePickedGraphic(ctx, mapId, x, y); return; }
  if (state.sceneTool === "erase") { eraseGeometryAtCell(ctx, mapId, x, y, preferredLayer); return; }

  if (state.sceneTool === "select") {
    selectSourceAt(ctx, mapId, x, y, preferredLayer);
    return;
  }

  const desc = state.sceneTool === "eyedropper"
    ? selectSourceAt(ctx, mapId, x, y, preferredLayer)
    : sourceDescriptorAt(ctx, mapId, x, y, preferredLayer);
  if (!desc) return;
  switch (state.sceneTool) {
    case "paint": applySimpleGeometry(ctx, desc); break;
    case "raise": adjustSimpleGeometryHeight(ctx, desc, 0.25); break;
    case "lower": adjustSimpleGeometryHeight(ctx, desc, -0.25); break;
    case "eyedropper": eyedropSimpleGeometry(ctx, desc); break;
    default: break;
  }
}

function cameraFor(ctx, geo, width = 640, height = 480) {
  const angle = state.preview.angle * Math.PI / 180;
  const yaw = state.preview.yaw * Math.PI / 180;
  const cosRaw = Math.cos(angle);
  const cosSafe = Math.max(0.10, Math.abs(cosRaw));
  const sin = Math.sin(angle);
  const cosYaw = Math.cos(yaw);
  const sinYaw = Math.sin(yaw);
  const distance = runtimeConfig.distanceH;
  const focal = distance * (state.preview.zoom / cosSafe);
  const pivotY = height * 0.52;
  const centerX = width / 2;
  const fx = Math.max(0, Math.min(geo.width - 1, Math.round(state.preview.focusX ?? geo.width / 2)));
  const fy = Math.max(0, Math.min(geo.height - 1, Math.round(state.preview.focusY ?? geo.height / 2)));
  const focusFootX = (fx + 0.5) * TILE_SIZE;
  const focusFootY = (fy + 1.0) * TILE_SIZE;
  const mapId = ctx.editor.activeMapId();
  const camElev = effectiveHeight(geo, mapId, fx, fy);
  // At yaw=0 this is exactly the runtime camera. Yaw rotates the
  // world around the focus point before applying the same pitch perspective.
  const camX = focusFootX;
  const camY = focusFootY - pivotY;
  return { width, height, angle, yaw, sin, cosRaw, cosYaw, sinYaw, distance, focal, pivotY, centerX, camX, camY, camElev, focusFootX, focusFootY };
}

function project(cam, wx, wy, elevation = 0) {
  const pivotWorldY = cam.camY + cam.pivotY;
  const rx = wx - cam.camX;
  const ry = wy - pivotWorldY;
  // Camera-space right/forward axes. Positive yaw orbits clockwise when viewed
  // from above. At yaw 0: right=world X, forward=world Y.
  const right = rx * cam.cosYaw - ry * cam.sinYaw;
  const forward = rx * cam.sinYaw + ry * cam.cosYaw;
  const relElev = elevation - cam.camElev;
  const depth = cam.distance - forward * cam.sin - relElev * cam.cosRaw;
  if (depth <= 24) return null;
  const sx = cam.centerX + cam.focal * right / depth;
  const vertical = forward * cam.cosRaw - relElev * cam.sin;
  const sy = cam.pivotY + cam.focal * vertical / depth;
  return { x: sx, y: sy, depth, scale: cam.focal / depth };
}

function polyDepth(points) {
  let sum = 0;
  let count = 0;
  for (const p of points) {
    if (!p) continue;
    sum += p.depth;
    count++;
  }
  return count ? sum / count : -Infinity;
}

function validPoly(points) {
  return points.length >= 3 && points.every(Boolean) && points.every((p) => Number.isFinite(p.x) && Number.isFinite(p.y));
}

function drawImageTriangle(c, img, s0, s1, s2, d0, d1, d2) {
  const den = s0.x * (s1.y - s2.y) + s1.x * (s2.y - s0.y) + s2.x * (s0.y - s1.y);
  if (Math.abs(den) < 1e-8) return;
  const a = (d0.x * (s1.y - s2.y) + d1.x * (s2.y - s0.y) + d2.x * (s0.y - s1.y)) / den;
  const cM = (d0.x * (s2.x - s1.x) + d1.x * (s0.x - s2.x) + d2.x * (s1.x - s0.x)) / den;
  const e = (d0.x * (s1.x * s2.y - s2.x * s1.y) + d1.x * (s2.x * s0.y - s0.x * s2.y) + d2.x * (s0.x * s1.y - s1.x * s0.y)) / den;
  const b = (d0.y * (s1.y - s2.y) + d1.y * (s2.y - s0.y) + d2.y * (s0.y - s1.y)) / den;
  const d = (d0.y * (s2.x - s1.x) + d1.y * (s0.x - s2.x) + d2.y * (s1.x - s0.x)) / den;
  const f = (d0.y * (s1.x * s2.y - s2.x * s1.y) + d1.y * (s2.x * s0.y - s0.x * s2.y) + d2.y * (s0.x * s1.y - s1.x * s0.y)) / den;
  c.save();
  c.beginPath();
  c.moveTo(d0.x, d0.y);
  c.lineTo(d1.x, d1.y);
  c.lineTo(d2.x, d2.y);
  c.closePath();
  c.clip();
  c.setTransform(a, b, cM, d, e, f);
  c.drawImage(img, 0, 0);
  c.restore();
}

function drawTexturedQuad(c, source, points, alpha = 1) {
  if (!source || !validPoly(points)) return false;
  const { img, sx, sy, sw, sh } = source;
  if (!img) return false;
  const [tl, tr, br, bl] = points;
  c.save();
  c.globalAlpha *= alpha;
  c.imageSmoothingEnabled = false;
  drawImageTriangle(c, img,
    { x: sx, y: sy }, { x: sx + sw, y: sy }, { x: sx + sw, y: sy + sh },
    tl, tr, br);
  drawImageTriangle(c, img,
    { x: sx, y: sy }, { x: sx + sw, y: sy + sh }, { x: sx, y: sy + sh },
    tl, br, bl);
  c.restore();
  return true;
}

function fillPoly(c, points, fill, stroke = null, lineWidth = 1) {
  if (!validPoly(points)) return;
  c.beginPath();
  c.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) c.lineTo(points[i].x, points[i].y);
  c.closePath();
  if (fill) { c.fillStyle = fill; c.fill(); }
  if (stroke) { c.strokeStyle = stroke; c.lineWidth = lineWidth; c.stroke(); }
}

function pointInPoly(px, py, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i].x, yi = poly[i].y;
    const xj = poly[j].x, yj = poly[j].y;
    const hit = ((yi > py) !== (yj > py)) && (px < (xj - xi) * (py - yi) / ((yj - yi) || 1e-9) + xi);
    if (hit) inside = !inside;
  }
  return inside;
}

function visualKind(props) {
  const tag = Number(props?.terrainTag) || 0;
  const priority = Number(props?.priority) || 0;
  if (MOUNTAIN_MATERIAL_TAGS.has(tag)) return "mountainMaterial";
  if (PLANE_WALL_TAGS.has(tag)) return "wallPlane";
  if (tag === TAG.WALL || tag === TAG.INDOOR_WALL) return "wallFacade";
  if (tag === TAG.STAIR) return "stair";
  if (tag === TAG.ROOF_PLANE) return "roofPlane";
  if (ROOF_BILLBOARD_TAGS.has(tag)) return "billboard";
  if (BILLBOARD_TAGS.has(tag)) return "billboard";
  if (priority > 0 && !TOP_SURFACE_TAGS.has(tag) && !WALL_ART_TAGS.has(tag)) return "billboard";
  return "ground";
}

function isBillboard(props) { return visualKind(props) === "billboard"; }
function isWallArt(props) {
  const k = visualKind(props);
  return k === "mountainMaterial" || k === "wallPlane" || k === "wallFacade";
}

function visibleLayers(ctx, mapId) {
  const native = [0, 1, 2].map((index) => ({ index, id: index, visible: true, opacity: 1, kind: "native" }));
  try {
    const extData = mapExtendedData(ctx, mapId);
    const extLayers = (extData?.layers || [])
      .filter((l) => l && l.visible !== false)
      .map((l) => ({ ...l, kind: "extended", index: firstDefined(l.index, l.id), id: firstDefined(l.id, l.index) }))
      .filter((l) => ![0, 1, 2].includes(Number(layerRef(l))))
      .sort((a, b) => layerSortValue(a) - layerSortValue(b));
    if (extLayers.length) {
      state.preview.layerStats = { native: native.length, extended: extLayers.length };
      return native.concat(extLayers);
    }
    const apiLayers = ctx.map.layers(mapId) || [];
    const extra = apiLayers
      .filter((l) => l && l.visible !== false && l.kind !== "shadow")
      .filter((l) => l.kind !== "native" && ![0, 1, 2].includes(Number(layerRef(l))))
      .sort((a, b) => layerSortValue(a) - layerSortValue(b));
    state.preview.layerStats = { native: native.length, extended: extra.length };
    return native.concat(extra);
  } catch (_) {
    state.preview.layerStats = { native: native.length, extended: 0 };
    return native;
  }
}

// Maker Studio builds have exposed map-layer opacity using 0..1, 0..100 and
// 0..255 conventions. A value of 100 must be fully opaque, not 100/255.
function normalizedLayerOpacity(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 1;
  if (n <= 0) return 0;
  if (n <= 1.0001) return Math.max(0, Math.min(1, n));
  if (n <= 100.0001) return Math.max(0, Math.min(1, n / 100));
  return Math.max(0, Math.min(1, n / 255));
}

function normalizedTileOpacity(value) {
  if (value == null) return 1;
  const n = Number(value);
  if (!Number.isFinite(n)) return 1;
  if (n <= 1.0001) return Math.max(0, Math.min(1, n));
  return Math.max(0, Math.min(1, n / 255));
}

function cellTileEntries(ctx, mapId, x, y, layers, tilesetId) {
  const ground = [];
  const billboards = [];
  const walls = [];          // art/material usable by generated cliffs
  const wallPlanes = [];     // explicit NDSWallPlane geometry
  const stairs = [];
  const roofPlanes = [];
  const all = [];
  // Early exit: quickly check if any layer has a tile at this position.
  let hasAnyTile = false;
  for (const layer of layers) {
    const data = readTileVisualData(ctx, mapId, layer, x, y);
    if (data) { hasAnyTile = true; break; }
  }
  if (!hasAnyTile) return { ground, billboards, walls, wallPlanes, stairs, roofPlanes, all };
  for (const layer of layers) {
    const data = readTileVisualData(ctx, mapId, layer, x, y);
    const tileId = Number(data?.tileId) || 0;
    if (!data || (!tileId && !String(data?.autotileName || "").trim())) continue;
    const sourceTilesetId = Number(data?.tilesetId) || tilesetId;
    const props = tileId ? { ...tileProps(ctx, sourceTilesetId, tileId) } : { passage: 0, priority: 0, terrainTag: 0 };
    if (data?.terrainTag !== undefined) props.terrainTag = Number(data.terrainTag) || 0;
    const kind = visualKind(props);
    const source = sourceForTileData(ctx, tileId, data, layer, sourceTilesetId);
    const tileOpacity = normalizedTileOpacity(data?.opacity);
    const layerOpacity = normalizedLayerOpacity(layer.opacity ?? 1);
    const entry = {
      tileId, props, layer, data, kind, source, sourceTilesetId,
      alpha: Math.max(0, Math.min(1, tileOpacity * layerOpacity)),
      tag: Number(props?.terrainTag) || 0,
    };
    all.push(entry);
    if (kind === "mountainMaterial") walls.push(entry);
    else if (kind === "wallPlane") { walls.push(entry); wallPlanes.push(entry); }
    else if (kind === "wallFacade") { walls.push(entry); billboards.push({ ...entry, facade: true }); }
    else if (kind === "stair") stairs.push(entry);
    else if (kind === "roofPlane") roofPlanes.push(entry);
    else if (kind === "billboard") billboards.push(entry);
    else ground.push(entry);
  }
  return { ground, billboards, walls, wallPlanes, stairs, roofPlanes, all };
}

function surfaceGroundEntries(entries, elev, explicitGeometry = false) {
  const ground = entries?.ground || [];
  if (elev <= 0.001 || !ground.length) return ground;

  // A legacy elevated cell usually has a real surface-defining tile (MountainTop,
  // Volume, Floor). Lower native layers are underlay and must stay at Z=0 instead
  // of being lifted and blended into the plateau texture. Keep the surface layer
  // and any untagged decoration painted above it.
  const defining = ground.filter((e) => [
    TAG.FLOOR, TAG.VOLUME, TAG.MOUNTAIN_TOP, TAG.VOLUME_HIGH,
    TAG.ROOF_PLANE, TAG.INDOOR_BORDER, TAG.INDOOR_BLACK
  ].includes(Number(e.tag) || 0));
  if (defining.length) {
    const firstLayer = Math.min(...defining.map((e) => layerSortValue(e.layer)));
    return ground.filter((e) => {
      const layerIndex = layerSortValue(e.layer);
      const tag = Number(e.tag) || 0;
      if (layerIndex < firstLayer) return false;
      return tag === 0 || defining.includes(e);
    });
  }

  // Explicit Geometry Editor height without a semantic top tag intentionally
  // lifts the visible horizontal stack chosen by the mapper.
  if (explicitGeometry) return ground;
  return ground.slice(-1);
}

function composeGroundSource(entries) {
  if (!entries || !entries.length) return null;
  const drawable = entries.filter((e) => e?.source && Number(e.alpha ?? 1) > 0.001);
  if (!drawable.length) return null;
  const canvas = getCanvas(TILE_SIZE, TILE_SIZE);
  const c = canvas.getContext("2d");
  c.imageSmoothingEnabled = false;
  // Compose the same per-cell layer stack first, then perspective-project the
  // result once. This avoids dark seams caused by independently warped alpha
  // layers and is closer to the RMXP/Maker Studio tile stack.
  for (const entry of drawable) {
    const src = entry.source;
    c.save();
    c.globalAlpha = Math.max(0, Math.min(1, Number(entry.alpha ?? 1)));
    c.drawImage(src.img, src.sx, src.sy, src.sw, src.sh, 0, 0, TILE_SIZE, TILE_SIZE);
    c.restore();
  }
  return { img: canvas, sx: 0, sy: 0, sw: TILE_SIZE, sh: TILE_SIZE };
}

function previewCliffSource(ctx, mapId, highX, highY, edge, layers, tilesetId, cellCache) {
  const custom = state.preview.cliffSource;
  if (custom && Number(custom.tileset_id) === Number(tilesetId) && custom.src_rect) {
    const r = custom.src_rect;
    const customImg = state.preview.tilesetImages.get(Number(custom.tileset_id)) || null;
    if (customImg) return { img: customImg, sx: r.x, sy: r.y, sw: r.w || 32, sh: r.h || 32 };
  }
  let nx = highX, ny = highY;
  if (edge === "south") ny++;
  else if (edge === "north") ny--;
  else if (edge === "east") nx++;
  else if (edge === "west") nx--;
  const key = cellCacheKey(mapId, nx, ny);
  let entries = cellCache.get(key);
  if (!entries) {
    entries = cellTileEntries(ctx, mapId, nx, ny, layers, tilesetId);
    cellCache.set(key, entries);
  }
  const wall = entries.walls.find((e) => e.source);
  if (wall?.source) return wall.source;
  const localKey = cellCacheKey(mapId, highX, highY);
  let local = cellCache.get(localKey);
  if (!local) {
    local = cellTileEntries(ctx, mapId, highX, highY, layers, tilesetId);
    cellCache.set(localKey, local);
  }
  return local.walls.find((e) => e.source)?.source || null;
}

function makeTopPoly(cam, x, y, elev) {
  return [
    project(cam, x * TILE_SIZE, y * TILE_SIZE, elev),
    project(cam, (x + 1) * TILE_SIZE, y * TILE_SIZE, elev),
    project(cam, (x + 1) * TILE_SIZE, (y + 1) * TILE_SIZE, elev),
    project(cam, x * TILE_SIZE, (y + 1) * TILE_SIZE, elev),
  ];
}

function makeRectTopPoly(cam, x0, y0, x1, y1, elev) {
  return [
    project(cam, x0 * TILE_SIZE, y0 * TILE_SIZE, elev),
    project(cam, (x1 + 1) * TILE_SIZE, y0 * TILE_SIZE, elev),
    project(cam, (x1 + 1) * TILE_SIZE, (y1 + 1) * TILE_SIZE, elev),
    project(cam, x0 * TILE_SIZE, (y1 + 1) * TILE_SIZE, elev),
  ];
}

function makeRectFacePoly(cam, x0, y0, x1, y1, edge, z0, z1) {
  let a, b;
  if (edge === "south") { a = [x0 * TILE_SIZE, (y1 + 1) * TILE_SIZE]; b = [(x1 + 1) * TILE_SIZE, (y1 + 1) * TILE_SIZE]; }
  else if (edge === "north") { a = [(x1 + 1) * TILE_SIZE, y0 * TILE_SIZE]; b = [x0 * TILE_SIZE, y0 * TILE_SIZE]; }
  else if (edge === "east") { a = [(x1 + 1) * TILE_SIZE, (y1 + 1) * TILE_SIZE]; b = [(x1 + 1) * TILE_SIZE, y0 * TILE_SIZE]; }
  else { a = [x0 * TILE_SIZE, y0 * TILE_SIZE]; b = [x0 * TILE_SIZE, (y1 + 1) * TILE_SIZE]; }
  return [
    project(cam, a[0], a[1], z1),
    project(cam, b[0], b[1], z1),
    project(cam, b[0], b[1], z0),
    project(cam, a[0], a[1], z0),
  ];
}

function makeFacePoly(cam, x, y, edge, z0, z1) {
  let a, b;
  if (edge === "south") { a = [x * TILE_SIZE, (y + 1) * TILE_SIZE]; b = [(x + 1) * TILE_SIZE, (y + 1) * TILE_SIZE]; }
  else if (edge === "north") { a = [(x + 1) * TILE_SIZE, y * TILE_SIZE]; b = [x * TILE_SIZE, y * TILE_SIZE]; }
  else if (edge === "east") { a = [(x + 1) * TILE_SIZE, (y + 1) * TILE_SIZE]; b = [(x + 1) * TILE_SIZE, y * TILE_SIZE]; }
  else { a = [x * TILE_SIZE, y * TILE_SIZE]; b = [x * TILE_SIZE, (y + 1) * TILE_SIZE]; }
  return [
    project(cam, a[0], a[1], z1),
    project(cam, b[0], b[1], z1),
    project(cam, b[0], b[1], z0),
    project(cam, a[0], a[1], z0),
  ];
}


function makeRampPoly(cam, x, y, southZ, northZ) {
  return [
    project(cam, x * TILE_SIZE, y * TILE_SIZE, northZ),
    project(cam, (x + 1) * TILE_SIZE, y * TILE_SIZE, northZ),
    project(cam, (x + 1) * TILE_SIZE, (y + 1) * TILE_SIZE, southZ),
    project(cam, x * TILE_SIZE, (y + 1) * TILE_SIZE, southZ),
  ];
}

function eventCharacterSource(graphic) {
  const name = String(graphic?.character_name || "");
  const img = state.preview.characterImages.get(name);
  if (!img) return null;
  // RPG Maker XP character sheets are normally 4 columns x 4 directions.
  const cols = 4, rows = 4;
  const fw = Math.max(1, Math.floor(img.width / cols));
  const fh = Math.max(1, Math.floor(img.height / rows));
  const dir = Number(graphic?.direction) || 2;
  const row = dir === 4 ? 1 : dir === 6 ? 2 : dir === 8 ? 3 : 0;
  const col = Math.max(0, Math.min(3, Number(graphic?.pattern) || 0));
  return { img, sx: col * fw, sy: row * fh, sw: fw, sh: fh };
}

function appendEventItems(ctx, mapId, geo, cam, items, minX, maxX, minY, maxY) {
  if (!state.preview.showEvents || !ctx.events?.list || !ctx.events?.getFull) return;
  for (const ev of ctx.events.list(mapId) || []) {
    if (ev.x < minX || ev.x > maxX || ev.y < minY || ev.y > maxY) continue;
    try {
      const full = ctx.events.getFull(mapId, ev.id);
      const page = full?.pages?.[0];
      const graphic = page?.graphic;
      if (!graphic?.character_name) continue;
      const elev = effectiveHeight(geo, mapId, ev.x, ev.y);
      const anchor = project(cam, (ev.x + 0.5) * TILE_SIZE, (ev.y + 1) * TILE_SIZE, elev);
      if (!anchor) continue;
      const source = eventCharacterSource(graphic);
      items.push({
        type: "event", x: ev.x, y: ev.y, elev, anchor, source,
        alpha: Math.max(0, Math.min(1, Number(graphic.opacity ?? 255) / 255)),
        depth: anchor.depth + (page?.always_on_bottom ? 0.25 : page?.always_on_top ? -0.25 : 0),
        name: ev.name || `Event ${ev.id}`,
      });
    } catch (_) {}
  }
}

function buildStructureBillboards(cam, structureCells, items) {
  const pending = new Set(structureCells.keys());
  while (pending.size) {
    const firstKey = pending.values().next().value;
    pending.delete(firstKey);
    const first = structureCells.get(firstKey);
    if (!first) continue;
    const component = [first];
    const queue = [first];
    while (queue.length) {
      const cur = queue.shift();
      const neighbours = [[cur.x - 1, cur.y], [cur.x + 1, cur.y], [cur.x, cur.y - 1], [cur.x, cur.y + 1]];
      for (const [nx, ny] of neighbours) {
        const key = `${nx},${ny}`;
        if (!pending.has(key)) continue;
        const next = structureCells.get(key);
        if (!next || Math.abs(next.elev - first.elev) > 0.001) continue;
        pending.delete(key);
        component.push(next);
        queue.push(next);
      }
    }
    const minX = Math.min(...component.map((v) => v.x));
    const maxX = Math.max(...component.map((v) => v.x));
    const minY = Math.min(...component.map((v) => v.y));
    const maxY = Math.max(...component.map((v) => v.y));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, (maxX - minX + 1) * TILE_SIZE);
    canvas.height = Math.max(1, (maxY - minY + 1) * TILE_SIZE);
    const cc = canvas.getContext("2d");
    cc.imageSmoothingEnabled = false;
    for (const cell of component) {
      for (const entry of cell.entries) {
        const src = entry.source;
        if (!src) continue;
        cc.save();
        cc.globalAlpha = Number(entry.alpha ?? 1);
        cc.drawImage(src.img, src.sx, src.sy, src.sw, src.sh,
          (cell.x - minX) * TILE_SIZE, (cell.y - minY) * TILE_SIZE, TILE_SIZE, TILE_SIZE);
        cc.restore();
      }
    }
    const wx = ((minX + maxX + 1) / 2) * TILE_SIZE;
    const wy = (maxY + 1) * TILE_SIZE;
    const anchor = project(cam, wx, wy, first.elev);
    if (!anchor) continue;
    items.push({
      type: "billboard", x: minX, y: maxY, elev: first.elev, anchor,
      entry: { source: { img: canvas, sx: 0, sy: 0, sw: canvas.width, sh: canvas.height }, alpha: 1, tag: TAG.STRUCTURE },
      depth: anchor.depth, tags: [TAG.STRUCTURE], structureBounds: { minX, minY, maxX, maxY },
    });
  }
}

function objectMaterialSource(ctx, obj, explicitMaterial = null) {
  const m = explicitMaterial || obj?.material;
  if (!m) return null;
  let source = null;
  if (m.kind === "autotile") {
    const name = String(m.graphic || "").trim();
    const pattern = Number(m.autotile_pattern) || 0;
    let img = null;
    if (name && String(obj?.source_key || m?.source_key || "").startsWith("extra:")) img = extraAutotileCanvas(name, pattern);
    if (!img && Number(m.tileset_id)) {
      const idx = Math.floor((Number(m.tile_id) || 0) / 48) - 1;
      img = autotileCanvas(Number(m.tileset_id), Math.max(0, idx), pattern);
    }
    if (img) source = { img, sx: 0, sy: 0, sw: TILE_SIZE, sh: TILE_SIZE };
  } else {
    const img = state.preview.tilesetImages.get(Number(m.tileset_id));
    if (img) {
      const r = m.src_rect || {};
      source = {
        img, sx: Number(r.x) || 0, sy: Number(r.y) || 0,
        sw: Math.max(1, Number(r.w) || TILE_SIZE),
        sh: Math.max(1, Number(r.h) || TILE_SIZE),
      };
    }
  }
  if (!source) return null;

  // Canonical compiled materials store Maker Studio runtime semantics:
  // saturation=100 and lighting=0 are neutral. Keep the preview on that exact
  // convention instead of re-detecting the editor colour model here.
  const rotation = normalizeRotation(m.rotation);
  const flipH = !!m.flip_h, flipV = !!m.flip_v;
  const hue = Number(m.hue) || 0;
  const saturation = m.saturation == null ? 100 : Number(m.saturation);
  const brightness = 100 + (Number(m.lighting) || 0);
  if (!rotation && !flipH && !flipV && !hue && saturation === 100 && brightness === 100) return source;
  const key = `compiled:${m.kind}:${m.tileset_id}:${m.graphic}:${m.tile_id}:${m.autotile_tid}:${rotation}:${flipH?1:0}:${flipV?1:0}:${hue}:${saturation}:${brightness}`;
  if (state.preview.transformedSourceCache.has(key)) return state.preview.transformedSourceCache.get(key);
  const canvas = document.createElement("canvas");
  canvas.width = TILE_SIZE; canvas.height = TILE_SIZE;
  const c = canvas.getContext("2d");
  c.imageSmoothingEnabled = false;
  c.save();
  c.translate(TILE_SIZE / 2, TILE_SIZE / 2);
  c.rotate(rotation * Math.PI / 180);
  c.scale(flipH ? -1 : 1, flipV ? -1 : 1);
  c.filter = `hue-rotate(${hue}deg) saturate(${Math.max(0, saturation)}%) brightness(${Math.max(5, brightness)}%)`;
  c.drawImage(source.img, source.sx, source.sy, source.sw, source.sh, -TILE_SIZE / 2, -TILE_SIZE / 2, TILE_SIZE, TILE_SIZE);
  c.restore();
  const out = { img: canvas, sx: 0, sy: 0, sw: TILE_SIZE, sh: TILE_SIZE };
  state.preview.transformedSourceCache.set(key, out);
  return out;
}


function meshFaceMaterialSource(ctx, face) {
  const base=objectMaterialSource(ctx,{source_key:face?.source_key||"",material:face?.material||null},face?.material||null);
  if(!base || face?.material_repeat===false)return base;
  let tilesWide=1,tilesHigh=1;
  if(Array.isArray(face?.vertices)&&face.vertices.length===4){
    const dist=(a,b)=>Math.hypot((a?.[0]||0)-(b?.[0]||0),(a?.[1]||0)-(b?.[1]||0),(a?.[2]||0)-(b?.[2]||0));
    tilesWide=Math.max(1,Math.round(dist(face.vertices[0],face.vertices[1])));
    tilesHigh=Math.max(1,Math.round(dist(face.vertices[0],face.vertices[3])));
  }else{
    const dx=Math.abs((Number(face.x1)||0)-(Number(face.x0)||0)),dy=Math.abs((Number(face.y1)||0)-(Number(face.y0)||0));
    tilesWide=face.kind==="top" ? Math.max(1,Math.round(dx)) : Math.max(1,Math.round(Math.max(dx,dy)));
    tilesHigh=face.kind==="top" ? Math.max(1,Math.round(dy)) : Math.max(1,Math.round(Math.abs((Number(face.z1)||0)-(Number(face.z0)||0))));
  }
  if(tilesWide===1 && tilesHigh===1)return base;
  const key=`meshrepeat:${materialSignature(face.material)}:${tilesWide}x${tilesHigh}`;
  if(state.preview.transformedSourceCache.has(key))return state.preview.transformedSourceCache.get(key);
  const cv=document.createElement("canvas");cv.width=tilesWide*TILE_SIZE;cv.height=tilesHigh*TILE_SIZE;const cc=cv.getContext("2d");cc.imageSmoothingEnabled=false;
  for(let y=0;y<tilesHigh;y++)for(let x=0;x<tilesWide;x++)cc.drawImage(base.img,base.sx,base.sy,base.sw,base.sh,x*TILE_SIZE,y*TILE_SIZE,TILE_SIZE,TILE_SIZE);
  const out={img:cv,sx:0,sy:0,sw:cv.width,sh:cv.height};state.preview.transformedSourceCache.set(key,out);return out;
}

function appendMeshFaceItems(ctx, geo, cam, items, collisionEdges, minX,maxX,minY,maxY){
  const step=Number(geo?.height_step)||DEFAULT_STEP;
  for(const face of geo?.mesh_faces||[]){
    let poly=null,fx0=0,fx1=0,fy0=0,fy1=0;
    if(Array.isArray(face?.vertices)&&face.vertices.length===4){
      const vs=face.vertices;fx0=Math.min(...vs.map(v=>Number(v?.[0])||0));fx1=Math.max(...vs.map(v=>Number(v?.[0])||0));fy0=Math.min(...vs.map(v=>Number(v?.[1])||0));fy1=Math.max(...vs.map(v=>Number(v?.[1])||0));
      if(fx1<minX||fx0>maxX+1||fy1<minY||fy0>maxY+1)continue;
      poly=vs.map(v=>project(cam,(Number(v?.[0])||0)*TILE_SIZE,(Number(v?.[1])||0)*TILE_SIZE,(Number(v?.[2])||0)*step));
    }else{
      fx0=Math.min(Number(face.x0)||0,Number(face.x1)||0);fx1=Math.max(Number(face.x0)||0,Number(face.x1)||0);fy0=Math.min(Number(face.y0)||0,Number(face.y1)||0);fy1=Math.max(Number(face.y0)||0,Number(face.y1)||0);
      if(fx1<minX||fx0>maxX+1||fy1<minY||fy0>maxY+1)continue;
      if(face.kind==="top") poly=makeRectTopPoly(cam,face.x0,face.y0,face.x1-1,face.y1-1,(Number(face.z1)||0)*step);
      else {const z0=(Number(face.z0)||0)*step,z1=(Number(face.z1)||0)*step;const ax=(Number(face.x0)||0)*TILE_SIZE,ay=(Number(face.y0)||0)*TILE_SIZE;const bx=(Number(face.x1)||0)*TILE_SIZE,by=(Number(face.y1)||0)*TILE_SIZE;poly=[project(cam,ax,ay,z1),project(cam,bx,by,z1),project(cam,bx,by,z0),project(cam,ax,ay,z0)];}
    }
    if(!validPoly(poly))continue;
    const isTop=face.kind==="top"||face.surface==="top";
    const item={type:isTop?"meshTop":"meshFace",meshFace:face,edge:face.edge,points:poly,source:meshFaceMaterialSource(ctx,face),depth:polyDepth(poly),tags:[]};items.push(item);
  }
}

function appendObjectItems(ctx, mapId, geo, cam, items, collisionEdges, minX, maxX, minY, maxY) {
  const step = Number(geo?.height_step) || DEFAULT_STEP;
  const objects = sceneObjects(geo);
  const connectIndex = new Map();
  for (const obj of objects) {
    if (obj?.type !== "cube" || obj?.components?.connect_neighbors !== true) continue;
    const r = objectRect(obj);
    for (let y = r.y0; y <= r.y1; y++) for (let x = r.x0; x <= r.x1; x++) {
      const k = `${x},${y}`;
      if (!connectIndex.has(k)) connectIndex.set(k, []);
      connectIndex.get(k).push(obj);
    }
  }
  const connected = (obj, x, y, baseZ, topZ) => (connectIndex.get(`${x},${y}`) || []).some((other) => {
    if (other === obj || other.category !== obj.category) return false;
    const otherBase = (Number(other.anchor_z) || 0) * step;
    const otherTop = otherBase + (Number(other.height) || 0) * step;
    return Math.abs(otherBase - baseZ) < 0.01 && Math.abs(otherTop - topZ) < 0.01;
  });

  for (const obj of objects) {
    if (obj?.render === false) continue;
    const r = objectRect(obj);
    if (r.x1 < minX || r.x0 > maxX || r.y1 < minY || r.y0 > maxY) continue;
    const baseZ = (Number(obj.anchor_z) || 0) * step;
    const source = objectMaterialSource(ctx, obj);
    const faceSource = (edge) => objectMaterialSource(ctx, obj, obj?.face_materials?.[edge]) || source;
    const isCube = obj.type === "cube";
    const topZ = isCube ? baseZ + (Number(obj.height) || 0) * step : baseZ;
    const comps = obj.components || {};

    if (!isCube || comps.cap !== false) {
      const top = makeRectTopPoly(cam, r.x0, r.y0, r.x1, r.y1, topZ);
      if (validPoly(top)) {
        items.push({
          type: "objectTop", obj, points: top, source: faceSource("top"),
          depth: polyDepth(top), tags: [], anchor: { x: top[0].x, y: top[0].y },
        });
      }
    }

    if (isCube && topZ > baseZ) {
      for (const edge of ["south", "north", "east", "west"]) {
        if (comps.connect_neighbors === true) {
          let nx = r.x0, ny = r.y0;
          if (edge === "south") ny = r.y1 + 1;
          if (edge === "north") ny = r.y0 - 1;
          if (edge === "east") nx = r.x1 + 1;
          if (edge === "west") nx = r.x0 - 1;
          if (connected(obj, nx, ny, baseZ, topZ)) continue;
        }
        const face = makeRectFacePoly(cam, r.x0, r.y0, r.x1, r.y1, edge, baseZ, topZ);
        if (validPoly(face)) items.push({ type: "objectFace", obj, edge, points: face, source: faceSource(edge), depth: polyDepth(face), tags: [] });
      }
      if (obj.collision !== "none") {
        const topEdge = makeRectFacePoly(cam, r.x0, r.y0, r.x1, r.y1, "south", topZ, topZ);
        if (validPoly(topEdge)) collisionEdges.push({ x: r.x0, y: r.y1, edge: "south", points: [topEdge[0], topEdge[1]] });
      }
    } else if (!isCube && obj.collision !== "none") {
      const topEdge = makeRectFacePoly(cam, r.x0, r.y0, r.x1, r.y1, "south", topZ, topZ);
      if (validPoly(topEdge)) collisionEdges.push({ x: r.x0, y: r.y1, edge: "south", points: [topEdge[0], topEdge[1]] });
    }
  }
}


function buildPreviewScene(ctx, mapId, geo, cam) {
  const info = ctx.map.info(mapId);
  if (!info) return { items: [], tops: [], collisionEdges: [] };
  const layers = visibleLayers(ctx, mapId);
  const tilesetId = mapTilesetId(info, mapId);
  const radius = state.preview.radius;
  const fx = Math.round(state.preview.focusX ?? info.width / 2);
  const fy = Math.round(state.preview.focusY ?? info.height / 2);
  const minX = state.preview.fullMap ? 0 : Math.max(0, fx - radius);
  const maxX = state.preview.fullMap ? info.width - 1 : Math.min(info.width - 1, fx + radius);
  const minY = state.preview.fullMap ? 0 : Math.max(0, fy - radius);
  const maxY = state.preview.fullMap ? info.height - 1 : Math.min(info.height - 1, fy + radius);
  const items = [];
  const tops = [];
  const collisionEdges = [];
  const cellCache = state.preview.cellEntryCache;
  const structureCells = new Map();

  for (let y = minY; y <= maxY; y++) {
    for (let x = minX; x <= maxX; x++) {
      const elev = effectiveHeight(geo, mapId, x, y);
      const top = makeTopPoly(cam, x, y, elev);
      if (!validPoly(top)) continue;
      const key = cellCacheKey(mapId, x, y);
      let entries = cellCache.get(key);
      if (!entries) {
        entries = cellTileEntries(ctx, mapId, x, y, layers, tilesetId);
        cellCache.set(key, entries);
      }
      const tags = [...new Set(entries.all.map((e) => e.tag).filter(Boolean))];
      const topItem = {
        type: "top",
        x, y, elev,
        points: top,
        depth: polyDepth(top),
        source: composeGroundSource(surfaceGroundEntries(entries, elev, hasExplicitCell(geo, x, y))),
        hasGroundEntries: surfaceGroundEntries(entries, elev, hasExplicitCell(geo, x, y)).length > 0,
        hasAnyEntries: entries.all.length > 0,
        tags,
      };
      items.push(topItem);
      tops.push(topItem);

      // Physical height field -> automatically generated cliff faces.
      const neighbours = [
        ["north", x, y - 1], ["east", x + 1, y], ["south", x, y + 1], ["west", x - 1, y],
      ];
      for (const [edge, nx, ny] of neighbours) {
        const low = (nx < 0 || ny < 0 || nx >= geo.width || ny >= geo.height) ? 0 : effectiveHeight(geo, mapId, nx, ny);
        if (elev <= low + 0.001) continue;
        const source = previewCliffSource(ctx, mapId, x, y, edge, layers, tilesetId, cellCache);
        const steps = Math.max(1, Math.ceil((elev - low) / DEFAULT_STEP));
        for (let i = 0; i < steps; i++) {
          const z0 = low + (elev - low) * (i / steps);
          const z1 = low + (elev - low) * ((i + 1) / steps);
          const face = makeFacePoly(cam, x, y, edge, z0, z1);
          if (!validPoly(face)) continue;
          items.push({ type: "face", x, y, edge, points: face, depth: polyDepth(face), source, step: i });
        }
        const edgeTop = makeFacePoly(cam, x, y, edge, elev - 0.01, elev);
        if (validPoly(edgeTop)) collisionEdges.push({ x, y, edge, points: [edgeTop[0], edgeTop[1]] });
      }

      // NDSStair: true inclined top face. Connect to north/south physical levels.
      for (const entry of entries.stairs) {
        const southZ = (y + 1 < geo.height) ? effectiveHeight(geo, mapId, x, y + 1) : elev;
        let northZ = (y - 1 >= 0) ? effectiveHeight(geo, mapId, x, y - 1) : elev + runtimeConfig.stairHeight;
        if (Math.abs(northZ - southZ) < 0.01) northZ = southZ + runtimeConfig.stairHeight;
        const ramp = makeRampPoly(cam, x, y, southZ, northZ);
        if (validPoly(ramp)) {
          const item = { type: "stair", x, y, points: ramp, source: entry.source, alpha: entry.alpha, depth: polyDepth(ramp), tags: [TAG.STAIR] };
          items.push(item);
          // A stair is also an editable/hittable physical surface.
          tops.push({ ...item, elev: Math.max(southZ, northZ) });
        }
      }

      // NDSRoofPlane: horizontal geometry at explicit roof elevation.
      for (const entry of entries.roofPlanes) {
        const z = elev + tagHeightOffset(entry.tag);
        const poly = makeTopPoly(cam, x, y, z);
        if (validPoly(poly)) items.push({ type: "roofPlane", x, y, points: poly, source: entry.source, alpha: entry.alpha, depth: polyDepth(poly), tags: [entry.tag] });
      }

      // NDSWallPlane: world-fixed north-edge quad, unlike a camera billboard.
      for (const entry of entries.wallPlanes) {
        const wallH = runtimeConfig.stairHeight;
        const poly = makeFacePoly(cam, x, y, "north", elev, elev + wallH);
        if (validPoly(poly)) items.push({ type: "wallPlane", x, y, points: poly, source: entry.source, alpha: entry.alpha, depth: polyDepth(poly), tags: [entry.tag] });
      }

      // Camera-facing categories: NDSBillboard / Structure / Overlay / protected
      // Roofs. This is deliberately different from WallPlane so rotating the
      // preview shows which assets are true geometry and which remain 2D art.
      for (const entry of entries.billboards) {
        const objectElev = elev + tagHeightOffset(entry.tag);
        if (entry.tag === TAG.STRUCTURE) {
          const key = `${x},${y}`;
          let cell = structureCells.get(key);
          if (!cell) { cell = { x, y, elev: objectElev, entries: [] }; structureCells.set(key, cell); }
          cell.entries.push(entry);
          continue;
        }
        const anchor = project(cam, (x + 0.5) * TILE_SIZE, (y + 1) * TILE_SIZE, objectElev);
        if (!anchor) continue;
        items.push({ type: "billboard", x, y, elev: objectElev, entry, anchor, depth: anchor.depth, tags: [entry.tag] });
      }
    }
  }

  buildStructureBillboards(cam, structureCells, items);
  appendMeshFaceItems(ctx, geo, cam, items, collisionEdges, minX, maxX, minY, maxY);
  appendObjectItems(ctx, mapId, geo, cam, items, collisionEdges, minX, maxX, minY, maxY);
  appendEventItems(ctx, mapId, geo, cam, items, minX, maxX, minY, maxY);

  if (state.preview.showPlayer) {
    const px = Math.round(state.preview.focusX);
    const py = Math.round(state.preview.focusY);
    const pe = effectiveHeight(geo, mapId, px, py);
    const anchor = project(cam, (px + 0.5) * TILE_SIZE, (py + 1) * TILE_SIZE, pe);
    if (anchor) items.push({ type: "player", x: px, y: py, elev: pe, anchor, depth: anchor.depth });
  }
  items.sort((a, b) => b.depth - a.depth);
  // Hit test near to far.
  tops.sort((a, b) => a.depth - b.depth);
  return { items, tops, collisionEdges };
}

function drawTagBadge(c, item) {
  if (!state.preview.showTags || !item?.tags?.length) return;
  const tags = [...new Set(item.tags.filter((t) => Number(t) > 0))];
  if (!tags.length) return;
  let x = null, y = null;
  if (item.anchor) { x = item.anchor.x; y = item.anchor.y - 8; }
  else if (item.points?.length) {
    x = item.points.reduce((a, p) => a + p.x, 0) / item.points.length;
    y = item.points.reduce((a, p) => a + p.y, 0) / item.points.length;
  }
  if (!Number.isFinite(x) || !Number.isFinite(y)) return;
  const text = tags.map((t) => `${t}:${tagName(t).replace(/^NDS/, "")}`).join("/");
  c.save();
  c.font = "9px system-ui,sans-serif";
  c.textAlign = "center";
  c.textBaseline = "middle";
  const w = Math.min(190, c.measureText(text).width + 8);
  c.fillStyle = "rgba(12,14,19,0.82)";
  c.fillRect(x - w / 2, y - 7, w, 14);
  c.fillStyle = "rgba(255,255,255,0.94)";
  c.fillText(text, x, y, w - 4);
  c.restore();
}

function drawPreviewItem(c, item) {
  if (item.type === "meshTop" || item.type === "meshFace") {
    const ok = drawTexturedQuad(c, item.source, item.points, item.type === "meshTop" ? 1 : 0.96);
    if (!ok) fillPoly(c, item.points, item.type === "meshTop" ? "rgba(92,125,78,0.96)" : "rgba(92,63,42,0.96)");
    if (state.preview.showWire) fillPoly(c, item.points, null, "rgba(255,255,255,0.18)", 0.75);
    return;
  }
  if (item.type === "top") {
    state.preview.assetStats.groundCells++;
    const drew = item.source ? drawTexturedQuad(c, item.source, item.points, 1) : false;
    if (drew) state.preview.assetStats.groundTextured++;
    if (!drew) {
      if (item.hasGroundEntries) {
        state.preview.assetStats.missingSources++;
        state.preview.assetStats.groundMissing++;
        fillPoly(c, item.points, item.elev > 0 ? "rgba(136,104,62,0.42)" : "rgba(86,145,72,0.28)");
        const cx = item.points.reduce((a,p)=>a+p.x,0)/item.points.length;
        const cy = item.points.reduce((a,p)=>a+p.y,0)/item.points.length;
        c.save(); c.fillStyle = "rgba(255,210,95,0.92)"; c.font = "9px system-ui,sans-serif"; c.textAlign = "center";
        c.fillText("tile?", cx, cy); c.restore();
      } else if (item.elev > 0.001) {
        // Keep editable physical geometry visible without inventing fake tile art.
        fillPoly(c, item.points, "rgba(90,150,100,0.12)");
      }
    }
    if (state.preview.showWire) fillPoly(c, item.points, null, "rgba(255,255,255,0.18)", 0.75);
    drawTagBadge(c, item);
    return;
  }
  if (item.type === "face") {
    const ok = drawTexturedQuad(c, item.source, item.points, 0.96);
    if (!ok) {
      const side = item.edge === "north" ? "rgba(72,52,40,0.94)" :
        item.edge === "east" || item.edge === "west" ? "rgba(92,63,42,0.94)" : "rgba(112,76,48,0.96)";
      fillPoly(c, item.points, side);
    }
    if (state.preview.showWire) fillPoly(c, item.points, null, "rgba(255,255,255,0.16)", 0.75);
    drawTagBadge(c, item);
    return;
  }
  if (item.type === "stair" || item.type === "roofPlane" || item.type === "wallPlane") {
    const ok = drawTexturedQuad(c, item.source, item.points, Number(item.alpha ?? 1));
    if (!ok) {
      const fallback = item.type === "stair" ? "rgba(168,148,125,0.92)" :
        item.type === "roofPlane" ? "rgba(120,105,125,0.90)" : "rgba(108,78,58,0.94)";
      fillPoly(c, item.points, fallback);
    }
    if (state.preview.showWire) fillPoly(c, item.points, null, "rgba(255,255,255,0.24)", 0.9);
    drawTagBadge(c, item);
    return;
  }
  if (item.type === "objectTop" || item.type === "objectFace") {
    const ok = drawTexturedQuad(c, item.source, item.points, 1);
    if (!ok) {
      const cat = item.obj?.category || "prop";
      const base = (CATEGORY_FALLBACK_COLORS[cat] || CATEGORY_FALLBACK_COLORS.prop);
      fillPoly(c, item.points, base);
    }
    if (item.type === "objectFace") {
      // Same shading as the runtime plugin (NDS_OBJECT_FRONT_SIDE/SIDE_SHADE).
      const shade = item.edge === "south" ? 0.094 : (item.edge === "east" || item.edge === "west") ? 0.18 : 0;
      if (shade) fillPoly(c, item.points, `rgba(0,0,0,${shade})`);
    }
    const isSelected = item.obj && state.objSelected != null && Number(item.obj.id) === Number(state.objSelected);
    if (state.preview.showWire) fillPoly(c, item.points, null, "rgba(200,180,255,0.30)", 0.9);
    if (isSelected) fillPoly(c, item.points, null, "rgba(80,220,255,0.95)", 2.5);
    if (item.type === "objectTop" && item.obj) {
      const label = `${isSelected ? "▸ " : ""}${item.obj.type.toUpperCase()}·H${item.obj.height}·A${item.obj.anchor_z}·${item.obj.collision}`;
      c.save();
      c.font = "9px system-ui,sans-serif";
      c.textAlign = "center";
      const cx = item.points.reduce((a, p) => a + p.x, 0) / item.points.length;
      const cy = item.points.reduce((a, p) => a + p.y, 0) / item.points.length;
      const w = Math.min(160, c.measureText(label).width + 8);
      c.fillStyle = "rgba(12,14,19,0.82)";
      c.fillRect(cx - w / 2, cy - 7, w, 14);
      c.fillStyle = "rgba(235,225,255,0.95)";
      c.fillText(label, cx, cy, w - 4);
      c.restore();
    }
    return;
  }
  if (item.type === "billboard") {
    const src = item.entry.source;
    if (!src) return;
    const scale = Math.max(0.2, Math.min(2.5, item.anchor.scale));
    const w = src.sw * scale;
    const h = src.sh * scale;
    c.save();
    c.imageSmoothingEnabled = false;
    c.globalAlpha *= Number(item.entry.alpha ?? 1);
    c.drawImage(src.img, src.sx, src.sy, src.sw, src.sh, item.anchor.x - w / 2, item.anchor.y - h, w, h);
    c.restore();
    drawTagBadge(c, item);
    return;
  }
  if (item.type === "event") {
    const p = item.anchor;
    const src = item.source;
    const scale = Math.max(0.25, Math.min(2.4, p.scale));
    c.save();
    c.imageSmoothingEnabled = false;
    c.globalAlpha *= Number(item.alpha ?? 1);
    if (src) {
      const w = src.sw * scale, h = src.sh * scale;
      c.drawImage(src.img, src.sx, src.sy, src.sw, src.sh, p.x - w / 2, p.y - h, w, h);
    } else {
      c.fillStyle = "rgba(100,205,255,0.9)";
      c.fillRect(p.x - 4, p.y - 12, 8, 12);
    }
    c.restore();
    if (state.preview.showTags && item.name) {
      c.save(); c.font = "9px system-ui,sans-serif"; c.textAlign = "center";
      c.fillStyle = "rgba(255,255,255,0.88)"; c.fillText(item.name, p.x, p.y + 10); c.restore();
    }
    return;
  }
  if (item.type === "player") {
    const p = item.anchor;
    const scale = Math.max(0.55, Math.min(1.65, p.scale));
    c.save();
    c.strokeStyle = "rgba(0,0,0,0.7)";
    c.fillStyle = "rgba(255,240,220,0.96)";
    c.lineWidth = 2;
    c.beginPath();
    c.arc(p.x, p.y - 23 * scale, 7 * scale, 0, Math.PI * 2);
    c.fill(); c.stroke();
    c.fillStyle = "rgba(232,118,132,0.96)";
    c.fillRect(p.x - 6 * scale, p.y - 17 * scale, 12 * scale, 16 * scale);
    c.strokeRect(p.x - 6 * scale, p.y - 17 * scale, 12 * scale, 16 * scale);
    c.restore();
  }
}
function drawPreviewHighlight(c, cell, kind = "hover") {
  if (!cell?.points) return;
  const stroke = kind === "hover" ? "rgba(255,235,80,0.98)" : "rgba(80,220,255,0.98)";
  fillPoly(c, cell.points, kind === "hover" ? "rgba(255,235,80,0.12)" : null, stroke, 2.2);
}

function schedulePanelRefresh() {
  if (state.dragging || state.preview.dragging) return;
  if (state.panelRaf || !state.panelRefresh) return;
  state.panelRaf = requestAnimationFrame(() => {
    state.panelRaf = 0;
    try { state.panelRefresh?.(); } catch (_) {}
  });
}

function scheduleTopDownPreview(ctx) {
  if (!state.topDownCanvas || state.preview.topDownRaf) return;
  state.preview.topDownRaf = requestAnimationFrame(() => {
    state.preview.topDownRaf = 0;
    try { v2RenderTopDown(ctx, state.topDownCanvas); } catch (err) { ctx.log.warn("2.5D Geometry: top-down refresh failed", err); }
  });
}

function schedulePreview(ctx) {
  state.preview.rerender = true;
  scheduleTopDownPreview(ctx);
  if (state.preview.raf) return;
  state.preview.raf = requestAnimationFrame(() => {
    state.preview.raf = 0;
    if (!state.preview.rerender) return;
    state.preview.rerender = false;
    void renderPreview(ctx);
  });
}

async function renderPreview(ctx) {
  if (state.preview.rendering) { state.preview.rerender = true; return; }
  const canvas = state.preview.canvas;
  if (!canvas) return;
  const mapId = ctx.editor.activeMapId();
  if (mapId == null) return;
  const geo = await ensureMap(ctx, mapId);
  if (!geo) return;
  state.preview.rendering = true;
  try {
    ensurePreviewFocus(ctx, mapId);
    const infoNow = ctx.map.info(mapId);
    if (infoNow && mapTilesetId(infoNow, mapId) !== state.preview.tilesetId || !state.preview.tilesetImage) {
      await ensurePreviewResources(ctx, mapId);
    }
    await ensureVisiblePreviewResources(ctx, mapId);
    const c = canvas.getContext("2d");
    // V2: render at the actual viewport size instead of stretching a 640x480
    // thumbnail. Large/Split views therefore keep crisp pixels and readable
    // elevation geometry.
    const cssW = Math.round(canvas.clientWidth || 640);
    const cssH = Math.round(canvas.clientHeight || 480);
    const W = canvas.width = Math.max(640, Math.min(1400, cssW));
    const H = canvas.height = Math.max(480, Math.min(900, cssH));
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.imageSmoothingEnabled = false;
    c.clearRect(0, 0, W, H);
    c.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--canvas-bg").trim() || "#1d2027";
    c.fillRect(0, 0, W, H);

    const cam = cameraFor(ctx, geo, W, H);
    state.preview.assetStats.standardAutotiles = [...state.preview.autotileImagesByTileset.values()].reduce((n, arr) => n + (arr || []).filter(Boolean).length, 0);
    state.preview.assetStats.extraAutotiles = [...state.preview.autotileImagesByName.values()].filter(Boolean).length;
    state.preview.assetStats.regularTilesets = [...state.preview.tilesetImages.values()].filter(Boolean).length;
    state.preview.assetStats.missingSources = 0;
    state.preview.assetStats.groundCells = 0;
    state.preview.assetStats.groundTextured = 0;
    state.preview.assetStats.groundMissing = 0;
    const scene = buildPreviewScene(ctx, mapId, geo, cam);
    trimCellEntryCache();
    for (const item of scene.items) drawPreviewItem(c, item);
    v2DrawPreviewHeightMarkers(c, scene);

    if (state.preview.showCollision) {
      c.save();
      c.strokeStyle = "rgba(255,70,70,0.92)";
      c.lineWidth = 1.5;
      c.beginPath();
      for (const edge of scene.collisionEdges) {
        const [a, b] = edge.points;
        c.moveTo(a.x, a.y); c.lineTo(b.x, b.y);
      }
      c.stroke();
      c.restore();
    }

    const focusCell = scene.tops.find((t) => t.x === Math.round(state.preview.focusX) && t.y === Math.round(state.preview.focusY));
    if (focusCell) drawPreviewHighlight(c, focusCell, "focus");
    if (state.preview.hovered) {
      const hoverCell = scene.tops.find((t) => t.x === state.preview.hovered.x && t.y === state.preview.hovered.y);
      if (hoverCell) drawPreviewHighlight(c, hoverCell, "hover");
    }
    state.preview.hitCells = scene.tops;
    state.preview.lastMapId = mapId;
    updatePreviewStatus(ctx, geo);
  } catch (err) {
    ctx.log.error(err);
    const c = canvas.getContext("2d");
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.fillStyle = "#2a1f23"; c.fillRect(0, 0, canvas.width, canvas.height);
    c.fillStyle = "#ffb9c2"; c.font = "14px sans-serif";
    c.fillText(`2.5D preview error: ${err?.message || err}`, 16, 28);
  } finally {
    state.preview.rendering = false;
    if (state.preview.rerender) schedulePreview(ctx);
  }
}

function updatePreviewStatus(ctx, geo) {
  if (!state.preview.status) return;
  const hover = state.preview.hovered;
  const fx = Math.round(state.preview.focusX);
  const fy = Math.round(state.preview.focusY);
  const mapId = ctx.editor.activeMapId();
  const focusLevel = effectiveLevel(geo, mapId, fx, fy);
  let hoverText = "";
  if (hover) {
    const info = ctx.map.info(mapId);
    const layers = visibleLayers(ctx, mapId);
    const entries = info ? cellTileEntries(ctx, mapId, hover.x, hover.y, layers, mapTilesetId(info, mapId)) : null;
    const tags = entries ? [...new Set(entries.all.map((e) => e.tag).filter(Boolean))] : [];
    const tagText = tags.length ? ` · ${tags.map((t) => tagName(t)).join("+")}` : "";
    hoverText = ` · Cursor ${hover.x},${hover.y} L${effectiveLevel(geo, mapId, hover.x, hover.y)}${tagText}`;
  }
  const ast = state.preview.assetStats || {};
  const ls = state.preview.layerStats || { native: 3, extended: 0 };
  const ms=geo?.mesh_compiler?.stats||{};
  const gfx = ` · GFX TS:${ast.regularTilesets || 0}(${ast.usedTilesetIds || "?"}) AT:${ast.standardAutotiles || 0} +EX:${ast.extraAutotiles || 0} · Layers ${ls.native || 0}+${ls.extended || 0} · Ground ${ast.groundTextured || 0}/${ast.groundCells || 0} miss:${ast.groundMissing || 0} · Mesh ${ms.faces||0} faces/${ms.cells||0} cells · Color:${detectColorModel(ctx)}${state.preview.ignoreColorTransforms ? "/RAW" : ""} · Layerα:auto`;
  state.preview.status.textContent = `Map${pad3(mapId)} · Cam ${fx},${fy} · Z ${focusLevel * (geo.height_step || DEFAULT_STEP)}px · Pitch ${state.preview.angle.toFixed(0)}° · Yaw ${state.preview.yaw.toFixed(0)}°${gfx}${hoverText}`;
}

function hitPreviewCell(canvas, clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const px = (clientX - rect.left) * (canvas.width / Math.max(1, rect.width));
  const py = (clientY - rect.top) * (canvas.height / Math.max(1, rect.height));
  for (const cell of state.preview.hitCells) {
    if (pointInPoly(px, py, cell.points)) return cell;
  }
  return null;
}

function previewPaint(ctx, cell, ev) {
  if (!cell) return;
  const mapId = ctx.editor.activeMapId();
  if (mapId == null) return;
  const geo = state.maps.get(mapId);
  if (!geo) return;
  if (state.workspaceMode === "scene") {
    const activeTool = ev?.altKey ? "erase" : state.sceneTool;
    const key = `${cell.x},${cell.y}:${activeTool}`;
    if (state.preview.visited.has(key)) return;
    state.preview.visited.add(key);
    if (activeTool === "erase") eraseGeometryAtCell(ctx, mapId, cell.x, cell.y, null);
    else runSimpleSceneTool(ctx, mapId, cell.x, cell.y, null);
    return;
  }
  if (state.objTool || state.workspaceMode === "object") {
    if (ev.altKey) {
      const key = `${cell.x},${cell.y}`;
      if (!state.preview.visited.has(key)) {
        state.preview.visited.add(key);
        removeObjectsAt(ctx, geo, mapId, cell.x, cell.y);
      }
    } else {
      const hit = findObjectAt(geo, cell.x, cell.y);
      if (hit && state.preview.objJustDown) { selectObject(ctx, geo, hit, mapId); return; }
      if (state.preview.objJustDown) state.objSelected = null;
      if (!state.objStart) state.objStart = { x: cell.x, y: cell.y };
      state.objCurrent = { x: cell.x, y: cell.y };
    }
    ctx.editor.requestRedraw();
    schedulePreview(ctx);
    return;
  }
  const mode = resolvePaintMode(ev);
  const key = `${cell.x},${cell.y}:${mode}`;
  if (state.preview.visited.has(key)) return;
  state.preview.visited.add(key);
  applyBrushToCell(ctx, geo, mapId, cell.x, cell.y, mode);
  ctx.editor.requestRedraw();
  schedulePreview(ctx);
}

function movePreviewFocus(ctx, dx, dy) {
  const mapId = ctx.editor.activeMapId();
  const info = mapId == null ? null : ctx.map.info(mapId);
  if (!info) return;
  state.preview.focusX = Math.max(0, Math.min(info.width - 1, Math.round((state.preview.focusX ?? 0) + dx)));
  state.preview.focusY = Math.max(0, Math.min(info.height - 1, Math.round((state.preview.focusY ?? 0) + dy)));
  const geo = state.maps.get(mapId); if (geo) persistPreviewPrefs(geo);
  schedulePreview(ctx);
}

async function chooseCliffTexture(ctx) {
  if (!ctx.selectors?.pickGraphic) {
    ctx.ui.showToast({ message: "Tu Maker Studio no expone el selector gráfico requerido.", level: "warn" });
    return;
  }
  const picked = await ctx.selectors.pickGraphic("Tilesets", {
    allowTileSelect: true,
    fields: ["sheetCols", "sheetRows"],
    title: "2.5D Geometry · textura de cliff",
  });
  if (!picked?.srcRect?.w) return;
  const list = ctx.tileset.list();
  const match = list.find((t) => String(t.tilesetName || "").toLowerCase() === String(picked.name || "").toLowerCase());
  if (!match) {
    ctx.ui.showToast({ message: "No pude resolver el tileset seleccionado.", level: "warn" });
    return;
  }
  await ensureTilesetResourceSet(ctx, match.id);
  state.preview.cliffSource = {
    tileset_id: match.id,
    graphic: picked.name,
    src_rect: { x: picked.srcRect.x, y: picked.srcRect.y, w: 32, h: 32 },
  };
  const mapId = ctx.editor.activeMapId();
  const geo = mapId == null ? null : state.maps.get(mapId);
  if (geo) persistPreviewPrefs(geo);
  schedulePreview(ctx);
}

async function chooseObjectTexture(ctx, render) {
  if (!ctx.selectors?.pickGraphic) {
    ctx.ui.showToast({ message: "Tu Maker Studio no expone el selector gráfico requerido.", level: "warn" });
    return;
  }
  const picked = await ctx.selectors.pickGraphic("Tilesets", {
    allowTileSelect: true,
    fields: ["sheetCols", "sheetRows"],
    title: "2.5D Geometry · textura de objeto",
  });
  if (!picked?.srcRect?.w) return;
  const list = ctx.tileset.list();
  const match = list.find((t) => String(t.tilesetName || "").toLowerCase() === String(picked.name || "").toLowerCase());
  if (!match) {
    ctx.ui.showToast({ message: "No pude resolver el tileset seleccionado.", level: "warn" });
    return;
  }
  await ensureTilesetResourceSet(ctx, match.id);
  const material = {
    tileset_id: match.id,
    graphic: picked.name,
    src_rect: { x: picked.srcRect.x, y: picked.srcRect.y, w: picked.srcRect.w, h: picked.srcRect.h },
  };
  const geo = currentGeo(ctx);
  const target = objFieldTarget(geo);
  if (target) {
    target.material = material;
    objEditChanged(ctx);
  } else {
    state.objMaterial = material;
  }
  const mapId = ctx.editor.activeMapId();
  if (mapId != null) void ensureSceneTilesetResources(ctx, mapId, false);
  render?.();
  schedulePreview(ctx);
}

function buttonStyle(active = false) {
  return `padding:4px 7px;border:1px solid ${active ? "var(--accent)" : "var(--border)"};border-radius:4px;background:${active ? "var(--accent-muted)" : "var(--bg-tertiary)"};color:var(--text-primary);cursor:pointer;`;
}

function selectStyle() {
  return `padding:3px 4px;background:var(--input-bg);color:var(--text-primary);border:1px solid var(--border);border-radius:4px;`;
}

function inputStyle(width = 52) {
  return `padding:3px 4px;background:var(--input-bg);color:var(--text-primary);border:1px solid var(--border);border-radius:4px;width:${width}px;`;
}

function panelHtml(geo) {
  const sel = state.sourceSelection && Number(state.sourceSelection.map_id) === Number(geo?.map_id) ? state.sourceSelection : null;
  const sourceDef = sel ? geo?.definitions?.[sel.key] || null : null;
  const sourceOverride = sel ? geo?.instance_overrides?.[sel.instance_key] || null : null;
  const sourceRule = sourceDef ? effectiveSourceRule(sourceDef, sourceOverride) : null;
  const activePreset = sourceRule?.enabled === false ? "ignore" : (sourceRule?.category || null);
  const activeHeight = sourceRule ? Number(sourceRule.height) || 0 : Number(state.brushHeight) || 0;
  const usage = state.sourceUsage && Number(state.sourceUsage.map_id) === Number(geo?.map_id) ? state.sourceUsage : null;
  const compilerStats = geo?.compiler?.stats || {};
  const selectedScopeText = state.sceneScope === "this" ? "solo este tile" : state.sceneScope === "connected" ? "iguales conectados" : "todos los iguales";
  const toolHelp = {
    select: "Haz clic en algo del mapa para editarlo.",
    paint: `Haz clic o arrastra para aplicar ${simplePresetLabel(state.brushPreset)}.`,
    raise: "Haz clic o arrastra para subir la geometría 0.25 tiles.",
    lower: "Haz clic o arrastra para bajar la geometría 0.25 tiles.",
    eyedropper: "Haz clic en algo configurado para copiar su Geometry.",
    erase: "Haz clic o arrastra para quitar Geometry sin borrar el tile.",
  }[state.sceneTool] || "";

  const sourceButtons = ["floor", "wall", "mountain", "prop", "roof", "border"].map((p) => {
    const active = state.brushPreset === p;
    return `<button data-brush-preset="${p}" style="${buttonStyle(active)}min-width:82px;height:48px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;">
      <span style="font-size:18px;line-height:16px;">${simplePresetIcon(p)}</span><span>${simplePresetLabel(p)}</span>
    </button>`;
  }).join("");

  const detectedRows = usage?.sources instanceof Map
    ? [...usage.sources.values()].sort((a,b) => b.count-a.count).slice(0,50).map((row) =>
      `<button data-source-jump="${escapeHtml(row.key)}" style="${buttonStyle(sel?.key === row.key)}max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(row.label || row.key)} · ×${row.count}${geo?.definitions?.[row.key] ? " · ✓" : ""}</button>`
    ).join("")
    : `<span style="color:var(--text-tertiary);">Aún no se ha indexado el mapa.</span>`;

  const simpleInspector = sel ? `
    <div style="border:1px solid var(--border);border-radius:8px;background:var(--bg-secondary);padding:10px;display:flex;flex-direction:column;gap:9px;">
      <div style="display:flex;gap:10px;align-items:center;min-width:0;">
        <canvas data-id="source-thumb" width="64" height="64" style="width:64px;height:64px;flex:0 0 auto;border:1px solid var(--border);border-radius:5px;image-rendering:pixelated;background:var(--canvas-bg);"></canvas>
        <div style="min-width:0;flex:1;">
          <div style="font-size:11px;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.04em;">Seleccionado</div>
          <strong style="font-size:14px;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(sel.label)}</strong>
          <div style="font-size:11px;color:var(--text-secondary);margin-top:2px;">${sourceDef ? `${simplePresetLabel(activePreset)} · ${activeHeight} tiles` : "Sin Geometry todavía"}</div>
        </div>
      </div>

      <div>
        <div style="font-size:11px;color:var(--text-tertiary);margin-bottom:5px;">¿QUÉ ES?</div>
        <div style="display:flex;flex-wrap:wrap;gap:5px;">
          ${["floor","wall","mountain","prop","roof","border"].map((p) => `<button data-quick-preset="${p}" style="${buttonStyle(activePreset === p)}">${simplePresetIcon(p)} ${simplePresetLabel(p)}</button>`).join("")}
        </div>
      </div>

      <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;">
        <strong>Altura</strong>
        <button data-act="simple-height-minus" style="${buttonStyle()}">−</button>
        <input data-id="simple-height" type="number" min="0" step="0.25" value="${activeHeight}" style="${inputStyle(64)}" />
        <span style="color:var(--text-secondary);">tiles</span>
        <button data-act="simple-height-plus" style="${buttonStyle()}">+</button>
      </div>

      ${sourceDef ? `<div style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;font-size:12px;">
        <label><input data-id="simple-connect" type="checkbox" ${sourceRule?.components?.connect_neighbors ? "checked" : ""}/> Unir piezas vecinas</label>
        <label><input data-id="simple-cap" type="checkbox" ${sourceRule?.components?.cap !== false ? "checked" : ""}/> Superficie arriba</label>
        <label>Colisión <select data-id="simple-collision" style="${selectStyle()}">
          <option value="none" ${sourceRule?.collision === "none" ? "selected" : ""}>Atravesable</option>
          <option value="solid" ${sourceRule?.collision === "solid" ? "selected" : ""}>Sólida</option>
          <option value="climb" ${sourceRule?.collision === "climb" ? "selected" : ""}>Escalable</option>
          <option value="one-way" ${sourceRule?.collision === "one-way" ? "selected" : ""}>Solo desde arriba</option>
        </select></label>
      </div>` : `<div style="font-size:12px;color:var(--text-secondary);">Elige un tipo arriba o usa <strong>Pintar</strong> para crear Geometry.</div>`}

      <div style="display:flex;gap:6px;flex-wrap:wrap;">
        <button data-act="simple-copy" style="${buttonStyle()}">Copiar Geometry</button>
        <button data-act="simple-remove" style="${buttonStyle()}">Quitar Geometry</button>
      </div>
    </div>` : `
    <div style="border:1px dashed var(--border);border-radius:8px;padding:18px;text-align:center;color:var(--text-secondary);background:var(--bg-secondary);">
      <div style="font-size:28px;margin-bottom:5px;">⬉</div>
      <strong>Haz clic en el mapa</strong>
      <div style="font-size:12px;margin-top:4px;">Geometry detectará automáticamente el tile real y su tileset, incluso en capas extendidas.</div>
    </div>`;

  const previewBlock = state.viewMode === "2.5d" ? `
    <div style="padding:7px 8px;border-bottom:1px solid var(--border);display:flex;flex-wrap:wrap;gap:8px;align-items:center;background:var(--bg-secondary);">
      <button data-act="gameView" style="${buttonStyle()}">Vista juego</button>
      <button data-yaw="0" style="${buttonStyle()}">Frente</button>
      <button data-yaw="90" style="${buttonStyle()}">Derecha</button>
      <button data-yaw="180" style="${buttonStyle()}">Atrás</button>
      <button data-yaw="270" style="${buttonStyle()}">Izquierda</button>
      <label>Zoom <input data-id="pzoom" type="range" min="0.35" max="2.2" step="0.05" value="${state.preview.zoom}" /></label>
      <label><input data-id="collision" type="checkbox" ${state.preview.showCollision ? "checked" : ""}/> colisión</label>
      <label><input data-id="wire" type="checkbox" ${state.preview.showWire ? "checked" : ""}/> wire</label>
      <label><input data-id="player" type="checkbox" ${state.preview.showPlayer ? "checked" : ""}/> jugador</label>
    </div>
    <div style="flex:1;min-height:360px;padding:8px;display:flex;align-items:center;justify-content:center;background:var(--canvas-bg);overflow:hidden;">
      <canvas data-id="preview" width="640" height="480" style="display:block;width:min(100%,1040px);height:auto;max-height:100%;aspect-ratio:4/3;border:1px solid var(--border);background:var(--canvas-bg);image-rendering:pixelated;cursor:crosshair;touch-action:none;"></canvas>
    </div>
    <div style="padding:6px 8px;border-top:1px solid var(--border);display:flex;justify-content:space-between;gap:8px;color:var(--text-tertiary);font-size:11px;">
      <span data-id="status">Vista 2.5D</span><span>Clic = editar · arrastre derecho = mover cámara · rueda = zoom</span>
    </div>` : `
    <div style="flex:1;min-height:220px;display:flex;align-items:center;justify-content:center;padding:24px;background:var(--canvas-bg);">
      <div style="max-width:520px;text-align:center;color:var(--text-secondary);line-height:1.5;">
        <div style="font-size:34px;margin-bottom:8px;">🗺️</div>
        <strong style="color:var(--text-primary);font-size:15px;">Edita directamente sobre el mapa de Maker Studio</strong>
        <div style="margin-top:5px;">No necesitas importar el gráfico ni buscar su tileset. Selecciona una herramienta arriba y haz clic sobre los tiles ya colocados.</div>
        <div style="margin-top:10px;font-size:12px;">${escapeHtml(toolHelp)} Alcance actual: <strong>${selectedScopeText}</strong>.</div>
        <button data-view="2.5d" style="${buttonStyle()}margin-top:14px;">Abrir vista 2.5D</button>
      </div>
    </div>`;

  return `
  <div style="height:100%;min-height:420px;display:flex;flex-direction:column;color:var(--text-primary);font:13px system-ui,sans-serif;background:var(--bg-primary);">
    <div style="padding:8px;border-bottom:1px solid var(--border);display:flex;gap:6px;align-items:center;flex-wrap:wrap;background:var(--bg-tertiary);">
      <strong style="font-size:14px;margin-right:4px;">⬢ Geometry</strong>
      <button data-view="2d" style="${buttonStyle(state.viewMode === "2d")}">Mapa 2D</button>
      <button data-view="2.5d" style="${buttonStyle(state.viewMode === "2.5d")}">Vista 2.5D</button>
      <span style="font-size:11px;color:var(--text-tertiary);">Edita lo que ya está colocado. Geometry resuelve el recurso automáticamente.</span>
      <button data-act="save" style="${buttonStyle()}margin-left:auto;">Guardar</button>
    </div>

    <div style="padding:8px;border-bottom:1px solid var(--border);background:var(--bg-secondary);">
      <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
        <button data-scene-tool="select" style="${buttonStyle(state.sceneTool === "select")}">⬉ Seleccionar</button>
        <button data-scene-tool="paint" style="${buttonStyle(state.sceneTool === "paint")}">🖌 Pintar</button>
        <button data-scene-tool="raise" style="${buttonStyle(state.sceneTool === "raise")}">↥ Altura +</button>
        <button data-scene-tool="lower" style="${buttonStyle(state.sceneTool === "lower")}">↧ Altura −</button>
        <button data-scene-tool="eyedropper" style="${buttonStyle(state.sceneTool === "eyedropper")}">◉ Copiar</button>
        <button data-scene-tool="erase" style="${buttonStyle(state.sceneTool === "erase")}">⌫ Borrar Geometry</button>
        <span style="font-size:11px;color:var(--text-secondary);margin-left:4px;">${escapeHtml(toolHelp)}</span>
      </div>

      <div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-top:8px;">
        <span style="font-size:11px;color:var(--text-tertiary);text-transform:uppercase;">Aplicar a</span>
        <button data-scope="this" style="${buttonStyle(state.sceneScope === "this")}">Este tile</button>
        <button data-scope="connected" style="${buttonStyle(state.sceneScope === "connected")}">Iguales conectados</button>
        <button data-scope="all" style="${buttonStyle(state.sceneScope === "all")}">Todos los iguales</button>
      </div>

      <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-top:9px;">
        <span style="font-size:11px;color:var(--text-tertiary);text-transform:uppercase;">Pincel</span>
        ${sourceButtons}
        <label style="display:flex;gap:4px;align-items:center;margin-left:4px;">Altura
          <input data-id="brush-height" type="number" min="0" step="0.25" value="${Number(state.brushHeight) || 0}" style="${inputStyle(60)}" />
        </label>
      </div>
    </div>

    <div style="padding:8px;border-bottom:1px solid var(--border);">${simpleInspector}</div>

    <details style="border-bottom:1px solid var(--border);background:var(--bg-secondary);">
      <summary style="padding:7px 9px;cursor:pointer;color:var(--text-secondary);">Avanzado</summary>
      <div style="padding:8px;display:flex;flex-direction:column;gap:8px;font-size:11px;">
        <div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;">
          <button data-act="source-scan" style="${buttonStyle()}">Reescanear mapa</button>
          <button data-act="source-compile" style="${buttonStyle()}">Recompilar</button>
          <label><input data-id="compiler-auto" type="checkbox" ${geo?.compiler?.auto_compile !== false ? "checked" : ""}/> recompilar automáticamente</label>
          <span style="color:var(--text-tertiary);">Tiles ${compilerStats.placed_tiles || 0} · recursos ${compilerStats.unique_sources || 0} · Geometry ${(geo?.compiled_objects || []).length}</span>
        </div>
        ${sel ? `<div style="font-family:monospace;color:var(--text-tertiary);overflow-wrap:anywhere;">Origen: ${escapeHtml(sel.key)} · Map ${sel.map_id} · Layer ${sel.layer} · ${sel.x},${sel.y} · tileId ${sel.tile_id} · tilesetId ${sel.tileset_id || "extra"}</div>` : ""}
        ${sourceDef ? `<div style="display:flex;flex-wrap:wrap;gap:7px;align-items:center;">
          <label><input data-id="src-enabled" type="checkbox" ${sourceDef.enabled !== false ? "checked" : ""}/> activo</label>
          <label>Tipo <select data-id="src-category" style="${selectStyle()}">${OBJECT_CATEGORIES.map(([id,name]) => `<option value="${id}" ${(sourceRule?.category || "wall") === id ? "selected" : ""}>${name}</option>`).join("")}</select></label>
          <label>Mesh <select data-id="src-type" style="${selectStyle()}"><option value="cube" ${sourceRule?.type === "cube" ? "selected" : ""}>Extruded</option><option value="plane" ${sourceRule?.type === "plane" ? "selected" : ""}>Plane</option></select></label>
          <label>H <input data-id="src-height" type="number" min="0" step="0.25" value="${sourceRule?.height ?? 0}" style="${inputStyle(52)}" /></label>
          <label>Z <input data-id="src-z" type="number" min="0" step="0.25" value="${sourceRule?.anchor_z ?? 0}" style="${inputStyle(52)}" /></label>
          <label>Collision <select data-id="src-collision" style="${selectStyle()}">${OBJECT_COLLISIONS.map((c) => `<option value="${c}" ${(sourceRule?.collision || "none") === c ? "selected" : ""}>${c}</option>`).join("")}</select></label>
          <label><input data-id="src-connect" type="checkbox" ${sourceRule?.components?.connect_neighbors ? "checked" : ""}/> connect</label>
          <label><input data-id="src-cap" type="checkbox" ${sourceRule?.components?.cap !== false ? "checked" : ""}/> cap</label>
          <label><input data-id="src-charfront" type="checkbox" ${sourceRule?.characters_in_front ? "checked" : ""}/> character front</label>
        </div>` : ""}
        <div style="display:flex;gap:5px;align-items:center;overflow-x:auto;">${detectedRows}</div>
      </div>
    </details>

    ${previewBlock}
  </div>`;
}
function bindPanel(ctx, host, render) {
  const q = (s) => host.querySelector(s);

  for (const btn of host.querySelectorAll("[data-view]")) {
    btn.addEventListener("click", () => {
      const view = btn.getAttribute("data-view");
      if (!['2d','2.5d'].includes(view)) return;
      state.viewMode = view;
      render();
      if (view === '2.5d') schedulePreview(ctx);
    });
  }
  for (const btn of host.querySelectorAll("[data-scene-tool]")) {
    btn.addEventListener("click", () => {
      state.workspaceMode = "scene";
      state.objTool = false;
      state.sceneTool = btn.getAttribute("data-scene-tool") || "select";
      try { ctx.editor.setTool(TOOL_ID); } catch (_) {}
      render();
      ctx.editor.requestRedraw();
    });
  }
  for (const btn of host.querySelectorAll("[data-scope]")) {
    btn.addEventListener("click", () => {
      const scope = btn.getAttribute("data-scope");
      if (!["this", "connected", "all"].includes(scope)) return;
      state.sceneScope = scope;
      render();
    });
  }
  for (const btn of host.querySelectorAll("[data-brush-preset]")) {
    btn.addEventListener("click", () => {
      state.brushPreset = btn.getAttribute("data-brush-preset") || "wall";
      state.sourcePreset = state.brushPreset;
      const preset = SCENE_GEOMETRY_PRESETS[state.brushPreset];
      if (preset) state.brushHeight = Number(preset.height) || 0;
      state.sceneTool = "paint";
      render();
    });
  }
  for (const btn of host.querySelectorAll("[data-quick-preset]")) {
    btn.addEventListener("click", () => {
      const preset = btn.getAttribute("data-quick-preset") || "wall";
      const sel = state.sourceSelection;
      if (!sel) return;
      state.brushPreset = preset;
      state.sourcePreset = preset;
      const p = SCENE_GEOMETRY_PRESETS[preset];
      if (p) state.brushHeight = Number(p.height) || 0;
      applySimpleGeometry(ctx, sel, preset, state.brushHeight);
      render();
    });
  }
  q('[data-id="brush-height"]')?.addEventListener("change", (e) => {
    state.brushHeight = Math.max(0, Number(e.target.value) || 0);
    render();
  });
  q('[data-act="simple-height-minus"]')?.addEventListener("click", () => {
    const sel = state.sourceSelection; if (!sel) return;
    const geo = currentGeo(ctx); const def = geo?.definitions?.[sel.key];
    const rule = def ? effectiveSourceRule(def, geo.instance_overrides?.[sel.instance_key]) : null;
    setSimpleGeometryHeight(ctx, sel, Math.max(0, (Number(rule?.height) || Number(state.brushHeight) || 0) - 0.25));
  });
  q('[data-act="simple-height-plus"]')?.addEventListener("click", () => {
    const sel = state.sourceSelection; if (!sel) return;
    const geo = currentGeo(ctx); const def = geo?.definitions?.[sel.key];
    const rule = def ? effectiveSourceRule(def, geo.instance_overrides?.[sel.instance_key]) : null;
    setSimpleGeometryHeight(ctx, sel, (Number(rule?.height) || Number(state.brushHeight) || 0) + 0.25);
  });
  q('[data-id="simple-height"]')?.addEventListener("change", (e) => {
    const sel = state.sourceSelection; if (!sel) return;
    setSimpleGeometryHeight(ctx, sel, e.target.value);
  });
  q('[data-id="simple-connect"]')?.addEventListener("change", (e) => {
    const sel = state.sourceSelection; if (sel) patchSimpleGeometry(ctx, sel, { components: { connect_neighbors: !!e.target.checked } });
  });
  q('[data-id="simple-cap"]')?.addEventListener("change", (e) => {
    const sel = state.sourceSelection; if (sel) patchSimpleGeometry(ctx, sel, { components: { cap: !!e.target.checked } });
  });
  q('[data-id="simple-collision"]')?.addEventListener("change", (e) => {
    const sel = state.sourceSelection; if (sel) patchSimpleGeometry(ctx, sel, { collision: e.target.value });
  });
  q('[data-act="simple-copy"]')?.addEventListener("click", () => {
    const sel = state.sourceSelection; if (sel) eyedropSimpleGeometry(ctx, sel);
  });
  q('[data-act="simple-remove"]')?.addEventListener("click", () => {
    const sel = state.sourceSelection; if (sel) eraseSimpleGeometry(ctx, sel);
  });

  // Workspace switcher: Geometry is one Maker Studio tool, while Scene/Height/
  // Objects are editor sub-modes. Scene is the default source-driven workflow.
  for (const btn of host.querySelectorAll("[data-workspace]")) {
    btn.addEventListener("click", () => {
      const mode = btn.getAttribute("data-workspace");
      if (!["scene", "height", "object"].includes(mode)) return;
      state.workspaceMode = mode;
      state.objTool = mode === "object";
      try { ctx.editor.setTool(TOOL_ID); } catch (_) {}
      render();
      ctx.editor.requestRedraw();
      schedulePreview(ctx);
    });
  }

  // Scene Compiler controls --------------------------------------------------
  q('[data-act="source-scan"]')?.addEventListener("click", async () => {
    const mapId = ctx.editor.activeMapId();
    if (mapId == null) return;
    await scanGeometrySources(ctx, mapId, true);
    render();
  });
  q('[data-act="source-compile"]')?.addEventListener("click", async () => {
    const mapId = ctx.editor.activeMapId();
    const geo = mapId == null ? null : state.maps.get(mapId);
    if (!geo) return;
    await compileGeometryScene(ctx, mapId, geo, { forceScan: true, reason: "manual-panel" });
    await saveMap(ctx, mapId, { skipCompile: true });
    render();
  });
  q('[data-id="compiler-auto"]')?.addEventListener("change", async (e) => {
    const mapId = ctx.editor.activeMapId();
    const geo = mapId == null ? null : state.maps.get(mapId);
    if (!geo) return;
    geo.compiler ||= {};
    geo.compiler.auto_compile = !!e.target.checked;
    if (geo.compiler.auto_compile && Object.keys(geo.definitions || {}).length) {
      await compileGeometryScene(ctx, mapId, geo, { reason: "auto-enabled" });
    }
    await saveMap(ctx, mapId, { skipCompile: true });
    render();
  });
  for (const btn of host.querySelectorAll("[data-source-preset]")) {
    btn.addEventListener("click", () => applyPresetToSelectedSource(ctx, btn.getAttribute("data-source-preset")));
  }
  const bindSource = (selector, eventName, patcher) => {
    q(selector)?.addEventListener(eventName, (e) => updateSelectedSourceDefinition(ctx, patcher(e.target)));
  };
  bindSource('[data-id="src-enabled"]', "change", (el) => ({ enabled: !!el.checked }));
  bindSource('[data-id="src-category"]', "change", (el) => ({ category: el.value }));
  bindSource('[data-id="src-type"]', "change", (el) => ({ type: el.value === "plane" ? "plane" : "cube" }));
  bindSource('[data-id="src-height"]', "change", (el) => ({ height: Math.max(0, Number(el.value) || 0) }));
  bindSource('[data-id="src-z"]', "change", (el) => ({ anchor_z: Math.max(0, Number(el.value) || 0) }));
  bindSource('[data-id="src-collision"]', "change", (el) => ({ collision: el.value }));
  bindSource('[data-id="src-connect"]', "change", (el) => ({ components: { connect_neighbors: !!el.checked } }));
  bindSource('[data-id="src-cap"]', "change", (el) => ({ components: { cap: !!el.checked } }));
  bindSource('[data-id="src-charfront"]', "change", (el) => ({ characters_in_front: !!el.checked }));

  q('[data-id="inst-height"]')?.addEventListener("change", (e) => updateSelectedInstanceOverride(ctx, { height: Math.max(0, Number(e.target.value) || 0) }));
  q('[data-id="inst-z"]')?.addEventListener("change", (e) => updateSelectedInstanceOverride(ctx, { anchor_z: Math.max(0, Number(e.target.value) || 0) }));

  q('[data-act="instance-disable"]')?.addEventListener("click", () => {
    const geo = currentGeo(ctx), sel = state.sourceSelection;
    if (!geo || !sel) return;
    const old = geo.instance_overrides?.[sel.instance_key];
    updateSelectedInstanceOverride(ctx, { disabled: old?.disabled !== true });
  });
  q('[data-act="instance-clear"]')?.addEventListener("click", () => clearSelectedInstanceOverride(ctx));
  q('[data-act="source-delete"]')?.addEventListener("click", async () => {
    const geo = currentGeo(ctx), sel = state.sourceSelection;
    if (!geo || !sel) return;
    delete geo.definitions?.[sel.key];
    if (geo.instance_overrides) {
      for (const key of Object.keys(geo.instance_overrides)) {
        if (key.endsWith(`|${sel.key}`)) delete geo.instance_overrides[key];
      }
    }
    await compileGeometryScene(ctx, sel.map_id, geo, { reason: "definition-delete" });
    await saveMap(ctx, sel.map_id, { skipCompile: true });
    render();
  });
  for (const btn of host.querySelectorAll("[data-source-jump]")) {
    btn.addEventListener("click", async () => {
      const mapId = ctx.editor.activeMapId();
      if (mapId == null) return;
      const key = btn.getAttribute("data-source-jump");
      let usage = state.sourceUsageByMap.get(mapId);
      if (!usage) usage = await scanGeometrySources(ctx, mapId, true);
      const ex = usage?.sources?.get?.(key)?.examples?.[0];
      if (ex) selectSourceAt(ctx, mapId, ex.x, ex.y, ex.layer);
    });
  }

  // Paint the selected source from the exact tile occurrence. This is not a
  // tileset-base lookup: readTileVisualData retains the extended layer's own
  // tilesetId/autotile source before sourceForTileData resolves the pixels.
  const paintSourceThumb = async () => {
    const canvas = q('[data-id="source-thumb"]');
    const sel = state.sourceSelection;
    if (!canvas || !sel || Number(sel.map_id) !== Number(ctx.editor.activeMapId())) return;
    try {
      await ensureSceneTilesetResources(ctx, sel.map_id, false);
      const layer = authoritativeLayers(ctx, sel.map_id, true).find((l) => Number(layerRef(l)) === Number(sel.layer));
      if (!layer || !host.isConnected) return;
      const data = readTileVisualData(ctx, sel.map_id, layer, sel.x, sel.y);
      if (!data) return;
      const src = sourceForTileData(ctx, Number(data.tileId) || 0, data, layer, Number(data.tilesetId) || sel.tileset_id);
      if (!src) return;
      const c = canvas.getContext("2d");
      c.clearRect(0, 0, canvas.width, canvas.height);
      c.imageSmoothingEnabled = false;
      const scale = Math.min(canvas.width / src.sw, canvas.height / src.sh);
      const dw = src.sw * scale, dh = src.sh * scale;
      c.drawImage(src.img, src.sx, src.sy, src.sw, src.sh, (canvas.width - dw) / 2, (canvas.height - dh) / 2, dw, dh);
    } catch (err) { ctx.log.warn("2.5D Geometry: source thumbnail failed", err); }
  };
  void paintSourceThumb();
  const levelInput = q('[data-id="level"]');
  levelInput?.addEventListener("change", () => {
    state.level = Math.max(0, Math.round(Number(levelInput.value) || 0));
    render();
  });
  q('[data-act="minus"]')?.addEventListener("click", () => { state.level = Math.max(0, state.level - 1); render(); });
  q('[data-act="plus"]')?.addEventListener("click", () => { state.level += 1; render(); });
  for (const btn of host.querySelectorAll("[data-mode]")) {
    const mode = btn.getAttribute("data-mode");
    btn.addEventListener("click", () => { state.mode = mode; render(); });
  }
  q('[data-act="tool"]')?.addEventListener("click", () => ctx.editor.setTool(TOOL_ID));
  q('[data-act="save"]')?.addEventListener("click", () => { const id = ctx.editor.activeMapId(); if (id != null) void saveMap(ctx, id); });

  q('[data-act="objtool"]')?.addEventListener("click", () => { state.workspaceMode = "object"; state.objTool = true; ctx.editor.setTool(TOOL_ID); render(); });
  for (const btn of host.querySelectorAll("[data-select-object]")) {
    btn.addEventListener("click", () => {
      const geo = currentGeo(ctx);
      const obj = (geo?.objects || []).find((o) => Number(o.id) === Number(btn.getAttribute("data-select-object")));
      if (obj) selectObject(ctx, geo, obj, ctx.editor.activeMapId());
    });
  }
  const objTarget = () => objFieldTarget(currentGeo(ctx));
  q('[data-id="objtype"]')?.addEventListener("change", (e) => {
    const t = objTarget();
    if (t) { t.type = e.target.value === "plane" ? "plane" : "cube"; objEditChanged(ctx); }
    else { state.objType = e.target.value; render(); }
  });
  q('[data-id="objheight"]')?.addEventListener("change", (e) => {
    const v = Math.max(0, Math.round(Number(e.target.value) || 0));
    const t = objTarget();
    if (t) { t.height = v; objEditChanged(ctx); }
    else { state.objHeight = v; }
  });
  q('[data-id="objz"]')?.addEventListener("change", (e) => {
    const v = Math.max(0, Math.round(Number(e.target.value) || 0));
    const t = objTarget();
    if (t) { t.anchor_z = v; objEditChanged(ctx); }
    else { state.objAnchorZ = v; }
  });
  q('[data-id="objcollision"]')?.addEventListener("change", (e) => {
    const t = objTarget();
    if (t) { t.collision = e.target.value; objEditChanged(ctx); }
    else { state.objCollision = e.target.value; render(); }
  });
  q('[data-id="objcategory"]')?.addEventListener("change", (e) => {
    const cat = e.target.value;
    const preset = OBJECT_CATEGORY_PRESETS[cat];
    const t = objTarget();
    if (t) {
      t.category = cat;
      if (preset) Object.assign(t, { type: preset.type, height: preset.height, anchor_z: preset.anchor_z, collision: preset.collision });
      objEditChanged(ctx);
    } else {
      state.objCategory = cat;
      if (preset) Object.assign(state, { objType: preset.type, objHeight: preset.height, objAnchorZ: preset.anchor_z, objCollision: preset.collision });
      render();
    }
  });
  q('[data-act="objmaterial"]')?.addEventListener("click", () => void chooseObjectTexture(ctx, render));

  q('[data-id="objname"]')?.addEventListener("change", (e) => {
    const t = objTarget(); if (!t) return; t.name = String(e.target.value || `Object ${t.id}`).trim() || `Object ${t.id}`; objEditChanged(ctx);
  });
  q('[data-id="objanchorrow"]')?.addEventListener("change", (e) => {
    const t = objTarget(); if (!t) return; t.anchor_row = Math.min(t.h - 1, Math.max(0, Math.round(Number(e.target.value) || 0))); objEditChanged(ctx);
  });
  q('[data-id="objcharfront"]')?.addEventListener("change", (e) => {
    const t = objTarget(); if (!t) return; t.characters_in_front = !!e.target.checked; objEditChanged(ctx);
  });
  q('[data-id="fpmode"]')?.addEventListener("change", (e) => { state.objFootprintMode = e.target.value; });
  for (const cell of host.querySelectorAll("[data-fp-cell]")) {
    cell.addEventListener("click", () => {
      const t = objTarget(); if (!t) return;
      const [dx, dy] = cell.getAttribute("data-fp-cell").split(",").map(Number);
      setFootprintCell(ctx, t, dx, dy, state.objFootprintMode);
    });
  }
  q('[data-act="objmoveleft"]')?.addEventListener("click", () => moveSelectedObject(ctx, -1, 0));
  q('[data-act="objmoveright"]')?.addEventListener("click", () => moveSelectedObject(ctx, 1, 0));
  q('[data-act="objmoveup"]')?.addEventListener("click", () => moveSelectedObject(ctx, 0, -1));
  q('[data-act="objmovedown"]')?.addEventListener("click", () => moveSelectedObject(ctx, 0, 1));
  q('[data-act="objrotleft"]')?.addEventListener("click", () => rotateSelectedObject(ctx, false));
  q('[data-act="objrotright"]')?.addEventListener("click", () => rotateSelectedObject(ctx, true));
  q('[data-act="objheightminus"]')?.addEventListener("click", () => { const t=objTarget(); if(t){t.height=Math.max(0,(Number(t.height)||0)-1);objEditChanged(ctx);} });
  q('[data-act="objheightplus"]')?.addEventListener("click", () => { const t=objTarget(); if(t){t.height=(Number(t.height)||0)+1;objEditChanged(ctx);} });
  q('[data-act="objfit"]')?.addEventListener("click", () => fitSelectedObjectToMaterial(ctx));
  q('[data-act="objduplicate"]')?.addEventListener("click", () => duplicateSelectedObject(ctx));
  q('[data-act="objdelete"]')?.addEventListener("click", () => deleteSelectedObject(ctx));

  q('[data-id="objx"]')?.addEventListener("change", (e) => {
    const geo = currentGeo(ctx); const t = objFieldTarget(geo);
    if (!t || !geo) return;
    const v = Math.max(0, Math.round(Number(e.target.value) || 0));
    if (v + t.w <= geo.width) { t.x = v; objEditChanged(ctx); } else e.target.value = t.x;
  });
  q('[data-id="objy"]')?.addEventListener("change", (e) => {
    const geo = currentGeo(ctx); const t = objFieldTarget(geo);
    if (!t || !geo) return;
    const v = Math.max(0, Math.round(Number(e.target.value) || 0));
    if (v + t.h <= geo.height) { t.y = v; objEditChanged(ctx); } else e.target.value = t.y;
  });
  q('[data-id="objw"]')?.addEventListener("change", (e) => {
    const geo = currentGeo(ctx); const t = objFieldTarget(geo);
    if (!t || !geo) return;
    const v = Math.max(1, Math.round(Number(e.target.value) || 1));
    if (t.x + v <= geo.width) { t.w = v; t.footprint = normalizeFootprint(t.footprint, t.w, t.h); objEditChanged(ctx); } else e.target.value = t.w;
  });
  q('[data-id="objh"]')?.addEventListener("change", (e) => {
    const geo = currentGeo(ctx); const t = objFieldTarget(geo);
    if (!t || !geo) return;
    const v = Math.max(1, Math.round(Number(e.target.value) || 1));
    if (t.y + v <= geo.height) { t.h = v; t.anchor_row = Math.min(t.h - 1, t.anchor_row ?? t.h - 1); t.footprint = normalizeFootprint(t.footprint, t.w, t.h); objEditChanged(ctx); } else e.target.value = t.h;
  });
  q('[data-act="objnew"]')?.addEventListener("click", () => { state.objSelected = null; render(); });

  const angle = q('[data-id="angle"]');
  angle?.addEventListener("input", () => {
    state.preview.angle = Number(angle.value) || 25;
    const t = q('[data-id="angleText"]'); if (t) t.textContent = `${Math.round(state.preview.angle)}°`;
    schedulePreview(ctx);
  });
  angle?.addEventListener("change", () => { const id = ctx.editor.activeMapId(); const geo = id == null ? null : state.maps.get(id); if (geo) persistPreviewPrefs(geo); });

  const yaw = q('[data-id="yaw"]');
  const setYaw = (value, persist = false) => {
    state.preview.yaw = ((Number(value) % 360) + 360) % 360;
    if (yaw) yaw.value = String(Math.round(state.preview.yaw));
    const t = q('[data-id="yawText"]'); if (t) t.textContent = `${Math.round(state.preview.yaw)}°`;
    if (persist) { const id = ctx.editor.activeMapId(); const geo = id == null ? null : state.maps.get(id); if (geo) persistPreviewPrefs(geo); }
    schedulePreview(ctx);
  };
  yaw?.addEventListener("input", () => setYaw(yaw.value, false));
  yaw?.addEventListener("change", () => setYaw(yaw.value, true));
  q('[data-act="yawLeft"]')?.addEventListener("click", () => setYaw(state.preview.yaw - 15, true));
  q('[data-act="yawRight"]')?.addEventListener("click", () => setYaw(state.preview.yaw + 15, true));
  for (const btn of host.querySelectorAll("[data-yaw]")) {
    btn.addEventListener("click", () => setYaw(Number(btn.getAttribute("data-yaw")) || 0, true));
  }

  const pzoom = q('[data-id="pzoom"]');
  pzoom?.addEventListener("input", () => {
    state.preview.zoom = Number(pzoom.value) || 1;
    const t = q('[data-id="zoomText"]'); if (t) t.textContent = state.preview.zoom.toFixed(2);
    schedulePreview(ctx);
  });
  pzoom?.addEventListener("change", () => { const id = ctx.editor.activeMapId(); const geo = id == null ? null : state.maps.get(id); if (geo) persistPreviewPrefs(geo); });

  q('[data-act="left"]')?.addEventListener("click", () => movePreviewFocus(ctx, -1, 0));
  q('[data-act="right"]')?.addEventListener("click", () => movePreviewFocus(ctx, 1, 0));
  q('[data-act="up"]')?.addEventListener("click", () => movePreviewFocus(ctx, 0, -1));
  q('[data-act="down"]')?.addEventListener("click", () => movePreviewFocus(ctx, 0, 1));
  q('[data-act="center2d"]')?.addEventListener("click", () => {
    const mapId = ctx.editor.activeMapId();
    const hover = ctx.editor.hoverTile?.();
    const sel = mapId == null ? null : ctx.map.selection(mapId)?.bounds;
    if (hover) { state.preview.focusX = hover.x; state.preview.focusY = hover.y; }
    else if (sel) { state.preview.focusX = sel.x + (sel.w - 1) / 2; state.preview.focusY = sel.y + (sel.h - 1) / 2; }
    ensurePreviewFocus(ctx, mapId);
    schedulePreview(ctx);
  });
  q('[data-act="cliff"]')?.addEventListener("click", () => void chooseCliffTexture(ctx));
  q('[data-act="gameView"]')?.addEventListener("click", () => {
    state.preview.angle = 25;
    state.preview.yaw = 0;
    state.preview.zoom = 1.0;
    if (angle) angle.value = "25";
    const angleText = q('[data-id="angleText"]'); if (angleText) angleText.textContent = "25°";
    if (yaw) yaw.value = "0";
    const yawText = q('[data-id="yawText"]'); if (yawText) yawText.textContent = "0°";
    if (pzoom) pzoom.value = "1";
    const zoomText = q('[data-id="zoomText"]'); if (zoomText) zoomText.textContent = "1.00";
    const id = ctx.editor.activeMapId(); const geo = id == null ? null : state.maps.get(id); if (geo) persistPreviewPrefs(geo);
    schedulePreview(ctx);
  });

  const persistSceneToggle = () => { const id = ctx.editor.activeMapId(); const geo = id == null ? null : state.maps.get(id); if (geo) persistPreviewPrefs(geo); };
  q('[data-id="collision"]')?.addEventListener("change", (e) => { state.preview.showCollision = e.target.checked; schedulePreview(ctx); });
  q('[data-id="wire"]')?.addEventListener("change", (e) => { state.preview.showWire = e.target.checked; schedulePreview(ctx); });
  q('[data-id="player"]')?.addEventListener("change", (e) => { state.preview.showPlayer = e.target.checked; schedulePreview(ctx); });
  q('[data-id="events"]')?.addEventListener("change", (e) => { state.preview.showEvents = e.target.checked; persistSceneToggle(); const id = ctx.editor.activeMapId(); if (id != null && state.preview.showEvents) void ensurePreviewResources(ctx, id, true); schedulePreview(ctx); });
  q('[data-id="tags"]')?.addEventListener("change", (e) => { state.preview.showTags = e.target.checked; persistSceneToggle(); schedulePreview(ctx); });
  q('[data-id="fullmap"]')?.addEventListener("change", (e) => { state.preview.fullMap = e.target.checked; persistSceneToggle(); schedulePreview(ctx); });
  q('[data-id="follow"]')?.addEventListener("change", (e) => { state.preview.followHover = e.target.checked; });
  q('[data-id="overlay"]')?.addEventListener("change", (e) => { state.showOverlay = e.target.checked; ctx.editor.requestRedraw(); });
  q('[data-id="refs2d"]')?.addEventListener("change", (e) => { state.show2DRefs = e.target.checked; ctx.editor.requestRedraw(); });
  q('[data-id="ignoreColor"]')?.addEventListener("change", (e) => {
    state.preview.ignoreColorTransforms = e.target.checked;
    state.preview.transformedSourceCache.clear();
    schedulePreview(ctx);
  });

  const canvas = q('[data-id="preview"]');
  state.preview.canvas = canvas;
  state.preview.status = q('[data-id="status"]');
  if (canvas) {
    canvas.addEventListener("contextmenu", (ev) => ev.preventDefault());
    canvas.addEventListener("pointerdown", (ev) => {
      if (ev.button === 2) {
        ev.preventDefault();
        canvas.setPointerCapture?.(ev.pointerId);
        state.preview.orbiting = true;
        state.preview.orbitStartX = ev.clientX;
        state.preview.orbitStartY = ev.clientY;
        state.preview.orbitStartYaw = state.preview.yaw;
        state.preview.orbitStartPitch = state.preview.angle;
        canvas.style.cursor = "grabbing";
        return;
      }
      if (ev.button !== 0) return;
      canvas.setPointerCapture?.(ev.pointerId);
      state.preview.dragging = true;
      state.preview.objJustDown = (state.objTool || state.workspaceMode === "object") && !ev.altKey;
      state.preview.visited.clear();
      if ((state.objTool || state.workspaceMode === "object") && !ev.altKey) { state.objStart = null; state.objCurrent = null; }
      const cell = hitPreviewCell(canvas, ev.clientX, ev.clientY);
      if (cell) previewPaint(ctx, cell, ev);
    });
    canvas.addEventListener("pointermove", (ev) => {
      if (state.preview.orbiting) {
        const dx = ev.clientX - state.preview.orbitStartX;
        const dy = ev.clientY - state.preview.orbitStartY;
        state.preview.yaw = ((state.preview.orbitStartYaw + dx * 0.45) % 360 + 360) % 360;
        state.preview.angle = Math.max(5, Math.min(70, state.preview.orbitStartPitch - dy * 0.28));
        const yawInput = q('[data-id="yaw"]'); if (yawInput) yawInput.value = String(Math.round(state.preview.yaw));
        const yawText = q('[data-id="yawText"]'); if (yawText) yawText.textContent = `${Math.round(state.preview.yaw)}°`;
        const pitchInput = q('[data-id="angle"]'); if (pitchInput) pitchInput.value = String(Math.round(state.preview.angle));
        const pitchText = q('[data-id="angleText"]'); if (pitchText) pitchText.textContent = `${Math.round(state.preview.angle)}°`;
        schedulePreview(ctx);
        return;
      }
      state.preview.objJustDown = false;
      const cell = hitPreviewCell(canvas, ev.clientX, ev.clientY);
      const next = cell ? { x: cell.x, y: cell.y } : null;
      if (!state.preview.hovered || !next || state.preview.hovered.x !== next.x || state.preview.hovered.y !== next.y) {
        state.preview.hovered = next;
        schedulePreview(ctx);
      }
      if (state.preview.dragging && (ev.buttons & 1) && cell) previewPaint(ctx, cell, ev);
    });
    const endPointer = () => {
      state.preview.objJustDown = false;
      if (state.preview.orbiting) {
        state.preview.orbiting = false;
        canvas.style.cursor = "crosshair";
        const id = ctx.editor.activeMapId(); const geo = id == null ? null : state.maps.get(id); if (geo) persistPreviewPrefs(geo);
      }
      if (state.preview.dragging) {
        state.preview.dragging = false;
        state.preview.visited.clear();
        const id = ctx.editor.activeMapId();
        const geo = id == null ? null : state.maps.get(id);
        if ((state.objTool || state.workspaceMode === "object") && geo && state.objStart && state.objCurrent) {
          commitObjectFromRect(ctx, geo, id,
            state.objStart.x, state.objStart.y, state.objCurrent.x, state.objCurrent.y);
          state.objStart = null;
          state.objCurrent = null;
        }
        if (id != null) void saveMap(ctx, id);
      }
    };
    canvas.addEventListener("pointerup", endPointer);
    canvas.addEventListener("pointercancel", endPointer);
    canvas.addEventListener("pointerleave", () => {
      if (!state.preview.dragging && !state.preview.orbiting) { state.preview.hovered = null; schedulePreview(ctx); }
    });
    canvas.addEventListener("dblclick", (ev) => {
      const cell = hitPreviewCell(canvas, ev.clientX, ev.clientY);
      if (!cell) return;
      state.preview.focusX = cell.x;
      state.preview.focusY = cell.y;
      const id = ctx.editor.activeMapId(); const geo = id == null ? null : state.maps.get(id); if (geo) persistPreviewPrefs(geo);
      schedulePreview(ctx);
    });
    canvas.addEventListener("wheel", (ev) => {
      ev.preventDefault();
      if (ev.shiftKey) {
        const step = ev.deltaY > 0 ? 7.5 : -7.5;
        setYaw(state.preview.yaw + step, false);
        return;
      }
      const dir = ev.deltaY > 0 ? -0.05 : 0.05;
      state.preview.zoom = Math.max(0.35, Math.min(2.2, Math.round((state.preview.zoom + dir) * 20) / 20));
      const z = q('[data-id="pzoom"]'); if (z) z.value = String(state.preview.zoom);
      const t = q('[data-id="zoomText"]'); if (t) t.textContent = state.preview.zoom.toFixed(2);
      schedulePreview(ctx);
    }, { passive: false });
  }  schedulePreview(ctx);
}


// =============================================================================
// V2.5 MODEL WORKSHOP
// =============================================================================

function nextModelId(geo) {
  let n = 1; while (geo?.models?.[`model_${n}`]) n++; return `model_${n}`;
}
function nextModelInstanceId(geo) {
  return Math.max(0, ...(geo?.model_instances || []).map(i=>Number(i.id)||0)) + 1;
}
function modelInstanceCoversCell(geo, inst, x, y) {
  const model = geo?.models?.[inst?.model_id]; if (!model) return false;
  for (const c of expandedModelCells(inst, model).values()) if (Math.round(c.x)===Math.round(x) && Math.round(c.y)===Math.round(y)) return true;
  return false;
}
function modelInstanceAt(geo,x,y){ return [...(geo?.model_instances||[])].reverse().find(i=>modelInstanceCoversCell(geo,i,x,y))||null; }
function placeModelInstance(ctx,mapId,x,y){
  const geo=state.maps.get(mapId); const id=state.modelBrushId||state.modelSelectedId; const model=geo?.models?.[id];
  if(!geo||!model){ctx.ui.showToast?.({message:"Crea o selecciona un modelo primero.",level:"info"});return;}
  geo.model_instances ||= [];
  geo.model_instances.push({id:nextModelInstanceId(geo),model_id:model.id,x:Math.round(x),y:Math.round(y),scale_x:Math.max(1,Math.round(state.modelScaleX||1)),scale_y:Math.max(1,Math.round(state.modelScaleY||1)),height_scale:Math.max(.25,Number(state.modelHeightScale)||1),rotation:normalizeRotation(state.modelRotation)});
  compileModelObjects(geo); ctx.editor.requestRedraw(); schedulePreview(ctx); void saveMap(ctx,mapId,{skipCompile:true}); state.panelRefresh?.();
}
function eraseModelAt(ctx,mapId,x,y){
  const geo=state.maps.get(mapId); if(!geo)return;
  const hit=modelInstanceAt(geo,x,y); if(!hit)return;
  geo.model_instances=(geo.model_instances||[]).filter(i=>Number(i.id)!==Number(hit.id));
  compileModelObjects(geo);ctx.editor.requestRedraw();schedulePreview(ctx);void saveMap(ctx,mapId,{skipCompile:true});state.panelRefresh?.();
}
function resolvePickedTileset(ctx,picked){
  const list=ctx.tileset.list?.()||[];
  const ids=[picked?.tilesetId,picked?.tileset_id,picked?.resourceId,picked?.resource_id].map(Number).filter(Number.isFinite);
  for(const id of ids){const hit=list.find(t=>Number(t.id)===id);if(hit)return hit;}
  const candidates=[picked?.name,picked?.fileName,picked?.filename,picked?.path,picked?.graphic].filter(Boolean).map(v=>String(v).replaceAll('\\','/').split('/').pop().replace(/\.[^.]+$/,'').toLowerCase());
  return list.find(t=>{const names=[t.tilesetName,t.name,t.fileName,t.filename,t.path].filter(Boolean).map(v=>String(v).replaceAll('\\','/').split('/').pop().replace(/\.[^.]+$/,'').toLowerCase());return names.some(n=>candidates.includes(n));})||null;
}
async function pickModelFaceMaterial(ctx){
  const picked=await openGeometryGraphicPicker(ctx,{title:"Geometry Model · textura de cara"});
  if(!picked?.srcRect?.w)return null;
  const match=picked.tileset||tilesetInfo(ctx,picked.tilesetId)||{id:picked.tilesetId};
  await ensureTilesetResourceSet(ctx,picked.tilesetId);
  return {kind:"tileset",tileset_id:Number(picked.tilesetId),graphic:String(match.tilesetName||match.name||""),src_rect:{x:Number(picked.srcRect.x)||0,y:Number(picked.srcRect.y)||0,w:Math.max(32,Number(picked.srcRect.w)||32),h:Math.max(32,Number(picked.srcRect.h)||32)},rotation:0,flip_h:false,flip_v:false,opacity:255,hue:0,saturation:100,lighting:0};
}

function resizeModel(model,newW,newH){
  newW=Math.max(1,Math.min(32,Math.round(newW)));newH=Math.max(1,Math.min(32,Math.round(newH)));
  const next={}; for(const [key,val] of Object.entries(model.cells||{})){const [x,y]=key.split(',').map(Number);if(x<newW&&y<newH)next[key]=val;}
  model.width=newW;model.height=newH;model.cells=next;
}
function createModel(ctx){
  const geo=currentGeo(ctx);if(!geo)return null;geo.models||={};const id=nextModelId(geo);
  geo.models[id]=normalizeModelTemplate({id,name:`Modelo ${Object.keys(geo.models).length+1}`,category:"mountain",width:1,height:1,default_height:1,collision:"solid",connect_neighbors:true,builder_version:3,allow_empty:true,parts:[],cells:{}},id);
  state.modelSelectedId=id;state.modelBrushId=id;compileModelObjects(geo);void saveMap(ctx,geo.map_id,{skipCompile:true});state.panelRefresh?.();return geo.models[id];
}

async function createModelFromMapSelection(ctx) {
  const geo=currentGeo(ctx);const mapId=ctx.editor.activeMapId?.();if(!geo||mapId==null)return null;
  let selected=null;try{selected=ctx.map.selectionTiles?.(mapId)||null;}catch(_){ }
  if(!selected?.length){ctx.ui.showToast?.({message:"Selecciona primero uno o varios tiles en el mapa con Select de Maker Studio.",level:"info"});return null;}
  const rows=[...selected].sort((a,b)=>(Number(a.layerIndex)||0)-(Number(b.layerIndex)||0));
  const minX=Math.min(...rows.map(r=>r.x)),maxX=Math.max(...rows.map(r=>r.x)),minY=Math.min(...rows.map(r=>r.y)),maxY=Math.max(...rows.map(r=>r.y));
  const id=nextModelId(geo),parts=[];const layers=authoritativeLayers(ctx,mapId,true);
  let n=1;
  for(const r of rows){
    const layer=layers.find(l=>Number(layerRef(l))===Number(r.layerIndex))||{index:r.layerIndex,id:r.layerIndex,kind:Number(r.layerIndex)>=3?'extended':'native'};
    const data=readTileVisualData(ctx,mapId,layer,r.x,r.y);const desc=data?sourceDescriptor(ctx,mapId,layer,r.x,r.y,data):null;const mat=desc?materialFromSourceDescriptor(desc):null;
    parts.push(normalizeModelPart({id:`box_${n}`,name:`Tile ${n++}`,type:"box",position:{x:r.x-minX+.5,y:r.y-minY+.5,z:0},size:{x:1,y:1,z:1},material:mat,face_materials:{top:mat,north:null,south:null,east:null,west:null}},parts.length));
    if(desc?.tileset_id)await ensureTilesetResourceSet(ctx,desc.tileset_id);
  }
  geo.models||={};geo.models[id]=normalizeModelTemplate({id,name:`Modelo selección ${Object.keys(geo.models).length+1}`,category:"mountain",width:maxX-minX+1,height:maxY-minY+1,default_height:1,collision:"solid",connect_neighbors:true,builder_version:3,allow_empty:true,parts,cells:{}},id);
  state.modelSelectedId=id;state.modelBrushId=id;compileModelObjects(geo);await saveMap(ctx,mapId,{skipCompile:true});state.panelRefresh?.();ctx.editor.requestRedraw();schedulePreview(ctx);ctx.ui.showToast?.({message:`Modelo creado desde ${rows.length} tiles como partes editables.`,level:"success"});return geo.models[id];
}

function deleteModel(ctx,id){
  const geo=currentGeo(ctx);if(!geo?.models?.[id])return;delete geo.models[id];geo.model_instances=(geo.model_instances||[]).filter(i=>i.model_id!==id);if(state.modelSelectedId===id)state.modelSelectedId=null;if(state.modelBrushId===id)state.modelBrushId=null;compileModelObjects(geo);void saveMap(ctx,geo.map_id,{skipCompile:true});ctx.editor.requestRedraw();schedulePreview(ctx);state.panelRefresh?.();
}
function drawModelPreview(ctx,canvas,model,previewRotation=0){
  if(!canvas||!model)return;
  const c=canvas.getContext('2d'),W=canvas.width,H=canvas.height;c.clearRect(0,0,W,H);c.fillStyle='#151922';c.fillRect(0,0,W,H);c.imageSmoothingEnabled=false;
  const built=modelMeshFacesForInstance({id:0,model_id:model.id,x:0,y:0,scale_x:1,scale_y:1,height_scale:1,rotation:normalizeRotation(previewRotation)},model,1);
  const allVerts=built.faces.flatMap(f=>Array.isArray(f.vertices)?f.vertices:[[f.x0,f.y0,f.z0],[f.x1,f.y0,f.z1],[f.x1,f.y1,f.z1],[f.x0,f.y1,f.z0]]);
  const bx=allVerts.length?{x0:Math.min(...allVerts.map(v=>v[0])),x1:Math.max(...allVerts.map(v=>v[0])),y0:Math.min(...allVerts.map(v=>v[1])),y1:Math.max(...allVerts.map(v=>v[1])),z0:Math.min(...allVerts.map(v=>v[2])),z1:Math.max(...allVerts.map(v=>v[2]))}:{x0:0,x1:1,y0:0,y1:1,z0:0,z1:1};
  const cx=(bx.x0+bx.x1)/2,cy=(bx.y0+bx.y1)/2,cz=(bx.z0+bx.z1)/2,span=Math.max(1,bx.x1-bx.x0,bx.y1-bx.y0,bx.z1-bx.z0);const scale=Math.min(W,H)*.62/span;
  const yaw=Math.PI/4,pitch=-Math.PI/5;
  const proj=v=>{let x=v[0]-cx,y=v[1]-cy,z=v[2]-cz;const ca=Math.cos(yaw),sa=Math.sin(yaw);let rx=x*ca-y*sa,ry=x*sa+y*ca;const cp=Math.cos(pitch),sp=Math.sin(pitch);let sy=ry*cp-z*sp,depth=ry*sp+z*cp;return{x:W/2+rx*scale,y:H*.52+sy*scale,depth};};
  const faces=built.faces.map(f=>{let verts;if(Array.isArray(f.vertices))verts=f.vertices;else if(f.kind==='top')verts=[[f.x0,f.y0,f.z1],[f.x1,f.y0,f.z1],[f.x1,f.y1,f.z1],[f.x0,f.y1,f.z1]];else verts=[[f.x0,f.y0,f.z1],[f.x1,f.y1,f.z1],[f.x1,f.y1,f.z0],[f.x0,f.y0,f.z0]];const pts=verts.map(proj);return{f,pts,depth:pts.reduce((a,p)=>a+p.depth,0)/pts.length};}).sort((a,b)=>a.depth-b.depth);
  for(const it of faces){const pts=it.pts;c.save();c.beginPath();c.moveTo(pts[0].x,pts[0].y);for(let i=1;i<pts.length;i++)c.lineTo(pts[i].x,pts[i].y);c.closePath();const src=meshFaceMaterialSource(ctx,it.f);if(src?.img){c.save();c.clip();const xs=pts.map(p=>p.x),ys=pts.map(p=>p.y),x0=Math.min(...xs),y0=Math.min(...ys),x1=Math.max(...xs),y1=Math.max(...ys);c.drawImage(src.img,src.sx,src.sy,src.sw,src.sh,x0,y0,Math.max(1,x1-x0),Math.max(1,y1-y0));c.restore();}else{c.fillStyle=(it.f.surface==='top'||it.f.kind==='top')?'#6c7d55':'#6b5040';c.fill();}c.strokeStyle='rgba(255,255,255,.18)';c.stroke();c.restore();}
  c.fillStyle='rgba(8,12,18,.82)';c.fillRect(10,H-34,Math.min(W-20,360),24);c.fillStyle='#dffcff';c.font='12px sans-serif';c.fillText(`${model.parts?.length||0} partes · ${built.faces.length} caras · ${built.cells.size} celdas de colisión`,18,H-18);
}

function scheduleModelSave(ctx, mapId, delay = 260) {
  clearTimeout(state.modelSaveTimer);
  state.modelSaveTimer = setTimeout(() => {
    state.modelSaveTimer = 0;
    void saveMap(ctx, mapId, { skipCompile: true, skipModelCompile: true });
  }, delay);
}

function scheduleModelTemplateRefresh(ctx, geo, modelId) {
  state.modelCompilePending = { ctx, geo, modelId };
  if (state.modelCompileRaf) return;
  state.modelCompileRaf = requestAnimationFrame(() => {
    state.modelCompileRaf = 0;
    const job = state.modelCompilePending;
    state.modelCompilePending = null;
    if (!job?.geo || !job?.modelId) return;
    compileModelTemplateInstances(job.geo, job.modelId);
    job.ctx.editor.requestRedraw();
    schedulePreview(job.ctx);
  });
}

function openModelWorkshop(ctx){
  const geo=currentGeo(ctx);if(!geo)return;if(!Object.keys(geo.models||{}).length)createModel(ctx);
  const tsList=()=>{try{return(ctx.tileset.list?.()||[]).filter(t=>Number(t?.id));}catch(_){return[];}};
  const initialTs=()=>Number(ctx.tileset.currentId?.()||ctx.tileset.mapTilesetId?.(ctx.editor.activeMapId?.())||tsList()[0]?.id||1);
  const dialog=ctx.ui.showCustomDialog({title:"2.5D Geometry · Model Studio",width:"99vw",height:"97vh",render(body){
    body.style.padding='0';body.style.overflow='hidden';
    let selectedPartId=null,atlasTilesetId=initialTs(),atlasImage=null,atlasSelection=null,atlasDrag=null,atlasZoom=1,renderToken=0,previewRaf=0;
    const cam={yaw:45,pitch:-28,zoom:1,mode:'free'};let previewDrag=null,previewHits=[];
    const getGeo=()=>currentGeo(ctx),getModels=()=>getGeo()?.models||{},getModel=()=>{const ms=getModels();if(!state.modelSelectedId||!ms[state.modelSelectedId])state.modelSelectedId=Object.keys(ms)[0]||null;return ms[state.modelSelectedId]||null;};
    const getPart=()=>{const m=getModel();if(!m)return null;if(!selectedPartId||!(m.parts||[]).some(p=>p.id===selectedPartId))selectedPartId=m.parts?.[0]?.id||null;return(m.parts||[]).find(p=>p.id===selectedPartId)||null;};
    const materialFromAtlas=()=>atlasSelection?{kind:'tileset',tileset_id:Number(atlasTilesetId),graphic:String(tilesetGraphicName(tilesetInfo(ctx,atlasTilesetId))||tilesetInfo(ctx,atlasTilesetId)?.name||''),src_rect:{x:atlasSelection.x,y:atlasSelection.y,w:Math.max(TILE_SIZE,atlasSelection.w),h:Math.max(TILE_SIZE,atlasSelection.h)},rotation:0,flip_h:false,flip_v:false,opacity:255,hue:0,saturation:100,lighting:0}:null;
    const atlasFootprint=()=>({w:Math.max(1,Math.round((Number(atlasSelection?.w)||TILE_SIZE)/TILE_SIZE)),h:Math.max(1,Math.round((Number(atlasSelection?.h)||TILE_SIZE)/TILE_SIZE))});
    const basePartSizeFromAtlas=(type)=>{const fp=atlasFootprint(),w=fp.w,h=fp.h;switch(type){case 'billboard':return{x:w,y:.05,z:h};case 'relief':return{x:w,y:.15,z:h};case 'sphere':case 'cylinder':case 'dome':return{x:w,y:Math.max(1,w),z:h};case 'prism':case 'wedge':case 'box':default:return{x:w,y:1,z:h};}};
    const fitPartToAtlas=(part)=>{if(!part||!atlasSelection)return false;const next=basePartSizeFromAtlas(part.type);part.size={...part.size,...next};return true;};
    const normalizeRect=(a,b)=>{const x0=Math.min(a.x,b.x),y0=Math.min(a.y,b.y),x1=Math.max(a.x,b.x),y1=Math.max(a.y,b.y);return{x:x0*TILE_SIZE,y:y0*TILE_SIZE,w:(x1-x0+1)*TILE_SIZE,h:(y1-y0+1)*TILE_SIZE};};
    const persist=(rerender=false)=>{const g=getGeo(),m=getModel(),mapId=ctx.editor.activeMapId?.();if(!g||!m||mapId==null)return;const b=modelPartBounds(m);m.width=Math.max(1,Math.ceil(b.x1-b.x0));m.height=Math.max(1,Math.ceil(b.y1-b.y0));scheduleModelTemplateRefresh(ctx,g,m.id);scheduleModelSave(ctx,mapId,160);ctx.editor.requestRedraw();schedulePreview(ctx);state.panelRefresh?.();queuePreview();if(rerender)render();};
    const addPart=(type)=>{const m=getModel();if(!m)return;m.parts||=[];const id=nextModelPartId(m,type),b=modelPartBounds(m),mat=materialFromAtlas(),defaults=basePartSizeFromAtlas(type);const empty=m.parts.length===0,cx=empty?defaults.x/2:Math.max(defaults.x/2,(b.x0+b.x1)/2||defaults.x/2),cy=empty?defaults.y/2:Math.max(defaults.y/2,(b.y0+b.y1)/2||defaults.y/2);const p=normalizeModelPart({id,name:`${type.toUpperCase()} ${m.parts.length+1}`,type,position:{x:cx,y:cy,z:0},size:defaults,material:mat,face_materials:mat?{top:mat,north:mat,south:mat,east:mat,west:mat}:null},m.parts.length);m.parts.push(p);selectedPartId=id;persist(true);};
    const duplicatePart=()=>{const m=getModel(),p=getPart();if(!m||!p)return;const cp=deepClone(p);cp.id=nextModelPartId(m,p.type);cp.name=`${p.name} copy`;cp.position.x+=.25;cp.position.y+=.25;m.parts.push(normalizeModelPart(cp,m.parts.length));selectedPartId=cp.id;persist(true);};
    const deletePart=()=>{const m=getModel(),p=getPart();if(!m||!p)return;m.parts=m.parts.filter(x=>x.id!==p.id);selectedPartId=m.parts[0]?.id||null;persist(true);};
    const applyMaterial=(edge='all')=>{const p=getPart(),mat=materialFromAtlas();if(!p||!mat){ctx.ui.showToast?.({message:'Selecciona primero una textura en el tileset.',level:'info'});return;}const hadMaterial=!!p.material||Object.values(p.face_materials||{}).some(Boolean);if(edge==='all'){p.material=deepClone(mat);p.face_materials=normalizeFaceMaterialMap({top:mat,north:mat,south:mat,east:mat,west:mat});if(!hadMaterial)fitPartToAtlas(p);}else{p.face_materials||=normalizeFaceMaterialMap(null);p.face_materials[edge]=deepClone(mat);}persist();drawMaterialButtons();};
    const clearMaterial=(edge)=>{const p=getPart();if(!p)return;if(edge==='all'){p.material=null;p.face_materials=normalizeFaceMaterialMap(null);}else{p.face_materials||=normalizeFaceMaterialMap(null);p.face_materials[edge]=null;}persist();drawMaterialButtons();};

    const atlasPos=(canvas,ev)=>{const r=canvas.getBoundingClientRect();if(!atlasImage||!r.width||!r.height)return null;const px=(ev.clientX-r.left)*(canvas.width/r.width),py=(ev.clientY-r.top)*(canvas.height/r.height);return{x:Math.max(0,Math.min(Math.floor((atlasImage.width-1)/TILE_SIZE),Math.floor(px/TILE_SIZE))),y:Math.max(0,Math.min(Math.floor((atlasImage.height-1)/TILE_SIZE),Math.floor(py/TILE_SIZE)))};};
    const drawAtlas=()=>{const cv=body.querySelector('[data-ms-atlas]');if(!cv)return;const c=cv.getContext('2d');c.imageSmoothingEnabled=false;if(!atlasImage){cv.width=512;cv.height=512;cv.style.width='512px';cv.style.height='512px';c.fillStyle='#0f131a';c.fillRect(0,0,512,512);c.fillStyle='#b7c0cc';c.fillText('Loading tileset…',18,28);return;}cv.width=atlasImage.width;cv.height=atlasImage.height;cv.style.width=`${Math.round(atlasImage.width*atlasZoom)}px`;cv.style.height=`${Math.round(atlasImage.height*atlasZoom)}px`;c.clearRect(0,0,cv.width,cv.height);c.drawImage(atlasImage,0,0);c.strokeStyle='rgba(255,255,255,.10)';for(let x=0;x<=cv.width;x+=TILE_SIZE){c.beginPath();c.moveTo(x+.5,0);c.lineTo(x+.5,cv.height);c.stroke();}for(let y=0;y<=cv.height;y+=TILE_SIZE){c.beginPath();c.moveTo(0,y+.5);c.lineTo(cv.width,y+.5);c.stroke();}if(atlasSelection){c.fillStyle='rgba(255,85,24,.20)';c.fillRect(atlasSelection.x,atlasSelection.y,atlasSelection.w,atlasSelection.h);c.strokeStyle='#ff4b18';c.lineWidth=2/atlasZoom;c.strokeRect(atlasSelection.x+.5,atlasSelection.y+.5,atlasSelection.w-1,atlasSelection.h-1);}const info=body.querySelector('[data-ms-atlas-info]');if(info)info.textContent=atlasSelection?`${atlasSelection.w/TILE_SIZE}×${atlasSelection.h/TILE_SIZE} · ${atlasSelection.x}, ${atlasSelection.y}`:'Drag over the tileset to pick a texture';};
    const loadAtlas=async(id)=>{atlasTilesetId=Number(id)||initialTs();atlasImage=null;atlasSelection=null;drawAtlas();const token=++renderToken;const res=await ensureTilesetResourceSet(ctx,atlasTilesetId);if(token!==renderToken)return;atlasImage=res?.image||state.preview.tilesetImages.get(atlasTilesetId)||null;drawAtlas();};

    const partFacesLocal=()=>{const m=getModel();if(!m)return[];const inst={id:0,model_id:m.id,x:0,y:0,scale_x:1,scale_y:1,height_scale:1,rotation:0};return modelPartMeshFacesForInstance(inst,m,1).faces;};
    const drawPreview=()=>{const cv=body.querySelector('[data-ms-preview]'),m=getModel();if(!cv||!m)return;const dpr=Math.max(1,Math.min(2,window.devicePixelRatio||1)),r=cv.getBoundingClientRect();const w=Math.max(640,Math.round(r.width*dpr)),h=Math.max(360,Math.round(r.height*dpr));if(cv.width!==w||cv.height!==h){cv.width=w;cv.height=h;}const c=cv.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);const W=w/dpr,H=h/dpr;c.clearRect(0,0,W,H);c.fillStyle='#11161e';c.fillRect(0,0,W,H);c.imageSmoothingEnabled=false;const faces=partFacesLocal(),verts=faces.flatMap(f=>f.vertices||[]);const b=verts.length?{x0:Math.min(...verts.map(v=>v[0])),x1:Math.max(...verts.map(v=>v[0])),y0:Math.min(...verts.map(v=>v[1])),y1:Math.max(...verts.map(v=>v[1])),z0:Math.min(...verts.map(v=>v[2])),z1:Math.max(...verts.map(v=>v[2]))}:{x0:0,x1:4,y0:0,y1:4,z0:0,z1:2};const center=[(b.x0+b.x1)/2,(b.y0+b.y1)/2,(b.z0+b.z1)/2],span=Math.max(2,b.x1-b.x0,b.y1-b.y0,b.z1-b.z0),scale=Math.min(W,H)*.55/span*cam.zoom;const yaw=cam.yaw*Math.PI/180,pitch=cam.pitch*Math.PI/180;const projectP=v=>{let x=v[0]-center[0],y=v[1]-center[1],z=v[2]-center[2];const ca=Math.cos(yaw),sa=Math.sin(yaw);let rx=x*ca-y*sa,ry=x*sa+y*ca;const cp=Math.cos(pitch),sp=Math.sin(pitch);let sy=ry*cp-z*sp,depth=ry*sp+z*cp;return{x:W/2+rx*scale,y:H*.54+sy*scale,depth};};
      // floor grid
      c.strokeStyle='rgba(165,180,198,.18)';c.lineWidth=1;const grid=8;for(let i=-grid;i<=grid;i++){let a=projectP([center[0]+i,center[1]-grid,0]),bb=projectP([center[0]+i,center[1]+grid,0]);c.beginPath();c.moveTo(a.x,a.y);c.lineTo(bb.x,bb.y);c.stroke();a=projectP([center[0]-grid,center[1]+i,0]);bb=projectP([center[0]+grid,center[1]+i,0]);c.beginPath();c.moveTo(a.x,a.y);c.lineTo(bb.x,bb.y);c.stroke();}
      previewHits=[];const items=faces.map(f=>{const pts=(f.vertices||[]).map(projectP);return{f,pts,depth:pts.reduce((a,p)=>a+p.depth,0)/Math.max(1,pts.length)};}).sort((a,b)=>a.depth-b.depth);
      for(const it of items){const pts=it.pts;if(pts.length!==4)continue;c.save();c.beginPath();c.moveTo(pts[0].x,pts[0].y);for(let i=1;i<4;i++)c.lineTo(pts[i].x,pts[i].y);c.closePath();const src=meshFaceMaterialSource(ctx,it.f);if(src?.img){c.save();c.clip();const xs=pts.map(p=>p.x),ys=pts.map(p=>p.y),x0=Math.min(...xs),y0=Math.min(...ys),x1=Math.max(...xs),y1=Math.max(...ys);c.drawImage(src.img,src.sx,src.sy,src.sw,src.sh,x0,y0,Math.max(1,x1-x0),Math.max(1,y1-y0));c.restore();}else{c.fillStyle=it.f.surface==='top'?'#9da77b':'#6f6257';c.fill();}c.strokeStyle=it.f.part_id===selectedPartId?'#ff6a2a':'rgba(220,230,242,.35)';c.lineWidth=it.f.part_id===selectedPartId?2:1;c.stroke();c.restore();const xs=pts.map(p=>p.x),ys=pts.map(p=>p.y);previewHits.push({part_id:it.f.part_id,x0:Math.min(...xs),x1:Math.max(...xs),y0:Math.min(...ys),y1:Math.max(...ys)});}
      // selection handles
      if(selectedPartId){const selected=items.filter(i=>i.f.part_id===selectedPartId).flatMap(i=>i.pts);if(selected.length){c.fillStyle='#ff4b18';for(const p of selected.slice(0,24)){c.fillRect(p.x-3,p.y-3,6,6);}}}
      c.fillStyle='rgba(8,12,18,.88)';c.fillRect(8,H-26,390,20);c.fillStyle='#dfe7f1';c.font='11px monospace';c.fillText(`DRAG ORBIT · WHEEL ZOOM · ${m.parts?.length||0} PARTS · ${faces.length} FACES`,14,H-12);
    };
    const queuePreview=()=>{if(previewRaf)cancelAnimationFrame(previewRaf);previewRaf=requestAnimationFrame(()=>{previewRaf=0;drawPreview();drawPartThumb();drawMaterialButtons();});};
    const drawPartThumb=()=>{const p=getPart(),cv=body.querySelector('[data-ms-picked]');if(cv)v2DrawMaterialThumb(ctx,cv,materialFromAtlas(),atlasSelection?`ms:${atlasTilesetId}:${atlasSelection.x}:${atlasSelection.y}`:'');const txt=body.querySelector('[data-ms-picked-text]');if(txt)txt.textContent=atlasSelection?`Tileset ${atlasTilesetId} · ${atlasSelection.w/TILE_SIZE}×${atlasSelection.h/TILE_SIZE}`:'No texture selected';};
    const drawMaterialButtons=()=>{const p=getPart();for(const cv of body.querySelectorAll('canvas[data-ms-face-thumb]')){const edge=cv.getAttribute('data-ms-face-thumb'),mat=edge==='all'?(p?.material||p?.face_materials?.top):p?.face_materials?.[edge];v2DrawMaterialThumb(ctx,cv,mat||null,`part:${p?.id||''}:${edge}`);}};

    const render=()=>{const models=getModels(),m=getModel();if(!m)return;const p=getPart(),mb=modelPartBounds(m),modelHeight=Math.max(0,mb.z1-mb.z0);const modelList=Object.values(models).map(x=>`<button data-ms-model="${escapeHtml(x.id)}" style="${buttonStyle(x.id===state.modelSelectedId)}width:100%;text-align:left;margin-bottom:4px;">${escapeHtml(x.name)} <span style="opacity:.55;float:right">${x.parts?.length||0}</span></button>`).join('');const tsOpts=tsList().map(t=>`<option value="${Number(t.id)}" ${Number(t.id)===Number(atlasTilesetId)?'selected':''}>${escapeHtml(t.name||t.tilesetName||`Tileset ${t.id}`)}</option>`).join('');const parts=(m.parts||[]).map((x,i)=>`<button data-ms-part="${escapeHtml(x.id)}" style="${buttonStyle(x.id===selectedPartId)}width:100%;text-align:left;margin:2px 0;">${String(i).padStart(2,'0')} ${escapeHtml(x.name)} <span style="float:right;opacity:.6">${x.type.toUpperCase()}</span></button>`).join('')||`<div style="padding:8px;color:var(--text-tertiary)">No parts yet. Add a primitive.</div>`;
      const val=(obj,k)=>Number(obj?.[k])||0;
      body.innerHTML=`<style>[data-ms-root] input,[data-ms-root] select{background:#0b1017;color:#e6edf3;border:1px solid #3a4350;border-radius:4px;padding:4px 5px;box-sizing:border-box}[data-ms-root] input:focus,[data-ms-root] select:focus{outline:1px solid #ff6a2a;border-color:#ff6a2a}[data-ms-root] hr{border-color:#30363d!important}[data-ms-root] canvas{background-color:#0b1017}</style><div data-ms-root style="height:94vh;min-height:700px;display:grid;grid-template-rows:46px minmax(0,1fr);background:#0d1117;color:#e6edf3;font:12px ui-monospace,Consolas,monospace;">
        <header style="display:flex;align-items:center;gap:6px;padding:6px 10px;border-bottom:1px solid #30363d;background:#161b22;"><b style="letter-spacing:1px">■ 2.5D GEOMETRY STUDIO</b><span style="margin-left:12px;padding:6px 12px;background:#ff4b18;color:white;font-weight:700">MODEL</span><div style="flex:1"></div><button data-ms-map style="${buttonStyle(false)}">← MAP</button><button data-ms-place style="${buttonStyle(true)}">PLACE MODEL</button></header>
        <div style="min-height:0;display:grid;grid-template-columns:210px minmax(520px,1fr) 320px;">
          <aside style="min-height:0;border-right:1px solid #30363d;background:#11161e;display:grid;grid-template-rows:auto minmax(0,1fr) auto;">
            <div style="padding:10px;border-bottom:1px solid #30363d"><b>MODELS</b><div style="font-size:10px;color:#8b949e;margin-top:4px">Reusable geometry groups</div></div>
            <div style="overflow:auto;padding:8px">${modelList}</div>
            <div style="padding:8px;border-top:1px solid #30363d;display:grid;grid-template-columns:1fr 1fr;gap:5px"><button data-ms-new style="${buttonStyle(false)}">NEW</button><button data-ms-from style="${buttonStyle(false)}">FROM MAP</button><button data-ms-dup-model style="${buttonStyle(false)}">DUPLICATE</button><button data-ms-del-model style="${buttonStyle(false)}">DELETE</button></div>
          </aside>
          <main style="min-width:0;min-height:0;display:grid;grid-template-rows:minmax(260px,43%) minmax(320px,57%);">
            <section style="min-height:0;border-bottom:1px solid #30363d;display:grid;grid-template-rows:38px minmax(0,1fr);background:#0d1117"><div style="display:flex;align-items:center;gap:8px;padding:5px 10px;border-bottom:1px solid #30363d"><b>ROOM / TILESET PAL</b><select data-ms-ts style="min-width:220px">${tsOpts}</select><span data-ms-atlas-info style="color:#8b949e"></span><div style="flex:1"></div><label>ZOOM <select data-ms-atlas-zoom><option value=".5">50%</option><option value="1" selected>100%</option><option value="1.5">150%</option><option value="2">200%</option></select></label></div><div style="min-height:0;overflow:auto;padding:8px;background:#090d12"><canvas data-ms-atlas style="display:block;image-rendering:pixelated;cursor:crosshair"></canvas></div></section>
            <section style="min-height:0;display:grid;grid-template-rows:minmax(0,1fr) 34px;background:#11161e"><canvas data-ms-preview style="display:block;width:100%;height:100%;cursor:grab"></canvas><div style="display:flex;align-items:center;gap:5px;padding:4px 8px;border-top:1px solid #30363d"><span style="margin-right:8px">VIEW</span>${['ISO','FRONT','SIDE','TOP','FREE'].map(v=>`<button data-ms-view="${v.toLowerCase()}" style="${buttonStyle(cam.mode===v.toLowerCase())}">${v}</button>`).join('')}<div style="flex:1"></div><span>ZOOM</span><button data-ms-zoom="1" style="${buttonStyle(cam.zoom===1)}">1X</button><button data-ms-zoom="1.5" style="${buttonStyle(cam.zoom===1.5)}">2X</button><button data-ms-zoom="2" style="${buttonStyle(cam.zoom===2)}">3X</button></div></section>
          </main>
          <aside style="min-height:0;border-left:1px solid #30363d;background:#11161e;overflow:auto;padding:10px">
            <div style="display:grid;gap:6px"><label>GROUP<input data-ms-name value="${escapeHtml(m.name)}" style="width:100%"></label><div style="display:flex;justify-content:space-between"><span>MAP FOOTPRINT</span><b>${m.width} × ${m.height}</b></div><div style="display:flex;justify-content:space-between"><span>MODEL HEIGHT</span><b>${modelHeight.toFixed(2)} tiles</b></div><div style="display:flex;justify-content:space-between"><span>PARTS</span><b>${m.parts?.length||0}</b></div></div>
            <hr style="border:0;border-top:1px solid #30363d;margin:10px 0"><b>PARTS</b><div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:6px">${[['box','BOX'],['billboard','BILLBD'],['sphere','SPHERE'],['relief','RELIEF'],['cylinder','CYLNDR'],['prism','PRISM'],['dome','DOME'],['wedge','WEDGE']].map(([t,l])=>`<button data-ms-add="${t}" style="${buttonStyle(false)}">+ ${l}</button>`).join('')}</div>
            <div style="margin:8px 0;max-height:170px;overflow:auto">${parts}</div>
            ${p?`<hr style="border:0;border-top:1px solid #30363d;margin:10px 0"><b>PART ${escapeHtml(p.id)} · ${p.type.toUpperCase()}</b><input data-ms-part-name value="${escapeHtml(p.name)}" style="width:100%;margin:6px 0"><div style="display:grid;grid-template-columns:1fr 1fr;gap:5px"><button data-ms-dup-part style="${buttonStyle(false)}">DUPLICATE</button><button data-ms-del-part style="${buttonStyle(false)}">DELETE</button></div>
              <div style="margin-top:9px"><b>POS</b><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:4px">${['x','y','z'].map(k=>`<label>${k.toUpperCase()}<input data-ms-pos="${k}" type="number" step=".25" value="${val(p.position,k)}" style="width:100%"></label>`).join('')}</div></div>
              <div style="margin-top:8px"><div style="display:flex;align-items:center;justify-content:space-between;gap:6px"><b>SIZE</b><button data-ms-fit-texture style="${buttonStyle(false)}font-size:10px;padding:2px 6px">FIT TO TEXTURE</button></div><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:4px;margin-top:4px">${['x','y','z'].map(k=>`<label>${k.toUpperCase()}<input data-ms-size="${k}" type="number" min=".05" step=".25" value="${val(p.size,k)}" style="width:100%"></label>`).join('')}</div><div style="font-size:10px;color:#8b949e;margin-top:4px">Texture W×H → Size X×Z. ${atlasSelection?`Current: ${atlasSelection.w/TILE_SIZE}×${atlasSelection.h/TILE_SIZE} tiles`:''}</div></div>
              <div style="margin-top:8px"><b>ANGLE</b><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:4px">${['x','y','z'].map(k=>`<label>${k.toUpperCase()}<input data-ms-angle="${k}" type="number" step="5" value="${val(p.angle,k)}" style="width:100%"></label>`).join('')}</div></div>
              <div style="margin-top:8px;display:flex;gap:8px"><label>AXIS <select data-ms-axis><option value="x" ${p.axis==='x'?'selected':''}>X</option><option value="y" ${p.axis==='y'?'selected':''}>Y</option><option value="z" ${p.axis==='z'?'selected':''}>Z</option></select></label><label>SEG <input data-ms-segments type="number" min="4" max="24" value="${p.segments}" style="width:54px"></label><label><input data-ms-collision type="checkbox" ${p.collision!==false?'checked':''}> COLLISION</label></div>
              <hr style="border:0;border-top:1px solid #30363d;margin:10px 0"><b>MATERIAL</b><div style="display:grid;grid-template-columns:64px 1fr;gap:6px;align-items:center;margin-top:6px"><canvas data-ms-picked width="64" height="64" style="border:1px solid #3d4654;image-rendering:pixelated"></canvas><div><span data-ms-picked-text>No texture selected</span><div style="font-size:10px;color:#8b949e;margin-top:4px">Drag on the tileset, then assign a face.</div></div></div><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-top:7px">${['all','top','north','south','east','west'].map(edge=>`<button data-ms-apply="${edge}" style="padding:4px"><canvas data-ms-face-thumb="${edge}" width="38" height="30" style="display:block;margin:auto;image-rendering:pixelated"></canvas>${edge.toUpperCase()}</button>`).join('')}</div><button data-ms-clear-mat style="${buttonStyle(false)}width:100%;margin-top:5px">CLEAR MATERIALS</button>`:`<div style="padding:12px 0;color:#8b949e">Add or select a part to edit its transform and material.</div>`}
          </aside>
        </div></div>`;
      // model controls
      for(const b of body.querySelectorAll('[data-ms-model]'))b.onclick=()=>{state.modelSelectedId=b.getAttribute('data-ms-model');state.modelBrushId=state.modelSelectedId;selectedPartId=null;render();};
      body.querySelector('[data-ms-new]')?.addEventListener('click',()=>{createModel(ctx);selectedPartId=null;render();});
      body.querySelector('[data-ms-from]')?.addEventListener('click',()=>void createModelFromMapSelection(ctx).then(()=>{selectedPartId=null;render();}));
      body.querySelector('[data-ms-del-model]')?.addEventListener('click',()=>{if(state.modelSelectedId)deleteModel(ctx,state.modelSelectedId);selectedPartId=null;render();});
      body.querySelector('[data-ms-dup-model]')?.addEventListener('click',()=>{const g=getGeo(),m=getModel();if(!g||!m)return;const id=nextModelId(g),cp=deepClone(m);cp.id=id;cp.name=`${m.name} copy`;g.models[id]=normalizeModelTemplate(cp,id);state.modelSelectedId=id;state.modelBrushId=id;selectedPartId=null;persist(true);});
      body.querySelector('[data-ms-name]')?.addEventListener('change',e=>{const mm=getModel();if(mm){mm.name=e.target.value||mm.name;persist(true);}});
      for(const b of body.querySelectorAll('[data-ms-add]'))b.onclick=()=>addPart(b.getAttribute('data-ms-add'));
      for(const b of body.querySelectorAll('[data-ms-part]'))b.onclick=()=>{selectedPartId=b.getAttribute('data-ms-part');render();};
      body.querySelector('[data-ms-dup-part]')?.addEventListener('click',duplicatePart);body.querySelector('[data-ms-del-part]')?.addEventListener('click',deletePart);
      body.querySelector('[data-ms-part-name]')?.addEventListener('change',e=>{const pp=getPart();if(pp){pp.name=e.target.value||pp.name;persist(true);}});
      for(const el of body.querySelectorAll('[data-ms-pos]'))el.addEventListener('change',e=>{const pp=getPart();if(!pp)return;pp.position[el.getAttribute('data-ms-pos')]=Number(e.target.value)||0;persist();});
      for(const el of body.querySelectorAll('[data-ms-size]'))el.addEventListener('change',e=>{const pp=getPart();if(!pp)return;pp.size[el.getAttribute('data-ms-size')]=Math.max(.05,Math.abs(Number(e.target.value)||.05));persist();});
      body.querySelector('[data-ms-fit-texture]')?.addEventListener('click',()=>{const pp=getPart();if(!pp)return;if(!atlasSelection){ctx.ui.showToast?.({message:'Selecciona primero uno o varios tiles en la paleta.',level:'info'});return;}fitPartToAtlas(pp);persist(true);});
      for(const el of body.querySelectorAll('[data-ms-angle]'))el.addEventListener('change',e=>{const pp=getPart();if(!pp)return;pp.angle[el.getAttribute('data-ms-angle')]=Number(e.target.value)||0;persist();});
      body.querySelector('[data-ms-axis]')?.addEventListener('change',e=>{const pp=getPart();if(pp){pp.axis=e.target.value;persist();}});body.querySelector('[data-ms-segments]')?.addEventListener('change',e=>{const pp=getPart();if(pp){pp.segments=Math.max(4,Math.min(24,Math.round(Number(e.target.value)||8)));persist();}});body.querySelector('[data-ms-collision]')?.addEventListener('change',e=>{const pp=getPart();if(pp){pp.collision=!!e.target.checked;persist();}});
      for(const b of body.querySelectorAll('[data-ms-apply]'))b.onclick=()=>applyMaterial(b.getAttribute('data-ms-apply'));body.querySelector('[data-ms-clear-mat]')?.addEventListener('click',()=>clearMaterial('all'));
      // atlas
      const atlas=body.querySelector('[data-ms-atlas]');atlas?.addEventListener('pointerdown',e=>{if(e.button!==0)return;const p0=atlasPos(atlas,e);if(!p0)return;e.preventDefault();atlasDrag=p0;atlasSelection=normalizeRect(p0,p0);drawAtlas();atlas.setPointerCapture?.(e.pointerId);});atlas?.addEventListener('pointermove',e=>{if(!atlasDrag||(e.buttons&1)===0)return;const p0=atlasPos(atlas,e);if(!p0)return;atlasSelection=normalizeRect(atlasDrag,p0);drawAtlas();drawPartThumb();});const endAtlas=()=>{atlasDrag=null;drawAtlas();drawPartThumb();};atlas?.addEventListener('pointerup',endAtlas);atlas?.addEventListener('pointercancel',endAtlas);atlas?.addEventListener('dblclick',()=>applyMaterial('all'));body.querySelector('[data-ms-ts]')?.addEventListener('change',e=>void loadAtlas(e.target.value));body.querySelector('[data-ms-atlas-zoom]')?.addEventListener('change',e=>{atlasZoom=Math.max(.5,Math.min(2,Number(e.target.value)||1));drawAtlas();});
      // preview orbit/select
      const pv=body.querySelector('[data-ms-preview]');pv?.addEventListener('pointerdown',e=>{if(e.button!==0&&e.button!==2)return;e.preventDefault();previewDrag={x:e.clientX,y:e.clientY,yaw:cam.yaw,pitch:cam.pitch,moved:false};pv.setPointerCapture?.(e.pointerId);});pv?.addEventListener('pointermove',e=>{if(!previewDrag)return;const dx=e.clientX-previewDrag.x,dy=e.clientY-previewDrag.y;if(Math.abs(dx)+Math.abs(dy)>3)previewDrag.moved=true;if(previewDrag.moved){cam.mode='free';cam.yaw=previewDrag.yaw+dx*.45;cam.pitch=Math.max(-85,Math.min(85,previewDrag.pitch+dy*.35));queuePreview();}});pv?.addEventListener('pointerup',e=>{if(previewDrag&&!previewDrag.moved){const r=pv.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;const hits=previewHits.filter(h=>x>=h.x0&&x<=h.x1&&y>=h.y0&&y<=h.y1);if(hits.length){selectedPartId=hits[hits.length-1].part_id;render();}}previewDrag=null;});pv?.addEventListener('wheel',e=>{e.preventDefault();cam.zoom=Math.max(.35,Math.min(4,cam.zoom*(e.deltaY>0?.9:1.1)));queuePreview();},{passive:false});pv?.addEventListener('contextmenu',e=>e.preventDefault());
      for(const b of body.querySelectorAll('[data-ms-view]'))b.onclick=()=>{const v=b.getAttribute('data-ms-view');cam.mode=v;if(v==='iso'){cam.yaw=45;cam.pitch=-28;}else if(v==='front'){cam.yaw=0;cam.pitch=0;}else if(v==='side'){cam.yaw=90;cam.pitch=0;}else if(v==='top'){cam.yaw=0;cam.pitch=-90;}queuePreview();render();};for(const b of body.querySelectorAll('[data-ms-zoom]'))b.onclick=()=>{cam.zoom=Number(b.getAttribute('data-ms-zoom'))||1;queuePreview();};
      const place=()=>{const mm=getModel();if(!mm)return;state.modelBrushId=mm.id;state.modelSelectedId=mm.id;state.modelTool=true;state.modelEraseMode=false;state.sceneTool='model-place';ctx.editor.setTool(TOOL_ID);ctx.ui.showToast?.({message:`${mm.name}: haz clic en el mapa para colocarlo.`,level:'info'});dialog.close();state.panelRefresh?.();};body.querySelector('[data-ms-place]')?.addEventListener('click',place);body.querySelector('[data-ms-map]')?.addEventListener('click',()=>{state.sceneTool='select';state.modelTool=false;ctx.editor.setTool(TOOL_ID);dialog.close();state.panelRefresh?.();});
      queuePreview();drawAtlas();void loadAtlas(atlasTilesetId);
    };
    render();return()=>{if(previewRaf)cancelAnimationFrame(previewRaf);renderToken++;const g=getGeo();if(g){clearTimeout(state.modelSaveTimer);state.modelSaveTimer=0;void saveMap(ctx,g.map_id,{skipCompile:true,skipModelCompile:true});}};
  }});return dialog;
}

// =============================================================================
// V2 Visual Workspace
// =============================================================================

function v2RuleForSelection(ctx) {
  const geo = currentGeo(ctx);
  const sel = state.sourceSelection;
  if (!geo || !sel) return null;
  const def = geo.definitions?.[sel.key];
  return def ? effectiveSourceRule(def, geo.instance_overrides?.[sel.instance_key]) : null;
}

function v2PresetLabel(name) {
  return simplePresetLabel(name === "elevation" ? "mountain" : name);
}

function v2PresetInternal(name) {
  return name === "elevation" ? "mountain" : name;
}

function v2SourceMaterial(desc) {
  return desc ? materialFromSourceDescriptor(desc) : null;
}

function v2DrawMaterialThumb(ctx, canvas, material, sourceKey = "") {
  if (!canvas) return;
  const c = canvas.getContext("2d");
  const W = canvas.width || 96, H = canvas.height || 96;
  c.clearRect(0, 0, W, H);
  c.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--canvas-bg").trim() || "#1b1e25";
  c.fillRect(0, 0, W, H);
  c.imageSmoothingEnabled = false;
  if (!material) {
    c.fillStyle = "rgba(255,255,255,.45)";
    c.font = "12px sans-serif";
    c.textAlign = "center";
    c.fillText("Sin gráfico", W / 2, H / 2);
    return;
  }
  const src = objectMaterialSource(ctx, { material, source_key: sourceKey });
  if (!src?.img) {
    c.fillStyle = "rgba(255,190,75,.7)";
    c.font = "11px sans-serif";
    c.textAlign = "center";
    c.fillText("Cargando…", W / 2, H / 2);
    return;
  }
  const pad = 7;
  const scale = Math.min((W - pad * 2) / src.sw, (H - pad * 2) / src.sh);
  const dw = Math.max(1, Math.round(src.sw * scale));
  const dh = Math.max(1, Math.round(src.sh * scale));
  c.drawImage(src.img, src.sx, src.sy, src.sw, src.sh,
    Math.round((W - dw) / 2), Math.round((H - dh) / 2), dw, dh);
  c.strokeStyle = "rgba(120,220,255,.55)";
  c.strokeRect(.5, .5, W - 1, H - 1);
}

function v2DrawSelectedThumbnail(ctx, host) {
  const canvas = host?.querySelector?.('[data-id="v2-selected-thumb"]');
  if (!canvas) return;
  const sel = state.sourceSelection;
  v2DrawMaterialThumb(ctx, canvas, v2SourceMaterial(sel), sel?.key || "");
}

function v2DrawPickedThumbnail(ctx, host) {
  const canvas = host?.querySelector?.('[data-id="v2-picked-thumb"]');
  if (!canvas) return;
  v2DrawMaterialThumb(ctx, canvas, state.visualSource?.material || null, state.visualSource?.source_key || "");
}

function v2DrawBrowserThumbs(ctx, host) {
  if (!host) return;
  const usage = state.sourceUsage;
  for (const canvas of host.querySelectorAll('canvas[data-v2-source-thumb]')) {
    const key = canvas.getAttribute('data-v2-source-thumb');
    const desc = usage?.placements?.find?.((p) => p.key === key) || null;
    v2DrawMaterialThumb(ctx, canvas, v2SourceMaterial(desc), desc?.key || "");
  }
}

function openGeometryGraphicPicker(ctx, options = {}) {
  return new Promise((resolve) => {
    const list = (ctx.tileset.list?.() || []).filter(t => Number(t?.id));
    const mapId = ctx.editor.activeMapId?.();
    const initialId = Number(options.tilesetId || ctx.tileset.currentId?.() || (mapId != null ? ctx.tileset.mapTilesetId?.(mapId) : 0) || list[0]?.id || 0);
    let activeId = initialId;
    let image = null;
    let selection = null;
    let dragStart = null;
    let zoom = 1;
    let finished = false;
    let dialog = null;

    const finish = (value) => {
      if (finished) return;
      finished = true;
      resolve(value || null);
      try { dialog?.close?.(); } catch (_) {}
    };

    dialog = ctx.ui.showCustomDialog({
      title: options.title || "2.5D Geometry · Selector de gráficos",
      width: "98vw",
      height: "95vh",
      render(body) {
        body.style.padding = "0";
        body.style.overflow = "hidden";
        body.innerHTML = `<div style="height:91vh;min-height:700px;display:grid;grid-template-columns:240px minmax(0,1fr) 300px;background:var(--bg-primary);color:var(--text-primary);font:13px inherit;">
          <aside style="border-right:1px solid var(--border);display:flex;flex-direction:column;min-width:0;">
            <div style="padding:10px 12px;border-bottom:1px solid var(--border);font-weight:700;">Tilesets</div>
            <div data-gp-list style="flex:1;overflow:auto;padding:7px;display:flex;flex-direction:column;gap:4px;">
              ${list.map(t=>`<button data-gp-ts="${Number(t.id)}" style="${buttonStyle(Number(t.id)===activeId)}text-align:left;width:100%;padding:8px;">${escapeHtml(t.name || t.tilesetName || `Tileset ${t.id}`)}<br><small style="color:var(--text-tertiary);">${escapeHtml(t.tilesetName || '')}</small></button>`).join('')}
            </div>
          </aside>
          <main style="display:flex;flex-direction:column;min-width:0;min-height:0;">
            <div style="padding:8px 10px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:7px;">
              <strong style="flex:1;">Arrastra para seleccionar uno o varios tiles</strong>
              <label>Zoom <select data-gp-zoom style="${selectStyle()}"><option value="0.5">50%</option><option value="1" selected>100%</option><option value="1.5">150%</option><option value="2">200%</option></select></label>
            </div>
            <div data-gp-scroll style="flex:1;overflow:auto;background:var(--canvas-bg);padding:18px;">
              <canvas data-gp-canvas style="display:block;image-rendering:pixelated;touch-action:none;box-shadow:0 0 0 1px var(--border);"></canvas>
            </div>
          </main>
          <aside style="border-left:1px solid var(--border);padding:12px;display:flex;flex-direction:column;gap:10px;overflow:auto;">
            <div style="font-weight:700;font-size:14px;display:flex;align-items:center;gap:8px;">Selección <button data-gp-use-top disabled style="${buttonStyle(true)}margin-left:auto;padding:7px 10px;">✓ Seleccionar</button></div>
            <canvas data-gp-preview width="260" height="260" style="width:100%;aspect-ratio:1;border:1px solid var(--border);border-radius:7px;background:var(--canvas-bg);image-rendering:pixelated;"></canvas>
            <div data-gp-info style="color:var(--text-secondary);line-height:1.5;">Selecciona un tile.</div>
            <div style="flex:1;"></div>
            <button data-gp-use disabled style="${buttonStyle(true)}font-size:14px;padding:10px 12px;position:sticky;bottom:0;">✓ Seleccionar</button>
          </aside>
        </div>`;
        const canvas = body.querySelector('[data-gp-canvas]');
        const preview = body.querySelector('[data-gp-preview]');
        const info = body.querySelector('[data-gp-info]');
        const use = body.querySelector('[data-gp-use]');
        const useTop = body.querySelector('[data-gp-use-top]');
        const zoomSel = body.querySelector('[data-gp-zoom]');

        const normalizeRect = (a,b) => {
          const x0=Math.min(a.x,b.x), y0=Math.min(a.y,b.y), x1=Math.max(a.x,b.x), y1=Math.max(a.y,b.y);
          return {x:x0*TILE_SIZE,y:y0*TILE_SIZE,w:(x1-x0+1)*TILE_SIZE,h:(y1-y0+1)*TILE_SIZE};
        };
        const draw = () => {
          const c=canvas.getContext('2d');
          if(!image){canvas.width=512;canvas.height=512;c.fillStyle='#181b22';c.fillRect(0,0,512,512);return;}
          canvas.width=image.width;canvas.height=image.height;
          canvas.style.width=`${Math.round(image.width*zoom)}px`;canvas.style.height=`${Math.round(image.height*zoom)}px`;
          c.imageSmoothingEnabled=false;c.clearRect(0,0,canvas.width,canvas.height);c.drawImage(image,0,0);
          c.save();c.strokeStyle='rgba(255,255,255,.12)';c.lineWidth=1;
          if(zoom>=1){for(let x=0;x<=canvas.width;x+=TILE_SIZE){c.beginPath();c.moveTo(x+.5,0);c.lineTo(x+.5,canvas.height);c.stroke();}for(let y=0;y<=canvas.height;y+=TILE_SIZE){c.beginPath();c.moveTo(0,y+.5);c.lineTo(canvas.width,y+.5);c.stroke();}}
          if(selection){c.fillStyle='rgba(80,220,255,.18)';c.fillRect(selection.x,selection.y,selection.w,selection.h);c.strokeStyle='rgba(80,235,255,.98)';c.lineWidth=Math.max(1,2/zoom);c.strokeRect(selection.x+.5,selection.y+.5,selection.w-1,selection.h-1);}
          c.restore();
          const pc=preview.getContext('2d');pc.imageSmoothingEnabled=false;pc.clearRect(0,0,preview.width,preview.height);pc.fillStyle='#181b22';pc.fillRect(0,0,preview.width,preview.height);
          if(selection){const sc=Math.min((preview.width-16)/selection.w,(preview.height-16)/selection.h);const dw=selection.w*sc,dh=selection.h*sc;pc.drawImage(image,selection.x,selection.y,selection.w,selection.h,(preview.width-dw)/2,(preview.height-dh)/2,dw,dh);info.innerHTML=`<b>${selection.w/TILE_SIZE} × ${selection.h/TILE_SIZE} tiles</b><br>Origen: ${selection.x}, ${selection.y}<br>Tileset ID: ${activeId}`;use.disabled=false;if(useTop)useTop.disabled=false;}else{info.textContent='Selecciona un tile.';use.disabled=true;if(useTop)useTop.disabled=true;}
        };
        const loadActive = async (id) => {
          activeId=Number(id)||0;selection=null;dragStart=null;image=null;draw();
          for(const b of body.querySelectorAll('[data-gp-ts]')){const on=Number(b.getAttribute('data-gp-ts'))===activeId;b.style.background=on?'var(--accent)':'var(--bg-secondary)';b.style.color=on?'var(--accent-text)':'var(--text-primary)';}
          const res=await ensureTilesetResourceSet(ctx,activeId);image=res?.image||state.preview.tilesetImages.get(activeId)||null;draw();
        };
        const pos = (ev) => {const r=canvas.getBoundingClientRect();if(!image||!r.width||!r.height)return null;const px=(ev.clientX-r.left)*(canvas.width/r.width),py=(ev.clientY-r.top)*(canvas.height/r.height);return{x:Math.max(0,Math.min(Math.floor((image.width-1)/TILE_SIZE),Math.floor(px/TILE_SIZE))),y:Math.max(0,Math.min(Math.floor((image.height-1)/TILE_SIZE),Math.floor(py/TILE_SIZE)))};};
        canvas.addEventListener('pointerdown',ev=>{if(ev.button!==0)return;const p=pos(ev);if(!p)return;canvas.setPointerCapture?.(ev.pointerId);dragStart=p;selection=normalizeRect(p,p);draw();});
        canvas.addEventListener('pointermove',ev=>{if(!dragStart||(ev.buttons&1)===0)return;const p=pos(ev);if(!p)return;selection=normalizeRect(dragStart,p);draw();});
        const end=()=>{dragStart=null;draw();};canvas.addEventListener('pointerup',end);canvas.addEventListener('pointercancel',end);
        for(const b of body.querySelectorAll('[data-gp-ts]')) b.addEventListener('click',()=>void loadActive(b.getAttribute('data-gp-ts')));
        zoomSel.addEventListener('change',()=>{zoom=Math.max(.5,Math.min(2,Number(zoomSel.value)||1));draw();});
        const confirmSelection=()=>{if(!selection)return;const ts=list.find(t=>Number(t.id)===activeId)||tilesetInfo(ctx,activeId)||{id:activeId};finish({tilesetId:activeId,tileset:ts,srcRect:{...selection}});};
        use.addEventListener('click',confirmSelection);
        useTop?.addEventListener('click',confirmSelection);
        canvas.addEventListener('dblclick',confirmSelection);
        void loadActive(activeId);
        return () => { if (!finished) { finished=true; resolve(null); } };
      }
    });
  });
}

async function v2ChooseGraphic(ctx) {
  const picked = await openGeometryGraphicPicker(ctx, { title: "2.5D Geometry · Elegir gráfico" });
  if (!picked?.srcRect?.w || !picked?.srcRect?.h) return;
  const match = picked.tileset || tilesetInfo(ctx, picked.tilesetId) || { id:picked.tilesetId };
  await ensureTilesetResourceSet(ctx, picked.tilesetId);
  const rect = {
    x: Math.max(0, Number(picked.srcRect.x) || 0),
    y: Math.max(0, Number(picked.srcRect.y) || 0),
    w: Math.max(TILE_SIZE, Number(picked.srcRect.w) || TILE_SIZE),
    h: Math.max(TILE_SIZE, Number(picked.srcRect.h) || TILE_SIZE),
  };
  state.visualSource = {
    label: match.tilesetName || match.name || `Tileset ${picked.tilesetId}`,
    tileset_id: Number(picked.tilesetId),
    source_key: `picked:ts:${Number(picked.tilesetId)}:${rect.x},${rect.y},${rect.w},${rect.h}`,
    material: {
      kind: "tileset", tileset_id: Number(picked.tilesetId), graphic: String(match.tilesetName || match.name || ""),
      src_rect: rect, rotation: 0, flip_h: false, flip_v: false, opacity: 255, hue: 0, saturation: 100, lighting: 0,
    },
    footprint: { w: Math.max(1, Math.round(rect.w / TILE_SIZE)), h: Math.max(1, Math.round(rect.h / TILE_SIZE)) },
  };
  state.visualSourceFootprint = { ...state.visualSource.footprint };
  state.sceneTool = "place";
  schedulePanelRefresh();
  ctx.ui.showToast?.({ message: `${state.visualSource.label}: haz clic en el mapa para colocarlo como Geometry.`, level: "info" });
}

function v2PlacePickedGraphic(ctx, mapId, x, y) {
  const geo = state.maps.get(mapId);
  const src = state.visualSource;
  if (!geo || !src?.material) {
    ctx.ui.showToast?.({ message: "Primero elige un gráfico.", level: "info" });
    return null;
  }
  const presetName = v2PresetInternal(state.brushPreset || "wall");
  const scenePreset = SCENE_GEOMETRY_PRESETS[presetName] || SCENE_GEOMETRY_PRESETS.wall;
  const w = Math.max(1, Number(src.footprint?.w) || 1);
  const h = Math.max(1, Number(src.footprint?.h) || 1);
  const id = nextObjectId(geo);
  const obj = normalizeObject({
    id,
    name: src.label || `Geometry ${id}`,
    type: scenePreset.type === "plane" ? "plane" : "cube",
    x: Math.round(x), y: Math.round(y), w, h,
    height: Math.max(0, Number(state.brushHeight) || Number(scenePreset.height) || 0),
    anchor_z: Number(scenePreset.anchor_z) || 0,
    anchor_row: Math.max(0, h - 1),
    rotation: 0,
    collision: scenePreset.collision || "solid",
    category: scenePreset.category || presetName,
    characters_in_front: false,
    footprint: {},
    components: { ...(scenePreset.components || {}), connect_neighbors: false },
    material: JSON.parse(JSON.stringify(src.material)),
  }, id);
  geo.objects ||= [];
  geo.objects.push(obj);
  state.objSelected = obj.id;
  state.sourceSelection = null;
  ctx.editor.requestRedraw();
  schedulePreview(ctx);
  void saveMap(ctx, mapId);
  state.panelRefresh?.();
  return obj;
}

async function v2SelectBrowserSource(ctx, key) {
  const usage = state.sourceUsage;
  const desc = usage?.placements?.find?.((p) => p.key === key) || null;
  if (!desc) return;
  state.sourceSelection = desc;
  state.preview.focusX = desc.x;
  state.preview.focusY = desc.y;
  state.objSelected = null;
  const geo = currentGeo(ctx);
  if (geo?.definitions?.[desc.key]) {
    const rule = effectiveSourceRule(geo.definitions[desc.key], geo.instance_overrides?.[desc.instance_key]);
    if (rule) {
      state.brushPreset = rule.category || state.brushPreset;
      state.brushHeight = Number(rule.height) || 0;
    }
  }
  await ensureTilesetResourceSet(ctx, desc.tileset_id);
  state.panelRefresh?.();
  ctx.editor.requestRedraw();
  schedulePreview(ctx);
}

function v2ToolButton(tool, icon, label) {
  const active = state.sceneTool === tool;
  return `<button data-v2-tool="${tool}" title="${label}" style="${buttonStyle(active)}height:52px;min-width:68px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;font-size:11px;"><span style="font-size:18px;line-height:18px;">${icon}</span>${label}</button>`;
}

function v2PresetCard(name, icon, label) {
  const internal = v2PresetInternal(name);
  const active = v2PresetInternal(state.brushPreset) === internal;
  return `<button data-v2-preset="${name}" style="${buttonStyle(active)}min-width:82px;flex:1 1 82px;height:58px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;"><span style="font-size:21px;">${icon}</span><span>${label}</span></button>`;
}

function panelHtmlV2(ctx, geo) {
  const sel = state.sourceSelection && Number(state.sourceSelection.map_id) === Number(geo?.map_id) ? state.sourceSelection : null;
  const rule = v2RuleForSelection(ctx);
  const usage = state.sourceUsage && Number(state.sourceUsage.map_id) === Number(geo?.map_id) ? state.sourceUsage : null;
  const picked = state.visualSource;
  const activeType = rule?.enabled === false ? "ignore" : (rule?.category || state.brushPreset || "wall");
  const activeHeight = rule ? Number(rule.height) || 0 : Number(state.brushHeight) || 0;
  const scopeLabel = state.sceneScope === "this" ? "Este tile" : state.sceneScope === "all" ? "Todos los iguales" : "Conectados";
  const browserRows = usage?.sources instanceof Map
    ? [...usage.sources.values()].sort((a,b)=>b.count-a.count).slice(0,36).map((row) => `
      <button data-v2-browser-source="${escapeHtml(row.key)}" style="padding:5px;border:1px solid ${sel?.key===row.key?'var(--accent)':'var(--border)'};background:var(--bg-secondary);border-radius:7px;color:var(--text-primary);cursor:pointer;text-align:left;min-width:0;">
        <canvas data-v2-source-thumb="${escapeHtml(row.key)}" width="72" height="72" style="width:72px;height:72px;image-rendering:pixelated;display:block;border-radius:4px;background:var(--canvas-bg);"></canvas>
        <div style="font-size:10px;margin-top:4px;max-width:72px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(row.graphic || row.label || 'Tile')}</div>
        <div style="font-size:9px;color:var(--text-tertiary);">×${row.count}</div>
      </button>`).join("")
    : `<div style="color:var(--text-tertiary);padding:8px;">Escaneando gráficos usados…</div>`;

  return `<div style="height:100%;display:flex;flex-direction:column;background:var(--bg-primary);color:var(--text-primary);font:12px sans-serif;overflow:hidden;">
    <div style="padding:10px 11px;border-bottom:1px solid var(--border);display:flex;gap:8px;align-items:center;background:var(--bg-secondary);">
      <div style="font-weight:700;font-size:14px;">⬢ 2.5D Geometry</div>
      <span style="font-size:10px;color:var(--text-tertiary);padding:2px 6px;border:1px solid var(--border);border-radius:10px;">V2</span>
      <div style="flex:1;"></div>
      <button data-v2-view="map" style="${buttonStyle(true)}">MAP</button>
      <button data-v2-view="2.5d" style="${buttonStyle(false)}">2.5D</button>
      <button data-v2-view="split" style="${buttonStyle(false)}">SPLIT</button>
    </div>

    <div style="padding:8px 10px;border-bottom:1px solid var(--border);display:flex;gap:5px;overflow-x:auto;background:var(--bg-primary);">
      ${v2ToolButton('select','⬉','Seleccionar')}
      ${v2ToolButton('eyedropper','◉','Copiar')}
      ${v2ToolButton('paint','🖌','Pintar')}
      ${v2ToolButton('raise','↥','Height +')}
      ${v2ToolButton('lower','↧','Height −')}
      ${v2ToolButton('erase','⌫','Borrar')}
      ${v2ToolButton('place','▣','Colocar')}
    </div>
    <div style="padding:5px 10px;border-bottom:1px solid var(--border);font-size:10px;color:var(--text-tertiary);background:var(--bg-primary);">⌫ Borrar funciona con clic o arrastre sobre cualquier Geometry · Alt + arrastre = borrado rápido</div>
    <div style="padding:8px 10px;border-bottom:1px solid var(--border);display:flex;gap:7px;align-items:center;background:var(--bg-secondary);">
      <button data-v2-action="model-workshop" style="${buttonStyle(false)}font-weight:700;">▣ Model Builder</button>
      <button data-v2-action="model-from-selection" style="${buttonStyle(false)}">Desde selección</button>
      <button data-v2-action="model-place" style="${buttonStyle(state.sceneTool==='model-place')}">Colocar modelo</button>
      <span style="color:var(--text-tertiary);">${Object.keys(geo?.models||{}).length} modelos · ${(geo?.model_instances||[]).length} colocados</span>
    </div>

    <div style="flex:1;overflow:auto;padding:10px;display:flex;flex-direction:column;gap:10px;">
      <section style="border:1px solid var(--border);border-radius:9px;background:var(--bg-secondary);padding:10px;">
        <div style="display:flex;align-items:center;gap:10px;">
          <canvas data-id="v2-selected-thumb" width="104" height="104" style="width:104px;height:104px;image-rendering:pixelated;border:1px solid var(--border);border-radius:6px;background:var(--canvas-bg);"></canvas>
          <div style="flex:1;min-width:0;">
            <div style="font-size:10px;text-transform:uppercase;color:var(--text-tertiary);letter-spacing:.06em;">Selección del mapa</div>
            <div style="font-size:14px;font-weight:700;margin:3px 0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(sel?.graphic || sel?.label || 'Haz clic en un tile')}</div>
            <div style="font-size:11px;color:var(--text-secondary);">${sel ? `${sel.layer_name || `Layer ${sel.layer}`} · ${sel.kind === 'autotile' ? 'Autotile' : 'Tile'}${rule ? ` · ${v2PresetLabel(rule.category)} H${Number(rule.height)||0}` : ''}` : 'Geometry leerá el recurso real colocado, no el tileset base.'}</div>
            <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;">
              <button data-v2-action="sample-map" style="${buttonStyle(state.sceneTool==='select')}">Tomar del mapa</button>
              <button data-v2-action="pick-graphic" style="${buttonStyle(false)}">Elegir gráfico…</button>
            </div>
          </div>
        </div>
      </section>

      ${picked ? `<section style="border:1px solid var(--accent);border-radius:9px;background:var(--bg-secondary);padding:10px;">
        <div style="display:flex;gap:10px;align-items:center;">
          <canvas data-id="v2-picked-thumb" width="104" height="104" style="width:104px;height:104px;image-rendering:pixelated;border:1px solid var(--border);border-radius:6px;background:var(--canvas-bg);"></canvas>
          <div style="flex:1;min-width:0;">
            <div style="font-size:10px;color:var(--text-tertiary);text-transform:uppercase;">Gráfico para colocar</div>
            <strong style="display:block;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(picked.label)}</strong>
            <div style="font-size:11px;color:var(--text-secondary);margin-top:2px;">Huella ${picked.footprint.w} × ${picked.footprint.h} tiles</div>
            <button data-v2-action="place-picked" style="${buttonStyle(state.sceneTool==='place')}margin-top:7px;">▣ Colocar en el mapa</button>
          </div>
        </div>
      </section>` : ''}

      <section style="border:1px solid var(--border);border-radius:9px;background:var(--bg-secondary);padding:10px;">
        <div style="font-weight:700;margin-bottom:7px;">¿Qué forma debe tener?</div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;">
          ${v2PresetCard('floor','▱','Suelo')}
          ${v2PresetCard('wall','▥','Pared')}
          ${v2PresetCard('mountain','⛰','Montaña')}
          ${v2PresetCard('prop','♟','Prop')}
          ${v2PresetCard('roof','⌂','Techo')}
          ${v2PresetCard('border','▤','Borde')}
        </div>
      </section>

      <section style="border:1px solid var(--border);border-radius:9px;background:var(--bg-secondary);padding:10px;display:flex;flex-direction:column;gap:9px;">
        <div style="display:flex;justify-content:space-between;gap:8px;align-items:center;"><strong>Editar</strong><span style="color:var(--text-tertiary);">${scopeLabel}</span></div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          <button data-v2-scope="this" style="${buttonStyle(state.sceneScope==='this')}">Este tile</button>
          <button data-v2-scope="connected" style="${buttonStyle(state.sceneScope==='connected')}">Conectados</button>
          <button data-v2-scope="all" style="${buttonStyle(state.sceneScope==='all')}">Todos los iguales</button>
        </div>
        <div style="display:flex;align-items:center;gap:7px;flex-wrap:wrap;">
          <strong>Altura</strong>
          <button data-v2-action="height-minus" style="${buttonStyle(false)}">−</button>
          <input data-id="v2-height" type="number" min="0" step="0.25" value="${activeHeight}" style="${inputStyle(70)}"/>
          <span>tiles</span>
          <button data-v2-action="height-plus" style="${buttonStyle(false)}">+</button>
        </div>
        ${rule ? `<div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;">
          <label><input data-id="v2-connect" type="checkbox" ${rule.components?.connect_neighbors ? 'checked':''}/> Unir vecinos</label>
          <label><input data-id="v2-cap" type="checkbox" ${rule.components?.cap !== false ? 'checked':''}/> Superficie superior</label>
          <label>Colisión <select data-id="v2-collision" style="${selectStyle()}">
            <option value="none" ${rule.collision==='none'?'selected':''}>Atravesable</option>
            <option value="solid" ${rule.collision==='solid'?'selected':''}>Sólida</option>
            <option value="climb" ${rule.collision==='climb'?'selected':''}>Escalable</option>
            <option value="one-way" ${rule.collision==='one-way'?'selected':''}>Solo arriba</option>
          </select></label>
        </div>` : `<div style="color:var(--text-secondary);">Selecciona una pieza y pulsa una forma para crear su Geometry.</div>`}
      </section>

      <section style="border:1px solid var(--border);border-radius:9px;background:var(--bg-secondary);padding:10px;">
        <div style="display:flex;gap:8px;align-items:center;margin-bottom:8px;">
          <strong style="flex:1;">Gráficos usados en este mapa</strong>
          <button data-v2-action="rescan" style="${buttonStyle(false)}">↻ Actualizar</button>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(82px,1fr));gap:7px;max-height:260px;overflow:auto;">${browserRows}</div>
      </section>

      <details style="border:1px solid var(--border);border-radius:8px;padding:8px;background:var(--bg-secondary);">
        <summary style="cursor:pointer;font-weight:600;">Avanzado / Debug</summary>
        <div style="font-size:11px;color:var(--text-secondary);margin-top:8px;display:grid;gap:4px;">
          <div>Source: ${escapeHtml(sel?.key || '—')}</div>
          <div>Instancia: ${escapeHtml(sel?.instance_key || '—')}</div>
          <div>Origen real: ${sel ? `TS ${sel.tileset_id} · tile ${sel.tile_id} · layer ${sel.layer}` : '—'}</div>
          <div>Compilados: ${geo?.compiled_objects?.length || 0} · manuales: ${geo?.objects?.length || 0}</div>
        </div>
      </details>
    </div>
  </div>`;
}

function v2RenderTopDown(ctx, canvas) {
  if (!canvas) return;
  const mapId = ctx.editor.activeMapId();
  const info = mapId == null ? null : ctx.map.info(mapId);
  const geo = mapId == null ? null : state.maps.get(mapId);
  if (!info || !geo) return;
  const cssW = Math.max(480, Math.round(canvas.clientWidth || 700));
  const cssH = Math.max(360, Math.round(canvas.clientHeight || 620));
  canvas.width = Math.min(1200, cssW);
  canvas.height = Math.min(900, cssH);
  const c = canvas.getContext('2d');
  c.imageSmoothingEnabled = false;
  c.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--canvas-bg').trim() || '#171a20';
  c.fillRect(0,0,canvas.width,canvas.height);
  const layers = authoritativeLayers(ctx, mapId, false);
  const radius = Math.max(5, state.preview.radius || 10);
  const fx = Math.round(state.preview.focusX ?? info.width / 2), fy = Math.round(state.preview.focusY ?? info.height / 2);
  const minX = state.preview.fullMap ? 0 : Math.max(0, fx-radius), maxX = state.preview.fullMap ? info.width-1 : Math.min(info.width-1,fx+radius);
  const minY = state.preview.fullMap ? 0 : Math.max(0, fy-radius), maxY = state.preview.fullMap ? info.height-1 : Math.min(info.height-1,fy+radius);
  const cols = maxX-minX+1, rows=maxY-minY+1;
  const tile = Math.max(8, Math.floor(Math.min(canvas.width/cols, canvas.height/rows)));
  const ox = Math.floor((canvas.width-cols*tile)/2), oy=Math.floor((canvas.height-rows*tile)/2);
  canvas.__v2MapView = { minX, minY, maxX, maxY, tile, ox, oy, cols, rows };
  for (let y=minY;y<=maxY;y++) for (let x=minX;x<=maxX;x++) {
    for (const layer of layers) {
      const data = readTileVisualData(ctx,mapId,layer,x,y); if(!data) continue;
      const ts = Number(data.tilesetId) || ((layer?.kind === "native" || Number(layerRef(layer)) < 3) ? mapTilesetId(info,mapId) : 0);
      const src = sourceForTileData(ctx, Number(data.tileId)||0, data, layer, ts);
      if (!src?.img) continue;
      c.globalAlpha = Math.max(0,Math.min(1,Number(data.opacity == null ? layer.opacity ?? 1 : data.opacity > 1 ? data.opacity/255 : data.opacity)));
      c.drawImage(src.img,src.sx,src.sy,src.sw,src.sh,ox+(x-minX)*tile,oy+(y-minY)*tile,tile,tile);
    }
    c.globalAlpha=1;
  }
  for (const obj of sceneObjects(geo)) {
    const r=objectRect(obj); if(r.x1<minX||r.x0>maxX||r.y1<minY||r.y0>maxY) continue;
    const px=ox+(r.x0-minX)*tile, py=oy+(r.y0-minY)*tile, w=(r.x1-r.x0+1)*tile,h=(r.y1-r.y0+1)*tile;
    const height=Number(obj.height)||0;
    if(height>0){
      const lift=Math.min(tile*.45,Math.max(3,height*2.4));
      c.strokeStyle='rgba(112,225,255,.75)'; c.lineWidth=1.5;
      c.strokeRect(px-lift,py-lift,w,h);
      c.beginPath(); c.moveTo(px,py);c.lineTo(px-lift,py-lift);c.moveTo(px+w,py);c.lineTo(px+w-lift,py-lift);c.moveTo(px,py+h);c.lineTo(px-lift,py+h-lift);c.moveTo(px+w,py+h);c.lineTo(px+w-lift,py+h-lift);c.stroke();
    }
    c.strokeStyle = state.sourceSelection?.instance_key===obj.instance_key ? 'rgba(80,240,255,.98)' : 'rgba(255,205,80,.75)';
    c.strokeRect(px+.5,py+.5,w-1,h-1);
    if(tile>=20 && height>0){c.fillStyle='rgba(8,12,18,.82)';c.fillRect(px+2,py+2,34,14);c.fillStyle='#e8fbff';c.font='10px sans-serif';c.fillText(`H ${height}`,px+5,py+12);}
  }
  c.strokeStyle='rgba(80,220,255,.8)';c.lineWidth=1;c.strokeRect(ox-.5,oy-.5,cols*tile+1,rows*tile+1);
}

function v2BindTopDownCanvas(ctx, canvas) {
  if (!canvas) return;
  const at = (ev) => {
    const v = canvas.__v2MapView; if (!v) return null;
    const r = canvas.getBoundingClientRect();
    const px = (ev.clientX-r.left)*(canvas.width/Math.max(1,r.width));
    const py = (ev.clientY-r.top)*(canvas.height/Math.max(1,r.height));
    const cx = Math.floor((px-v.ox)/v.tile), cy=Math.floor((py-v.oy)/v.tile);
    if (cx<0||cy<0||cx>=v.cols||cy>=v.rows) return null;
    return { x:v.minX+cx, y:v.minY+cy };
  };
  canvas.addEventListener('pointerdown',(ev)=>{
    if(ev.button!==0)return;
    const p=at(ev); if(!p)return;
    const id=ctx.editor.activeMapId(); if(id==null)return;
    state.preview.focusX=p.x;state.preview.focusY=p.y;
    runSimpleSceneTool(ctx,id,p.x,p.y,null);
    v2RenderTopDown(ctx,canvas);schedulePreview(ctx);
  });
}

function v2DrawPreviewHeightMarkers(c, scene) {
  if (!scene?.items) return;
  const seen = new Set();
  c.save();
  c.font = '11px sans-serif';
  c.textAlign = 'center';
  for (const item of scene.items) {
    if (item.type !== 'objectTop' || !item.obj || !item.points?.length) continue;
    const obj = item.obj;
    const h = Number(obj.height)||0;
    if (h <= 0 || seen.has(obj.id)) continue;
    seen.add(obj.id);
    const should = state.sourceSelection?.instance_key===obj.instance_key || ['mountain','wall','border'].includes(obj.category);
    if (!should) continue;
    const x=item.points.reduce((a,p)=>a+p.x,0)/item.points.length;
    const y=item.points.reduce((a,p)=>a+p.y,0)/item.points.length;
    const text=`H ${h}`;
    const w=c.measureText(text).width+10;
    c.fillStyle='rgba(8,12,18,.78)'; c.fillRect(x-w/2,y-18,w,15);
    c.fillStyle='rgba(210,250,255,.98)'; c.fillText(text,x,y-7);
  }
  c.restore();
}

function v2BindPreviewCanvas(ctx, canvas, topDownCanvas = null) {
  if (!canvas) return;
  canvas.addEventListener('contextmenu',(ev)=>ev.preventDefault());
  canvas.addEventListener('pointerdown',(ev)=>{
    if(ev.button===2){ev.preventDefault();canvas.setPointerCapture?.(ev.pointerId);state.preview.orbiting=true;state.preview.orbitStartX=ev.clientX;state.preview.orbitStartY=ev.clientY;state.preview.orbitStartYaw=state.preview.yaw;state.preview.orbitStartPitch=state.preview.angle;return;}
    if(ev.button!==0)return;
    canvas.setPointerCapture?.(ev.pointerId);state.preview.dragging=true;state.preview.visited.clear();
    const cell=hitPreviewCell(canvas,ev.clientX,ev.clientY);if(cell)previewPaint(ctx,cell,ev);
  });
  canvas.addEventListener('pointermove',(ev)=>{
    if(state.preview.orbiting){const dx=ev.clientX-state.preview.orbitStartX,dy=ev.clientY-state.preview.orbitStartY;state.preview.yaw=((state.preview.orbitStartYaw+dx*.45)%360+360)%360;state.preview.angle=Math.max(5,Math.min(70,state.preview.orbitStartPitch-dy*.28));schedulePreview(ctx);if(topDownCanvas)v2RenderTopDown(ctx,topDownCanvas);return;}
    const cell=hitPreviewCell(canvas,ev.clientX,ev.clientY);const next=cell?{x:cell.x,y:cell.y}:null;state.preview.hovered=next;if(state.preview.dragging&&(ev.buttons&1)&&cell)previewPaint(ctx,cell,ev);schedulePreview(ctx);
  });
  const end=()=>{state.preview.orbiting=false;if(state.preview.dragging){state.preview.dragging=false;state.preview.visited.clear();const id=ctx.editor.activeMapId();if(id!=null)void saveMap(ctx,id);schedulePanelRefresh();}if(topDownCanvas)v2RenderTopDown(ctx,topDownCanvas);};
  canvas.addEventListener('pointerup',end);canvas.addEventListener('pointercancel',end);
  canvas.addEventListener('wheel',(ev)=>{ev.preventDefault();state.preview.zoom=Math.max(.35,Math.min(2.5,state.preview.zoom+(ev.deltaY>0?-.07:.07)));schedulePreview(ctx);},{passive:false});
}

function openLargePreviewV2(ctx, kind = '2.5d') {
  if (state.largeViewOpen) return;
  state.largeViewOpen = true;
  state.largeViewKind = kind;
  const dialog = ctx.ui.showCustomDialog({
    title: kind === 'split' ? '2.5D Geometry · MAP + 2.5D' : '2.5D Geometry · Vista 2.5D',
    width: '96vw', height: '90vh',
    render(body) {
      body.innerHTML = `<div style="height:82vh;min-height:620px;display:flex;flex-direction:column;gap:7px;color:var(--text-primary);">
        <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
          <button data-lv="game" style="${buttonStyle(false)}">Game</button>
          <button data-lv-yaw="0" style="${buttonStyle(false)}">Front</button><button data-lv-yaw="90" style="${buttonStyle(false)}">Right</button><button data-lv-yaw="180" style="${buttonStyle(false)}">Back</button><button data-lv-yaw="270" style="${buttonStyle(false)}">Left</button>
          <span style="color:var(--text-tertiary);">Arrastra con botón derecho para orbitar · rueda para zoom · clic izquierdo edita</span>
          <div style="flex:1"></div>
          <label><input data-lv-collision type="checkbox" ${state.preview.showCollision?'checked':''}/> colisión</label>
          <label><input data-lv-full type="checkbox" ${state.preview.fullMap?'checked':''}/> mapa completo</label>
        </div>
        <div style="flex:1;min-height:0;display:${kind==='split'?'grid':'block'};grid-template-columns:${kind==='split'?'1fr 1fr':'1fr'};gap:7px;">
          ${kind==='split'?'<canvas data-lv-top width="720" height="680" style="width:100%;height:100%;min-height:560px;border:1px solid var(--border);border-radius:6px;image-rendering:pixelated;background:var(--canvas-bg);"></canvas>':''}
          <canvas data-lv-preview width="960" height="680" style="width:100%;height:100%;min-height:560px;border:1px solid var(--border);border-radius:6px;image-rendering:pixelated;background:var(--canvas-bg);touch-action:none;"></canvas>
        </div>
        <div data-lv-status style="font-size:11px;color:var(--text-tertiary);min-height:16px;"></div>
      </div>`;
      const preview=body.querySelector('[data-lv-preview]');const top=body.querySelector('[data-lv-top]');
      state.preview.canvas=preview;state.preview.status=body.querySelector('[data-lv-status]');state.topDownCanvas=top;
      v2BindPreviewCanvas(ctx,preview,top);
      if(top)v2BindTopDownCanvas(ctx,top);
      body.querySelector('[data-lv="game"]')?.addEventListener('click',()=>{state.preview.angle=runtimeConfig.outdoorDefaultAlpha||25;state.preview.yaw=0;state.preview.zoom=1;schedulePreview(ctx);if(top)v2RenderTopDown(ctx,top);});
      for(const b of body.querySelectorAll('[data-lv-yaw]'))b.addEventListener('click',()=>{state.preview.yaw=Number(b.getAttribute('data-lv-yaw'))||0;schedulePreview(ctx);});
      body.querySelector('[data-lv-collision]')?.addEventListener('change',(e)=>{state.preview.showCollision=e.target.checked;schedulePreview(ctx);});
      body.querySelector('[data-lv-full]')?.addEventListener('change',(e)=>{state.preview.fullMap=e.target.checked;schedulePreview(ctx);if(top)v2RenderTopDown(ctx,top);});
      const id=ctx.editor.activeMapId();if(id!=null)void ensurePreviewResources(ctx,id,false).then(()=>{schedulePreview(ctx);if(top)v2RenderTopDown(ctx,top);});
      return ()=>{state.preview.canvas=null;state.preview.status=null;state.topDownCanvas=null;state.largeViewOpen=false;};
    },
  });
  return dialog;
}

function renderLivePreviewPanel(ctx, host) {
  const kind = state.largeViewKind === "split" ? "split" : "2.5d";
  host.innerHTML = `<div style="height:100%;min-height:320px;display:flex;flex-direction:column;gap:6px;padding:7px;box-sizing:border-box;background:var(--bg-primary);color:var(--text-primary);font:12px inherit;">
    <div style="display:flex;gap:5px;align-items:center;flex-wrap:wrap;">
      <button data-pv-mode="2.5d" style="${buttonStyle(kind==='2.5d')}">2.5D</button>
      <button data-pv-mode="split" style="${buttonStyle(kind==='split')}">SPLIT</button>
      <button data-pv-game style="${buttonStyle(false)}">Game</button>
      <button data-pv-yaw="0" style="${buttonStyle(false)}">Front</button><button data-pv-yaw="90" style="${buttonStyle(false)}">Right</button><button data-pv-yaw="180" style="${buttonStyle(false)}">Back</button><button data-pv-yaw="270" style="${buttonStyle(false)}">Left</button>
      <span style="color:var(--text-tertiary);">Vista viva: puedes seguir editando el mapa mientras este panel está abierto.</span>
      <div style="flex:1;"></div>
      <label><input data-pv-collision type="checkbox" ${state.preview.showCollision?'checked':''}/> colisión</label>
      <label><input data-pv-full type="checkbox" ${state.preview.fullMap?'checked':''}/> completo</label>
    </div>
    <div style="flex:1;min-height:0;display:${kind==='split'?'grid':'block'};grid-template-columns:${kind==='split'?'1fr 1fr':'1fr'};gap:6px;">
      ${kind==='split'?'<canvas data-pv-top width="900" height="620" style="width:100%;height:100%;min-height:280px;border:1px solid var(--border);border-radius:6px;image-rendering:pixelated;background:var(--canvas-bg);touch-action:none;"></canvas>':''}
      <canvas data-pv-main width="1000" height="620" style="width:100%;height:100%;min-height:280px;border:1px solid var(--border);border-radius:6px;image-rendering:pixelated;background:var(--canvas-bg);touch-action:none;"></canvas>
    </div>
    <div data-pv-status style="font-size:10px;color:var(--text-tertiary);min-height:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"></div>
  </div>`;
  const preview=host.querySelector('[data-pv-main]');
  const top=host.querySelector('[data-pv-top]');
  state.preview.canvas=preview;
  state.preview.status=host.querySelector('[data-pv-status]');
  state.topDownCanvas=top;
  v2BindPreviewCanvas(ctx,preview,top);
  if(top)v2BindTopDownCanvas(ctx,top);
  for(const b of host.querySelectorAll('[data-pv-mode]')) b.addEventListener('click',()=>{state.largeViewKind=b.getAttribute('data-pv-mode')||'2.5d';state.previewPanelRefresh?.();});
  host.querySelector('[data-pv-game]')?.addEventListener('click',()=>{state.preview.angle=runtimeConfig.outdoorDefaultAlpha||25;state.preview.yaw=0;state.preview.zoom=1;schedulePreview(ctx);});
  for(const b of host.querySelectorAll('[data-pv-yaw]')) b.addEventListener('click',()=>{state.preview.yaw=Number(b.getAttribute('data-pv-yaw'))||0;schedulePreview(ctx);});
  host.querySelector('[data-pv-collision]')?.addEventListener('change',e=>{state.preview.showCollision=!!e.target.checked;schedulePreview(ctx);});
  host.querySelector('[data-pv-full]')?.addEventListener('change',e=>{state.preview.fullMap=!!e.target.checked;schedulePreview(ctx);});
  const id=ctx.editor.activeMapId();
  if(id!=null) void ensureVisiblePreviewResources(ctx,id).then(()=>schedulePreview(ctx));
  schedulePreview(ctx);
}

function bindPanelV2(ctx, host, rerender) {
  const q=(s)=>host.querySelector(s);
  for(const b of host.querySelectorAll('[data-v2-tool]')) b.addEventListener('click',()=>{state.sceneTool=b.getAttribute('data-v2-tool');state.workspaceMode='scene';state.objTool=false;state.modelTool=false;state.modelEraseMode=false;ctx.editor.setTool(TOOL_ID);rerender();});
  for(const b of host.querySelectorAll('[data-v2-preset]')) b.addEventListener('click',()=>{
    const p=v2PresetInternal(b.getAttribute('data-v2-preset'));state.brushPreset=p;state.sourcePreset=p;
    const preset=SCENE_GEOMETRY_PRESETS[p]||SCENE_GEOMETRY_PRESETS.wall;if(!state.sourceSelection)state.brushHeight=Number(preset.height)||0;
    if(state.sourceSelection)applySimpleGeometry(ctx,state.sourceSelection,p,state.brushHeight||preset.height);
    rerender();
  });
  for(const b of host.querySelectorAll('[data-v2-scope]')) b.addEventListener('click',()=>{state.sceneScope=b.getAttribute('data-v2-scope');rerender();});
  for(const b of host.querySelectorAll('[data-v2-view]')) b.addEventListener('click',()=>{const v=b.getAttribute('data-v2-view');if(v==='map'){state.viewMode='2d';ctx.ui.closePanel?.(PREVIEW_PANEL_ID);return;}if(v==='2.5d'||v==='split'){state.viewMode=v;state.largeViewKind=v;ctx.ui.openPanel(PREVIEW_PANEL_ID);state.previewPanelRefresh?.();}});
  q('[data-v2-action="sample-map"]')?.addEventListener('click',()=>{state.sceneTool='select';ctx.editor.setTool(TOOL_ID);rerender();ctx.ui.showToast?.({message:'Haz clic en cualquier tile del mapa.',level:'info'});});
  q('[data-v2-action="pick-graphic"]')?.addEventListener('click',()=>void v2ChooseGraphic(ctx));
  q('[data-v2-action="place-picked"]')?.addEventListener('click',()=>{state.sceneTool='place';state.modelTool=false;ctx.editor.setTool(TOOL_ID);rerender();});
  q('[data-v2-action="model-workshop"]')?.addEventListener('click',()=>openModelWorkshop(ctx));
  q('[data-v2-action="model-from-selection"]')?.addEventListener('click',()=>void createModelFromMapSelection(ctx).then(m=>{if(m)openModelWorkshop(ctx);}));
  q('[data-v2-action="model-place"]')?.addEventListener('click',()=>{const g=currentGeo(ctx);if(!state.modelBrushId)state.modelBrushId=Object.keys(g?.models||{})[0]||null;if(!state.modelBrushId){createModel(ctx);openModelWorkshop(ctx);return;}state.modelTool=true;state.modelEraseMode=false;state.sceneTool='model-place';ctx.editor.setTool(TOOL_ID);rerender();});
  q('[data-v2-action="height-minus"]')?.addEventListener('click',()=>{if(state.sourceSelection)adjustSimpleGeometryHeight(ctx,state.sourceSelection,-.25);else state.brushHeight=Math.max(0,state.brushHeight-.25);rerender();});
  q('[data-v2-action="height-plus"]')?.addEventListener('click',()=>{if(state.sourceSelection)adjustSimpleGeometryHeight(ctx,state.sourceSelection,.25);else state.brushHeight+=.25;rerender();});
  q('[data-id="v2-height"]')?.addEventListener('change',(e)=>{const h=Math.max(0,Number(e.target.value)||0);state.brushHeight=h;if(state.sourceSelection)setSimpleGeometryHeight(ctx,state.sourceSelection,h);rerender();});
  q('[data-id="v2-connect"]')?.addEventListener('change',(e)=>{if(state.sourceSelection)patchSimpleGeometry(ctx,state.sourceSelection,{components:{connect_neighbors:!!e.target.checked}});rerender();});
  q('[data-id="v2-cap"]')?.addEventListener('change',(e)=>{if(state.sourceSelection)patchSimpleGeometry(ctx,state.sourceSelection,{components:{cap:!!e.target.checked}});rerender();});
  q('[data-id="v2-collision"]')?.addEventListener('change',(e)=>{if(state.sourceSelection)patchSimpleGeometry(ctx,state.sourceSelection,{collision:e.target.value});rerender();});
  q('[data-v2-action="rescan"]')?.addEventListener('click',()=>{const id=ctx.editor.activeMapId();if(id==null)return;state.sourceUsageByMap.delete(id);state.preview.usedAssetsByMap.delete(id);void scanGeometrySources(ctx,id,true).then(()=>ensureSceneTilesetResources(ctx,id,true)).then(()=>rerender());});
  for(const b of host.querySelectorAll('[data-v2-browser-source]'))b.addEventListener('click',()=>void v2SelectBrowserSource(ctx,b.getAttribute('data-v2-browser-source')));
  v2DrawSelectedThumbnail(ctx,host);v2DrawPickedThumbnail(ctx,host);v2DrawBrowserThumbs(ctx,host);
}


export async function activate(ctx) {
  ctx.log.info("2.5D Geometry v2.7.0 Region Mesh activated");
  await loadRuntimeConfig(ctx);
  state.preview.angle = runtimeConfig.outdoorDefaultAlpha || state.preview.angle;

  // Expose the same semantic Visual 2.5D categories inside Maker Studio's
  // Tileset Editor. The preview reads these exact ids at render time.
  for (const [id, name] of TAG_NAMES.entries()) {
    try { ctx.tileset.registerTerrainTag({ id, name }); } catch (_) {}
  }

  ctx.tools.registerTool({
    id: TOOL_ID,
    label: "Geometry",
    icon: "⬢",
    onPointerDown(ev) {
      if ((ev.buttons & 1) === 0) return;
      state.dragging = true;
      state.visited.clear();
      if (state.workspaceMode === "scene") {
        if (ev.altKey) {
          state.visited.add(`${ev.mapId}:${ev.tileX},${ev.tileY}:erase`);
          eraseGeometryAtCell(ctx, ev.mapId, ev.tileX, ev.tileY, ev.layerIndex);
          return;
        }
        if (state.sceneTool === "model-place") { placeModelInstance(ctx, ev.mapId, ev.tileX, ev.tileY); state.dragging=false; return; }
        const key = `${ev.mapId}:${ev.layerIndex}:${ev.tileX},${ev.tileY}:${state.sceneTool}`;
        state.visited.add(key);
        runSimpleSceneTool(ctx, ev.mapId, ev.tileX, ev.tileY, ev.layerIndex);
        if (["select", "eyedropper", "place"].includes(state.sceneTool)) { state.dragging = false; schedulePanelRefresh(); }
        return;
      }
      if (state.objTool || state.workspaceMode === "object") {
        if (ev.altKey) { void objectEraseAt(ctx, ev); return; }
        const geo = state.maps.get(ev.mapId);
        const hit = geo ? findObjectAt(geo, ev.tileX, ev.tileY) : null;
        if (hit) { selectObject(ctx, geo, hit, ev.mapId); return; }
        state.objSelected = null;
        state.objStart = { x: ev.tileX, y: ev.tileY };
        state.objCurrent = { x: ev.tileX, y: ev.tileY };
        ctx.editor.requestRedraw();
        schedulePreview(ctx);
        return;
      }
      void paintAt(ctx, ev);
    },
    onPointerMove(ev) {
      if (!state.dragging || (ev.buttons & 1) === 0) return;
      if (state.workspaceMode === "scene") {
        const activeTool = ev.altKey ? "erase" : state.sceneTool;
        if (!["paint", "raise", "lower", "erase"].includes(activeTool)) return;
        const key = `${ev.mapId}:${ev.layerIndex}:${ev.tileX},${ev.tileY}:${activeTool}`;
        if (state.visited.has(key)) return;
        state.visited.add(key);
        if (activeTool === "erase") eraseGeometryAtCell(ctx, ev.mapId, ev.tileX, ev.tileY, ev.layerIndex);
        else runSimpleSceneTool(ctx, ev.mapId, ev.tileX, ev.tileY, ev.layerIndex);
        return;
      }
      if (state.objTool || state.workspaceMode === "object") {
        if (ev.altKey) { void objectEraseAt(ctx, ev); return; }
        state.objCurrent = { x: ev.tileX, y: ev.tileY };
        ctx.editor.requestRedraw();
        schedulePreview(ctx);
        return;
      }
      void paintAt(ctx, ev);
    },
    onPointerUp(ev) {
      if (!state.dragging) return;
      state.dragging = false;
      state.visited.clear();
      if (state.workspaceMode === "scene") {
        clearTimeout(state.simpleEditTimer);
        state.simpleEditTimer = 0;
        const geo = state.maps.get(ev.mapId);
        if (geo) {
          // Keep mouse-up instant. The visible scene is already updated locally;
          // write lightweight data now and reconcile the full compiler later.
          void saveMap(ctx, ev.mapId, { skipCompile: true, skipModelCompile: true });
          scheduleSceneCompile(ctx, ev.mapId, "gesture-end", 320);
          schedulePanelRefresh();
          schedulePreview(ctx);
        }
        return;
      }
      if (state.objTool || state.workspaceMode === "object") {
        if (state.objStart && state.objCurrent) {
          const geo = state.maps.get(ev.mapId);
          if (geo) commitObjectFromRect(ctx, geo, ev.mapId,
            state.objStart.x, state.objStart.y, state.objCurrent.x, state.objCurrent.y);
        }
        state.objStart = null;
        state.objCurrent = null;
        void saveMap(ctx, ev.mapId);
        return;
      }
      void saveMap(ctx, ev.mapId);
    },
    onActivate() {
      ctx.ui.openPanel(PANEL_ID);
      ctx.editor.setStatusBarText?.("2.5D Geometry: selecciona, pinta o ajusta Geometry directamente sobre el mapa");
      const mapId = ctx.editor.activeMapId?.();
      if (mapId != null) void ensureMap(ctx, mapId, true).then(() => ensurePreviewResources(ctx, mapId, false));
    },
    onDeactivate() {
      state.dragging = false;
      state.visited.clear();
      state.objStart = null;
      state.objCurrent = null;
    },
  });

  ctx.ui.registerOverlay({
    id: `${MOD_ID}.overlay`,
    zOrder: 25,
    render(c2d, info) { renderOverlay(ctx, c2d, info); },
  });

  ctx.ui.registerPanel({
    id: PANEL_ID,
    title: "2.5D Geometry",
    defaultPosition: "right",
    defaultSize: { width: 540, height: 820 },
    icon: "⬢",
    render(host) {
      const render = () => {
        // V2 keeps the dock as a small human-facing inspector. The actual 2.5D
        // scene opens in a large viewport dialog instead of living in a tiny
        // legacy preview inside this panel.
        host.innerHTML = panelHtmlV2(ctx, currentGeo(ctx));
        bindPanelV2(ctx, host, render);
      };
      state.panelRefresh = render;
      render();
      return () => {
        if (state.panelRefresh === render) state.panelRefresh = null;
        if (!state.largeViewOpen && !ctx.ui.isPanelOpen?.(PREVIEW_PANEL_ID)) {
          state.preview.canvas = null;
          state.preview.status = null;
        }
      };
    },
  });

  ctx.ui.registerPanel({
    id: PREVIEW_PANEL_ID,
    title: "2.5D Geometry Preview",
    defaultPosition: "below",
    defaultSize: { width: 1000, height: 620 },
    icon: "◩",
    render(host) {
      const render = () => renderLivePreviewPanel(ctx, host);
      state.previewPanelRefresh = render;
      const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(() => schedulePreview(ctx)) : null;
      try { ro?.observe(host); } catch (_) {}
      render();
      return () => {
        try { ro?.disconnect(); } catch (_) {}
        if (state.previewPanelRefresh === render) state.previewPanelRefresh = null;
        state.topDownCanvas = null;
        if (!state.largeViewOpen) {
          state.preview.canvas = null;
          state.preview.status = null;
        }
      };
    },
  });

  // Native Maker Studio integration: Geometry behaves like a real installed mode.
  try {
    ctx.ui.registerShortcut("Alt+G", () => {
      ctx.editor.setTool(TOOL_ID);
      ctx.ui.openPanel(PANEL_ID);
    });
  } catch (_) {}

  // Familiar delete path: select something and press Delete/Backspace. It only
  // removes Geometry metadata/models; Maker Studio map tiles are never touched.
  const eraseCurrentSelection = () => {
    if (ctx.editor.activeTool?.() !== TOOL_ID) return;
    const sel = state.sourceSelection;
    const mapId = ctx.editor.activeMapId?.();
    if (mapId == null || !sel || Number(sel.map_id) !== Number(mapId)) return;
    if (eraseGeometryAtCell(ctx, mapId, sel.x, sel.y, sel.layer)) {
      void saveMap(ctx, mapId, { skipCompile: true, skipModelCompile: true });
      scheduleSceneCompile(ctx, mapId, "keyboard-erase", 320);
    }
  };
  try { ctx.ui.registerShortcut("Delete", eraseCurrentSelection); } catch (_) {}
  try { ctx.ui.registerShortcut("Backspace", eraseCurrentSelection); } catch (_) {}

  // Keep a visible panel entry as a fallback for Maker Studio builds where
  // project-mod tools are not inserted into the map toolbar until a reload.
  // The panel remains an inspector; selecting Geometry in the toolbar still
  // activates the actual map mode.
  try {
    ctx.ui.showToast?.({
      message: "2.5D Geometry v2.9.2 cargado: Model Builder con tileset embebido, construcción directa y selección visible.",
      level: "info"
    });
  } catch (_) {}

  try {
    ctx.ui.registerContextMenuItem({
      context: "map-tile",
      label: "2.5D Geometry: Seleccionar aquí",
      handler: (info) => {
        state.workspaceMode = "scene";
        state.objTool = false;
        state.sceneTool = "select";
        ctx.editor.setTool(TOOL_ID);
        ctx.ui.openPanel(PANEL_ID);
        void ensureMap(ctx, info.mapId).then(() => {
          selectSourceAt(ctx, info.mapId, info.tileX, info.tileY, info.layerIndex);
          state.panelRefresh?.();
        });
      },
    });
    ctx.ui.registerContextMenuItem({
      context: "map-tile",
      label: "2.5D Geometry: Borrar Geometry aquí",
      handler: (info) => {
        void ensureMap(ctx, info.mapId).then(() => {
          if (eraseGeometryAtCell(ctx, info.mapId, info.tileX, info.tileY, info.layerIndex)) {
            void saveMap(ctx, info.mapId, { skipCompile: true, skipModelCompile: true });
            scheduleSceneCompile(ctx, info.mapId, "context-erase", 320);
          }
        });
      },
    });
  } catch (_) {}

  ctx.lifecycle.onMapLoad((mapId) => {
    void ensureMap(ctx, mapId, true).then(async (geo) => {
      await ensurePreviewResources(ctx, mapId, true);
      await scanGeometrySources(ctx, mapId, false);
      if (geo && geo.compiler?.auto_compile !== false && Object.keys(geo.definitions || {}).length) {
        await compileGeometryScene(ctx, mapId, geo, { reason: "map-load" });
      }
    });
  });
  ctx.lifecycle.onSave((mapId) => { if (mapId != null) void saveMap(ctx, mapId); });
  ctx.bus.on("map.tile.changed", (e) => {
    state.preview.usedAssetsByMap.delete(e.mapId);
    state.sourceUsageByMap.delete(e.mapId);
    invalidateCellCache(e.mapId, e.x, e.y);
    refreshCompiledCell(ctx, e.mapId, e.x, e.y);
    clearTimeout(state.preview.legacyHeightTimer);
    state.preview.legacyHeightTimer = setTimeout(() => updateLegacyHeightForCell(ctx, e.mapId, e.x, e.y), 120);
    if (e.mapId === ctx.editor.activeMapId()) {
      ctx.editor.requestRedraw();
      schedulePreview(ctx);
      void ensureChangedCellResources(ctx, e.mapId, e.x, e.y, e.layer).then(() => { schedulePreview(ctx); scheduleTopDownPreview(ctx); });
    }
    // Rebuild browser/source inventories only after the user pauses editing.
    scheduleBackgroundMapRefresh(ctx, e.mapId, 480);
  });
  ctx.bus.on("map.batch.changed", (e) => {
    state.preview.usedAssetsByMap.delete(e.mapId);
    state.sourceUsageByMap.delete(e.mapId);
    state.preview.cellEntryCache.clear();
    clearTimeout(state.preview.legacyHeightTimer);
    state.preview.legacyHeightTimer = setTimeout(() => rebuildLegacyHeights(ctx, e.mapId), 420);
    if (e.mapId === ctx.editor.activeMapId()) {
      ctx.editor.requestRedraw();
      schedulePreview(ctx);
      void ensureVisiblePreviewResources(ctx, e.mapId).then(() => { schedulePreview(ctx); scheduleTopDownPreview(ctx); });
    }
    scheduleBackgroundMapRefresh(ctx, e.mapId, 520);
    scheduleSceneCompile(ctx, e.mapId, "batch-change", 650);
  });
  ctx.bus.on("tileset.changed", () => {
    const id = ctx.editor.activeMapId();
    if (id != null) {
      state.preview.usedAssetsByMap.delete(id);
      state.preview.transformedSourceCache.clear();
      ctx.editor.requestRedraw();
      schedulePreview(ctx);
      scheduleBackgroundMapRefresh(ctx, id, 300);
    }
  });
  ctx.bus.on("layer.changed", (e) => {
    state.sourceUsageByMap.delete(e.mapId);
    state.preview.cellEntryCache.clear();
    if (e.mapId === ctx.editor.activeMapId()) { ctx.editor.requestRedraw(); schedulePreview(ctx); }
    scheduleBackgroundMapRefresh(ctx, e.mapId, 420);
    scheduleSceneCompile(ctx, e.mapId, "layer-change", 560);
  });
  ctx.bus.on("undo", (e) => {
    state.sourceUsageByMap.delete(e.mapId);
    state.preview.usedAssetsByMap.delete(e.mapId);
    state.preview.cellEntryCache.clear();
    if (e.mapId === ctx.editor.activeMapId()) { ctx.editor.requestRedraw(); schedulePreview(ctx); }
    scheduleBackgroundMapRefresh(ctx, e.mapId, 360);
    scheduleSceneCompile(ctx, e.mapId, "undo", 480);
  });
  ctx.bus.on("redo", (e) => {
    state.sourceUsageByMap.delete(e.mapId);
    state.preview.usedAssetsByMap.delete(e.mapId);
    state.preview.cellEntryCache.clear();
    if (e.mapId === ctx.editor.activeMapId()) { ctx.editor.requestRedraw(); schedulePreview(ctx); }
    scheduleBackgroundMapRefresh(ctx, e.mapId, 360);
    scheduleSceneCompile(ctx, e.mapId, "redo", 480);
  });
  ctx.bus.on("hover.changed", (e) => {
    if (!state.preview.followHover || e.mapId !== ctx.editor.activeMapId() || e.x == null || e.y == null) return;
    state.preview.focusX = e.x;
    state.preview.focusY = e.y;
    schedulePreview(ctx);
  });
  ctx.bus.on("selection.changed", (e) => {
    if (e.mapId !== ctx.editor.activeMapId()) return;
    if (!state.preview.followHover && e.bounds) {
      // Selection does not force the camera, but causes a redraw so the user can
      // hit "Centrar en cursor 2D" immediately after selecting.
      schedulePreview(ctx);
    }
  });

  const active = ctx.editor.activeMapId();
  if (active != null) {
    void ensureMap(ctx, active).then(async (geo) => {
      await ensurePreviewResources(ctx, active, true);
      await scanGeometrySources(ctx, active, false);
      if (geo && geo.compiler?.auto_compile !== false && Object.keys(geo.definitions || {}).length) {
        await compileGeometryScene(ctx, active, geo, { reason: "activate" });
      }
    });
  }
}

export function deactivate() {
  if (state.preview.raf) cancelAnimationFrame(state.preview.raf);
  if (state.preview.topDownRaf) cancelAnimationFrame(state.preview.topDownRaf);
  if (state.panelRaf) cancelAnimationFrame(state.panelRaf);
  if (state.modelCompileRaf) cancelAnimationFrame(state.modelCompileRaf);
  state.preview.raf = 0;
  state.preview.topDownRaf = 0;
  state.panelRaf = 0;
  state.modelCompileRaf = 0;
  state.modelCompilePending = null;
  disposeAutotileUrls();
  state.preview.cellEntryCache.clear();
  state.preview.canvasPool.length = 0;
  state.preview.tilesetLoading.clear();
  clearTimeout(state.preview.legacyHeightTimer);
  clearTimeout(state.compilerTimer);
  clearTimeout(state.simpleEditTimer);
  clearTimeout(state.assetRefreshTimer);
  clearTimeout(state.sourceRefreshTimer);
  clearTimeout(state.modelSaveTimer);
  state.compilerTimer = 0;
  state.simpleEditTimer = 0;
  state.sourceRefreshTimer = 0;
  state.modelSaveTimer = 0;
  state.preview.canvas = null;
  state.preview.status = null;
  state.topDownCanvas = null;
  state.previewPanelRefresh = null;
}
