# Geometry V2 source identity

A placed source is identified by its actual origin, never by tile position alone.

Regular tile:

```text
ts:<tilesetId>:tile:<tileId>
```

Standard autotile:

```text
ts:<tilesetId>:autotile:<index>
```

Maker Studio extra autotile:

```text
extra:<autotileName>
```

Placed instance:

```text
L<layer>@<x>,<y>|<source-key>
```

`compiled_objects[].material.tileset_id` and `graphic` are persisted so MKXP-Z can load the same source atlas used by the editor.


## v2.7 render mesh fields

`mesh_faces` is generated editor data shared with the runtime. Each record stores `kind` (`top`/`side`), optional `edge`, tile-boundary coordinates `x0,y0,x1,y1`, height units `z0,z1`, material, model identifiers and `material_repeat`. `model_objects` are retained for collision and use `render:false` when their visible equivalent is present in `mesh_faces`.
