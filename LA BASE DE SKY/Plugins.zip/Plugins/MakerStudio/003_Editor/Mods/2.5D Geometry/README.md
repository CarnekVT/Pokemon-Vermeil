# 2.5D Geometry v2.9.2

Dark Model Studio + texture-footprint sizing. A selected W×H tile graphic creates a primitive W tiles wide and H tiles tall (X×Z).

# 2.5D Geometry v2.9.0 — Part Modeler

Esta versión se centra en que Geometry se sienta como una herramienta normal de Maker Studio: **editar, ver el cambio y seguir**, sin recompilar todo el mapa a cada gesto.

## Flujo rápido

1. Activa **⬢ Geometry**.
2. Usa **Seleccionar / Pintar / Altura + / Altura − / Borrar** directamente sobre el mapa.
3. **Borrar** funciona con clic o arrastre. **Alt + arrastre** borra Geometry temporalmente sin cambiar de herramienta. También puedes seleccionar algo y pulsar **Delete/Backspace**. Nunca borra el tile de Maker Studio.
4. Abre **2.5D** o **SPLIT**: ahora es un panel vivo, acoplable y redimensionable que puede quedarse abierto mientras editas el mapa.
5. Para elegir un gráfico, usa **Elegir gráfico…**. El navegador propio ocupa casi toda la ventana y permite seleccionar uno o varios tiles.
6. Para formas reutilizables abre **Model Workshop**. La cuadrícula de Forma/Altura admite pintar arrastrando.

## Part Modeler v2.8

El Part Modeler ya no obliga a abrir un selector modal para cada cara. El **tileset está embebido a la izquierda** y el modelo se construye en la misma ventana:

- **Seleccionar**: selecciona una celda del modelo.
- **Construir**: crea bloques/celdas arrastrando.
- **Borrar bloque**: elimina celdas arrastrando.
- **Altura**: pinta alturas por celda.
- **Textura**: pinta TOP/NORTH/SOUTH/EAST/WEST con el tile seleccionado del atlas lateral.
- Los modelos nuevos empiezan **vacíos**, para construirlos desde cero.
- El atlas permite seleccionar uno o varios tiles y aplicar el material directamente a una cara.
- La preview 3D es grande y puede rotarse en pasos de 90° sin alterar el modelo.
- El botón **Seleccionar en mapa** vuelve al modo de selección de Geometry.

El selector gráfico general también mantiene un botón **Seleccionar** visible arriba y abajo y acepta doble clic para confirmar.

## Preview reactiva

Los cambios de una celda se reflejan primero de forma incremental. Los strokes/fill/paste se actualizan visualmente al instante y el escaneo completo de fuentes se pospone hasta que dejas de editar unos instantes. Esto evita congelar la interacción por cada movimiento.

En **SPLIT**, la mitad MAP se vuelve a dibujar al editar el mapa y también cuando termina de cargar un tileset nuevo usado por una celda.

## Borrado

Un único borrador elimina lo que Geometry controla en la celda:

- Geometry simple,
- objetos manuales,
- instancias de Model Workshop.

Formas de usarlo:

- herramienta **Borrar** + clic/arrastre,
- **Alt + arrastre** con Geometry activo,
- **Delete** o **Backspace** sobre la selección,
- menú contextual **2.5D Geometry: Borrar Geometry aquí**.

El gráfico del mapa no se toca.

## Model Workshop

Los modelos pueden tener:

- forma arbitraria por celdas,
- altura independiente por celda,
- texturas independientes TOP/NORTH/SOUTH/EAST/WEST,
- override de material por celda,
- escala X/Y y escala vertical al colocarlos.

La edición de Forma y Altura funciona como un pincel: mantén pulsado y arrastra sobre la cuadrícula. El mapa/preview se recompila de forma agrupada, no una recompilación pesada por cada celda.

## Tiles de otros tilesets

Las capas extendidas se resuelven por su fuente real. `readTileData()` tiene prioridad para el dato vivo del editor y el `tileset_id` embebido se conserva como respaldo. Si un tile extendido no tiene un origen resoluble, Geometry evita sustituirlo por la misma posición del tileset base del mapa.

## Selector de gráficos

El selector visual propio usa casi toda la pantalla (**98vw × 95vh**), incluye lista de tilesets, canvas grande desplazable, zoom y preview de selección. La selección conserva `tilesetId` y `srcRect`.

## v2.7 Region Mesh

Reusable Geometry Models now compile to explicit `mesh_faces` instead of drawing every model cell as a visible cube. A flat 4×4 mountain with one material compiles to one top face plus four perimeter faces, while `model_objects` remain collision-only proxies. The same `mesh_faces` array is consumed by the Maker Studio preview and the included MKXP-Z renderer.

Different cell heights generate terrace faces only where height changes. Each top/north/south/east/west face may use its own tileset material, and merged faces repeat the selected tile rather than stretching it. Model placement also supports 0/90/180/270 rotation with the shape and directional face materials rotating together.
