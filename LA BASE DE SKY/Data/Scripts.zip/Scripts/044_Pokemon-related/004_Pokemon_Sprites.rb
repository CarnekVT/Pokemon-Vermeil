#===============================================================================
# Pokémon sprite (used out of battle).
#===============================================================================
class PokemonSprite < Sprite
  def initialize(viewport = nil)
    super(viewport)
    @_iconbitmap = nil
    @should_be_grey = false
    @tone_lock = false
  end

  def tone_lock?
    return @tone_lock == true
  end

  def tone_lock=(value)
    @tone_lock = (value == true)
  end

  def refresh_tone
    return if tone_lock?
    self.tone = if @show_as_silhouette
                  Tone.new(-255, -255, -255, 255)
                elsif @should_be_grey
                  Tone.new(0, 0, 0, 255)
                else
                  Tone.new(0, 0, 0, 0)
                end
  end

  def dispose
    @_iconbitmap&.dispose
    @_iconbitmap = nil
    self.bitmap = nil unless disposed?
    super
  end

  def clearBitmap
    @_iconbitmap&.dispose
    @_iconbitmap = nil
    self.bitmap = nil
  end

  def setOffset(offset = PictureOrigin::CENTER)
    @offset = offset
    changeOrigin
  end

  def changeOrigin
    return unless bitmap

    @offset ||= PictureOrigin::CENTER
    case @offset
    when PictureOrigin::TOP_LEFT, PictureOrigin::LEFT, PictureOrigin::BOTTOM_LEFT
      self.ox = 0
    when PictureOrigin::TOP, PictureOrigin::CENTER, PictureOrigin::BOTTOM
      self.ox = bitmap.width / 2
    when PictureOrigin::TOP_RIGHT, PictureOrigin::RIGHT, PictureOrigin::BOTTOM_RIGHT
      self.ox = bitmap.width
    end
    case @offset
    when PictureOrigin::TOP_LEFT, PictureOrigin::TOP, PictureOrigin::TOP_RIGHT
      self.oy = 0
    when PictureOrigin::LEFT, PictureOrigin::CENTER, PictureOrigin::RIGHT
      self.oy = bitmap.height / 2
    when PictureOrigin::BOTTOM_LEFT, PictureOrigin::BOTTOM, PictureOrigin::BOTTOM_RIGHT
      self.oy = bitmap.height
    end
  end

  def setPokemonBitmap(pokemon, back = false)
    @_iconbitmap&.dispose
    @_iconbitmap = pokemon ? GameData::Species.sprite_bitmap_from_pokemon(pokemon, back) : nil
    self.bitmap = @_iconbitmap&.bitmap
    self.color = Color.new(0, 0, 0, 0)
    self.make_grey_if_fainted = pokemon.fainted?
    refresh_tone
    changeOrigin
  end

  def setPokemonBitmapSpecies(pokemon, species, back = false)
    @_iconbitmap&.dispose
    @_iconbitmap = pokemon ? GameData::Species.sprite_bitmap_from_pokemon(pokemon, back, species) : nil
    self.bitmap = @_iconbitmap&.bitmap
    self.make_grey_if_fainted = pokemon.fainted?
    refresh_tone
    changeOrigin
  end

  def setSpeciesBitmap(species, gender = 0, form = 0, shiny = false, shadow = false, back = false, egg = false, super_shiny = false)
    @_iconbitmap&.dispose
    @_iconbitmap = GameData::Species.sprite_bitmap(species, form, gender, shiny, shadow, back, egg, super_shiny)
    self.bitmap = @_iconbitmap&.bitmap
    refresh_tone
    changeOrigin
  end

  def make_grey_if_fainted=(value)
    return unless Settings::GREY_OUT_FAINTED

    @should_be_grey = value
    refresh_tone
  end

  def show_as_silhouette=(value)
    @show_as_silhouette = value
    refresh_tone
  end

  def update
    super
    if @_iconbitmap
      @_iconbitmap.update
      self.bitmap = @_iconbitmap.bitmap
    end
    refresh_tone
  end
end

#===============================================================================
# Pokémon icon (for defined Pokémon).
#===============================================================================
class PokemonIconSprite < Sprite
  attr_accessor :selected
  attr_accessor :active
  attr_reader   :pokemon

  # Time in seconds for one animation cycle of this Pokémon icon. It is doubled
  # if the Pokémon is at 50% HP or lower, and doubled again if it is at 25% HP
  # or lower. The icon doesn't animate at all if the Pokémon is fainted.
  ANIMATION_DURATION = 0.25

  def initialize(pokemon, viewport = nil)
    super(viewport)
    @selected      = false
    @active        = false
    @frames_count  = 0
    @current_frame = 0
    self.pokemon   = pokemon
    @logical_x     = 0   # Actual x coordinate
    @logical_y     = 0   # Actual y coordinate
    @adjusted_x    = 0   # Offset due to "jumping" animation in party screen
    @adjusted_y    = 0   # Offset due to "jumping" animation in party screen
    @should_be_grey = @pokemon&.fainted? && Settings::GREY_OUT_FAINTED
  end

  def dispose
    @animBitmap&.dispose
    super
  end

  def x; return @logical_x; end
  def y; return @logical_y; end

  def x=(value)
    @logical_x = value
    super(@logical_x + @adjusted_x)
  end

  def y=(value)
    @logical_y = value
    super(@logical_y + @adjusted_y)
  end

  def make_grey_if_fainted=(value)
    return unless Settings::GREY_OUT_FAINTED

    @should_be_grey = value
  end

  def pokemon=(value)
    @pokemon = value
    # Check if the bitmap needs to be reloaded
    new_values = nil
    if @pokemon
      new_values = {
        :species => @pokemon.species,
        :form    => @pokemon.form,
        :gender  => @pokemon.gender,
        :shiny   => @pokemon.shiny?,
        :shadow  => @pokemon.shadowPokemon?,
        :egg     => @pokemon.egg?
      }
    end
    return if @pokemon_values == new_values

    @pokemon_values = new_values
    # Reload the bitmap
    @animBitmap&.dispose
    @animBitmap = nil
    unless @pokemon
      self.bitmap = nil
      @current_frame = 0
      return
    end
    
    filename = GameData::Species.icon_filename_from_pokemon(value)
    @animBitmap = AnimatedBitmap.new(filename)
    
    if value.super_shiny? && !(filename && filename.include?("supershiny"))
      hue = GameData::Species.super_shiny_hue_for(value.species, value.form, true)
      if hue != 0
        new_anim = @animBitmap.copy
        @animBitmap.dispose
        new_anim.bitmap.apply_super_shiny_hue(hue)
        @animBitmap = new_anim
      end
    end
    
    self.bitmap = @animBitmap.bitmap
    src_rect.width  = @animBitmap.height
    src_rect.height = @animBitmap.height
    @frames_count = @animBitmap.width / @animBitmap.height
    @current_frame = 0 if @current_frame >= @frames_count
    self.make_grey_if_fainted = value.fainted?
    changeOrigin
  end

  def setOffset(offset = PictureOrigin::CENTER)
    @offset = offset
    changeOrigin
  end

  def changeOrigin
    return unless bitmap

    @offset ||= PictureOrigin::TOP_LEFT
    case @offset
    when PictureOrigin::TOP_LEFT, PictureOrigin::LEFT, PictureOrigin::BOTTOM_LEFT
      self.ox = 0
    when PictureOrigin::TOP, PictureOrigin::CENTER, PictureOrigin::BOTTOM
      self.ox = src_rect.width / 2
    when PictureOrigin::TOP_RIGHT, PictureOrigin::RIGHT, PictureOrigin::BOTTOM_RIGHT
      self.ox = src_rect.width
    end
    case @offset
    when PictureOrigin::TOP_LEFT, PictureOrigin::TOP, PictureOrigin::TOP_RIGHT
      self.oy = 0
    when PictureOrigin::LEFT, PictureOrigin::CENTER, PictureOrigin::RIGHT
      # NOTE: This assumes the top quarter of the icon is blank, so oy is placed
      #       in the middle of the lower three quarters of the image.
      self.oy = src_rect.height * 5 / 8
    when PictureOrigin::BOTTOM_LEFT, PictureOrigin::BOTTOM, PictureOrigin::BOTTOM_RIGHT
      self.oy = src_rect.height
    end
  end

  def update_frame
    if @pokemon.fainted?
      @current_frame = 0
      return
    end
    duration = ANIMATION_DURATION
    if @pokemon.hp <= @pokemon.totalhp / 4      # Red HP - 1 second
      duration *= 4
    elsif @pokemon.hp <= @pokemon.totalhp / 2   # Yellow HP - 0.5 seconds
      duration *= 2
    end
    @current_frame = (@frames_count * (System.uptime % duration) / duration).floor
  end

  def update
    return unless @animBitmap

    super
    @animBitmap.update
    self.bitmap = @animBitmap.bitmap
    # Update animation
    update_frame
    src_rect.x = src_rect.width * @current_frame
    # Update "jumping" animation (used in party screen)
    if @selected
      @adjusted_x = 4
      @adjusted_y = (@current_frame >= @frames_count / 2) ? -2 : 6
    else
      @adjusted_x = 0
      @adjusted_y = 0
    end
    self.x = x
    self.y = y
    # Apply tone after any bitmap changes
    self.tone = if @should_be_grey
                  Tone.new(0, 0, 0, 255)
                else
                  Tone.new(0, 0, 0, 0)
                end
  end
end

#===============================================================================
# Pokémon icon (for species).
#===============================================================================
class PokemonSpeciesIconSprite < Sprite
  attr_reader :species
  attr_reader :gender
  attr_reader :form
  attr_reader :shiny
  attr_reader :super_shiny

  # Time in seconds for one animation cycle of this Pokémon icon.
  ANIMATION_DURATION = 0.25

  def initialize(species, viewport = nil)
    super(viewport)
    @species       = species
    @gender        = 0
    @form          = 0
    @shiny         = false
    @super_shiny   = false
    @frames_count  = 0
    @current_frame = 0
    refresh
  end

  def dispose
    @animBitmap&.dispose
    super
  end

  def species=(value)
    @species = value
    refresh
  end

  def gender=(value)
    @gender = value
    refresh
  end

  def form=(value)
    @form = value
    refresh
  end

  def shiny=(value)
    @shiny = value
    @super_shiny = false if !@shiny
    refresh
  end

  def super_shiny=(value)
    @super_shiny = value
    @shiny = true if @super_shiny
    refresh
  end

  def pbSetParams(species, gender, form, shiny = false, super_shiny = false)
    @species = species
    @gender  = gender
    @form    = form
    @shiny   = shiny
    @super_shiny = super_shiny
    refresh
  end

  def setOffset(offset = PictureOrigin::CENTER)
    @offset = offset
    changeOrigin
  end

  def changeOrigin
    return unless bitmap

    @offset ||= PictureOrigin::TOP_LEFT
    case @offset
    when PictureOrigin::TOP_LEFT, PictureOrigin::LEFT, PictureOrigin::BOTTOM_LEFT
      self.ox = 0
    when PictureOrigin::TOP, PictureOrigin::CENTER, PictureOrigin::BOTTOM
      self.ox = src_rect.width / 2
    when PictureOrigin::TOP_RIGHT, PictureOrigin::RIGHT, PictureOrigin::BOTTOM_RIGHT
      self.ox = src_rect.width
    end
    case @offset
    when PictureOrigin::TOP_LEFT, PictureOrigin::TOP, PictureOrigin::TOP_RIGHT
      self.oy = 0
    when PictureOrigin::LEFT, PictureOrigin::CENTER, PictureOrigin::RIGHT
      # NOTE: This assumes the top quarter of the icon is blank, so oy is placed
      #       in the middle of the lower three quarters of the image.
      self.oy = src_rect.height * 5 / 8
    when PictureOrigin::BOTTOM_LEFT, PictureOrigin::BOTTOM, PictureOrigin::BOTTOM_RIGHT
      self.oy = src_rect.height
    end
  end

  def refresh
    @animBitmap&.dispose
    @animBitmap = nil
    bitmapFileName = GameData::Species.icon_filename(@species, @form, @gender, @shiny, false, false, @super_shiny)
    return unless bitmapFileName

    @animBitmap = AnimatedBitmap.new(bitmapFileName)
    if @super_shiny && !bitmapFileName.include?("supershiny")
      hue = GameData::Species.super_shiny_hue_for(@species, @form, true)
      if hue != 0
        new_anim = @animBitmap.copy
        @animBitmap.dispose
        new_anim.bitmap.apply_super_shiny_hue(hue)
        @animBitmap = new_anim
      end
    end
    self.bitmap = @animBitmap.bitmap
    src_rect.width  = @animBitmap.height
    src_rect.height = @animBitmap.height
    @frames_count = @animBitmap.width / @animBitmap.height
    @current_frame = 0 if @current_frame >= @frames_count
    changeOrigin
  end

  def update_frame
    @current_frame = (@frames_count * (System.uptime % ANIMATION_DURATION) / ANIMATION_DURATION).floor
  end

  def update
    return unless @animBitmap

    super
    @animBitmap.update
    self.bitmap = @animBitmap.bitmap
    # Update animation
    update_frame
    src_rect.x = src_rect.width * @current_frame
  end
end
