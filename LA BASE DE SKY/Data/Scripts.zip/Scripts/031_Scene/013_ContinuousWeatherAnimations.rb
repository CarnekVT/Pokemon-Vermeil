#===============================================================================
# Continuous Weather Animations Plugin
# Makes weather animations play continuously during battle
#===============================================================================

class PokemonSystem
  alias continuous_weather_animations_initialize initialize unless method_defined?(:continuous_weather_animations_initialize)
  def initialize
    continuous_weather_animations_initialize
    @continuous_weather_animations = ContinuousWeatherSettings::ENABLED ? 0 : 1
  end

  def continuous_weather_animations
    @continuous_weather_animations ||= ContinuousWeatherSettings::ENABLED ? 0 : 1
    return @continuous_weather_animations == 0 ? true : false
  end

  def continuous_weather_animations=(value)
    @continuous_weather_animations = ContinuousWeatherSettings::ENABLED ? 0 : 1 if !@continuous_weather_animations
    @continuous_weather_animations = value
  end
end

module ContinuousWeatherSettings
  ENABLED = true
  # How often to restart weather animations (in frames, 60 = 1 second)
  ANIMATION_RESTART_INTERVAL = 600  # 10 seconds
  
  # Weather types that should NOT use continuous animation (keep original end-of-turn behavior)
  EXCLUDED_WEATHER_TYPES = []

  # Volume for weather sound effects (0-100)
  DEFAULT_VOLUME = 50 

  # Optional specific volume levels for certain weather types (overrides DEFAULT_VOLUME)
  VOLUME_PER_WEATHER = {
    :Sun => 20,
  }

  ALLOW_CHANGE_WEATHER_ANIMATIONS_IN_SETTINGS = true
end

class Battle::Scene
  # Add our weather system to the battle scene initialization
  alias cwas_pbInitSprites pbInitSprites
  def pbInitSprites
    cwas_pbInitSprites
    pbCreateWeatherOverlay if $PokemonSystem.continuous_weather_animations
  end

  # Add weather disposal to sprite cleanup
  alias cwas_pbDisposeSprites pbDisposeSprites
  def pbDisposeSprites
    cwas_pbDisposeSprites
    pbDisposeWeather if $PokemonSystem.continuous_weather_animations
  end

  # Add weather updates to frame updates
  alias cwas_pbFrameUpdate pbFrameUpdate
  def pbFrameUpdate(cw = nil)
    cwas_pbFrameUpdate(cw)
    pbUpdateWeather if $PokemonSystem.continuous_weather_animations
  end

  def pbCreateWeatherOverlay
    # Initialize continuous weather animation system
    @continuousWeatherActive = false
    @currentWeatherAnimation = nil
    @weatherAnimationPlayer = nil
    @weatherAnimationTimer = 0
    @weatherAnimationInterval = ContinuousWeatherSettings::ANIMATION_RESTART_INTERVAL
  end

  def pbStartContinuousWeather(battleWeather)
    return if !$PokemonSystem.continuous_weather_animations
    return if battleWeather == :None || battleWeather.nil?
    return if battleWeather == @currentWeatherType
    
    # Check if this weather type should be excluded
    if ContinuousWeatherSettings::EXCLUDED_WEATHER_TYPES.include?(battleWeather)
      return
    end
    
    
    # Stop any existing weather first
    pbStopContinuousWeather if @continuousWeatherActive
    
    # Get the animation name for this weather
    weather_data = GameData::BattleWeather.try_get(battleWeather)
    if !weather_data || !weather_data.animation
      return
    end
    
    @currentWeatherType = battleWeather
    @currentWeatherAnimation = weather_data.animation
    @continuousWeatherActive = true
    @weatherAnimationTimer = 0
    
    # Start the first weather animation immediately
    pbStartWeatherAnimation
  end

  def pbStopContinuousWeather
    return if !$PokemonSystem.continuous_weather_animations
    return if !@continuousWeatherActive

    # Dispose the current animation player if it exists
    if @weatherAnimationPlayer
      @weatherAnimationPlayer.dispose
      @weatherAnimationPlayer = nil
    end

    @continuousWeatherActive = false
    @currentWeatherType = :None
    @currentWeatherAnimation = nil
    @weatherAnimationTimer = 0
  end

  def pbStartWeatherAnimation
    return if !$PokemonSystem.continuous_weather_animations
    return if !@currentWeatherAnimation
    
    # Load the animation just like pbCommonAnimation does
    animations = pbLoadBattleAnimations
    if !animations
      return
    end
    
    animation = nil
    animations.each do |a|
      next if !a || a.name != "Common:" + @currentWeatherAnimation
      animation = a
      break
    end
    if !animation
      return
    end
    
    # Dispose previous animation player if it exists
    @weatherAnimationPlayer&.dispose
    
    # Create animation player using the scene (same as original approach)
    animation.volume = ContinuousWeatherSettings::DEFAULT_VOLUME if ContinuousWeatherSettings::DEFAULT_VOLUME
    animation.volume = ContinuousWeatherSettings::VOLUME_PER_WEATHER.fetch(@currentWeatherType, ContinuousWeatherSettings::DEFAULT_VOLUME) if ContinuousWeatherSettings::VOLUME_PER_WEATHER 
    @weatherAnimationPlayer = PBAnimationPlayerX.new(animation, nil, nil, self, false)
    
    # Start the animation
    @weatherAnimationPlayer.start
    @weatherAnimationTimer = 0
  end

  def pbUpdateWeather
    return if !$PokemonSystem.continuous_weather_animations
    return if !@continuousWeatherActive
    
    @weatherAnimationTimer += 1
    # Update the current animation player
    if @weatherAnimationPlayer && !@weatherAnimationPlayer.animDone?
      @weatherAnimationPlayer.update
    end
    
    # Check if we need to restart the animation
    if !@weatherAnimationPlayer || @weatherAnimationPlayer.animDone? || @weatherAnimationTimer >= @weatherAnimationInterval
      pbStartWeatherAnimation
    end
  end

  def pbDisposeWeather
    return if !$PokemonSystem.continuous_weather_animations
    pbStopContinuousWeather
  end
end

#===============================================================================
# Battle class modifications
#===============================================================================
class Battle
  # Hook into weather starting to begin continuous animations
  alias cwas_pbStartWeather pbStartWeather
  def pbStartWeather(user, newWeather, fixedDuration = false, showAnim = true, message = nil)
    cwas_pbStartWeather(user, newWeather, fixedDuration, showAnim, message)
    # Start continuous weather animation
    @scene.pbStartContinuousWeather(@field.weather) if @field.weather != :None && $PokemonSystem.continuous_weather_animations
  end

  alias cwas_pbStartBattleCore pbStartBattleCore
  def pbStartBattleCore(battle_loop = true)
    cwas_pbStartBattleCore(false)
    @scene.pbStartContinuousWeather(@field.weather) if @field.weather != :None && $PokemonSystem.continuous_weather_animations
    pbBattleLoop if battle_loop
  end

  # Hook into end of round weather to stop continuous animation when weather ends
  alias cwas_pbEOREndWeather pbEOREndWeather
  def pbEOREndWeather(priority)
    old_weather = @field.weather
    
    # Call the original method
    cwas_pbEOREndWeather(priority)
    
    # If weather ended, stop continuous animation
    if old_weather != :None && @field.weather == :None
      @scene.pbStopContinuousWeather
    end
  end

  alias cwas_pbEndPrimordialWeather pbEndPrimordialWeather
  def pbEndPrimordialWeather
    old_weather = @field.weather
    cwas_pbEndPrimordialWeather
    if old_weather != :None && @field.weather == :None
      @scene.pbStopContinuousWeather
    end
  end

end

MenuHandlers.add(:options_menu, :continuous_weather_animations, {
  "page"        => :graphics,
  "name"        => _INTL("Anim. clima cont."),
  "order"       => 20,
  "type"        => :toggle,
  "parameters"  => proc { [_INTL("Sí"), _INTL("No")] },
  "condition"   => proc { next ContinuousWeatherSettings::ALLOW_CHANGE_WEATHER_ANIMATIONS_IN_SETTINGS },
  "description" => _INTL("Elige si deseas ver las animaciones de clima continuas."),
  "get_proc"    => proc { next $PokemonSystem.continuous_weather_animations ? 0 : 1 },
  "set_proc"    => proc { |value, _screen| $PokemonSystem.continuous_weather_animations = value }
})