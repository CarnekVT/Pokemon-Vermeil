#===============================================================================
# CREDITOS
# DPertierra
#===============================================================================
class PokemonSummary_Scene

  BALL_IMAGE_X = 8
  BALL_IMAGE_Y = 60
  IMG_STATUS_X = 124
  IMG_STATUS_Y = 100
  IMG_POKERUS_X = 176
  IMG_POKERUS_Y = 100
  IMG_SHINY_X = 174
  IMG_SHINY_Y = 100
  ABILITY_NAME_X = 336
  ABILITY_NAME_Y = 22
  ABILITY_NAME_WIDTH = 0
  ABILITY_LABEL_X = 230
  ABILITY_LABEL_Y = 22
  ABILITY_DESC_X = 240
  ABILITY_DESC_Y = 85
  ABILITY_DESC_WIDTH = 230
  ABILITY_DESC_HEIGHT = 10
  SHADOW_DESCRIPTION_X = 270
  SHADOW_DESCRIPTION_Y = 22
  SHADOW_HEART_TEXT_X = 240
  SHADOW_HEART_TEXT_Y = 85
  SHADOW_HEART_TEXT_WIDTH = 264

  def pbStartScene(party, partyindex, inbattle = false, page=1, allow_learn_moves = true)
      @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
      @viewport.z = 99999
      @party      = party
      @partyindex = partyindex
      @pokemon    = @party[@partyindex]
      @inbattle   = inbattle
      @allow_learn_moves = allow_learn_moves
      @page = page
      @typebitmap    = AnimatedBitmap.new(_INTL("Graphics/UI/types"))
      @markingbitmap = AnimatedBitmap.new("Graphics/UI/Summary/markings")
      @sprites = {}
      @sprites["background"] = IconSprite.new(0, 0, @viewport)
      @sprites["pokemon"] = PokemonSprite.new(@viewport)
      @sprites["pokemon"].setOffset(PictureOrigin::CENTER)
      gray_out_fainted_pokemon("pokemon")
      # Uso de constantes
      @sprites["pokemon"].x = UI_POKEMON_SPRITE_X
      @sprites["pokemon"].y = UI_POKEMON_SPRITE_Y
      @sprites["pokemon"].setPokemonBitmap(@pokemon)
      @sprites["pokeicon"] = PokemonIconSprite.new(@pokemon, @viewport)
      @sprites["pokeicon"].setOffset(PictureOrigin::CENTER)
      gray_out_fainted_pokemon("pokeicon")
      # Uso de constantes
      @sprites["pokeicon"].x       = UI_POKEICON_X
      @sprites["pokeicon"].y       = UI_POKEICON_Y
      @sprites["pokeicon"].visible = false
      # Uso de constantes
      @sprites["itemicon"] = ItemIconSprite.new(UI_ITEMICON_X, UI_ITEMICON_Y, @pokemon.item_id, @viewport)
      @sprites["itemicon"].blankzero = true
      @sprites["overlay"] = BitmapSprite.new(Graphics.width, Graphics.height, @viewport)
      pbSetSystemFont(@sprites["overlay"].bitmap)
      @sprites["movepresel"] = MoveSelectionSprite.new(@viewport)
      @sprites["movepresel"].visible     = false
      @sprites["movepresel"].preselected = true
      @sprites["movesel"] = MoveSelectionSprite.new(@viewport)
      @sprites["movesel"].visible = false
      @sprites["ribbonpresel"] = RibbonSelectionSprite.new(@viewport)
      @sprites["ribbonpresel"].visible     = false
      @sprites["ribbonpresel"].preselected = true
      @sprites["ribbonsel"] = RibbonSelectionSprite.new(@viewport)
      @sprites["ribbonsel"].visible = false
      @sprites["uparrow"] = AnimatedSprite.new("Graphics/UI/up_arrow", 8, 28, 40, 2, @viewport)
      # Uso de constantes
      @sprites["uparrow"].x = UI_UP_ARROW_X
      @sprites["uparrow"].y = UI_UP_ARROW_Y
      @sprites["uparrow"].play
      @sprites["uparrow"].visible = false
      @sprites["downarrow"] = AnimatedSprite.new("Graphics/UI/down_arrow", 8, 28, 40, 2, @viewport)
      # Uso de constantes
      @sprites["downarrow"].x = UI_DOWN_ARROW_X
      @sprites["downarrow"].y = UI_DOWN_ARROW_Y
      @sprites["downarrow"].play
      @sprites["downarrow"].visible = false
      # Uso de constantes
      @sprites["markingbg"] = IconSprite.new(UI_MARKING_BG_X, UI_MARKING_BG_Y, @viewport)
      @sprites["markingbg"].setBitmap("Graphics/UI/Summary/overlay_marking")
      @sprites["markingbg"].visible = false
      @sprites["markingoverlay"] = BitmapSprite.new(Graphics.width, Graphics.height, @viewport)
      @sprites["markingoverlay"].visible = false
      pbSetSystemFont(@sprites["markingoverlay"].bitmap)
      @sprites["markingsel"] = IconSprite.new(0, 0, @viewport)
      @sprites["markingsel"].setBitmap("Graphics/UI/Summary/cursor_marking")
      @sprites["markingsel"].src_rect.height = @sprites["markingsel"].bitmap.height / 2
      @sprites["markingsel"].visible = false
      @sprites["messagebox"] = Window_AdvancedTextPokemon.new("")
      @sprites["messagebox"].viewport       = @viewport
      @sprites["messagebox"].visible        = false
      @sprites["messagebox"].letterbyletter = true
      pbBottomLeftLines(@sprites["messagebox"], 2)
      @nationalDexList = [:NONE]
      GameData::Species.each_species { |s| @nationalDexList.push(s.species) }
      drawPage(@page)
      pbFadeInAndShow(@sprites) { pbUpdate }
  end

  def drawPageOneEgg
      @sprites["itemicon"].item = @pokemon.item_id
      overlay = @sprites["overlay"].bitmap
      overlay.clear
      base   = Color.new(248, 248, 248)
      shadow = Color.new(104, 104, 104)
      # Set background image
      @sprites["background"].setBitmap("Graphics/UI/Summary/bg_egg")
      imagepos = []
      # Show the Poké Ball containing the Pokémon
      ballimage = sprintf("Graphics/UI/Summary/icon_ball_%s", @pokemon.poke_ball)
      # Uso de constantes
      imagepos.push([ballimage, IMG_BALL_X, IMG_BALL_Y])
      # Draw all images
      pbDrawImagePositions(overlay, imagepos)
      # Write various bits of text
      textpos = [
      # Uso de constantes
      [_INTL("NOTAS ENTRENADOR"), TEXT_PAGE_NAME_X, TEXT_PAGE_NAME_Y, :left, base, shadow],
      [@pokemon.name, TEXT_NAME_X, TEXT_NAME_Y, :left, base, shadow],
      [_INTL("Objeto"), TEXT_ITEM_LABEL_X, TEXT_ITEM_LABEL_Y, :left, base, shadow]
      ]
      # Write the held item's name
      if @pokemon.hasItem?
          # Uso de constantes
          textpos.push([@pokemon.item.name, TEXT_ITEM_NAME_X, TEXT_ITEM_NAME_Y, :left, Color.new(64, 64, 64), Color.new(176, 176, 176)])
      else
          textpos.push([_INTL("Ninguno"), TEXT_ITEM_NAME_X, TEXT_ITEM_NAME_Y, :left, Color.new(192, 200, 208), Color.new(208, 216, 224)])
      end
      # Draw all text
      pbDrawTextPositions(overlay, textpos)
      red_text_tag = shadowc3tag(RED_TEXT_BASE, RED_TEXT_SHADOW)
      black_text_tag = shadowc3tag(BLACK_TEXT_BASE, BLACK_TEXT_SHADOW)
      memo = ""
      # Write date received
      if @pokemon.timeReceived
      date  = @pokemon.timeReceived.day
      month = pbGetMonthName(@pokemon.timeReceived.mon)
      year  = @pokemon.timeReceived.year
      memo += black_text_tag + _INTL("{1} {2}, {3}", date, month, year) + "\n"
      end
      # Write map name egg was received on
      mapname = pbGetMapNameFromId(@pokemon.obtain_map)
      mapname = @pokemon.obtain_text if @pokemon.obtain_text && !@pokemon.obtain_text.empty?
      if mapname && mapname != ""
      mapname = red_text_tag + mapname + black_text_tag
      memo += black_text_tag + _INTL("Un misterioso huevo recibido en {1}.", mapname) + "\n"
      else
      memo += black_text_tag + _INTL("Un huevo misterioso de un Pokémon.") + "\n"
      end
      memo += "\n"   # Empty line
      # Write Egg Watch blurb
      if !MOSTRAR_PASOS_HUEVO
          #memo += black_text_tag + _INTL("\"El huevo eclosionará...\"") + "\n"
          eggstate = _INTL("Parece que va a tardar un buen rato en eclosionar.")
          eggstate = _INTL("¿Qué eclosionará de esto? No parece estar cerca de eclosionar.") if @pokemon.steps_to_hatch < 10_200
          eggstate = _INTL("Parece moverse ocasionalmente. Puede estar cerca de eclosionar.") if @pokemon.steps_to_hatch < 2550
          eggstate = _INTL("¡Se escuchan sonido desde dentro! ¡eclosionará pronto!") if @pokemon.steps_to_hatch < 1275
          memo += black_text_tag + eggstate
      else
          memo += black_text_tag + _INTL("Faltan {1} pasos para que el huevo eclosione.", @pokemon.steps_to_hatch)
      end
      # Draw all text - Uso de constantes
      drawFormattedTextEx(overlay, EGG_DATE_X, EGG_DATE_Y, EGG_MEMO_WIDTH, memo)
      # Draw the Pokémon's markings - Uso de constantes
      drawMarkings(overlay, IMG_MARKINGS_X, IMG_MARKINGS_Y)
  end

  def drawPageFourSelecting(move_to_learn)
      overlay = @sprites["overlay"].bitmap
      overlay.clear
      base   = Color.new(248, 248, 248)
      shadow = Color.new(104, 104, 104)
      moveBase   = Color.new(64, 64, 64)
      moveShadow = Color.new(176, 176, 176)
      ppBase   = [moveBase,                # More than 1/2 of total PP
                  Color.new(248, 192, 0),    # 1/2 of total PP or less
                  Color.new(248, 136, 32),   # 1/4 of total PP or less
                  Color.new(248, 72, 72)]    # Zero PP
      ppShadow = [moveShadow,             # More than 1/2 of total PP
                  Color.new(144, 104, 0),   # 1/2 of total PP or less
                  Color.new(144, 72, 24),   # 1/4 of total PP or less
                  Color.new(136, 48, 48)]   # Zero PP
      # Set background image
      if move_to_learn
        @sprites["background"].setBitmap("Graphics/UI/Summary/bg_learnmove")
      else
        @sprites["background"].setBitmap("Graphics/UI/Summary/bg_movedetail")
      end
      # Write various bits of text
      textpos = [
        # Uso de constantes
        [_INTL("MOVIMIENTOS"), TEXT_PAGE_NAME_X, TEXT_PAGE_NAME_Y, :left, base, shadow],
        [_INTL("CATEGORÍA"), P4_SEL_CATEGORY_LABEL_X, P4_SEL_CATEGORY_LABEL_Y, :left, base, shadow],
        [_INTL("POTENCIA"), P4_SEL_POWER_LABEL_X, P4_SEL_POWER_LABEL_Y, :left, base, shadow],
        [_INTL("PRECISIÓN"), P4_SEL_ACCURACY_LABEL_X, P4_SEL_ACCURACY_LABEL_Y, :left, base, shadow],
        
      ]
      # Uso de constantes para "DATOS"
      textpos.push([_INTL("DATOS"), P4_LEARN_DATA_LABEL_X, P4_LEARN_DATA_LABEL_Y, :left, base, shadow]) if move_to_learn
      imagepos = []
      # Write move names, types and PP amounts for each known move
      yPos = P4_MOVE_LIST_Y
      yPos -= 76 if move_to_learn
      limit = (move_to_learn) ? Pokemon::MAX_MOVES + 1 : Pokemon::MAX_MOVES
      limit.times do |i|
        move = @pokemon.moves[i]
        if i == Pokemon::MAX_MOVES
          move = move_to_learn
          yPos += 20
        end
        if move
          type_number = GameData::Type.get(move.display_type(@pokemon)).icon_position
          # Uso de constantes
          imagepos.push([_INTL("Graphics/UI/types"), P4_TYPE_ICON_X, yPos + P4_TYPE_ICON_OFFSET_Y, 0, type_number * 28, 64, 28])
          textpos.push([move.name, P4_MOVE_NAME_X, yPos, :left, moveBase, moveShadow])
          if move.total_pp > 0
            textpos.push([_INTL("PP"), P4_PP_LABEL_X, yPos + P4_PP_LABEL_OFFSET_Y, :left, moveBase, moveShadow])
            ppfraction = 0
            if move.pp == 0
              ppfraction = 3
            elsif move.pp * 4 <= move.total_pp
              ppfraction = 2
            elsif move.pp * 2 <= move.total_pp
              ppfraction = 1
            end
            textpos.push([sprintf("%d/%d", move.pp, move.total_pp), P4_PP_NUM_X, yPos + P4_PP_NUM_OFFSET_Y, :right,
                          ppBase[ppfraction], ppShadow[ppfraction]])
          end
        else
          textpos.push(["-", P4_MOVE_NAME_X, yPos, :left, moveBase, moveShadow])
          textpos.push(["--", P4_PP_NUM_X - 18, yPos + P4_PP_NUM_OFFSET_Y, :right, moveBase, moveShadow])
        end
        yPos += P4_MOVE_OFFSET_Y
        # Uso de constantes para BetterMoveSummary
        imagepos.push([_INTL("Graphics/UI/BetterMoveSummary/recuadro"), P4_LEARN_BOX_X, P4_LEARN_BOX_Y]) if move_to_learn
        imagepos.push([_INTL("Graphics/UI/BetterMoveSummary/help_actionkey"), P4_LEARN_ACTION_KEY_X, P4_LEARN_ACTION_KEY_Y]) if move_to_learn
        # Draw all text and images
        pbDrawImagePositions(overlay, imagepos)
        pbDrawTextPositions(overlay, textpos)
      end
  end
    
    def pbChooseMoveToForget(move_to_learn)
        new_move = (move_to_learn) ? Pokemon::Move.new(move_to_learn) : nil
        selmove = 0
        maxmove = (new_move) ? Pokemon::MAX_MOVES : Pokemon::MAX_MOVES - 1
        loop do
          Graphics.update
          Input.update
          pbUpdate
          if Input.trigger?(Input::BACK)
            selmove = Pokemon::MAX_MOVES
            pbPlayCloseMenuSE if new_move
            break
          elsif Input.trigger?(Input::USE)
            pbPlayDecisionSE
            break
          elsif Input.trigger?(Input::ACTION)
            newScene = PokemonSummary_Scene.new
            newScreen = PokemonSummaryScreen.new(newScene, @inbattle, false)
            newScreen.pbStartScreen(@party, @partyindex, 3)
          elsif Input.trigger?(Input::UP)
            selmove -= 1
            selmove = maxmove if selmove < 0
            if selmove < Pokemon::MAX_MOVES && selmove >= @pokemon.numMoves
              selmove = @pokemon.numMoves - 1
            end
            @sprites["movesel"].index = selmove
            selected_move = (selmove == Pokemon::MAX_MOVES) ? new_move : @pokemon.moves[selmove]
            drawSelectedMove(new_move, selected_move)
          elsif Input.trigger?(Input::DOWN)
            selmove += 1
            selmove = 0 if selmove > maxmove
            if selmove < Pokemon::MAX_MOVES && selmove >= @pokemon.numMoves
              selmove = (new_move) ? maxmove : 0
            end
            @sprites["movesel"].index = selmove
            selected_move = (selmove == Pokemon::MAX_MOVES) ? new_move : @pokemon.moves[selmove]
            drawSelectedMove(new_move, selected_move)
          end
        end
        return (selmove == Pokemon::MAX_MOVES) ? -1 : selmove
    end

      if !PluginManager.installed?("Modular UI Scenes")
        def pbScene
          @pokemon.play_cry
          loop do
            Graphics.update
            Input.update
            pbUpdate
            dorefresh = false
            if Input.trigger?(Input::ACTION)
              pbSEStop
              @pokemon.play_cry
            elsif Input.trigger?(Input::SPECIAL)
              pbPlayDecisionSE
              showAbilityDescription(@pokemon)
            elsif Input.trigger?(Input::BACK)
              pbPlayCloseMenuSE
              break
            elsif Input.trigger?(Input::USE)
              if @page == 4
                pbPlayDecisionSE
                pbMoveSelection
                dorefresh = true
              elsif @page == 5
                pbPlayDecisionSE
                pbRibbonSelection
                dorefresh = true
              elsif !@inbattle
                pbPlayDecisionSE
                dorefresh = pbOptions
              end
            elsif Input.trigger?(Input::UP) && @partyindex > 0
              oldindex = @partyindex
              pbGoToPrevious
              if @partyindex != oldindex
                pbChangePokemon
                @ribbonOffset = 0
                dorefresh = true
              end
            elsif Input.trigger?(Input::DOWN) && @partyindex < @party.length - 1
              oldindex = @partyindex
              pbGoToNext
              if @partyindex != oldindex
                pbChangePokemon
                @ribbonOffset = 0
                dorefresh = true
              end
            elsif Input.trigger?(Input::LEFT) && !@pokemon.egg?
              oldpage = @page
              @page -= 1
              @page = 1 if @page < 1
              @page = 5 if @page > 5
              if @page != oldpage   # Move to next page
                pbSEPlay("GUI summary change page")
                @ribbonOffset = 0
                dorefresh = true
              end
            elsif Input.trigger?(Input::RIGHT) && !@pokemon.egg?
              oldpage = @page
              @page += 1
              @page = 1 if @page < 1
              @page = 5 if @page > 5
              if @page != oldpage   # Move to next page
                pbSEPlay("GUI summary change page")
                @ribbonOffset = 0
                dorefresh = true
              end
            end
            drawPage(@page) if dorefresh
          end
          return @partyindex
        end
      end 


      def drawInfoPageBase(bg_bitmap, extra_textpos)
        @sprites["itemicon"].item = @pokemon.item_id
        overlay = @sprites["overlay"].bitmap
        overlay.clear
        @sprites["background"].setBitmap(bg_bitmap)
        imagepos = []
        ballimage = sprintf("Graphics/UI/Summary/icon_ball_%s", @pokemon.poke_ball)
        imagepos.push([ballimage, BALL_IMAGE_X, BALL_IMAGE_Y])
        status = -1
        if @pokemon.fainted?
          status = GameData::Status.count - 1
        elsif @pokemon.status != :NONE
          status = GameData::Status.get(@pokemon.status).icon_position
        elsif @pokemon.pokerusStage == 1
          status = GameData::Status.count
        end
        imagepos.push(["Graphics/UI/statuses", IMG_STATUS_X, IMG_STATUS_Y, 0, 16 * status, 44, 16]) if status >= 0
        imagepos.push(["Graphics/UI/Summary/icon_pokerus", IMG_POKERUS_X, IMG_POKERUS_Y]) if @pokemon.pokerusStage == 2
        imagepos.push(["Graphics/UI/shiny", IMG_SHINY_X, IMG_SHINY_Y]) if @pokemon.shiny?
        pbDrawImagePositions(overlay, imagepos)
        base = Color.new(248, 248, 248)
        shadow = Color.new(176, 176, 176)
        shadow2 = Color.new(104, 104, 104)
        pbSetSystemFont(overlay)
        textpos = [
          [_INTL("INFORMACIÓN"), TEXT_PAGE_NAME_X, TEXT_PAGE_NAME_Y, :left, base, shadow2],
          [@pokemon.name, TEXT_NAME_X, TEXT_NAME_Y, :left, base, shadow2],
          [@pokemon.level.to_s, TEXT_LEVEL_X, TEXT_LEVEL_Y, :left, Color.new(64, 64, 64), Color.new(176, 176, 176)],
        ]
        textpos.concat(extra_textpos)
        textpos.push([_INTL("Objeto"), TEXT_ITEM_LABEL_X, TEXT_ITEM_LABEL_Y, :left, base, shadow2])
        if @pokemon.hasItem?
          textpos.push([@pokemon.item.name, TEXT_ITEM_NAME_X, TEXT_ITEM_NAME_Y, :left, Color.new(64, 64, 64), Color.new(176, 176, 176)])
        else
          textpos.push([_INTL("Ninguno"), TEXT_ITEM_NAME_X, TEXT_ITEM_NAME_Y, :left, Color.new(192, 200, 208), Color.new(208, 216, 224)])
        end
        if @pokemon.male?
          textpos.push([_INTL("♂"), TEXT_GENDER_X, TEXT_GENDER_Y, :left, Color.new(24, 146, 240), Color.new(13, 73, 119)])
        elsif @pokemon.female?
          textpos.push([_INTL("♀"), TEXT_GENDER_X, TEXT_GENDER_Y, :left, Color.new(249, 93, 210), Color.new(128, 20, 90)])
        end
        pbDrawTextPositions(overlay, textpos)
        drawMarkings(overlay, IMG_MARKINGS_X, IMG_MARKINGS_Y)
        return overlay, shadow
      end

      def waitForReturn(mui_page, legacy_page)
        loop do
          Graphics.update
          Input.update
          pbUpdate
          if Input.trigger?(Input::BACK) || Input.trigger?(Input::SPECIAL)
            Input.update
            drawPage(PluginManager.installed?("Modular UI Scenes") ? mui_page : legacy_page)
            break
          end
        end
      end

      def showAbilityDescription(pokemon)
        base = Color.new(248, 248, 248)
        shadow2 = Color.new(104, 104, 104)
        extra = [
          [_INTL("Habilidad:"), ABILITY_LABEL_X, ABILITY_LABEL_Y, :left, base, shadow2],
          [pokemon.ability.name, ABILITY_NAME_X, ABILITY_NAME_Y, :left, base, shadow2],
        ]
        overlay, shadow = drawInfoPageBase("Graphics/UI/Summary/bgability_extender", extra)
        drawTextEx(overlay, ABILITY_DESC_X, ABILITY_DESC_Y, ABILITY_DESC_WIDTH, ABILITY_DESC_HEIGHT,
                   pokemon.ability.description, Color.new(64, 64, 64), shadow)
        waitForReturn(:page_skills, 3)
      end

      def showShadowDescription(pokemon)
        base = Color.new(248, 248, 248)
        shadow2 = Color.new(104, 104, 104)
        extra = [
          [_INTL("Puerta del Corazón"), SHADOW_DESCRIPTION_X + 28, SHADOW_DESCRIPTION_Y, :left, base, shadow2],
        ]
        overlay, _shadow = drawInfoPageBase("Graphics/UI/Summary/bg_shadow", extra)
        black_text_tag = shadowc3tag(BLACK_TEXT_BASE, BLACK_TEXT_SHADOW)
        heartmessage = [_INTL("¡La puerta de su corazón está abierta! ¡Deshaz el bloqueo final!"),
                        _INTL("La puerta de su corazón está prácticamente abierta."),
                        _INTL("La puerta de su corazón está cerca de abrirse."),
                        _INTL("La puerta de su corazón se ha empezado a abrir."),
                        _INTL("La puerta de su corazón está empezando a abrirse."),
                        _INTL("La puerta de su corazón está fuertemente cerrada.")][@pokemon.heartStage]
        drawFormattedTextEx(overlay, SHADOW_HEART_TEXT_X, SHADOW_HEART_TEXT_Y, SHADOW_HEART_TEXT_WIDTH, black_text_tag + heartmessage)
        waitForReturn(:page_info, 1)
      end
end

class PokemonSummaryScreen
    def pbStartScreen(party, partyindex, page=1)
        @scene.pbStartScene(party, partyindex, @inbattle, page, @allow_learn_moves)
        ret = @scene.pbScene
        @scene.pbEndScene
        return ret
    end
end
