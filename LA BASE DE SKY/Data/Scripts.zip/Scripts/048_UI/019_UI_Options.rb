#===============================================================================
#
#===============================================================================
if !Settings::USE_NEW_OPTIONS_UI
  class PokemonSystem
    attr_accessor :textspeed
    attr_accessor :battlescene
    attr_accessor :battlestyle
    attr_accessor :sendtoboxes
    attr_accessor :givenicknames
    attr_accessor :frame
    attr_accessor :textskin
    attr_accessor :screensize
    attr_accessor :language
    attr_accessor :runstyle
    
    attr_reader   :skip_move_learning
    attr_reader   :main_volume
    attr_reader   :bgmvolume
    attr_reader   :sevolume
    attr_reader   :pokemon_cry_volume
    
    attr_accessor :textinput
    attr_accessor :vsync
    attr_accessor :autotile_animations

    def initialize
      @textspeed           = 2  # Text speed (0=slow, 1=medium, 2=fast, 3=instant)
      @battlescene         = 0  # Battle effects (animations) (0=on, 1=off)
      @battlestyle         = 0  # Battle style (0=switch, 1=set)
      @sendtoboxes         = 0  # Send to Boxes (0=manual, 1=automatic)
      @givenicknames       = 0  # Give nicknames (0=give, 1=don't give)
      @skip_move_learning  = 1  # Skip move learning (0=Sí, 1=No)
      @frame               = 0  # Default window frame (see also Settings::MENU_WINDOWSKINS)
      @textskin            = 0  # Speech frame
      @screensize          = Settings.screensize_index_from_screen_scale
      @language            = 0     # Language (see also Settings::LANGUAGES in script PokemonSystem)
      @runstyle            = 0     # Default movement speed (0=walk, 1=run)
      @main_volume         = 100   # Main volume control
      @bgmvolume           = 80    # Volume of background music and ME
      @sevolume            = 100   # Volume of sound effects
      @pokemon_cry_volume  = 100   # Volume of Pokémon cries
      @textinput           = 0     # Text input mode (0=cursor, 1=keyboard)
      @vsync               = vsync_initial_value?
      @autotile_animations = 0
    end

    def main_volume=(value)
      return if @main_volume == value #&& !@force_set_options
      @main_volume = value
      return if !$game_system
      if $game_system.playing_bgm
        playingBGM = $game_system.getPlayingBGM
        $game_system.bgm_pause
        $game_system.bgm_resume(playingBGM)
      end
      if $game_system.playing_bgs
        playingBGS = $game_system.getPlayingBGS
        $game_system.bgs_pause
        $game_system.bgs_resume(playingBGS)
      end
    end

    def vsync_config_path
      return File.join(Dir.pwd, "mkxp.json")
    end

    def vsync_initial_value?
      file_path = vsync_config_path
      return 1 if !File.exist?(file_path) || $joiplay
      file_content = File.read(file_path)
      clean_json_string = json_remove_comments(file_content)
      begin
        config = HTTPLite::JSON.parse(clean_json_string)
        return config["vsync"] == true ? 0 : 1
      rescue MKXPError, StandardError => e
        echoln "Error parsing JSON: #{e.message}"
        return 1
      end
    end

    def pbApplyVsyncToMkxpLines(lines, enable_vsync)
      vsync_str = enable_vsync ? "true" : "false"
      lines.map do |line|
        if line.match?(/^\s*"vsync"\s*:\s*(true|false)/)
          line.sub(/"vsync"\s*:\s*(true|false)/, "\"vsync\": #{vsync_str}")
        elsif line.match?(/^\s*"syncToRefreshrate"\s*:\s*(true|false)/)
          if enable_vsync
            line.sub(/"syncToRefreshrate"\s*:\s*(true|false),?/, "\"syncToRefreshrate\": true")
          else
            line.sub(/"syncToRefreshrate"\s*:\s*(true|false),?/, "\"syncToRefreshrate\": false,")
          end
        elsif enable_vsync && line.match?(/^\s*"fixedFramerate"\s*:\s*\d+/)
          line.sub(/^(\s*)("fixedFramerate")/, '\1//\2')
        elsif !enable_vsync && line.match?(/^\s*\/\/\s*"fixedFramerate"\s*:\s*\d+/)
          line.sub(/^(\s*)\/\/\s*/, '\1')
        else
          line
        end
      end
    end

    def pbRestartAfterVsyncChange
      if System.is_really_windows?
        Thread.new { system('start "" "Game.exe"') }
        sleep(0.1)
        return
      end
      if RUBY_PLATFORM =~ /darwin/i && File.directory?("Game.app")
        Thread.new { system('open -n "Game.app"') }
        sleep(0.1)
        return
      end
      exe = nil
      begin
        exe = File.readlink("/proc/self/exe") if File.exist?("/proc/self/exe")
      rescue
        exe = nil
      end
      if exe && !exe.empty? && File.exist?(exe)
        Thread.new { system("nohup \"#{exe}\" \"#{Dir.pwd}\" >/dev/null 2>&1 &") }
        sleep(0.1)
        return
      end
      ["./mkxp-z", "./Game", "mkxp-z"].each do |candidate|
        next if !File.exist?(candidate)
        Thread.new { system("cd \"#{Dir.pwd}\" && nohup \"#{candidate}\" >/dev/null 2>&1 &") }
        sleep(0.1)
        return
      end
      pbMessage(_INTL("No se pudo reiniciar automáticamente.\nCierra y abre el juego manualmente."))
    end

    def update_vsync(vsync_value)
      file_path = vsync_config_path
      return true if !File.exist?(file_path) || $joiplay
      message = $player ? _INTL("Cambiar el valor del vsync requiere reiniciar el juego.\nPodrás guardar antes de reiniciar.\n¿Deseas reiniciar ahora?") : _INTL("Cambiar el valor del vsync requiere reiniciar el juego.\n¿Deseas reiniciar ahora?")
      return false unless Kernel.pbConfirmMessageSerious(message)
      enable_vsync = (vsync_value != 1)
      lines = File.readlines(file_path)
      updated_lines = pbApplyVsyncToMkxpLines(lines, enable_vsync)
      File.open(file_path, "w") { |file| file.puts(updated_lines) }
      pbSaveScreen if $player
      pbRestartAfterVsyncChange
      Kernel.exit!
      true
    end
  end
end

#===============================================================================
#
#===============================================================================
module PropertyMixin
  attr_reader :name

  def get
    return @get_proc&.call
  end

  def set(*args)
    @set_proc&.call(*args)
  end
end

#===============================================================================
#
#===============================================================================
class EnumOption
  include PropertyMixin
  attr_reader :values

  def initialize(name, values, get_proc, set_proc)
    @name     = name
    values = values.call if values.is_a?(Proc)
    values = [] if values.nil?
    values = [values] unless values.is_a?(Array)
    @values   = values.map { |val| _INTL(val) }
    @get_proc = get_proc
    @set_proc = set_proc
  end

  def next(current)
    index = current + 1
    index = @values.length - 1 if index > @values.length - 1
    return index
  end

  def prev(current)
    index = current - 1
    index = 0 if index < 0
    return index
  end
end

#===============================================================================
#
#===============================================================================
class ArrowOption < EnumOption
end

#===============================================================================
#
#===============================================================================
class NumberOption
  include PropertyMixin
  attr_reader :lowest_value
  attr_reader :highest_value

  def initialize(name, range, get_proc, set_proc)
    @name = name
    case range
    when Range
      @lowest_value  = range.begin
      @highest_value = range.end
    when Array
      @lowest_value  = range[0]
      @highest_value = range[1]
    end
    @get_proc = get_proc
    @set_proc = set_proc
  end

  def next(current)
    index = current + @lowest_value
    index += 1
    index = @lowest_value if index > @highest_value
    return index - @lowest_value
  end

  def prev(current)
    index = current + @lowest_value
    index -= 1
    index = @highest_value if index < @lowest_value
    return index - @lowest_value
  end
end

#===============================================================================
#
#===============================================================================
class SliderOption
  include PropertyMixin
  attr_reader :lowest_value
  attr_reader :highest_value

  def initialize(name, range, get_proc, set_proc)
    @name          = name
    @lowest_value  = range[0]
    @highest_value = range[1]
    @interval      = range[2]
    @get_proc      = get_proc
    @set_proc      = set_proc
  end

  def next(current)
    index = current + @lowest_value
    index += @interval
    index = @highest_value if index > @highest_value
    return index - @lowest_value
  end

  def prev(current)
    index = current + @lowest_value
    index -= @interval
    index = @lowest_value if index < @lowest_value
    return index - @lowest_value
  end
end

class ButtonOption
  include PropertyMixin

  def initialize(name, values, get_proc, set_proc)
    @name = name
    @values = [_INTL("")]
    @get_proc = get_proc
    @set_proc = set_proc
  end

  def values
    return @values
  end

  def next(current)
    return current
  end

  def prev(current)
    return current
  end

  def action(scene)
    @set_proc.call(0, scene)
  end

  def set(value, scene)
    # Do nothing when the value is changed
  end
end

if !Settings::USE_NEW_OPTIONS_UI
  #===============================================================================
  # Main options list
  #===============================================================================
  class Window_PokemonOption < Window_DrawableCommand
    attr_reader :value_changed

    SEL_NAME_BASE_COLOR    = Color.new(192, 120, 0)
    SEL_NAME_SHADOW_COLOR  = Color.new(248, 176, 80)
    SEL_VALUE_BASE_COLOR   = Color.new(248, 48, 24)
    SEL_VALUE_SHADOW_COLOR = Color.new(248, 136, 128)

    # Porcentaje del ancho del rect usado para el nombre de la opción (9/20)
    OPTION_NAME_WIDTH_RATIO = 9.0 / 20.0
    # Multiplicador para desplazar X en opciones numéricas (rect.x * MULTIPLIER)
    NUMBER_X_OFFSET_MULTIPLIER = 2
    # Parámetros del deslizador: desplazamientos y tamaño de la barra/knob
    SLIDER_BAR_Y_OFFSET   = -2
    SLIDER_BAR_HEIGHT     = 4
    SLIDER_KNOB_WIDTH     = 8
    SLIDER_KNOB_HEIGHT    = 16
    SLIDER_KNOB_Y_OFFSET  = -8

    def initialize(options, x, y, width, height, is_sub_menu = false)
      @options = options
      @values = []
      @options.length.times { |i| @values[i] = 0 }
      @value_changed = false
      @is_sub_menu = is_sub_menu
      @left_arrow_bmp = Bitmap.new("Graphics/UI/left_arrow") rescue nil
      @right_arrow_bmp = Bitmap.new("Graphics/UI/right_arrow") rescue nil
      super(x, y, width, height)
    end

    def dispose
      @left_arrow_bmp&.dispose
      @right_arrow_bmp&.dispose
      super
    end

    def [](i)
      return @values[i]
    end

    def []=(i, value)
      @values[i] = value
      refresh
    end

    def setValueNoRefresh(i, value)
      @values[i] = value
    end

    def itemCount
      return @options.length + 1
    end

    def drawItem(index, _count, rect)
      rect = drawCursor(index, rect)
      sel_index = self.index
      # Draw option's name
      optionname = (index == @options.length) ? (@is_sub_menu ? _INTL("Volver") : _INTL("Cerrar")) : @options[index].name
      optionwidth = rect.width * OPTION_NAME_WIDTH_RATIO
      pbDrawShadowText(self.contents, rect.x, rect.y, optionwidth, rect.height, optionname,
                      (index == sel_index) ? SEL_NAME_BASE_COLOR : self.baseColor,
                      (index == sel_index) ? SEL_NAME_SHADOW_COLOR : self.shadowColor)
      return if index == @options.length
      # Draw option's values
      case @options[index]
      when ArrowOption
        value_text = @options[index].values[self[index]]
        x_start = rect.x + optionwidth
        width_area = rect.width - x_start
        center_x = x_start + (width_area / 2)
        
        pbDrawShadowText(self.contents, x_start, rect.y, width_area, rect.height, value_text,
                         (index == sel_index) ? SEL_VALUE_BASE_COLOR : self.baseColor,
                         (index == sel_index) ? SEL_VALUE_SHADOW_COLOR : self.shadowColor,
                         1)

        if index == sel_index
          total_frames = 8
          current_frame = (System.uptime * 10).to_i % total_frames
          arrow_padding = 70
          
          current_val_index = self[index]
          max_val_index = @options[index].values.length - 1
          
          if @right_arrow_bmp && current_val_index < max_val_index
            frame_height = @right_arrow_bmp.height / total_frames
            frame_width  = @right_arrow_bmp.width
            src_rect = Rect.new(0, current_frame * frame_height, frame_width, frame_height)
            y_pos = rect.y + (rect.height - frame_height) / 2
            self.contents.blt(center_x + arrow_padding, y_pos, @right_arrow_bmp, src_rect)
          end
          
          if @left_arrow_bmp && current_val_index > 0
            frame_height = @left_arrow_bmp.height / total_frames
            frame_width  = @left_arrow_bmp.width
            src_rect = Rect.new(0, current_frame * frame_height, frame_width, frame_height)
            y_pos = rect.y + (rect.height - frame_height) / 2
            self.contents.blt(center_x - arrow_padding - frame_width, y_pos, @left_arrow_bmp, src_rect)
          end
        end
      when EnumOption
        if @options[index].values.length > 1
          totalwidth = 0
          @options[index].values.each do |value|
            totalwidth += self.contents.text_size(value).width
          end
          spacing = (rect.width - rect.x - optionwidth - totalwidth) / (@options[index].values.length - 1)
          spacing = 0 if spacing < 0
          xpos = optionwidth + rect.x
          ivalue = 0
          @options[index].values.each do |value|
            pbDrawShadowText(self.contents, xpos, rect.y, optionwidth, rect.height, value,
                            (ivalue == self[index]) ? SEL_VALUE_BASE_COLOR : self.baseColor,
                            (ivalue == self[index]) ? SEL_VALUE_SHADOW_COLOR : self.shadowColor)
            xpos += self.contents.text_size(value).width
            xpos += spacing
            ivalue += 1
          end
        else
          pbDrawShadowText(self.contents, rect.x + optionwidth, rect.y, optionwidth, rect.height,
                          optionname, self.baseColor, self.shadowColor)
        end
      when NumberOption
        value = _INTL("Tipo {1}/{2}", @options[index].lowest_value + self[index],
                      @options[index].highest_value - @options[index].lowest_value + 1)
        xpos = optionwidth + (rect.x * NUMBER_X_OFFSET_MULTIPLIER)
        pbDrawShadowText(self.contents, xpos, rect.y, optionwidth, rect.height, value,
                        SEL_VALUE_BASE_COLOR, SEL_VALUE_SHADOW_COLOR, 1)
      when SliderOption
        value = sprintf(" %d", @options[index].highest_value)
        sliderlength = rect.width - rect.x - optionwidth - self.contents.text_size(value).width
        xpos = optionwidth + rect.x
        self.contents.fill_rect(xpos, rect.y + SLIDER_BAR_Y_OFFSET + (rect.height / 2), sliderlength, SLIDER_BAR_HEIGHT, self.baseColor)
        self.contents.fill_rect(
          xpos + ((sliderlength - SLIDER_KNOB_WIDTH) * (@options[index].lowest_value + self[index]) / @options[index].highest_value),
          rect.y + SLIDER_KNOB_Y_OFFSET + (rect.height / 2),
          SLIDER_KNOB_WIDTH, SLIDER_KNOB_HEIGHT, SEL_VALUE_BASE_COLOR
        )
        value = (@options[index].lowest_value + self[index]).to_s
        xpos += (rect.width - rect.x - optionwidth) - self.contents.text_size(value).width
        pbDrawShadowText(self.contents, xpos, rect.y, optionwidth, rect.height, value,
                        SEL_VALUE_BASE_COLOR, SEL_VALUE_SHADOW_COLOR)
      else
        value = @options[index].values[self[index]]
        xpos = optionwidth + rect.x
        pbDrawShadowText(self.contents, xpos, rect.y, optionwidth, rect.height, value,
                        SEL_VALUE_BASE_COLOR, SEL_VALUE_SHADOW_COLOR)
      end
    end

    def update
      oldindex = self.index
      @value_changed = false
      super
      dorefresh = (self.index != oldindex)
      if self.active && self.index < @options.length
        if @options[self.index].is_a?(ButtonOption)
          if Input.trigger?(Input::USE)
            self[self.index] = @options[self.index].prev(self[self.index])
            dorefresh = true
            @value_changed = true
          end
        else
          if Input.repeat?(Input::LEFT)
            self[self.index] = @options[self.index].prev(self[self.index])
            dorefresh = true
            @value_changed = true
            
          elsif Input.repeat?(Input::RIGHT)
            self[self.index] = @options[self.index].next(self[self.index])
            dorefresh = true
            @value_changed = true
          end
        end
      end
      if self.index >= 0 && self.index < @options.length && @options[self.index].is_a?(ArrowOption)
        dorefresh = true
      end
      refresh if dorefresh
    end
  end

  #===============================================================================
  # Options main screen
  #===============================================================================
  class PokemonOption_Scene
    attr_reader :sprites
    attr_reader :in_load_screen

    def pbStartScene(in_load_screen = false, options_menu = :options_menu, is_sub_menu = false)
      @in_load_screen = in_load_screen
      @is_sub_menu = is_sub_menu
      # Get all options
      @options = []
      @hashes = []
      $PokemonSystem.vsync = $PokemonSystem.vsync_initial_value?
      MenuHandlers.each_available(options_menu) do |option, hash, name|
        @options.push(
          hash["type"].new(name, hash["parameters"], hash["get_proc"], hash["set_proc"])
        )
        @hashes.push(hash)
      end
      # Create sprites
      @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
      @viewport.z = 99999
      @sprites = {}
      addBackgroundOrColoredPlane(@sprites, "bg", "optionsbg", Color.new(192, 200, 208), @viewport)
      @sprites["title"] = Window_UnformattedTextPokemon.newWithSize(
        _INTL("Opciones"), 0, -16, Graphics.width, 64, @viewport
      )
      @sprites["title"].back_opacity = 0
      @sprites["textbox"] = pbCreateMessageWindow
      pbSetSystemFont(@sprites["textbox"].contents)
      @sprites["option"] = Window_PokemonOption.new(
        @options, 0, @sprites["title"].y + @sprites["title"].height - 16, Graphics.width,
        Graphics.height - (@sprites["title"].y + @sprites["title"].height - 16) - @sprites["textbox"].height,
        @is_sub_menu
      )
      @sprites["option"].viewport = @viewport
      @sprites["option"].visible  = true
      # Get the values of each option
      @options.length.times { |i| @sprites["option"].setValueNoRefresh(i, @options[i].get || 0) }
      @sprites["option"].refresh
      pbChangeSelection
      pbDeactivateWindows(@sprites)
      pbFadeInAndShow(@sprites) { pbUpdate }
    end

    def pbChangeSelection
      hash = @hashes[@sprites["option"].index]
      # Call selected option's "on_select" proc (if defined)
      @sprites["textbox"].letterbyletter = false
      hash["on_select"]&.call(self) if hash
      # Set descriptive text
      description = ""
      if hash
        if hash["description"].is_a?(Proc)
          description = hash["description"].call
        elsif !hash["description"].nil?
          description = _INTL(hash["description"])
        end
      else
        description = _INTL("Cierra el menú de opciones.")
      end
      @sprites["textbox"].text = description
    end

    def pbOptions
      pbActivateWindow(@sprites, "option") do
        index = -1
        submenu_open = false
        @close_sub_menu = false
        loop do
          Graphics.update
          Input.update
          pbUpdate
          if @close_sub_menu
            break
          end
          if @sprites["option"].index != index && !submenu_open
            pbChangeSelection
            index = @sprites["option"].index
          end
          if !submenu_open
            if @options[index].is_a?(ButtonOption)
              # Do nothing
            else
              @options[index].set(@sprites["option"][index], self) if @sprites["option"].value_changed
              if (Input.trigger?(Input::USE) && @sprites["option"].index == @options.length)
                break
              end
            end
            if Input.trigger?(Input::BACK) && !submenu_open
              break
            elsif Input.trigger?(Input::USE) && @options[index].is_a?(ButtonOption) && !submenu_open
              submenu_open = true
              pbPlayDecisionSE
              @options[index].instance_variable_get(:@set_proc).call(0, self)
              submenu_open = false
            end
          end
        end
      end
    end

    def pbCloseSubMenu
      @close_sub_menu = true
    end

    def pbEndScene
      pbPlayCloseMenuSE
      pbFadeOutAndHide(@sprites) { pbUpdate }
      # Set the values of each option, to make sure they're all set
      @options.length.times do |i|
        @options[i].set(@sprites["option"][i], self)
      end
      pbDisposeMessageWindow(@sprites["textbox"])
      pbDisposeSpriteHash(@sprites)
      pbUpdateSceneMap
      @viewport.dispose
    end

    def pbUpdate
      pbUpdateSpriteHash(@sprites)
    end
  end

  #===============================================================================
  #
  #===============================================================================
  class PokemonOptionScreen
    def initialize(scene)
      @scene = scene
    end

    def pbStartScreen(in_load_screen = false, options_menu = :options_menu)
      @scene.pbStartScene(in_load_screen, options_menu)
      @scene.pbOptions
      @scene.pbEndScene
    end
  end

  #===============================================================================
  # Options Menu commands
  #===============================================================================
  # MenuHandlers.add(:options_menu, :main_volume, {
  #   "name"        => _INTL("Volumen General"),
  #   "order"       => 9,
  #   "type"        => SliderOption,
  #   "parameters"  => [0, 100, 5],   # [minimum_value, maximum_value, interval]
  #   "description" => _INTL("Ajusta el volumen de todo el audio en el juego."),
  #   "get_proc"    => proc { next $PokemonSystem.main_volume },
  #   "set_proc"    => proc { |value, screen| $PokemonSystem.main_volume = value }
  # })


  MenuHandlers.add(:options_menu, :bgm_volume, {
    "name"        => _INTL("Volumen Música"),
    "order"       => 10,
    "type"        => SliderOption,
    "parameters"  => [0, 100, 5],   # [minimum_value, maximum_value, interval]
    "description" => _INTL("Ajusta el volumen de la música de fondo."),
    "get_proc"    => proc { next $PokemonSystem.bgmvolume },
    "set_proc"    => proc { |value, scene|
      next if $PokemonSystem.bgmvolume == value
      $PokemonSystem.bgmvolume = value
      next if scene.in_load_screen || $game_system.playing_bgm.nil?
      playingBGM = $game_system.getPlayingBGM
      $game_system.bgm_pause
      $game_system.bgm_resume(playingBGM)
    }
  })

  MenuHandlers.add(:options_menu, :se_volume, {
    "name"        => _INTL("Volumen Efectos"),
    "order"       => 20,
    "type"        => SliderOption,
    "parameters"  => [0, 100, 5],   # [minimum_value, maximum_value, interval]
    "description" => _INTL("Ajusta el volumen de los efectos de sonido."),
    "get_proc"    => proc { next $PokemonSystem.sevolume },
    "set_proc"    => proc { |value, _scene|
      next if $PokemonSystem.sevolume == value
      $PokemonSystem.sevolume = value
      if $game_system.playing_bgs
        $game_system.playing_bgs.volume = value
        playingBGS = $game_system.getPlayingBGS
        $game_system.bgs_pause
        $game_system.bgs_resume(playingBGS)
      end
      pbPlayCursorSE
    }
  })

  MenuHandlers.add(:options_menu, :pokemon_cry_volume, {
    "name"        => _INTL("Volumen Gritos Pkmn"),
    "order"       => 21,
    "type"        => SliderOption,
    "parameters"  => [0, 100, 5],   # [minimum_value, maximum_value, interval]
    "description" => _INTL("Ajusta el volumen de los gritos de los Pokémon."),
    "get_proc"    => proc { next $PokemonSystem.pokemon_cry_volume },
    "set_proc"    => proc { |value, _scene|
      next if $PokemonSystem.pokemon_cry_volume == value
      $PokemonSystem.pokemon_cry_volume = value
      pbPlayCursorSE
    }
  })

  MenuHandlers.add(:options_menu, :text_speed, {
    "name"        => _INTL("Velocidad de texto"),
    "order"       => 30,
    "type"        => EnumOption,
    "parameters"  => [_INTL("Len"), _INTL("Med"), _INTL("Ráp"), _INTL("Inst")],
    "description" => _INTL("Elige la velocidad a la que aparece el texto."),
    "on_select"   => proc { |scene| scene.sprites["textbox"].letterbyletter = true },
    "get_proc"    => proc { next $PokemonSystem.textspeed },
    "set_proc"    => proc { |value, scene|
      next if value == $PokemonSystem.textspeed
      $PokemonSystem.textspeed = value
      MessageConfig.pbSetTextSpeed(MessageConfig.pbSettingToTextSpeed(value))
      # Display the message with the selected text speed to gauge it better.
      scene.sprites["textbox"].textspeed      = MessageConfig.pbGetTextSpeed
      scene.sprites["textbox"].letterbyletter = true
      scene.sprites["textbox"].text           = scene.sprites["textbox"].text
    }
  })

  MenuHandlers.add(:options_menu, :battle_animations, {
    "name"        => _INTL("Efectos Batalla"),
    "order"       => 40,
    "type"        => EnumOption,
    "parameters"  => [_INTL("Sí"), _INTL("No")],
    "description" => _INTL("Elige si quieres ver las animaciones de ataques en combate."),
    "get_proc"    => proc { next $PokemonSystem.battlescene },
    "set_proc"    => proc { |value, _scene| $PokemonSystem.battlescene = value }
  })

  MenuHandlers.add(:options_menu, :battle_style, {
    "name"        => _INTL("Estilo de Combate."),
    "order"       => 50,
    "type"        => EnumOption,
    "parameters"  => [_INTL("Cambio"), _INTL("Fijo")],
    "description" => _INTL("Elige si puedes cambiar de Pokémon al derrotar un Pokémon rival."),
    "get_proc"    => proc { next $PokemonSystem.battlestyle },
    "set_proc"    => proc { |value, _scene| $PokemonSystem.battlestyle = value }
  })

  MenuHandlers.add(:options_menu, :movement_style, {
    "name"        => _INTL("Movimiento Predt."),
    "order"       => 60,
    "type"        => EnumOption,
    "parameters"  => [_INTL("Andar"), _INTL("Correr")],
    "description" => _INTL("Elige la velocidad de movimiento. Pulsa el botón al moverte para elegir la otra."),
    "condition"   => proc { next $player&.has_running_shoes },
    "get_proc"    => proc { next $PokemonSystem.runstyle },
    "set_proc"    => proc { |value, _scene| $PokemonSystem.runstyle = value }
  })

  MenuHandlers.add(:options_menu, :send_to_boxes, {
    "name"        => _INTL("Enviar al PC"),
    "order"       => 70,
    "type"        => EnumOption,
    "parameters"  => [_INTL("Manual"), _INTL("Automático")],
    "description" => _INTL("Elige si tus Pokémon se mandan al PC cuando tu equipo está lleno."),
    "condition"   => proc { next Settings::NEW_CAPTURE_CAN_REPLACE_PARTY_MEMBER },
    "get_proc"    => proc { next $PokemonSystem.sendtoboxes },
    "set_proc"    => proc { |value, _scene| $PokemonSystem.sendtoboxes = value }
  })

  MenuHandlers.add(:options_menu, :give_nicknames, {
    "name"        => _INTL("Poner Motes"),
    "order"       => 80,
    "type"        => EnumOption,
    "parameters"  => [_INTL("Sí"), _INTL("No")],
    "description" => _INTL("Elige si quieres que te pregunte qué mote ponerle a un Pokémon al conseguirlo."),
    "get_proc"    => proc { next $PokemonSystem.givenicknames },
    "set_proc"    => proc { |value, _scene| $PokemonSystem.givenicknames = value }
  })

  MenuHandlers.add(:options_menu, :skip_move_learning, {
    "page"        => :gameplay,
    "name"        => _INTL("Saltar aprender Movs."),
    "order"       => 81,
    "type"        => EnumOption,
    "parameters"  => [_INTL("Sí"), _INTL("No")],
    "description" => _INTL("Elige si quieres saltarte el aprendizaje de movimientos al subir de nivel.\nPuedes aprenderlos más tarde desde el recordador de movimientos."),
    "condition"   => proc { next Settings::ALLOW_SKIPPING_MOVE_LEARNING },
    "get_proc"    => proc { next $PokemonSystem.skip_move_learning },
    "set_proc"    => proc { |value, _screen| $PokemonSystem.skip_move_learning = value }
  })

  MenuHandlers.add(:options_menu, :speech_frame, {
    "name"        => _INTL("Marco de Texto"),
    "order"       => 90,
    "type"        => NumberOption,
    "parameters"  => 1..Settings::SPEECH_WINDOWSKINS.length,
    "description" => _INTL("Elige la apariencia de las cajas de diálogos."),
    "get_proc"    => proc { next $PokemonSystem.textskin },
    "set_proc"    => proc { |value, scene|
      $PokemonSystem.textskin = value
      MessageConfig.pbSetSpeechFrame("Graphics/Windowskins/" + Settings::SPEECH_WINDOWSKINS[value])
      # Change the windowskin of the options text box to selected one
      scene.sprites["textbox"].setSkin(MessageConfig.pbGetSpeechFrame)
    }
  })

  MenuHandlers.add(:options_menu, :menu_frame, {
    "name"        => _INTL("Marco de Menú"),
    "order"       => 100,
    "type"        => NumberOption,
    "parameters"  => 1..Settings::MENU_WINDOWSKINS.length,
    "description" => _INTL("Elige la apariencia de los mensajes de menús."),
    "get_proc"    => proc { next $PokemonSystem.frame },
    "set_proc"    => proc { |value, scene|
      $PokemonSystem.frame = value
      MessageConfig.pbSetSystemFrame("Graphics/Windowskins/" + Settings::MENU_WINDOWSKINS[value])
      # Change the windowskin of the options text box to selected one
      scene.sprites["option"].setSkin(MessageConfig.pbGetSystemFrame)
    }
  })

  MenuHandlers.add(:options_menu, :text_input_style, {
    "name"        => _INTL("Entrada de Texto"),
    "order"       => 110,
    "type"        => EnumOption,
    "parameters"  => [_INTL("Teclado"), _INTL("Cursor")],
    "description" => _INTL("Elige cómo quieres introducir el texto."),
    "get_proc"    => proc { next $PokemonSystem.textinput },
    "set_proc"    => proc { |value, _scene| $PokemonSystem.textinput = value }
  })

  MenuHandlers.add(:options_menu, :screen_size, {
    "name"        => _INTL("Tamaño Pantalla"),
    "order"       => 120,
    "type"        => ArrowOption,
    "condition"   => proc { next !$joiplay },
    "parameters"  => proc { [_INTL("Pequeña"), _INTL("Mediana"), _INTL("Grande"), _INTL("Extra Grande"), _INTL("Completa")] },
    "description" => _INTL("Elige el tamaño de la ventana de juego."),
    "get_proc"    => proc { next [$PokemonSystem.screensize, 4].min },
    "set_proc"    => proc { |value, _scene|
      next if $PokemonSystem.screensize == value
      $PokemonSystem.screensize = value
      pbSetResizeFactor($PokemonSystem.screensize)
    }
  })

  MenuHandlers.add(:options_menu, :vsync, {
    "name"        => _INTL("VSync"),
    "order"       => 130,
    "type"        => EnumOption,
    "parameters"  => [_INTL("Sí"), _INTL("No")],
    "condition"   => proc { next !$joiplay },
    "description" => _INTL("Si el juego va muy rápido desactiva el VSync.\nRequiere reiniciar el juego"),
    "get_proc"    => proc { next $PokemonSystem.vsync },
    "set_proc"    => proc { |value, _scene|
      next if $PokemonSystem.vsync == value
      old_value = $PokemonSystem.vsync
      $PokemonSystem.vsync = value
      $PokemonSystem.vsync = old_value unless $PokemonSystem.update_vsync(value)
    }
  })

  MenuHandlers.add(:options_menu, :autotile_animations, {
    "name"        => _INTL("Anim. de mapas"),
    "order"       => 140,
    "type"        => EnumOption,
    "parameters"  => [_INTL("Sí"), _INTL("No")],
    "description" => _INTL("Activa o desactiva las animaciones de los mapas."),
    "get_proc"    => proc { next $PokemonSystem.autotile_animations || 0 },
    "set_proc"    => proc { |value, _scene| 
      $PokemonSystem.autotile_animations = value
    }
  })
end