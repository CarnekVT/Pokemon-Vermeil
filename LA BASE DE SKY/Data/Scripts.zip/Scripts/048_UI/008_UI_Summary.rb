#===============================================================================
#
#===============================================================================
class MoveSelectionSprite < Sprite
  attr_reader :preselected
  attr_reader :index

  # Constantes de posicionamiento del cursor de movimientos
  CURSOR_BASE_X       = 240
  CURSOR_BASE_Y       = 92
  CURSOR_OFFSET_Y     = 64
  FIFTH_MOVE_OFFSET_Y = -76
  FIFTH_MOVE_GAP      = 20

  def initialize(viewport = nil, fifthmove = false)
    super(viewport)
    @movesel = AnimatedBitmap.new("Graphics/UI/Summary/cursor_move")
    @frame = 0
    @index = 0
    @fifthmove = fifthmove
    @preselected = false
    @updating = false
    refresh
  end

  def dispose
    @movesel.dispose
    super
  end

  def index=(value)
    @index = value
    refresh
  end

  def preselected=(value)
    @preselected = value
    refresh
  end

  def refresh
    w = @movesel.width
    h = @movesel.height / 2
    self.x = CURSOR_BASE_X
    self.y = CURSOR_BASE_Y + (self.index * CURSOR_OFFSET_Y)
    self.y += FIFTH_MOVE_OFFSET_Y if @fifthmove
    self.y += FIFTH_MOVE_GAP if @fifthmove && self.index == Pokemon::MAX_MOVES
    self.bitmap = @movesel.bitmap
    if self.preselected
      self.src_rect.set(0, h, w, h)
    else
      self.src_rect.set(0, 0, w, h)
    end
  end

  def update
    @updating = true
    super
    @movesel.update
    @updating = false
    refresh
  end
end

#===============================================================================
#
#===============================================================================
class RibbonSelectionSprite < MoveSelectionSprite

  # Constantes de posicionamiento del cursor de cintas
  CURSOR_BASE_X   = 228
  CURSOR_BASE_Y   = 76
  CURSOR_OFFSET_X = 68
  CURSOR_OFFSET_Y = 68
  COLUMNS_PER_ROW = 4

  def initialize(viewport = nil)
    super(viewport)
    @movesel = AnimatedBitmap.new("Graphics/UI/Summary/cursor_ribbon")
    @frame = 0
    @index = 0
    @preselected = false
    @updating = false
    @spriteVisible = true
    refresh
  end

  def visible=(value)
    super
    @spriteVisible = value if !@updating
  end

  def refresh
    return unless Settings::GREY_OUT_FAINTED
    w = @movesel.width
    h = @movesel.height / 2
    self.x = CURSOR_BASE_X + ((self.index % COLUMNS_PER_ROW) * CURSOR_OFFSET_X)
    self.y = CURSOR_BASE_Y + ((self.index / COLUMNS_PER_ROW).floor * CURSOR_OFFSET_Y)
    self.bitmap = @movesel.bitmap
    if self.preselected
      self.src_rect.set(0, h, w, h)
    else
      self.src_rect.set(0, 0, w, h)
    end
  end

  def update
    @updating = true
    super
    self.visible = @spriteVisible && @index >= 0 && @index < 12
    @movesel.update
    @updating = false
    refresh
  end
end

#===============================================================================
#
#===============================================================================
class PokemonSummary_Scene
  
  # --- CONSTANTES GENERALES DE UI ---

  # Tamaño para mostrar el spritesheet de las marcars
  MARK_WIDTH  = 16
  MARK_HEIGHT = 16
  
  # --- Posiciones de elementos ---
  UI_POKEMON_SPRITE_X = 104
  UI_POKEMON_SPRITE_Y = 206
  UI_POKEICON_X       = 46
  UI_POKEICON_Y       = 92
  UI_ITEMICON_X       = 30
  UI_ITEMICON_Y       = 320
  UI_UP_ARROW_X       = 350
  UI_UP_ARROW_Y       = 56
  UI_DOWN_ARROW_X     = 350
  UI_DOWN_ARROW_Y     = 260

  # Better Summary
  UI_MARKING_BG_X     = 260  
  UI_MARKING_BG_Y     = 88
  
  # --- Posiciones de texto ---
  TEXT_PAGE_NAME_X    = 26
  TEXT_PAGE_NAME_Y    = 22
  TEXT_NAME_X         = 40
  TEXT_NAME_Y         = 68
  TEXT_LEVEL_X        = 46
  TEXT_LEVEL_Y        = 98
  TEXT_ITEM_LABEL_X   = 66
  TEXT_ITEM_LABEL_Y   = 324
  TEXT_ITEM_NAME_X    = 16
  TEXT_ITEM_NAME_Y    = 358
  TEXT_GENDER_X       = 178
  TEXT_GENDER_Y       = 68
  SHADOW_DESCRIPTION_X_MUI = 234
  SHADOW_DESCRIPTION_Y_MUI = 308
  SHADOW_DESCRIPTION_W_MUI = 264
  SHADOW_DESCRIPTION_X_OFFSET = 10
  SHADOW_DESCRIPTION_Y_OFFSET = -10
  SHADOW_DESCRIPTION_H = 2

  # Modular UI Scenes
  EGG_DATE_X          = 232
  EGG_DATE_Y          = 86
  EGG_TEXT_X          = 232
  EGG_TEXT_Y          = 118
  EGG_MEMO_WIDTH      = 268
  
  # --- Imágenes ---
  IMG_BALL_X          = 8
  IMG_BALL_Y          = 60
  IMG_STATUS_X        = 124
  IMG_STATUS_Y        = 100
  IMG_POKERUS_X       = 176
  IMG_POKERUS_Y       = 100
  IMG_SHINY_X         = 174
  IMG_SHINY_Y         = 100
  IMG_MARKINGS_X      = 84
  IMG_MARKINGS_Y      = 292

  # --- Página: Información ---
  P1_DEX_LABEL_X      = 238
  P1_DEX_LABEL_Y      = 86
  P1_SPECIES_LABEL_X  = 238
  P1_SPECIES_LABEL_Y  = 118
  P1_SPECIES_TEXT_X   = 433
  P1_SPECIES_TEXT_Y   = 118
  P1_TYPE_LABEL_X     = 238
  P1_TYPE_LABEL_Y     = 150
  P1_OT_LABEL_X       = 238
  P1_OT_LABEL_Y       = 182
  P1_ID_LABEL_X       = 238
  P1_ID_LABEL_Y       = 214
  P1_DEX_NUM_X        = 433
  P1_DEX_NUM_Y        = 86
  P1_OT_NAME_X        = 433
  P1_OT_NAME_Y        = 182
  P1_ID_NUM_X         = 433
  P1_ID_NUM_Y         = 214
  P1_EXP_LABEL_X      = 238
  P1_EXP_LABEL_Y      = 246
  P1_EXP_NUM_X        = 488
  P1_EXP_NUM_Y        = 278
  P1_NEXTLV_LABEL_X   = 238
  P1_NEXTLV_LABEL_Y   = 310
  P1_NEXTLV_NUM_X     = 488
  P1_NEXTLV_NUM_Y     = 342
  P1_TYPE_ICON_Y      = 146
  P1_TYPE_1_ICON_X    = 402
  P1_TYPE_2_ICON_X    = 368
  P1_EXP_BAR_X        = 362
  P1_EXP_BAR_Y        = 372

  # --- Página: Notas de Entrenador ---
  P2_MEMO_X           = 232
  P2_MEMO_Y           = 86
  P2_MEMO_WIDTH       = 268

  # --- Página: Estadísticas ---
  P3_HP_LABEL_X       = 292
  P3_HP_LABEL_Y       = 82
  P3_HP_NUM_X         = 462
  P3_HP_NUM_Y         = 82
  P3_STAT_LABEL_X     = 248
  P3_STAT_NUM_X       = 456
  P3_ATTACK_Y         = 126
  P3_DEFENSE_Y        = 158
  P3_SPATK_Y          = 190
  P3_SPDEF_Y          = 222
  P3_SPEED_Y          = 254
  P3_ABILITY_LABEL_X  = 224
  P3_ABILITY_LABEL_Y  = 290
  P3_ABILITY_NAME_X   = 330
  P3_ABILITY_NAME_Y   = 290
  P3_ABILITY_DESC_X   = 228
  P3_ABILITY_DESC_Y   = 338
  P3_ABILITY_DESC_W   = 282
  P3_HP_BAR_X         = 360
  P3_HP_BAR_Y         = 110

  # Enhanced Pokemon UI
  # Hoja Brillante / Corona
  SHINY_CROWN_OFFSET_X   = -18
  SHINY_CROWN_OFFSET_Y   = -3
  SHINY_LEAF_SPACING_X   = 10  
  SHINY_LEAF_SPACING_Y   = 10
  SHINY_LEAF_X           = 182
  SHINY_LEAF_Y           = 124 
  SHINY_LEAF_BW_X        = -18
  SHINY_LEAF_BW_Y        = 114 

  # Medidor de Felicidad
  HAPPY_METER_WIDTH_MAX   = 254.0 
  HAPPY_METER_X           = 242
  HAPPY_METER_Y           = 340

  # Calificación de IVs (Estrellas)
  IV_RATING_ICON_SIZE     = 16
  IV_RATING_SPACING_X     = 16
  IV_RATING_SPACING_Y     = 32
  IV_RATINGS_X            = 465
  IV_RATINGS_Y            = 83
  IV_RATINGS_BW_X         = 110
  IV_RATINGS_BW_Y         = 83
  
  # Espacio extra después de la estadística de HP
  IV_RATING_HP_GAP_STD    = 12
  IV_RATING_HP_GAP_BW     = 18

  # --- Página: Movimientos ---
  P4_MOVE_LIST_Y        = 104
  P4_MOVE_OFFSET_Y      = 64
  P4_TYPE_ICON_X        = 248
  P4_TYPE_ICON_OFFSET_Y = -4
  P4_MOVE_NAME_X        = 316
  P4_PP_LABEL_X         = 342
  P4_PP_LABEL_OFFSET_Y  = 32
  P4_PP_NUM_X           = 460
  P4_PP_NUM_OFFSET_Y    = 32
  
  # Página Movimientos (Selección/Detalle)
  P4_SEL_CATEGORY_LABEL_X = 20
  P4_SEL_CATEGORY_LABEL_Y = 128
  P4_SEL_POWER_LABEL_X    = 20
  P4_SEL_POWER_LABEL_Y    = 160
  P4_SEL_ACCURACY_LABEL_X = 20
  P4_SEL_ACCURACY_LABEL_Y = 192
  P4_SEL_VAL_X            = 216
  P4_SEL_VAL_POWER_Y      = 160
  P4_SEL_VAL_ACCURACY_Y   = 192
  P4_SEL_CAT_ICON_X       = 166
  P4_SEL_CAT_ICON_Y       = 124
  P4_SEL_DESC_X           = 4
  P4_SEL_DESC_Y           = 224
  P4_SEL_DESC_WIDTH       = 230
  P4_SEL_TYPE_Y           = 78

  # Better Move Summary
  P4_LEARN_DATA_LABEL_X   = 92
  P4_LEARN_DATA_LABEL_Y   = 81
  P4_LEARN_BOX_X          = 85
  P4_LEARN_BOX_Y          = 76
  P4_LEARN_ACTION_KEY_X   = 165
  P4_LEARN_ACTION_KEY_Y   = 79

  # --- Página: CINTAS ---
  P5_RIBBON_COUNT_LABEL_X = 234
  P5_RIBBON_COUNT_LABEL_Y = 338
  P5_RIBBON_COUNT_NUM_X   = 450
  P5_RIBBON_COUNT_NUM_Y   = 338
  P5_RIBBON_LIST_X        = 230
  P5_RIBBON_LIST_Y        = 78
  P5_RIBBON_OFFSET_X      = 68
  P5_RIBBON_OFFSET_Y      = 68
  
  # Página Cintas (Selección)
  P5_SEL_BG_X             = 8
  P5_SEL_BG_Y             = 280
  P5_SEL_NAME_X           = 18
  P5_SEL_NAME_Y           = 292
  P5_SEL_DESC_X           = 18
  P5_SEL_DESC_Y           = 324
  P5_SEL_DESC_WIDTH       = 480

  # Colores
  RED_TEXT_BASE     = Color.new(248, 56, 32)
  RED_TEXT_SHADOW   = Color.new(224, 152, 144)
  BLACK_TEXT_BASE   = Color.new(64, 64, 64)
  BLACK_TEXT_SHADOW = Color.new(176, 176, 176)

  def pbUpdate
    pbUpdateSpriteHash(@sprites)
  end

  def gray_out_fainted_pokemon(sprite_name)
    return unless Settings::GREY_OUT_FAINTED
    @sprites[sprite_name].make_grey_if_fainted = @pokemon.fainted?
    pbUpdate
  end

  def pbStartScene(party, partyindex, inbattle = false, page=1, allow_learn_moves = true)
    @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @viewport.z = 99999
    @party      = party
    @partyindex = partyindex
    @pokemon    = @party[@partyindex]
    @inbattle   = inbattle
    @allow_learn_moves = allow_learn_moves
    @page = page
    @typebitmap    = AnimatedBitmap.new(_INTL("Graphics/UI/types"))
    @markingbitmap = AnimatedBitmap.new("Graphics/UI/Summary/markings")
    @sprites = {}
    @sprites["background"] = IconSprite.new(0, 0, @viewport)
    @sprites["pokemon"] = PokemonSprite.new(@viewport)
    gray_out_fainted_pokemon("pokemon")
    @sprites["pokemon"].setOffset(PictureOrigin::CENTER)
    @sprites["pokemon"].x = UI_POKEMON_SPRITE_X
    @sprites["pokemon"].y = UI_POKEMON_SPRITE_Y
    @sprites["pokemon"].setPokemonBitmap(@pokemon)
    @sprites["pokeicon"] = PokemonIconSprite.new(@pokemon, @viewport)
    @sprites["pokeicon"].setOffset(PictureOrigin::CENTER)
    gray_out_fainted_pokemon("pokeicon")
    @sprites["pokeicon"].x       = UI_POKEICON_X
    @sprites["pokeicon"].y       = UI_POKEICON_Y
    @sprites["pokeicon"].visible = false
    @sprites["itemicon"] = ItemIconSprite.new(UI_ITEMICON_X, UI_ITEMICON_Y, @pokemon.item_id, @viewport)
    @sprites["itemicon"].blankzero = true
    @sprites["overlay"] = BitmapSprite.new(Graphics.width, Graphics.height, @viewport)
    pbSetSystemFont(@sprites["overlay"].bitmap)
    @sprites["movepresel"] = MoveSelectionSprite.new(@viewport)
    @sprites["movepresel"].visible     = false
    @sprites["movepresel"].preselected = true
    @sprites["movesel"] = MoveSelectionSprite.new(@viewport)
    @sprites["movesel"].visible = false
    @sprites["ribbonpresel"] = RibbonSelectionSprite.new(@viewport)
    @sprites["ribbonpresel"].visible     = false
    @sprites["ribbonpresel"].preselected = true
    @sprites["ribbonsel"] = RibbonSelectionSprite.new(@viewport)
    @sprites["ribbonsel"].visible = false
    @sprites["uparrow"] = AnimatedSprite.new("Graphics/UI/up_arrow", 8, 28, 40, 2, @viewport)
    @sprites["uparrow"].x = UI_UP_ARROW_X
    @sprites["uparrow"].y = UI_UP_ARROW_Y
    @sprites["uparrow"].play
    @sprites["uparrow"].visible = false
    @sprites["downarrow"] = AnimatedSprite.new("Graphics/UI/down_arrow", 8, 28, 40, 2, @viewport)
    @sprites["downarrow"].x = UI_DOWN_ARROW_X
    @sprites["downarrow"].y = UI_DOWN_ARROW_Y
    @sprites["downarrow"].play
    @sprites["downarrow"].visible = false
    @sprites["markingbg"] = IconSprite.new(UI_MARKING_BG_X, UI_MARKING_BG_Y, @viewport)
    @sprites["markingbg"].setBitmap("Graphics/UI/Summary/overlay_marking")
    @sprites["markingbg"].visible = false
    @sprites["markingoverlay"] = BitmapSprite.new(Graphics.width, Graphics.height, @viewport)
    @sprites["markingoverlay"].visible = false
    pbSetSystemFont(@sprites["markingoverlay"].bitmap)
    @sprites["markingsel"] = IconSprite.new(0, 0, @viewport)
    @sprites["markingsel"].setBitmap("Graphics/UI/Summary/cursor_marking")
    @sprites["markingsel"].src_rect.height = @sprites["markingsel"].bitmap.height / 2
    @sprites["markingsel"].visible = false
    @sprites["messagebox"] = Window_AdvancedTextPokemon.new("")
    @sprites["messagebox"].viewport       = @viewport
    @sprites["messagebox"].visible        = false
    @sprites["messagebox"].letterbyletter = true
    pbBottomLeftLines(@sprites["messagebox"], 2)
    @nationalDexList = [:NONE]
    GameData::Species.each_species { |s| @nationalDexList.push(s.species) }
    drawPage(@page)
    pbFadeInAndShow(@sprites) { pbUpdate }
  end

  def pbStartForgetScene(party, partyindex, move_to_learn)
    @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @viewport.z = 99999
    @party      = party
    @partyindex = partyindex
    @pokemon    = @party[@partyindex]
    @page = 4
    @typebitmap = AnimatedBitmap.new(_INTL("Graphics/UI/types"))
    @sprites = {}
    @sprites["background"] = IconSprite.new(0, 0, @viewport)
    @sprites["overlay"] = BitmapSprite.new(Graphics.width, Graphics.height, @viewport)
    pbSetSystemFont(@sprites["overlay"].bitmap)
    @sprites["pokeicon"] = PokemonIconSprite.new(@pokemon, @viewport)
    @sprites["pokeicon"].setOffset(PictureOrigin::CENTER)
    gray_out_fainted_pokemon("pokeicon")
    @sprites["pokeicon"].x       = UI_POKEICON_X
    @sprites["pokeicon"].y       = UI_POKEICON_Y
    @sprites["movesel"] = MoveSelectionSprite.new(@viewport, !move_to_learn.nil?)
    @sprites["movesel"].visible = false
    @sprites["movesel"].visible = true
    @sprites["movesel"].index   = 0
    new_move = (move_to_learn) ? Pokemon::Move.new(move_to_learn) : nil
    drawSelectedMove(new_move, @pokemon.moves[0])
    pbFadeInAndShow(@sprites)
  end

  def pbEndScene
    pbFadeOutAndHide(@sprites) { pbUpdate }
    pbDisposeSpriteHash(@sprites)
    @typebitmap.dispose
    @markingbitmap&.dispose
    @viewport.dispose
  end

  def pbDisplay(text)
    @sprites["messagebox"].text = text
    @sprites["messagebox"].visible = true
    pbPlayDecisionSE
    loop do
      Graphics.update
      Input.update
      pbUpdate
      if @sprites["messagebox"].busy?
        if Input.trigger?(Input::USE)
          pbPlayDecisionSE if @sprites["messagebox"].pausing?
          @sprites["messagebox"].resume
        end
      elsif Input.trigger?(Input::USE) || Input.trigger?(Input::BACK)
        break
      end
    end
    @sprites["messagebox"].visible = false
  end

  def pbConfirm(text)
    ret = -1
    @sprites["messagebox"].text    = text
    @sprites["messagebox"].visible = true
    using(cmdwindow = Window_CommandPokemon.new([_INTL("Sí"), _INTL("No")])) do
      cmdwindow.z       = @viewport.z + 1
      cmdwindow.visible = false
      pbBottomRight(cmdwindow)
      cmdwindow.y -= @sprites["messagebox"].height
      loop do
        Graphics.update
        Input.update
        cmdwindow.visible = true if !@sprites["messagebox"].busy?
        cmdwindow.update
        pbUpdate
        if !@sprites["messagebox"].busy?
          if Input.trigger?(Input::BACK)
            ret = false
            break
          elsif Input.trigger?(Input::USE) && @sprites["messagebox"].resume
            ret = (cmdwindow.index == 0)
            break
          end
        end
      end
    end
    @sprites["messagebox"].visible = false
    return ret
  end

  def pbShowCommands(commands, index = 0)
    ret = -1
    using(cmdwindow = Window_CommandPokemon.new(commands)) do
      cmdwindow.z = @viewport.z + 1
      cmdwindow.index = index
      pbBottomRight(cmdwindow)
      loop do
        Graphics.update
        Input.update
        cmdwindow.update
        pbUpdate
        if Input.trigger?(Input::BACK)
          pbPlayCancelSE
          ret = -1
          break
        elsif Input.trigger?(Input::USE)
          pbPlayDecisionSE
          ret = cmdwindow.index
          break
        end
      end
    end
    return ret
  end

  def drawMarkings(bitmap, x, y)
    mark_variants = @markingbitmap.bitmap.height / MARK_HEIGHT
    markings = @pokemon.markings
    markrect = Rect.new(0, 0, MARK_WIDTH, MARK_HEIGHT)
    (@markingbitmap.bitmap.width / MARK_WIDTH).times do |i|
      markrect.x = i * MARK_WIDTH
      markrect.y = [(markings[i] || 0), mark_variants - 1].min * MARK_HEIGHT
      bitmap.blt(x + (i * MARK_WIDTH), y, @markingbitmap.bitmap, markrect)
    end
  end

  def drawPage(page)
    if @pokemon.egg?
      drawPageOneEgg
      return
    end
    @sprites["pokemon"].setPokemonBitmap(@pokemon)
    gray_out_fainted_pokemon("pokemon")
    @sprites["pokeicon"].pokemon = @pokemon
    gray_out_fainted_pokemon("pokeicon")
    @sprites["itemicon"].item = @pokemon.item_id
    overlay = @sprites["overlay"].bitmap
    overlay.clear
    base   = Color.new(248, 248, 248)
    shadow = Color.new(104, 104, 104)
    # Set background image
    @sprites["background"].setBitmap("Graphics/UI/Summary/bg_#{page}")
    imagepos = []
    # Show the Poké Ball containing the Pokémon
    ballimage = sprintf("Graphics/UI/Summary/icon_ball_%s", @pokemon.poke_ball)
    imagepos.push([ballimage, IMG_BALL_X, IMG_BALL_Y])
    # Show status/fainted/Pokérus infected icon
    status = -1
    if @pokemon.fainted?
      status = GameData::Status.count - 1
    elsif @pokemon.status != :NONE
      status = GameData::Status.get(@pokemon.status).icon_position
    elsif @pokemon.pokerusStage == 1
      status = GameData::Status.count
    end
    if status >= 0
      imagepos.push([_INTL("Graphics/UI/statuses"), IMG_STATUS_X, IMG_STATUS_Y, 0, 16 * status, 44, 16])
    end
    # Show Pokérus cured icon
    if @pokemon.pokerusStage == 2
      imagepos.push(["Graphics/UI/Summary/icon_pokerus", IMG_POKERUS_X, IMG_POKERUS_Y])
    end
    # Show shininess star
    imagepos.push(["Graphics/UI/shiny", IMG_SHINY_X, IMG_SHINY_Y]) if @pokemon.shiny?
    # Draw all images
    pbDrawImagePositions(overlay, imagepos)
    # Write various bits of text
    pagename = [_INTL("INFORMACIÓN"),
                _INTL("NOTAS ENTREN."),
                _INTL("ESTADÍSTICAS"),
                _INTL("MOVIMIENTOS"),
                _INTL("CINTAS")][page - 1]
    textpos = [
      [pagename, TEXT_PAGE_NAME_X, TEXT_PAGE_NAME_Y, :left, base, shadow],
      [@pokemon.name, TEXT_NAME_X, TEXT_NAME_Y, :left, base, shadow],
      [@pokemon.level.to_s, TEXT_LEVEL_X, TEXT_LEVEL_Y, :left, Color.new(64, 64, 64), Color.new(176, 176, 176)],
      [_INTL("Objeto"), TEXT_ITEM_LABEL_X, TEXT_ITEM_LABEL_Y, :left, base, shadow]
    ]
    # Write the held item's name
    if @pokemon.hasItem?
      textpos.push([@pokemon.item.name, TEXT_ITEM_NAME_X, TEXT_ITEM_NAME_Y, :left, Color.new(64, 64, 64), Color.new(176, 176, 176)])
    else
      textpos.push([_INTL("Ninguno"), TEXT_ITEM_NAME_X, TEXT_ITEM_NAME_Y, :left, Color.new(192, 200, 208), Color.new(208, 216, 224)])
    end
    # Write the gender symbol
    if @pokemon.male?
      textpos.push([_INTL("♂"), TEXT_GENDER_X, TEXT_GENDER_Y, :left, Color.new(24, 146, 240), Color.new(13, 73, 119)])
    elsif @pokemon.female?
      textpos.push([_INTL("♀"), TEXT_GENDER_X, TEXT_GENDER_Y, :left, Color.new(249, 93, 210), Color.new(128, 20, 90)])
    end
    # Draw all text
    pbDrawTextPositions(overlay, textpos)
    # Draw the Pokémon's markings
    drawMarkings(overlay, IMG_MARKINGS_X, IMG_MARKINGS_Y)
    # Draw page-specific information
    case page
    when 1 then drawPageOne
    when 2 then drawPageTwo
    when 3 then drawPageThree
    when 4 then drawPageFour
    when 5 then drawPageFive
    end
  end

  def drawPageOne
    overlay = @sprites["overlay"].bitmap
    base   = Color.new(248, 248, 248)
    shadow = Color.new(104, 104, 104)
    dexNumBase   = (@pokemon.shiny?) ? Color.new(248, 56, 32) : Color.new(64, 64, 64)
    dexNumShadow = (@pokemon.shiny?) ? Color.new(224, 152, 144) : Color.new(176, 176, 176)
    # If a Shadow Pokémon, draw the heart gauge area and bar
    if @pokemon.shadowPokemon?
      shadowfract = @pokemon.heart_gauge.to_f / @pokemon.max_gauge_size
      imagepos = [
        ["Graphics/UI/Summary/overlay_shadow", 224, 240],
        ["Graphics/UI/Summary/overlay_shadowbar", 242, 280, 0, 0, (shadowfract * 248).floor, -1]
      ]
      pbDrawImagePositions(overlay, imagepos)
    end
    # Write various bits of text
    textpos = [
      [_INTL("No. Dex"), P1_DEX_LABEL_X, P1_DEX_LABEL_Y, :left, base, shadow],
      [_INTL("Especie"), P1_SPECIES_LABEL_X, P1_SPECIES_LABEL_Y, :left, base, shadow],
      [@pokemon.speciesName, P1_SPECIES_TEXT_X, P1_SPECIES_TEXT_Y, :center, Color.new(64, 64, 64), Color.new(176, 176, 176)],
      [_INTL("Tipo"), P1_TYPE_LABEL_X, P1_TYPE_LABEL_Y, :left, base, shadow],
      [_INTL("EO"), P1_OT_LABEL_X, P1_OT_LABEL_Y, :left, base, shadow],
      [_INTL("No. ID"), P1_ID_LABEL_X, P1_ID_LABEL_Y, :left, base, shadow]
    ]
    # Write the Regional/National Dex number
    dexnum = 0
    dexnumshift = false
    if $player.pokedex.unlocked?(-1)   # National Dex is unlocked
      dexnum = @nationalDexList.index(@pokemon.species_data.species) || 0
      dexnumshift = true if Settings::DEXES_WITH_OFFSETS.include?(-1)
    else
      ($player.pokedex.dexes_count - 1).times do |i|
        next if !$player.pokedex.unlocked?(i)
        num = pbGetRegionalNumber(i, @pokemon.species)
        break if num <= 0
        dexnum = num
        dexnumshift = true if Settings::DEXES_WITH_OFFSETS.include?(i)
        break
      end
    end
    if dexnum <= 0
      textpos.push(["???", P1_DEX_NUM_X, P1_DEX_NUM_Y, :center, dexNumBase, dexNumShadow])
    else
      dexnum -= 1 if dexnumshift
      textpos.push([sprintf("%03d", dexnum), P1_DEX_NUM_X, P1_DEX_NUM_Y, :center, dexNumBase, dexNumShadow])
    end
    # Write Original Trainer's name and ID number
    if @pokemon.owner.name.empty?
      textpos.push([_INTL("PRESTADO"), P1_OT_NAME_X, P1_OT_NAME_Y, :center, Color.new(64, 64, 64), Color.new(176, 176, 176)])
      textpos.push(["?????", P1_ID_NUM_X, P1_ID_NUM_Y, :center, Color.new(64, 64, 64), Color.new(176, 176, 176)])
    else
      ownerbase   = Color.new(64, 64, 64)
      ownershadow = Color.new(176, 176, 176)
      case @pokemon.owner.gender
      when 0
        ownerbase = Color.new(24, 112, 216)
        ownershadow = Color.new(136, 168, 208)
      when 1
        ownerbase = Color.new(248, 56, 32)
        ownershadow = Color.new(224, 152, 144)
      end
      textpos.push([@pokemon.owner.name, P1_OT_NAME_X, P1_OT_NAME_Y, :center, ownerbase, ownershadow])
      textpos.push([sprintf("%05d", @pokemon.owner.public_id), P1_ID_NUM_X, P1_ID_NUM_Y, :center,
                    Color.new(64, 64, 64), Color.new(176, 176, 176)])
    end
    # Write Exp text OR heart gauge message (if a Shadow Pokémon)
    if @pokemon.shadowPokemon?
      textpos.push([_INTL("Puerta del Corazón"), P1_EXP_LABEL_X, P1_EXP_LABEL_Y, :left, base, shadow])
      if !PluginManager.installed?("Modular UI Scenes")
        black_text_tag = shadowc3tag(BLACK_TEXT_BASE, BLACK_TEXT_SHADOW)
        heartmessage = [_INTL("¡La puerta de su corazón está abierta! ¡Deshaz el bloqueo final!"),
                        _INTL("La puerta de su corazón está prácticamente abierta."),
                        _INTL("La puerta de su corazón está cerca de abrirse."),
                        _INTL("La puerta de su corazón se ha empezado a abrir."),
                        _INTL("La puerta de su corazón está empezando a abrirse."),
                        _INTL("La puerta de su corazón está fuertemente cerrada.")][@pokemon.heartStage]
        memo = black_text_tag + heartmessage
        drawFormattedTextEx(overlay, SHADOW_DESCRIPTION_X, SHADOW_DESCRIPTION_Y, SHADOW_DESCRIPTION_W, memo)
      else
        drawTextEx(overlay, P3_ABILITY_DESC_X + SHADOW_DESCRIPTION_X_OFFSET, P3_ABILITY_DESC_Y + SHADOW_DESCRIPTION_Y_OFFSET, P3_ABILITY_DESC_W, SHADOW_DESCRIPTION_H, _INTL("[{1}]: Información", KeybindingReader.key_name(:SPECIAL)), Color.new(64, 64, 64), Color.new(176, 176, 176))
      end
    else
      endexp = @pokemon.growth_rate.minimum_exp_for_level(@pokemon.level + 1)
      textpos.push([_INTL("Puntos Exp."), P1_EXP_LABEL_X, P1_EXP_LABEL_Y, :left, base, shadow])
      textpos.push([@pokemon.exp.to_s_formatted, P1_EXP_NUM_X, P1_EXP_NUM_Y, :right, Color.new(64, 64, 64), Color.new(176, 176, 176)])
      textpos.push([_INTL("Siguiente Nv."), P1_NEXTLV_LABEL_X, P1_NEXTLV_LABEL_Y, :left, base, shadow])
      textpos.push([(endexp - @pokemon.exp).to_s_formatted, P1_NEXTLV_NUM_X, P1_NEXTLV_NUM_Y, :right, Color.new(64, 64, 64), Color.new(176, 176, 176)])
    end
    # Draw all text
    pbDrawTextPositions(overlay, textpos)
    # Draw Pokémon type(s)
    @pokemon.types.each_with_index do |type, i|
      type_number = GameData::Type.get(type).icon_position
      type_rect = Rect.new(0, type_number * GameData::Type::ICON_SIZE[1], GameData::Type::ICON_SIZE[0], GameData::Type::ICON_SIZE[1])
      type_x = (@pokemon.types.length == 1) ? P1_TYPE_1_ICON_X : P1_TYPE_2_ICON_X + (66 * i)
      overlay.blt(type_x, P1_TYPE_ICON_Y, @typebitmap.bitmap, type_rect)
    end
    # Draw Exp bar
    if @pokemon.level < GameData::GrowthRate.max_level
      w = @pokemon.exp_fraction * 128
      w = ((w / 2).round) * 2
      pbDrawImagePositions(overlay,
                           [["Graphics/UI/Summary/overlay_exp", P1_EXP_BAR_X, P1_EXP_BAR_Y, 0, 0, w, 6]])
    end
  end

  def drawPageOneEgg
    @sprites["itemicon"].item = @pokemon.item_id
    overlay = @sprites["overlay"].bitmap
    overlay.clear
    base   = Color.new(248, 248, 248)
    shadow = Color.new(104, 104, 104)
    # Set background image
    @sprites["background"].setBitmap("Graphics/UI/Summary/bg_egg")
    imagepos = []
    # Show the Poké Ball containing the Pokémon
    ballimage = sprintf("Graphics/UI/Summary/icon_ball_%s", @pokemon.poke_ball)
    imagepos.push([ballimage, IMG_BALL_X, IMG_BALL_Y])
    # Draw all images
    pbDrawImagePositions(overlay, imagepos)
    # Write various bits of text
    textpos = [
      [_INTL("INFORMACIÓN"), TEXT_PAGE_NAME_X, TEXT_PAGE_NAME_Y, :left, base, shadow],
      [@pokemon.name, TEXT_NAME_X, TEXT_NAME_Y, :left, base, shadow],
      [_INTL("Objeto"), TEXT_ITEM_LABEL_X, TEXT_ITEM_LABEL_Y, :left, base, shadow]
    ]
    # Write the held item's name
    if @pokemon.hasItem?
      textpos.push([@pokemon.item.name, TEXT_ITEM_NAME_X, TEXT_ITEM_NAME_Y, :left, Color.new(64, 64, 64), Color.new(176, 176, 176)])
    else
      textpos.push([_INTL("Ninguno"), TEXT_ITEM_NAME_X, TEXT_ITEM_NAME_Y, :left, Color.new(192, 200, 208), Color.new(208, 216, 224)])
    end
    # Draw all text
    pbDrawTextPositions(overlay, textpos)
    red_text_tag = shadowc3tag(RED_TEXT_BASE, RED_TEXT_SHADOW)
    black_text_tag = shadowc3tag(BLACK_TEXT_BASE, BLACK_TEXT_SHADOW)
    memo = ""
    # Write date received
    if @pokemon.timeReceived
      date  = @pokemon.timeReceived.day
      month = pbGetMonthName(@pokemon.timeReceived.mon)
      year  = @pokemon.timeReceived.year
      memo += black_text_tag + _INTL("{1} {2}, {3}", date, month, year) + "\n"
    end
    # Write map name egg was received on
    mapname = pbGetMapNameFromId(@pokemon.obtain_map)
    mapname = @pokemon.obtain_text if @pokemon.obtain_text && !@pokemon.obtain_text.empty?
    if mapname && mapname != ""
      mapname = red_text_tag + mapname + black_text_tag
      memo += black_text_tag + _INTL("Un misterioso Huevo Pokémon entregado por {1}.", mapname) + "\n"
    else
      memo += black_text_tag + _INTL("Un misterioso Huevo Pokémon.") + "\n"
    end
    memo += "\n"   # Empty line
    # Write Egg Watch blurb
    memo += black_text_tag + _INTL("\"Estado del Huevo\"") + "\n"
    eggstate = _INTL("Parece que a este Huevo le tomará mucho tiempo abrirse.")
    eggstate = _INTL("¿Qué saldrá? Aún le queda para abrirse.") if @pokemon.steps_to_hatch < 10_200
    eggstate = _INTL("A veces se mueve. Debería abrirse pronto.") if @pokemon.steps_to_hatch < 2550
    eggstate = _INTL("Está haciendo ruidos. ¡Está a punto de abrirse!") if @pokemon.steps_to_hatch < 1275
    memo += black_text_tag + eggstate
    # Draw all text
    drawFormattedTextEx(overlay, EGG_TEXT_X, EGG_TEXT_Y, EGG_TEXT_WIDTH, memo)
    # Draw the Pokémon's markings
    drawMarkings(overlay, IMG_MARKINGS_X, IMG_MARKINGS_Y)
  end

  def drawPageTwo
    overlay = @sprites["overlay"].bitmap
    red_text_tag = shadowc3tag(RED_TEXT_BASE, RED_TEXT_SHADOW)
    black_text_tag = shadowc3tag(BLACK_TEXT_BASE, BLACK_TEXT_SHADOW)
    memo = ""
    # Write nature
    showNature = !@pokemon.shadowPokemon? || @pokemon.heartStage <= 3
    if showNature
      nature_name = red_text_tag + @pokemon.nature.name + black_text_tag
      memo += _INTL("Naturaleza {1}.", nature_name) + "\n"
    end
    # Write date received
    if @pokemon.timeReceived
      date  = @pokemon.timeReceived.day
      month = pbGetMonthName(@pokemon.timeReceived.mon)
      year  = @pokemon.timeReceived.year
      memo += black_text_tag + _INTL("{1} {2}, {3}", date, month, year) + "\n"
    end
    # Write map name Pokémon was received on
    mapname = pbGetMapNameFromId(@pokemon.obtain_map)
    mapname = @pokemon.obtain_text if @pokemon.obtain_text && !@pokemon.obtain_text.empty?
    mapname = _INTL("Lugar lejano") if nil_or_empty?(mapname)
    memo += red_text_tag + mapname + "\n"
    # Write how Pokémon was obtained
    mettext = [
      _INTL("Encontrado con Nv. {1}.", @pokemon.obtain_level),
      _INTL("Huevo recibido."),
      _INTL("Intercambiado al Nv. {1}.", @pokemon.obtain_level),
      "",
      _INTL("Conocido en un Encuentro Fatídico al Nv. {1}.", @pokemon.obtain_level)
    ][@pokemon.obtain_method]
    memo += black_text_tag + mettext + "\n" if mettext && mettext != ""
    # If Pokémon was hatched, write when and where it hatched
    if @pokemon.obtain_method == 1
      if @pokemon.timeEggHatched
        date  = @pokemon.timeEggHatched.day
        month = pbGetMonthName(@pokemon.timeEggHatched.mon)
        year  = @pokemon.timeEggHatched.year
        memo += black_text_tag + _INTL("{1} {2}, {3}", date, month, year) + "\n"
      end
      mapname = pbGetMapNameFromId(@pokemon.hatched_map)
      mapname = _INTL("Lugar lejano") if nil_or_empty?(mapname)
      memo += red_text_tag + mapname + "\n"
      memo += black_text_tag + _INTL("Huevo eclosionado.") + "\n"
    else
      memo += "\n"   # Empty line
    end
    # Write characteristic
    if showNature
      best_stat = nil
      best_iv = 0
      stats_order = [:HP, :ATTACK, :DEFENSE, :SPEED, :SPECIAL_ATTACK, :SPECIAL_DEFENSE]
      start_point = @pokemon.personalID % stats_order.length   # Tiebreaker
      stats_order.length.times do |i|
        stat = stats_order[(i + start_point) % stats_order.length]
        if !best_stat || @pokemon.iv[stat] > @pokemon.iv[best_stat]
          best_stat = stat
          best_iv = @pokemon.iv[best_stat]
        end
      end
      characteristics = {
        :HP              => [_INTL("Le encanta comer."),
                             _INTL("A menudo se duerme."),
                             _INTL("Suele desordenar cosas."),
                             _INTL("A veces se enfada."),
                             _INTL("Le gusta relajarse.")],
        :ATTACK          => [_INTL("Orgulloso de su fuerza."),
                             _INTL("Le gusta revolverse."),
                             _INTL("Un poco cabezota."),
                             _INTL("Le gusta luchar."),
                             _INTL("Tiene mal genio.")],
        :DEFENSE         => [_INTL("Cuerpo resistente."),
                             _INTL("Es buen fajador."),
                             _INTL("Muy persistente."),
                             _INTL("Muy resistente."),
                             _INTL("Muy perseverante.")],
        :SPECIAL_ATTACK  => [_INTL("Extremadamente curioso."),
                             _INTL("Le gusta hacer travesuras."),
                             _INTL("Muy astuto."),
                             _INTL("A menudo está en Babia."),
                             _INTL("Muy quisquilloso.")],
        :SPECIAL_DEFENSE => [_INTL("Voluntarioso."),
                             _INTL("Es algo orgulloso."),
                             _INTL("Muy insolente."),
                             _INTL("Odia perder."),
                             _INTL("Un poco cabezota.")],
        :SPEED           => [_INTL("Le gusta correr."),
                             _INTL("Siempre tiene el oído alerta."),
                             _INTL("Impetuoso y bobo."),
                             _INTL("Es un poco payaso."),
                             _INTL("Huye rápido.")]
      }
      memo += black_text_tag + characteristics[best_stat][best_iv % 5] + "\n"
    end
    # Write all text
    drawFormattedTextEx(overlay, P2_MEMO_X, P2_MEMO_Y, P2_MEMO_WIDTH, memo)
  end

  def drawPageThree
    overlay = @sprites["overlay"].bitmap
    base   = Color.new(248, 248, 248)
    shadow = Color.new(104, 104, 104)
    # Determine which stats are boosted and lowered by the Pokémon's nature
    statshadows = {}
    GameData::Stat.each_main { |s| statshadows[s.id] = shadow }
    if !@pokemon.shadowPokemon? || @pokemon.heartStage <= 3
      @pokemon.nature_for_stats.stat_changes.each do |change|
        statshadows[change[0]] = Color.new(136, 96, 72) if change[1] > 0
        statshadows[change[0]] = Color.new(64, 120, 152) if change[1] < 0
      end
    end
    # Write various bits of text
    textpos = [
      [_INTL("PS"), P3_HP_LABEL_X, P3_HP_LABEL_Y, :center, base, statshadows[:HP]],
      [sprintf("%d/%d", @pokemon.hp, @pokemon.totalhp), P3_HP_NUM_X, P3_HP_NUM_Y, :right, Color.new(64, 64, 64), Color.new(176, 176, 176)],
      [_INTL("Ataque"), P3_STAT_LABEL_X, P3_ATTACK_Y, :left, base, statshadows[:ATTACK]],
      [@pokemon.attack.to_s, P3_STAT_NUM_X, P3_ATTACK_Y, :right, Color.new(64, 64, 64), Color.new(176, 176, 176)],
      [_INTL("Defensa"), P3_STAT_LABEL_X, P3_DEFENSE_Y, :left, base, statshadows[:DEFENSE]],
      [@pokemon.defense.to_s, P3_STAT_NUM_X, P3_DEFENSE_Y, :right, Color.new(64, 64, 64), Color.new(176, 176, 176)],
      [_INTL("At. Esp."), P3_STAT_LABEL_X, P3_SPATK_Y, :left, base, statshadows[:SPECIAL_ATTACK]],
      [@pokemon.spatk.to_s, P3_STAT_NUM_X, P3_SPATK_Y, :right, Color.new(64, 64, 64), Color.new(176, 176, 176)],
      [_INTL("Def. Esp."), P3_STAT_LABEL_X, P3_SPDEF_Y, :left, base, statshadows[:SPECIAL_DEFENSE]],
      [@pokemon.spdef.to_s, P3_STAT_NUM_X, P3_SPDEF_Y, :right, Color.new(64, 64, 64), Color.new(176, 176, 176)],
      [_INTL("Velocidad"), P3_STAT_LABEL_X, P3_SPEED_Y, :left, base, statshadows[:SPEED]],
      [@pokemon.speed.to_s, P3_STAT_NUM_X, P3_SPEED_Y, :right, Color.new(64, 64, 64), Color.new(176, 176, 176)],
      [_INTL("Habilidad"), P3_ABILITY_LABEL_X, P3_ABILITY_LABEL_Y, :left, base, shadow]
    ]
    # Draw ability name and description
    ability = @pokemon.ability
    if ability
      textpos.push([ability.name, P3_ABILITY_NAME_X, P3_ABILITY_NAME_Y, :left, Color.new(64, 64, 64), Color.new(176, 176, 176)])
      drawTextEx(overlay, P3_ABILITY_DESC_X, P3_ABILITY_DESC_Y, P3_ABILITY_DESC_W, 2, _INTL("[{1}]: Descripción", KeybindingReader.key_name(:SPECIAL)), Color.new(64, 64, 64), Color.new(176, 176, 176))
    end
    # Draw all text
    pbDrawTextPositions(overlay, textpos)
    # Draw HP bar
    if @pokemon.hp > 0
      w = @pokemon.hp * 96 / @pokemon.totalhp.to_f
      w = 1 if w < 1
      w = ((w / 2).round) * 2
      color_index, next_color_index, blend_alpha = pbHPBarZoneInfo(@pokemon.hp, @pokemon.totalhp, 4)
      if blend_alpha > 0 && color_index != next_color_index
        hp_bmp = AnimatedBitmap.new("Graphics/UI/Summary/overlay_hp")
        overlay.blt(P3_HP_BAR_X, P3_HP_BAR_Y, hp_bmp.bitmap, Rect.new(0, color_index * 6, w, 6))
        overlay.blt(P3_HP_BAR_X, P3_HP_BAR_Y, hp_bmp.bitmap, Rect.new(0, next_color_index * 6, w, 6), blend_alpha)
        hp_bmp.dispose
      else
        imagepos = [
          ["Graphics/UI/Summary/overlay_hp", P3_HP_BAR_X, P3_HP_BAR_Y, 0, color_index * 6, w, 6]
        ]
        pbDrawImagePositions(overlay, imagepos)
      end
    end
  end

  def drawPageFour
    overlay = @sprites["overlay"].bitmap
    moveBase   = Color.new(64, 64, 64)
    moveShadow = Color.new(176, 176, 176)
    ppBase   = [moveBase,                # More than 1/2 of total PP
                Color.new(248, 192, 0),    # 1/2 of total PP or less
                Color.new(248, 136, 32),   # 1/4 of total PP or less
                Color.new(248, 72, 72)]    # Zero PP
    ppShadow = [moveShadow,             # More than 1/2 of total PP
                Color.new(144, 104, 0),   # 1/2 of total PP or less
                Color.new(144, 72, 24),   # 1/4 of total PP or less
                Color.new(136, 48, 48)]   # Zero PP
    @sprites["pokemon"].visible  = true
    @sprites["pokeicon"].visible = false
    @sprites["itemicon"].visible = true
    textpos  = []
    imagepos = []
    # Write move names, types and PP amounts for each known move
    yPos = P4_MOVE_LIST_Y
    Pokemon::MAX_MOVES.times do |i|
      move = @pokemon.moves[i]
      if move
        type_number = GameData::Type.get(move.display_type(@pokemon)).icon_position
        imagepos.push([_INTL("Graphics/UI/types"), P4_TYPE_ICON_X, yPos + P4_TYPE_ICON_OFFSET_Y, 0, type_number * 28, 64, 28])
        textpos.push([move.name, P4_MOVE_NAME_X, yPos, :left, moveBase, moveShadow])
        if move.total_pp > 0
          textpos.push([_INTL("PP"), P4_PP_LABEL_X, yPos + P4_PP_LABEL_OFFSET_Y, :left, moveBase, moveShadow])
          ppfraction = 0
          if move.pp == 0
            ppfraction = 3
          elsif move.pp * 4 <= move.total_pp
            ppfraction = 2
          elsif move.pp * 2 <= move.total_pp
            ppfraction = 1
          end
          textpos.push([sprintf("%d/%d", move.pp, move.total_pp), P4_PP_NUM_X, yPos + P4_PP_NUM_OFFSET_Y, :right, ppBase[ppfraction], ppShadow[ppfraction]])
        end
      else
        textpos.push(["-", P4_MOVE_NAME_X, yPos, :left, moveBase, moveShadow])
        textpos.push(["--", P4_PP_NUM_X - 18, yPos + P4_PP_NUM_OFFSET_Y, :right, moveBase, moveShadow])
      end
      yPos += P4_MOVE_OFFSET_Y
    end
    # Draw all text and images
    pbDrawTextPositions(overlay, textpos)
    pbDrawImagePositions(overlay, imagepos)
  end

  def drawPageFourSelecting(move_to_learn)
    overlay = @sprites["overlay"].bitmap
    overlay.clear
    base   = Color.new(248, 248, 248)
    shadow = Color.new(104, 104, 104)
    moveBase   = Color.new(64, 64, 64)
    moveShadow = Color.new(176, 176, 176)
    ppBase   = [moveBase,                # More than 1/2 of total PP
                Color.new(248, 192, 0),    # 1/2 of total PP or less
                Color.new(248, 136, 32),   # 1/4 of total PP or less
                Color.new(248, 72, 72)]    # Zero PP
    ppShadow = [moveShadow,             # More than 1/2 of total PP
                Color.new(144, 104, 0),   # 1/2 of total PP or less
                Color.new(144, 72, 24),   # 1/4 of total PP or less
                Color.new(136, 48, 48)]   # Zero PP
    # Set background image
    if move_to_learn
      @sprites["background"].setBitmap("Graphics/UI/Summary/bg_learnmove")
    else
      @sprites["background"].setBitmap("Graphics/UI/Summary/bg_movedetail")
    end
    # Write various bits of text
    textpos = [
      [_INTL("MOVIMIENTOS"), TEXT_PAGE_NAME_X, TEXT_PAGE_NAME_Y, :left, base, shadow],
      [_INTL("CATEGORÍA"), P4_SEL_CATEGORY_LABEL_X, P4_SEL_CATEGORY_LABEL_Y, :left, base, shadow],
      [_INTL("POTENCIA"), P4_SEL_POWER_LABEL_X, P4_SEL_POWER_LABEL_Y, :left, base, shadow],
      [_INTL("PRECISIÓN"), P4_SEL_ACCURACY_LABEL_X, P4_SEL_ACCURACY_LABEL_Y, :left, base, shadow]
    ]
    imagepos = []
    # Write move names, types and PP amounts for each known move
    yPos = P4_MOVE_LIST_Y
    yPos -= 76 if move_to_learn
    limit = (move_to_learn) ? Pokemon::MAX_MOVES + 1 : Pokemon::MAX_MOVES
    limit.times do |i|
      move = @pokemon.moves[i]
      if i == Pokemon::MAX_MOVES
        move = move_to_learn
        yPos += 20
      end
      if move
        type_number = GameData::Type.get(move.display_type(@pokemon)).icon_position
        imagepos.push([_INTL("Graphics/UI/types"), P4_TYPE_ICON_X, yPos + P4_TYPE_ICON_OFFSET_Y, 0, type_number * 28, 64, 28])
        textpos.push([move.name, P4_MOVE_NAME_X, yPos, :left, moveBase, moveShadow])
        if move.total_pp > 0
          textpos.push([_INTL("PP"), P4_PP_LABEL_X, yPos + P4_PP_LABEL_OFFSET_Y, :left, moveBase, moveShadow])
          ppfraction = 0
          if move.pp == 0
            ppfraction = 3
          elsif move.pp * 4 <= move.total_pp
            ppfraction = 2
          elsif move.pp * 2 <= move.total_pp
            ppfraction = 1
          end
          textpos.push([sprintf("%d/%d", move.pp, move.total_pp), P4_PP_NUM_X, yPos + P4_PP_NUM_OFFSET_Y, :right,
                        ppBase[ppfraction], ppShadow[ppfraction]])
        end
      else
        textpos.push(["-", P4_MOVE_NAME_X, yPos, :left, moveBase, moveShadow])
        textpos.push(["--", P4_PP_NUM_X - 18, yPos + P4_PP_NUM_OFFSET_Y, :right, moveBase, moveShadow])
      end
      yPos += P4_MOVE_OFFSET_Y
    end
    # Draw all text and images
    pbDrawTextPositions(overlay, textpos)
    pbDrawImagePositions(overlay, imagepos)
    # Draw Pokémon's type icon(s)
    @pokemon.types.each_with_index do |type, i|
      type_number = GameData::Type.get(type).icon_position
      type_rect = Rect.new(0, type_number * GameData::Type::ICON_SIZE[1], GameData::Type::ICON_SIZE[0], GameData::Type::ICON_SIZE[1])
      type_x = (@pokemon.types.length == 1) ? 130 : 96 + (70 * i)
      overlay.blt(type_x, P4_SEL_TYPE_Y, @typebitmap.bitmap, type_rect)
    end
  end

  def drawSelectedMove(move_to_learn, selected_move)
    # Draw all of page four, except selected move's details
    drawPageFourSelecting(move_to_learn)
    # Set various values
    overlay = @sprites["overlay"].bitmap
    base = Color.new(64, 64, 64)
    shadow = Color.new(176, 176, 176)
    @sprites["pokemon"].visible = false if @sprites["pokemon"]
    @sprites["pokeicon"].pokemon = @pokemon
    @sprites["pokeicon"].visible = true
    @sprites["itemicon"].visible = false if @sprites["itemicon"]
    textpos = []
    # Write power and accuracy values for selected move
    case selected_move.display_damage(@pokemon)
    when 0 then textpos.push(["---", P4_SEL_VAL_X, P4_SEL_VAL_POWER_Y, :right, base, shadow])   # Status move
    when 1 then textpos.push(["???", P4_SEL_VAL_X, P4_SEL_VAL_POWER_Y, :right, base, shadow])   # Variable power move
    else        textpos.push([selected_move.display_damage(@pokemon).to_s, P4_SEL_VAL_X, P4_SEL_VAL_POWER_Y, :right, base, shadow])
    end
    if selected_move.display_accuracy(@pokemon) == 0
      textpos.push(["---", P4_SEL_VAL_X, P4_SEL_VAL_ACCURACY_Y, :right, base, shadow])
    else
      textpos.push(["#{selected_move.display_accuracy(@pokemon)}%", P4_SEL_VAL_X + overlay.text_size("%").width, P4_SEL_VAL_ACCURACY_Y, :right, base, shadow])
    end
    # Draw all text
    pbDrawTextPositions(overlay, textpos)
    # Draw selected move's damage category icon
    imagepos = [["Graphics/UI/category", P4_SEL_CAT_ICON_X, P4_SEL_CAT_ICON_Y, 0, selected_move.display_category(@pokemon) * 28, 64, 28]]
    pbDrawImagePositions(overlay, imagepos)
    # Draw selected move's description
    drawTextEx(overlay, P4_SEL_DESC_X, P4_SEL_DESC_Y, P4_SEL_DESC_WIDTH, 5, selected_move.description, base, shadow)
  end

  def drawPageFive
    overlay = @sprites["overlay"].bitmap
    @sprites["uparrow"].visible   = false
    @sprites["downarrow"].visible = false
    # Write various bits of text
    textpos = [
      [_INTL("No. de Cintas:"), P5_RIBBON_COUNT_LABEL_X, P5_RIBBON_COUNT_LABEL_Y, :left, Color.new(64, 64, 64), Color.new(176, 176, 176)],
      [@pokemon.numRibbons.to_s, P5_RIBBON_COUNT_NUM_X, P5_RIBBON_COUNT_NUM_Y, :right, Color.new(64, 64, 64), Color.new(176, 176, 176)]
    ]
    # Draw all text
    pbDrawTextPositions(overlay, textpos)
    # Show all ribbons
    imagepos = []
    coord = 0
    (@ribbonOffset * 4...(@ribbonOffset * 4) + 12).each do |i|
      break if !@pokemon.ribbons[i]
      ribbon_data = GameData::Ribbon.get(@pokemon.ribbons[i])
      ribn = ribbon_data.icon_position
      imagepos.push(["Graphics/UI/Summary/ribbons",
                     P5_RIBBON_LIST_X + (P5_RIBBON_OFFSET_X * (coord % 4)), P5_RIBBON_LIST_Y + (P5_RIBBON_OFFSET_Y * (coord / 4).floor),
                     64 * (ribn % 8), 64 * (ribn / 8).floor, 64, 64])
      coord += 1
    end
    # Draw all images
    pbDrawImagePositions(overlay, imagepos)
  end

  def drawSelectedRibbon(ribbonid)
    # Draw all of page five
    drawPage(5)
    # Set various values
    overlay = @sprites["overlay"].bitmap
    base   = Color.new(64, 64, 64)
    shadow = Color.new(176, 176, 176)
    nameBase   = Color.new(248, 248, 248)
    nameShadow = Color.new(104, 104, 104)
    # Get data for selected ribbon
    name = ribbonid ? GameData::Ribbon.get(ribbonid).name : ""
    desc = ribbonid ? GameData::Ribbon.get(ribbonid).description : ""
    # Draw the description box
    imagepos = [
      ["Graphics/UI/Summary/overlay_ribbon", P5_SEL_BG_X, P5_SEL_BG_Y]
    ]
    pbDrawImagePositions(overlay, imagepos)
    # Draw name of selected ribbon
    textpos = [
      [name, P5_SEL_NAME_X, P5_SEL_NAME_Y, :left, nameBase, nameShadow]
    ]
    pbDrawTextPositions(overlay, textpos)
    # Draw selected ribbon's description
    drawTextEx(overlay, P5_SEL_DESC_X, P5_SEL_DESC_Y, P5_SEL_DESC_WIDTH, 2, desc, base, shadow)
  end

  def pbGoToPrevious
    newindex = @partyindex
    while newindex > 0
      newindex -= 1
      if @party[newindex] && (@page == 1 || !@party[newindex].egg?)
        @partyindex = newindex
        break
      end
    end
  end

  def pbGoToNext
    newindex = @partyindex
    while newindex < @party.length - 1
      newindex += 1
      if @party[newindex] && (@page == 1 || !@party[newindex].egg?)
        @partyindex = newindex
        break
      end
    end
  end

  def pbChangePokemon
    @pokemon = @party[@partyindex]
    @sprites["pokemon"].setPokemonBitmap(@pokemon)
    @sprites["itemicon"].item = @pokemon.item_id
    pbSEStop
    @pokemon.play_cry
  end

  def pbMoveSelection
    @sprites["movesel"].visible = true
    @sprites["movesel"].index   = 0
    selmove    = 0
    oldselmove = 0
    switching = false
    drawSelectedMove(nil, @pokemon.moves[selmove])
    loop do
      Graphics.update
      Input.update
      pbUpdate
      if @sprites["movepresel"].index == @sprites["movesel"].index
        @sprites["movepresel"].z = @sprites["movesel"].z + 1
      else
        @sprites["movepresel"].z = @sprites["movesel"].z
      end
      if Input.trigger?(Input::BACK)
        (switching) ? pbPlayCancelSE : pbPlayCloseMenuSE
        break if !switching
        @sprites["movepresel"].visible = false
        switching = false
      elsif Input.trigger?(Input::USE) && @allow_learn_moves
        pbPlayDecisionSE
        if selmove == Pokemon::MAX_MOVES
          break if !switching
          @sprites["movepresel"].visible = false
          switching = false
        elsif !@pokemon.shadowPokemon?
          if switching
            tmpmove                    = @pokemon.moves[oldselmove]
            @pokemon.moves[oldselmove] = @pokemon.moves[selmove]
            @pokemon.moves[selmove]    = tmpmove
            @sprites["movepresel"].visible = false
            switching = false
            drawSelectedMove(nil, @pokemon.moves[selmove])
          else
            @sprites["movepresel"].index   = selmove
            @sprites["movepresel"].visible = true
            oldselmove = selmove
            switching = true
          end
        end
      elsif Input.trigger?(Input::UP)
        selmove -= 1
        if selmove < Pokemon::MAX_MOVES && selmove >= @pokemon.numMoves
          selmove = @pokemon.numMoves - 1
        end
        selmove = 0 if selmove >= Pokemon::MAX_MOVES
        selmove = @pokemon.numMoves - 1 if selmove < 0
        @sprites["movesel"].index = selmove
        pbPlayCursorSE
        drawSelectedMove(nil, @pokemon.moves[selmove])
      elsif Input.trigger?(Input::DOWN)
        selmove += 1
        selmove = 0 if selmove < Pokemon::MAX_MOVES && selmove >= @pokemon.numMoves
        selmove = 0 if selmove >= Pokemon::MAX_MOVES
        selmove = Pokemon::MAX_MOVES if selmove < 0
        @sprites["movesel"].index = selmove
        pbPlayCursorSE
        drawSelectedMove(nil, @pokemon.moves[selmove])
      end
    end
    @sprites["movesel"].visible = false
  end

  def pbRibbonSelection
    @sprites["ribbonsel"].visible = true
    @sprites["ribbonsel"].index   = 0
    selribbon    = @ribbonOffset * 4
    oldselribbon = selribbon
    switching = false
    numRibbons = @pokemon.ribbons.length
    numRows    = [((numRibbons + 3) / 4).floor, 3].max
    drawSelectedRibbon(@pokemon.ribbons[selribbon])
    loop do
      @sprites["uparrow"].visible   = (@ribbonOffset > 0)
      @sprites["downarrow"].visible = (@ribbonOffset < numRows - 3)
      Graphics.update
      Input.update
      pbUpdate
      if @sprites["ribbonpresel"].index == @sprites["ribbonsel"].index
        @sprites["ribbonpresel"].z = @sprites["ribbonsel"].z + 1
      else
        @sprites["ribbonpresel"].z = @sprites["ribbonsel"].z
      end
      hasMovedCursor = false
      if Input.trigger?(Input::BACK)
        (switching) ? pbPlayCancelSE : pbPlayCloseMenuSE
        break if !switching
        @sprites["ribbonpresel"].visible = false
        switching = false
      elsif Input.trigger?(Input::USE)
        if switching
          pbPlayDecisionSE
          tmpribbon                      = @pokemon.ribbons[oldselribbon]
          @pokemon.ribbons[oldselribbon] = @pokemon.ribbons[selribbon]
          @pokemon.ribbons[selribbon]    = tmpribbon
          if @pokemon.ribbons[oldselribbon] || @pokemon.ribbons[selribbon]
            @pokemon.ribbons.compact!
            if selribbon >= numRibbons
              selribbon = numRibbons - 1
              hasMovedCursor = true
            end
          end
          @sprites["ribbonpresel"].visible = false
          switching = false
          drawSelectedRibbon(@pokemon.ribbons[selribbon])
        else
          if @pokemon.ribbons[selribbon]
            pbPlayDecisionSE
            @sprites["ribbonpresel"].index = selribbon - (@ribbonOffset * 4)
            oldselribbon = selribbon
            @sprites["ribbonpresel"].visible = true
            switching = true
          end
        end
      elsif Input.trigger?(Input::UP)
        selribbon -= 4
        selribbon += numRows * 4 if selribbon < 0
        hasMovedCursor = true
        pbPlayCursorSE
      elsif Input.trigger?(Input::DOWN)
        selribbon += 4
        selribbon -= numRows * 4 if selribbon >= numRows * 4
        hasMovedCursor = true
        pbPlayCursorSE
      elsif Input.trigger?(Input::LEFT)
        selribbon -= 1
        selribbon += 4 if selribbon % 4 == 3
        hasMovedCursor = true
        pbPlayCursorSE
      elsif Input.trigger?(Input::RIGHT)
        selribbon += 1
        selribbon -= 4 if selribbon % 4 == 0
        hasMovedCursor = true
        pbPlayCursorSE
      end
      next if !hasMovedCursor
      @ribbonOffset = (selribbon / 4).floor if selribbon < @ribbonOffset * 4
      @ribbonOffset = (selribbon / 4).floor - 2 if selribbon >= (@ribbonOffset + 3) * 4
      @ribbonOffset = 0 if @ribbonOffset < 0
      @ribbonOffset = numRows - 3 if @ribbonOffset > numRows - 3
      @sprites["ribbonsel"].index    = selribbon - (@ribbonOffset * 4)
      @sprites["ribbonpresel"].index = oldselribbon - (@ribbonOffset * 4)
      drawSelectedRibbon(@pokemon.ribbons[selribbon])
    end
    @sprites["ribbonsel"].visible = false
  end

  def pbMarking(pokemon)
    @sprites["markingbg"].visible      = true
    @sprites["markingoverlay"].visible = true
    @sprites["markingsel"].visible     = true
    base   = Color.new(248, 248, 248)
    shadow = Color.new(104, 104, 104)
    ret = pokemon.markings.clone
    markings = pokemon.markings.clone
    mark_variants = @markingbitmap.bitmap.height / MARK_HEIGHT
    index = 0
    redraw = true
    markrect = Rect.new(0, 0, MARK_WIDTH, MARK_HEIGHT)
    loop do
      # Redraw the markings and text
      if redraw
        @sprites["markingoverlay"].bitmap.clear
        (@markingbitmap.bitmap.width / MARK_WIDTH).times do |i|
          markrect.x = i * MARK_WIDTH
          markrect.y = [(markings[i] || 0), mark_variants - 1].min * MARK_HEIGHT
          @sprites["markingoverlay"].bitmap.blt(300 + (58 * (i % 3)), 154 + (50 * (i / 3)),
                                                @markingbitmap.bitmap, markrect)
        end
        textpos = [
          [_INTL("Marcar a {1}", pokemon.name), 366, 102, :center, base, shadow],
          [_INTL("OK"), 366, 254, :center, base, shadow],
          [_INTL("Cancelar"), 366, 304, :center, base, shadow]
        ]
        pbDrawTextPositions(@sprites["markingoverlay"].bitmap, textpos)
        redraw = false
      end
      # Reposition the cursor
      @sprites["markingsel"].x = 284 + (58 * (index % 3))
      @sprites["markingsel"].y = 144 + (50 * (index / 3))
      case index
      when 6   # OK
        @sprites["markingsel"].x = 284
        @sprites["markingsel"].y = 244
        @sprites["markingsel"].src_rect.y = @sprites["markingsel"].bitmap.height / 2
      when 7   # Cancel
        @sprites["markingsel"].x = 284
        @sprites["markingsel"].y = 294
        @sprites["markingsel"].src_rect.y = @sprites["markingsel"].bitmap.height / 2
      else
        @sprites["markingsel"].src_rect.y = 0
      end
      Graphics.update
      Input.update
      pbUpdate
      if Input.trigger?(Input::BACK)
        pbPlayCloseMenuSE
        break
      elsif Input.trigger?(Input::USE)
        pbPlayDecisionSE
        case index
        when 6   # OK
          ret = markings
          break
        when 7   # Cancel
          break
        else
          markings[index] = ((markings[index] || 0) + 1) % mark_variants
          redraw = true
        end
      elsif Input.trigger?(Input::ACTION)
        if index < 6 && markings && markings[index] && markings[index] > 0
          pbPlayDecisionSE
          markings[index] = 0
          redraw = true
        end
      elsif Input.trigger?(Input::UP)
        if index == 7
          index = 6
        elsif index == 6
          index = 4
        elsif index < 3
          index = 7
        else
          index -= 3
        end
        pbPlayCursorSE
      elsif Input.trigger?(Input::DOWN)
        if index == 7
          index = 1
        elsif index == 6
          index = 7
        elsif index >= 3
          index = 6
        else
          index += 3
        end
        pbPlayCursorSE
      elsif Input.trigger?(Input::LEFT)
        if index < 6
          index -= 1
          index += 3 if index % 3 == 2
          pbPlayCursorSE
        end
      elsif Input.trigger?(Input::RIGHT)
        if index < 6
          index += 1
          index -= 3 if index % 3 == 0
          pbPlayCursorSE
        end
      end
    end
    @sprites["markingbg"].visible      = false
    @sprites["markingoverlay"].visible = false
    @sprites["markingsel"].visible     = false
    if pokemon.markings != ret
      pokemon.markings = ret
      return true
    end
    return false
  end

  def pbOptions
    dorefresh = false
    commands = []
    cmdGiveItem = -1
    cmdTakeItem = -1
    cmdPokedex  = -1
    cmdMark     = -1
    if !@pokemon.egg?
      commands[cmdGiveItem = commands.length] = _INTL("Dar objeto")
      commands[cmdTakeItem = commands.length] = _INTL("Guardar objeto") if @pokemon.hasItem?
      commands[cmdPokedex = commands.length]  = _INTL("Ver Pokédex") if $player.has_pokedex
    end
    commands[cmdMark = commands.length]       = _INTL("Marcas")
    commands[commands.length]                 = _INTL("Cancelar")
    command = pbShowCommands(commands)
    if cmdGiveItem >= 0 && command == cmdGiveItem
      item = nil
      pbFadeOutIn do
        scene = PokemonBag_Scene.new
        screen = PokemonBagScreen.new(scene, $bag)
        item = screen.pbChooseItemScreen(proc { |itm| GameData::Item.get(itm).can_hold? })
      end
      dorefresh = pbGiveItemToPokemon(item, @pokemon, self, @partyindex) if item
    elsif cmdTakeItem >= 0 && command == cmdTakeItem
      dorefresh = pbTakeItemFromPokemon(@pokemon, self)
    elsif cmdPokedex >= 0 && command == cmdPokedex
      $player.pokedex.register_last_seen(@pokemon)
      pbFadeOutIn do
        scene = PokemonPokedexInfo_Scene.new
        screen = PokemonPokedexInfoScreen.new(scene)
        screen.pbStartSceneSingle(@pokemon.species, true)
      end
      dorefresh = true
    elsif cmdMark >= 0 && command == cmdMark
      dorefresh = pbMarking(@pokemon)
    end
    return dorefresh
  end

  def pbChooseMoveToForget(move_to_learn)
    new_move = (move_to_learn) ? Pokemon::Move.new(move_to_learn) : nil
    selmove = 0
    maxmove = (new_move) ? Pokemon::MAX_MOVES : Pokemon::MAX_MOVES - 1
    loop do
      Graphics.update
      Input.update
      pbUpdate
      if Input.trigger?(Input::BACK)
        selmove = Pokemon::MAX_MOVES
        pbPlayCloseMenuSE if new_move
        break
      elsif Input.trigger?(Input::USE)
        pbPlayDecisionSE
        break
      elsif Input.trigger?(Input::UP)
        selmove -= 1
        selmove = maxmove if selmove < 0
        if selmove < Pokemon::MAX_MOVES && selmove >= @pokemon.numMoves
          selmove = @pokemon.numMoves - 1
        end
        @sprites["movesel"].index = selmove
        selected_move = (selmove == Pokemon::MAX_MOVES) ? new_move : @pokemon.moves[selmove]
        drawSelectedMove(new_move, selected_move)
      elsif Input.trigger?(Input::DOWN)
        selmove += 1
        selmove = 0 if selmove > maxmove
        if selmove < Pokemon::MAX_MOVES && selmove >= @pokemon.numMoves
          selmove = (new_move) ? maxmove : 0
        end
        @sprites["movesel"].index = selmove
        selected_move = (selmove == Pokemon::MAX_MOVES) ? new_move : @pokemon.moves[selmove]
        drawSelectedMove(new_move, selected_move)
      end
    end
    return (selmove == Pokemon::MAX_MOVES) ? -1 : selmove
  end

  def pbScene
    @pokemon.play_cry
    loop do
      Graphics.update
      Input.update
      pbUpdate
      dorefresh = false
      if Input.trigger?(Input::ACTION)
        pbSEStop
        @pokemon.play_cry
      elsif Input.trigger?(Input::BACK)
        pbPlayCloseMenuSE
        break
      elsif Input.trigger?(Input::USE)
        if @page == 4
          pbPlayDecisionSE
          pbMoveSelection
          dorefresh = true
        elsif @page == 5
          pbPlayDecisionSE
          pbRibbonSelection
          dorefresh = true
        elsif !@inbattle
          pbPlayDecisionSE
          dorefresh = pbOptions
        end
      elsif Input.trigger?(Input::UP) && @partyindex > 0
        oldindex = @partyindex
        pbGoToPrevious
        if @partyindex != oldindex
          pbChangePokemon
          @ribbonOffset = 0
          dorefresh = true
        end
      elsif Input.trigger?(Input::DOWN) && @partyindex < @party.length - 1
        oldindex = @partyindex
        pbGoToNext
        if @partyindex != oldindex
          pbChangePokemon
          @ribbonOffset = 0
          dorefresh = true
        end
      elsif Input.trigger?(Input::LEFT) && !@pokemon.egg?
        oldpage = @page
        @page -= 1
        @page = 1 if @page < 1
        @page = 5 if @page > 5
        if @page != oldpage   # Move to next page
          pbSEPlay("GUI summary change page")
          @ribbonOffset = 0
          dorefresh = true
        end
      elsif Input.trigger?(Input::RIGHT) && !@pokemon.egg?
        oldpage = @page
        @page += 1
        @page = 1 if @page < 1
        @page = 5 if @page > 5
        if @page != oldpage   # Move to next page
          pbSEPlay("GUI summary change page")
          @ribbonOffset = 0
          dorefresh = true
        end
      end
      drawPage(@page) if dorefresh
    end
    return @partyindex
  end
end

#===============================================================================
#
#===============================================================================
class PokemonSummaryScreen
  def initialize(scene, inbattle = false, allow_learn_moves = true)
    @scene = scene
    @inbattle = inbattle
    @allow_learn_moves = allow_learn_moves
  end

  def pbStartScreen(party, partyindex, page = 1)
    @scene.pbStartScene(party, partyindex, @inbattle, page, @allow_learn_moves)
    ret = @scene.pbScene
    @scene.pbEndScene
    return ret
  end

  def pbStartForgetScreen(party, partyindex, move_to_learn)
    ret = -1
    @scene.pbStartForgetScene(party, partyindex, move_to_learn)
    loop do
      ret = @scene.pbChooseMoveToForget(move_to_learn)
      break if ret < 0 || !move_to_learn
      break if $DEBUG || !party[partyindex].moves[ret].hidden_move?
      pbMessage(_INTL("Las MOs no se pueden olvidar así como así.")) { @scene.pbUpdate }
    end
    @scene.pbEndScene
    return ret
  end

  def pbStartChooseMoveScreen(party, partyindex, message)
    ret = -1
    @scene.pbStartForgetScene(party, partyindex, nil)
    pbMessage(message) { @scene.pbUpdate }
    loop do
      ret = @scene.pbChooseMoveToForget(nil)
      break if ret >= 0
      pbMessage(_INTL("¡Debes elegir un movimiento!")) { @scene.pbUpdate }
    end
    @scene.pbEndScene
    return ret
  end
end

#===============================================================================
#
#===============================================================================
def pbChooseMove(pokemon, variableNumber, nameVarNumber)
  return if !pokemon
  ret = -1
  pbFadeOutIn do
    scene = PokemonSummary_Scene.new
    screen = PokemonSummaryScreen.new(scene)
    ret = screen.pbStartForgetScreen([pokemon], 0, nil)
  end
  $game_variables[variableNumber] = ret
  if ret >= 0
    $game_variables[nameVarNumber] = pokemon.moves[ret].name
  else
    $game_variables[nameVarNumber] = ""
  end
  $game_map.need_refresh = true if $game_map
end

