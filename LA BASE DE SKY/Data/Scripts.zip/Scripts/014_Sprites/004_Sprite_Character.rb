#===============================================================================
#
#===============================================================================
class BushBitmap
  def initialize(bitmap, isTile, depth)
    @bitmaps  = []
    @bitmap   = bitmap
    @isTile   = isTile
    @isBitmap = @bitmap.is_a?(Bitmap)
    @depth    = depth
  end

  def dispose
    @bitmaps.each { |b| b&.dispose }
  end

  def bitmap
    thisBitmap = (@isBitmap) ? @bitmap : @bitmap.bitmap
    current = (@isBitmap) ? 0 : @bitmap.currentIndex
    if !@bitmaps[current]
      if @isTile
        @bitmaps[current] = pbBushDepthTile(thisBitmap, @depth)
      else
        @bitmaps[current] = pbBushDepthBitmap(thisBitmap, @depth)
      end
    end
    return @bitmaps[current]
  end

  def pbBushDepthBitmap(bitmap, depth)
    ret = Bitmap.new(bitmap.width, bitmap.height)
    charheight = ret.height / 4
    cy = charheight - depth - 2
    4.times do |i|
      y = i * charheight
      if cy >= 0
        ret.blt(0, y, bitmap, Rect.new(0, y, ret.width, cy))
        ret.blt(0, y + cy, bitmap, Rect.new(0, y + cy, ret.width, 2), 170)
      end
      ret.blt(0, y + cy + 2, bitmap, Rect.new(0, y + cy + 2, ret.width, 2), 85) if cy + 2 >= 0
    end
    return ret
  end

  def pbBushDepthTile(bitmap, depth)
    ret = Bitmap.new(bitmap.width, bitmap.height)
    charheight = ret.height
    cy = charheight - depth - 2
    y = charheight
    if cy >= 0
      ret.blt(0, y, bitmap, Rect.new(0, y, ret.width, cy))
      ret.blt(0, y + cy, bitmap, Rect.new(0, y + cy, ret.width, 2), 170)
    end
    ret.blt(0, y + cy + 2, bitmap, Rect.new(0, y + cy + 2, ret.width, 2), 85) if cy + 2 >= 0
    return ret
  end
end

#===============================================================================
#
#===============================================================================
class Sprite_Character < RPG::Sprite
  attr_accessor :character
  attr_accessor :steps
  attr_reader :follower

  def initialize(viewport, character = nil)
    super(viewport)
    @character = character
    @old_bush_depth = 0
    @spriteoffset = false
    if !character || character == $game_player || (character.name[/reflection/i] rescue false)
      @reflection = Sprite_Reflection.new(self, viewport)
    end
    @surfbase = Sprite_SurfBase.new(self, viewport) if character == $game_player
    self.zoom_x = TilemapRenderer::ZOOM_X
    self.zoom_y = TilemapRenderer::ZOOM_Y
    update
    if $PokemonTemp && $PokemonTemp.respond_to?(:followers) &&
       $game_temp.followers && $game_temp.followers.respond_to?(:realEvents) &&
       $game_temp.followers.realEvents.is_a?(Array) &&
       $game_temp.followers.realEvents.include?(@character)
      @follower = true
    end
    @steps = []
  end

  def dispose
    @steps.each { |e| e[0].dispose }
    @bushbitmap&.dispose
    @bushbitmap = nil
    @charbitmap&.dispose
    @charbitmap = nil
    @reflection&.dispose
    @reflection = nil
    @surfbase&.dispose
    @surfbase = nil
    @character = nil
    super
  end

  #-----------------------------------------------------------------------------

  def visible=(value)
    super(value)
    @reflection.visible = value if @reflection
  end

  # Used by class Sprite_Reflection.
  def ground_y
    return @character.screen_y_ground
  end

  def source_frame_x
    return @character.pattern
  end

  def source_frame_y
    return (@character.direction - 2) / 2
  end

  def screen_x
    ret = @character.screen_x
    ret = ((ret - (Graphics.width / 2)) * TilemapRenderer::ZOOM_X) + (Graphics.width / 2) if TilemapRenderer::ZOOM_X != 1
    return ret
  end

  def screen_y
    ret = @character.screen_y
    ret = ((ret - (Graphics.height / 2)) * TilemapRenderer::ZOOM_Y) + (Graphics.height / 2) if TilemapRenderer::ZOOM_Y != 1
    return ret
  end

  def screen_z
    return @character.screen_z(@ch)
  end

  def bush_depth
    return @character.bush_depth
  end

  #-----------------------------------------------------------------------------

  def refresh_graphic
    return if @tile_id == @character.tile_id &&
              @character_name == @character.character_name &&
              @character_hue == @character.character_hue &&
              @old_bush_depth == @character.bush_depth
    @tile_id        = @character.tile_id
    @character_name = @character.character_name
    @character_hue  = @character.character_hue
    @old_bush_depth = @character.bush_depth
    @charbitmap&.dispose
    @charbitmap = nil
    @bushbitmap&.dispose
    @bushbitmap = nil
    if @tile_id >= TilemapRenderer::TILESET_START_ID
      set_tile_graphic
    elsif @character_name != ""
      set_charset_graphic
    else
      self.bitmap = nil
      @cw = 0
      @ch = 0
      @reflection&.update
    end
    @character.sprite_size = [@cw, @ch]
  end

  def set_tile_graphic
    @charbitmap = pbGetTileBitmap(@character.map.tileset_name, @tile_id,
                                  @character_hue, @character.width, @character.height)
    @charbitmapAnimated = false
    @spriteoffset = false
    @cw = Game_Map::TILE_WIDTH * @character.width
    @ch = Game_Map::TILE_HEIGHT * @character.height
    self.src_rect.set(0, 0, @cw, @ch)
    self.ox = @cw / 2
    self.oy = @ch
  end

  def set_charset_graphic
    @charbitmap = AnimatedBitmap.new(
      "Graphics/Characters/" + @character_name, @character_hue
    )
    RPG::Cache.retain("Graphics/Characters/", @character_name, @character_hue) if @character == $game_player
    @charbitmapAnimated = true
    @spriteoffset = @character_name[/offset/i]
    @cw = @charbitmap.width / 4
    @ch = @charbitmap.height / 4
    self.ox = @cw / 2
  end

  #-----------------------------------------------------------------------------

  def update
    return if @character.is_a?(Game_Event) && !@character.should_update?
    super
    refresh_graphic   # Check if it has changed, and changes it if so
    return if !@charbitmap
    @charbitmap.update if @charbitmapAnimated
    # Update graphic
    update_bitmap   # For bush bitmaps and animated charbitmaps
    update_charset_frame
    # Update position
    update_charset_offset
    self.x = screen_x
    self.y = screen_y
    self.z = screen_z
    # Update appearance
    update_visibility
    self.opacity = @character.opacity
    self.blend_type = @character.blend_type
    update_tone
    # Update extra animation
    start_pending_animation
    # Update child graphics
    update_child_graphics
    update_footsteps_aux
    update_footsteps
  end

  # true si el tile en (x, y) tiene terrain tag 3 (arena) en cualquier capa.
  def on_footprint_terrain?(x, y)
    tilesetid = @character.map.instance_eval { @map.tileset_id }
    [2, 1, 0].any? do |e|
      tile_id = @character.map.data[x, y, e]
      next false if tile_id.nil?
      next $data_tilesets[tilesetid].terrain_tags[tile_id] == 3
    end
  end

  def update_footsteps_aux
    @old_x ||= @character.x
    @old_y ||= @character.y
    if (@character.x != @old_x || @character.y != @old_y) && !["", "nil"].include?(@character.character_name)
      if @character == $game_player && $game_temp.followers &&
         $game_temp.followers.respond_to?(:realEvents) &&
         $game_temp.followers.realEvents.select { |e| !["", "nil"].include?(e.character_name) }.size > 0 &&
         !FootprintsSettings::DUPLICATE_FOOTSTEPS_WITH_FOLLOWER
        if !FootprintsSettings::EVENTNAME_MAY_NOT_INCLUDE.include?($game_temp.followers.realEvents[0].name) &&
           !FootprintsSettings::FILENAME_MAY_NOT_INCLUDE.include?($game_temp.followers.realEvents[0].character_name)
          make_steps = false
        else
          # Follower excluido: el jugador hace las huellas, pero solo sobre arena
          make_steps = on_footprint_terrain?(@old_x, @old_y)
        end
      elsif (!@character.respond_to?(:name) || !FootprintsSettings::EVENTNAME_MAY_NOT_INCLUDE.include?(@character.name)) &&
             !FootprintsSettings::FILENAME_MAY_NOT_INCLUDE.include?(@character.character_name)
        make_steps = on_footprint_terrain?(@old_x, @old_y)
      end
      if make_steps
        fstep = Sprite.new(self.viewport)
        fstep.z = 0
        dirs = [nil,"DownLeft","Down","DownRight","Left","Still","Right","UpLeft", "Up", "UpRight"]
        if @character == $game_player && $PokemonGlobal.bicycle
          fstep.bmp(File.join("Graphics", "Characters", "steps#{dirs[@character.direction]}Bike"))
        else
          fstep.bmp(File.join("Graphics", "Characters", "steps#{dirs[@character.direction]}"))
        end
        @steps ||= []
        if @character == $game_player && $PokemonGlobal.bicycle
          x = FootprintsSettings::BIKE_X_OFFSET
          y = FootprintsSettings::BIKE_Y_OFFSET
        else
          x = FootprintsSettings::WALK_X_OFFSET
          y = FootprintsSettings::WALK_Y_OFFSET
        end
        @steps << [fstep, @character.map, @old_x + x / Game_Map::TILE_WIDTH.to_f, @old_y + y / Game_Map::TILE_HEIGHT.to_f]
      end
    end
    @old_x = @character.x
    @old_y = @character.y
  end

  def update_footsteps
    if @steps
      for i in 0...@steps.size
        next unless @steps[i]
        sprite, map, x, y, ox = @steps[i]
        sprite.x = -map.display_x / Game_Map::X_SUBPIXELS + x * Game_Map::TILE_WIDTH
        sprite.y = -map.display_y / Game_Map::Y_SUBPIXELS + (y + 1) * Game_Map::TILE_HEIGHT
        sprite.y -= Game_Map::TILE_HEIGHT
        sprite.opacity -= FootprintsSettings::FADE_OUT_SPEED
        if sprite.opacity <= 0
          sprite.dispose
          @steps[i] = nil
        end
      end
      @steps.compact!
    end
  end

  #-----------------------------------------------------------------------------

  private

  # Update animated bitmap, and alternate between bitmaps depending on whether
  # self has a bush depth (i.e. it makes the bottom few pixels transparent).
  def update_bitmap
    bushdepth = bush_depth
    if bushdepth == 0
      # Not in a bush, just update self's bitmap
      self.bitmap = (@charbitmapAnimated) ? @charbitmap.bitmap : @charbitmap
      return
    end
    # Make and use a bush bitmap
    @bushbitmap = BushBitmap.new(@charbitmap, (@tile_id >= TilemapRenderer::TILESET_START_ID), bushdepth) if !@bushbitmap
    self.bitmap = @bushbitmap.bitmap
  end

  def update_visibility
    self.visible = !@character.transparent
  end

  def update_charset_frame
    return if @tile_id > 0   # Is using a tile
    sx = source_frame_x * @cw
    sy = source_frame_y * @ch
    self.src_rect.set(sx, sy, @cw, @ch)
    self.oy = (@spriteoffset rescue false) ? @ch - 16 : @ch
  end

  def update_charset_offset
    return if @tile_id > 0   # Is using a tile
    self.oy -= @character.bob_height   # For the player when surfing/diving
  end

  def update_tone
    return if !self.visible
    if @character.is_a?(Game_Event) && @character.name[/regulartone/i]
      self.tone.set(0, 0, 0, 0)
      return
    end
    pbDayNightTint(self)
  end

  def start_pending_animation
    return if !@character.animation_id || @character.animation_id == 0
    animation = $data_animations[@character.animation_id]
    animation(animation, true, @character.animation_height || 3, @character.animation_regular_tone || false)
    @character.animation_id = 0
  end

  def update_child_graphics
    unless Settings::MAPAS_SIN_REFLEJO.include?($game_map.map_id)
      @reflection&.visible = true
      @reflection&.update
    else
      @reflection&.visible = true
    end
    @surfbase&.update
  end
end
