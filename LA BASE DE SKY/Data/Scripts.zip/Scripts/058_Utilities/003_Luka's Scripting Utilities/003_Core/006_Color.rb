#===============================================================================
#  Luka's Scripting Utilities
#
#  Core extensions for the `Color` class
#===============================================================================
class ::Color
  # Allows color components to be animated easily
  include ::LUTS::Concerns::Animatable

  # @return [Color]
  def self.blank
    Color.new(0, 0, 0, 0)
  end

  # @return [Color]
  def self.dark_gray
    Color.new(64, 64, 64)
  end

  # @param amt [Numeric]
  # @return [Color]
  def darken(amt = 0.2)
    r = red - red * amt
    g = green - green * amt
    b = blue - blue * amt

    Color.new(r, g, b)
  end

  # @return [Boolean]
  def blank?
    red.zero? && green.zero? && blue.zero? && alpha.zero?
  end

  # @return [Boolean]
  def present?
    !blank?
  end
  #-----------------------------------------------------------------------------
end

#===============================================================================
#  Extensions for the `Color` class
#===============================================================================
class Color
  #-----------------------------------------------------------------------------
	# returns an RGB color value as a hex value
  #-----------------------------------------------------------------------------
	def to_hex
		r = sprintf("%02X", self.red)
		g = sprintf("%02X", self.green)
		b = sprintf("%02X", self.blue)
		return ("#" + r + g + b).upcase
	end

  #-----------------------------------------------------------------------------
	# returns decimal color
  #-----------------------------------------------------------------------------
	def to_dec
		return self.to_hex.gsub("#", "").to_i(16)
	end

  #-----------------------------------------------------------------------------
	# return color from byte integer value
  #-----------------------------------------------------------------------------
  def self.from_i(value)
    b =  clr & 255
    g = (clr >> 8) & 255
    r = (clr >> 16) & 255
    a = (clr >> 24) & 255
    return Color.new(r, g, b, a)
  end

  #-----------------------------------------------------------------------------
	# returns darkened color
  #-----------------------------------------------------------------------------
  def darken(amt = 0.2)
    red = self.red - self.red*amt
    green = self.green - self.green*amt
    blue = self.blue - self.blue*amt
    return Color.new(red, green, blue)
  end
  #-----------------------------------------------------------------------------
end