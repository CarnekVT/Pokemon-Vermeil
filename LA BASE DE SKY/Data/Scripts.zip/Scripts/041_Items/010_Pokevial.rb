#===============================================================================
# CREDITOS
# Voltseon, DPertierra, lavinytuttini
#===============================================================================
class PokemonGlobalMetadata
  attr_accessor :vial_charges
  attr_accessor :max_vial_charges
  attr_accessor :vial_locked
end

INITIAL_CHARGES_POKEVIAL = 1
INFINITE_POKEVIAL = false

ItemHandlers::UseFromBag.add(:VIAL, proc { |item| use_pokevial; next 1 })
ItemHandlers::UseInField.add(:VIAL, proc { |item| use_pokevial; next 1 })
ItemHandlers::UseFromBag.copy(:VIAL, :EMPTYVIAL)
ItemHandlers::UseInField.copy(:VIAL, :EMPTYVIAL)

def init_pokevial
  $PokemonGlobal.vial_charges ||= INITIAL_CHARGES_POKEVIAL
  $PokemonGlobal.max_vial_charges ||= INITIAL_CHARGES_POKEVIAL
  $PokemonGlobal.vial_locked ||= false
end

def player_has_pokevial?
  $bag.has?(:VIAL) || $bag.has?(:EMPTYVIAL)
end


def give_vial
  return if player_has_pokevial?

  pbGetKeyItem('VIAL_key') if defined?(pbGetKeyItem)
  pbReceiveItem(:VIAL)
  init_pokevial
end

def lock_vial
  return unless ensure_pokevial_initialized

  $PokemonGlobal.vial_locked = true
  pbMessage(_INTL('El Curaportátil ha sido bloqueado.'))
end

def unlock_vial
  return unless ensure_pokevial_initialized

  $PokemonGlobal.vial_locked = false
  pbMessage(_INTL('El Curaportátil ha sido desbloqueado.'))
end

def ensure_pokevial_initialized
  return false unless player_has_pokevial?

  init_pokevial
  true
end

def show_message_pokevial
  if $PokemonGlobal.vial_charges <= 0
    pbMessage(_INTL('El Curaportátil está vacío. Recárgalo en el Centro Pokémon.'))
    return false
  end
  unless INFINITE_POKEVIAL
    pbMessage(_INTL('Tienes {1} {2} {3} de un máximo de {4}.',
                    vial_charges,
                    vial_charges == 1 ? _INTL('curación') : _INTL('curaciones'),
                    vial_charges == 1 ? _INTL('disponible') : _INTL('disponibles'),
                    max_vial_charges))
  end
  true
end

def max_vial_charges
  ensure_pokevial_initialized
  $PokemonGlobal.max_vial_charges || 0
end

def vial_charges
  ensure_pokevial_initialized
  $PokemonGlobal.vial_charges || 0
end

def vial_full?
  ensure_pokevial_initialized
  vial_charges == max_vial_charges
end


def use_pokevial
  return false unless ensure_pokevial_initialized

  if $PokemonGlobal.vial_locked
    pbMessage(_INTL('El Curaportátil está bloqueado.'))
    return false
  end
  return false unless show_message_pokevial

  if pbConfirmMessage(_INTL('¿Quieres curar a tu equipo?'))
    heal_party_with_pokevial
    return true
  end
  return false
end

def heal_party_with_pokevial
  $player.heal_party
  pbMEPlay('Pkmn healing')
  pbMessage(_INTL('¡Tu equipo Pokémon se ha curado al completo!'))
  $PokemonGlobal.vial_charges -= 1 unless INFINITE_POKEVIAL
  $bag.replace_item(:VIAL, :EMPTYVIAL) if vial_charges <= 0
end

def recharge_vial
  return unless ensure_pokevial_initialized

  $PokemonGlobal.vial_charges = max_vial_charges
  pbMessage(_INTL('¡Tu Curaportátil ha sido recargado!')) unless INFINITE_POKEVIAL
  $bag.replace_item(:EMPTYVIAL, :VIAL) if $bag.has?(:EMPTYVIAL)
end

def add_new_vial_charge
  return unless ensure_pokevial_initialized || INFINITE_POKEVIAL

  $PokemonGlobal.max_vial_charges += 1
  # Se hace de esta forma para que recibir una nueva carga no restaure completamente el vial
  $PokemonGlobal.vial_charges += 1
  pbMessage(_INTL("¡Ahora tu Curaportátil puede almacenar {1} carga#{$PokemonGlobal.max_vial_charges > 1 ? 's' : ''}!",$PokemonGlobal.max_vial_charges))
end

def remove_vial_charge
  return unless ensure_pokevial_initialized || INFINITE_POKEVIAL

  if max_vial_charges > 1
    $PokemonGlobal.max_vial_charges -= 1
    # Se hace de esta forma para que al eliminar una carga no restaure completamente el vial
    $PokemonGlobal.vial_charges -= 1 if vial_charges.positive?
    pbMessage(_INTL("¡Ahora tu Curaportátil puede almacenar {1} carga#{$PokemonGlobal.max_vial_charges > 1 ? 's' : ''}!",
                    max_vial_charges))
  end
end

