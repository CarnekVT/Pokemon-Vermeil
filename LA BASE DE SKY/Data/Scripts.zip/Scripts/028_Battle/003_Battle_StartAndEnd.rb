#===============================================================================
#
#===============================================================================
class Battle
  class BattleAbortedException < Exception; end

  #-----------------------------------------------------------------------------

  def pbAbort
    raise BattleAbortedException.new("Battle aborted")
  end

  # Makes sure all Pokémon exist that need to. Alter the type of battle if
  # necessary. Will never try to create battler positions, only delete them
  # (except for wild Pokémon whose number of positions are fixed). Reduces the
  # size of each side by 1 and tries again. If the side sizes are uneven, only
  # the larger side's size will be reduced by 1 each time, until both sides are
  # an equal size (then both sides will be reduced equally).
  def pbEnsureParticipants
    # Prevent battles larger than 2v2 if both sides have multiple trainers
    # NOTE: This is necessary to ensure that battlers can never become unable to
    #       hit each other due to being too far away. In such situations,
    #       battlers will move to the centre position at the end of a round, but
    #       because they cannot move into a position owned by a different
    #       trainer, it's possible that battlers will be unable to move close
    #       enough to hit each other if there are multiple trainers on both
    #       sides.
    if trainerBattle? && (@sideSizes[0] > 2 || @sideSizes[1] > 2) &&
       @player.length > 1 && @opponent.length > 1
      raise _INTL("No se pueden tener batallas de más de 2 contra 2 en las que ambos bandos tengan varios entrenadores.")
    end
    # Find out how many Pokémon each trainer has
    side1counts = pbAbleTeamCounts(0)
    side2counts = pbAbleTeamCounts(1)
    # Change the size of the battle depending on how many wild Pokémon there are
    if wildBattle? && side2counts[0] != @sideSizes[1]
      if @sideSizes[0] == @sideSizes[1]
        # Even number of battlers per side, change both equally
        @sideSizes = [side2counts[0], side2counts[0]]
      else
        # Uneven number of battlers per side, just change wild side's size
        @sideSizes[1] = side2counts[0]
      end
    end
    # Check if battle is possible, including changing the number of battlers per
    # side if necessary
    loop do
      needsChanging = false
      2.times do |side|   # Each side in turn
        next if side == 1 && wildBattle?   # Wild side's size already checked above
        sideCounts = (side == 0) ? side1counts : side2counts
        requireds = []
        # Find out how many Pokémon each trainer on side needs to have
        @sideSizes[side].times do |i|
          idxTrainer = pbGetOwnerIndexFromBattlerIndex((i * 2) + side)
          requireds[idxTrainer] = 0 if requireds[idxTrainer].nil?
          requireds[idxTrainer] += 1
        end
        # Compare the have values with the need values
        if requireds.length > sideCounts.length
          raise _INTL("Error: def pbGetOwnerIndexFromBattlerIndex proporciona un índice de propietario no válido ({1} para el tipo de batalla {2} contra {3}, entrenadores {4} contra {5})",
                      requireds.length - 1, @sideSizes[0], @sideSizes[1], side1counts.length, side2counts.length)
        end
        sideCounts.each_with_index do |_count, i|
          if !requireds[i] || requireds[i] == 0
            case side
            when 0
              raise _INTL("El entrenador del lado del jugador {1} no tiene una posición asignada para que sus Pokémon combatan (intentando una batalla {2} contra {3})",
                          i + 1, @sideSizes[0], @sideSizes[1])
            when 1
              raise _INTL("El entrenador rival {1} no tiene una posición asignada para que sus Pokémon combatan (intentando una batalla {2} contra {3})",
                          i + 1, @sideSizes[0], @sideSizes[1])
            end
          end
          next if requireds[i] <= sideCounts[i]   # Trainer has enough Pokémon to fill their positions
          if requireds[i] == 1
            raise _INTL("El entrenador del lado del jugador {1} no tiene Pokémon válidos", i + 1) if side == 0
            raise _INTL("El entrenador rival {1} no tiene Pokémon válidos", i + 1) if side == 1
          end
          # Not enough Pokémon, try lowering the number of battler positions
          needsChanging = true
          break
        end
        break if needsChanging
      end
      break if !needsChanging
      # Reduce one or both side's sizes by 1 and try again
      if wildBattle?
        PBDebug.log("#{@sideSizes[0]}v#{@sideSizes[1]} battle isn't possible " +
                    "(#{side1counts} player-side teams versus #{side2counts[0]} wild Pokémon)")
        newSize = @sideSizes[0] - 1
      else
        PBDebug.log("#{@sideSizes[0]}v#{@sideSizes[1]} battle isn't possible " +
                    "(#{side1counts} player-side teams versus #{side2counts} opposing teams)")
        newSize = @sideSizes.max - 1
      end
      if newSize == 0
        raise _INTL("No se pudo reducir más el tamaño de ninguno de los bandos, la batalla no es posible")
      end
      2.times do |side|
        next if side == 1 && wildBattle?   # Wild Pokémon's side size is fixed
        next if @sideSizes[side] == 1 || newSize > @sideSizes[side]
        @sideSizes[side] = newSize
      end
      PBDebug.log("Trying #{@sideSizes[0]}v#{@sideSizes[1]} battle instead")
    end
  end

  #-----------------------------------------------------------------------------
  # Set up all battlers
  #-----------------------------------------------------------------------------

  def pbCreateBattler(idxBattler, pkmn, idxParty)
    if !@battlers[idxBattler].nil?
      raise _INTL("El índice de batalla {1} ya existe", idxBattler)
    end
    @battlers[idxBattler] = Battler.new(self, idxBattler)
    @positions[idxBattler] = ActivePosition.new
    pbClearChoice(idxBattler)
    @successStates[idxBattler] = SuccessState.new
    @battlers[idxBattler].pbInitialize(pkmn, idxParty)
  end

  def pbSetUpSides
    ret = [[], []]
    2.times do |side|
      # Set up wild Pokémon
      if side == 1 && wildBattle?
        pbParty(1).each_with_index do |pkmn, idxPkmn|
          pbCreateBattler((2 * idxPkmn) + side, pkmn, idxPkmn)
          # Changes the Pokémon's form upon entering battle (if it should)
          @peer.pbOnEnteringBattle(self, @battlers[(2 * idxPkmn) + side], pkmn, true)
          pbSetSeen(@battlers[(2 * idxPkmn) + side])
          @usedInBattle[side][idxPkmn] = true
        end
        next
      end
      # Set up player's Pokémon and trainers' Pokémon
      trainer = (side == 0) ? @player : @opponent
      requireds = []
      # Find out how many Pokémon each trainer on side needs to have
      @sideSizes[side].times do |i|
        idxTrainer = pbGetOwnerIndexFromBattlerIndex((i * 2) + side)
        requireds[idxTrainer] = 0 if requireds[idxTrainer].nil?
        requireds[idxTrainer] += 1
      end
      # For each trainer in turn, find the needed number of Pokémon for them to
      # send out, and initialize them
      battlerNumber = 0
      partyOrder = pbPartyOrder(side)
      starts = pbPartyStarts(side)
      trainer.each_with_index do |_t, idxTrainer|
        ret[side][idxTrainer] = []
        eachInTeam(side, idxTrainer) do |pkmn, idxPkmn|
          next if !pkmn.able?
          idxBattler = (2 * battlerNumber) + side
          pbCreateBattler(idxBattler, pkmn, idxPkmn)
          ret[side][idxTrainer].push(idxBattler)
          if idxPkmn != starts[idxTrainer] + battlerNumber
            idxOther = starts[idxTrainer] + battlerNumber
            partyOrder[idxPkmn], partyOrder[idxOther] = partyOrder[idxOther], partyOrder[idxPkmn]
          end
          battlerNumber += 1
          break if ret[side][idxTrainer].length >= requireds[idxTrainer]
        end
      end
    end
    return ret
  end

  #-----------------------------------------------------------------------------
  # Send out all battlers at the start of battle.
  #-----------------------------------------------------------------------------

  def pbStartBattleSendOut(sendOuts)
    pbStartBattleFirstMessage
    # Send out Pokémon (opposing trainers first)
    [1, 0].each do |side|
      next if side == 1 && wildBattle?
      # Message about all the Pokémon being sent out on side
      pbStartBattleSendOutMessage(sendOuts, side)
      # The actual sending out of Pokémon
      animSendOuts = []
      trainers = (side == 0) ? @player : @opponent
      trainers.length.times do |trainer_index|
        animSendOuts.concat(sendOuts[side][trainer_index]) if side != 0 || trainer_index != 0   # Not the player's Pokémon
      end
      animSendOuts.concat(sendOuts[side][0]) if side == 0
      animSendOuts.map! { |idxBattler| [idxBattler, @battlers[idxBattler].pokemon] }
      pbSendOut(animSendOuts, true)
    end
  end

  # "Want to battle" message at the start of battle.
  def pbStartBattleFirstMessage
    if wildBattle?
      foeParty = pbParty(1)
      names = foeParty.map { |pkmn| pkmn.name }      
      case foeParty.length
      when 1
        pbDisplayPaused(_INTL("¡Un {1} salvaje te corta el paso!", names[0]))
      
      when 2
        if names[0] == names[1]
          pbDisplayPaused(_INTL("¡Dos {1} salvajes te cortan el paso!", names[0]))
        else
          pbDisplayPaused(_INTL("¡Un {1} y un {2} salvajes te cortan el paso!", names[0], names[1]))
        end      
      when 3
        counts = names.tally        
        if counts.size == 1
          pbDisplayPaused(_INTL("¡Tres {1} salvajes te cortan el paso!", names[0]))
          
        elsif counts.size == 3
          pbDisplayPaused(_INTL("¡Un {1}, un {2} y un {3} salvajes te cortan el paso!", 
                                names[0], names[1], names[2]))                                
        else
          double_name = counts.find { |name, count| count == 2 }.first
          single_name = counts.find { |name, count| count == 1 }.first
          pbDisplayPaused(_INTL("¡Dos {1} y un {2} salvajes te cortan el paso!", 
                                double_name, single_name))
        end
      end
    else   # Trainer battle
      case @opponent.length
      when 1
        pbDisplayPaused(_INTL("¡{1} te desafía!", @opponent[0].full_name))
      when 2
        pbDisplayPaused(_INTL("¡{1} y {2} te desafían!", @opponent[0].full_name,
                              @opponent[1].full_name))
      when 3
        pbDisplayPaused(_INTL("¡{1}, {2} y {3} te desafían!",
                              @opponent[0].full_name, @opponent[1].full_name, @opponent[2].full_name))
      end
    end
  end

  # Constructs and shows the full "sent out" messages for both sides at the
  # start of battle.
  def pbStartBattleSendOutMessage(sendOuts, side)
    msg = ""
    trainers = (side == 0) ? @player : @opponent
    # Opposing trainers and partner trainers's messages about sending out Pokémon
    trainers.each_with_index do |t, i|
      next if side == 0 && i == 0   # The player's message is shown last
      msg += "\n" if msg.length > 0
      msg += pbStartBattleSendOutMessageSingle(sendOuts, side, i)
    end
    # The player's message about sending out Pokémon
    if side == 0
      msg += "\n" if msg.length > 0
      msg += pbStartBattleSendOutMessageSingle(sendOuts, side, 0)
    end
    pbDisplayBrief(msg) if msg.length > 0
  end

  def pbStartBattleSendOutMessageSingle(sendOuts, side, trainer_index)
    trainers = (side == 0) ? @player : @opponent
    trainer = trainers[trainer_index]
    sent_out_indices = sendOuts[side][trainer_index]
    ret = ""
    if side == 0 && trainer_index == 0   # Player
      case sent_out_indices.length
      when 1
        ret += _INTL("¡Adelante, {1}!", @battlers[sent_out_indices[0]].name)
      when 2
        ret += _INTL("¡Adelante, {1} y {2}!", @battlers[sent_out_indices[0]].name,
                     @battlers[sent_out_indices[1]].name)
      when 3
        ret += _INTL("¡Adelante, {1}, {2} y {3}!", @battlers[sent_out_indices[0]].name,
                     @battlers[sent_out_indices[1]].name, @battlers[sent_out_indices[2]].name)
      end
    else   # NPC trainer
      case sent_out_indices.length
      when 1
        ret += _INTL("{1} saca a {2}!", trainer.full_name, @battlers[sent_out_indices[0]].name)
      when 2
        ret += _INTL("{1} saca a {2} y {3}!", trainer.full_name,
                     @battlers[sent_out_indices[0]].name, @battlers[sent_out_indices[1]].name)
      when 3
        ret += _INTL("{1} saca a {2}, {3} y {4}!", trainer.full_name,
                     @battlers[sent_out_indices[0]].name, @battlers[sent_out_indices[1]].name,
                     @battlers[sent_out_indices[2]].name)
      end
    end
    return ret
  end

  #=============================================================================
  # Start a battle
  #=============================================================================
  def pbStartBattle
    PBDebug.log("")
    PBDebug.log("================================================================")
    PBDebug.log("")
    logMsg = "[Started battle] "
    if @sideSizes[0] == 1 && @sideSizes[1] == 1
      logMsg += "Single "
    elsif @sideSizes[0] == 2 && @sideSizes[1] == 2
      logMsg += "Double "
    elsif @sideSizes[0] == 3 && @sideSizes[1] == 3
      logMsg += "Triple "
    else
      logMsg += "#{@sideSizes[0]}v#{@sideSizes[1]} "
    end
    logMsg += "wild " if wildBattle?
    logMsg += "trainer " if trainerBattle?
    logMsg += "battle (#{@player.length} trainer(s) vs. "
    logMsg += "#{pbParty(1).length} wild Pokémon)" if wildBattle?
    logMsg += "#{@opponent.length} trainer(s))" if trainerBattle?
    PBDebug.log(logMsg)
    pbEnsureParticipants
    pbParty(0).each { |pkmn| @peer.pbOnStartingBattle(self, pkmn, wildBattle?) if pkmn }
    pbParty(1).each { |pkmn| @peer.pbOnStartingBattle(self, pkmn, wildBattle?) if pkmn }
    begin
      pbStartBattleCore
    rescue BattleAbortedException
      @decision = Outcome::UNDECIDED
      @scene.pbEndBattle(@decision)
    end
    return @decision
  end

  def pbStartBattleCore(battle_loop = true)
    # Set up the battlers on each side
    sendOuts = pbSetUpSides
    @battleAI.create_ai_objects
    # Create all the sprites and play the battle intro animation
    @scene.pbStartBattle(self)
    # Show trainers on both sides sending out Pokémon
    pbStartBattleSendOut(sendOuts)
    # Weather announcement
    weather_data = GameData::BattleWeather.try_get(@field.weather)
    pbCommonAnimation(weather_data.animation) if weather_data
    case @field.weather
    when :Sun         then pbDisplay(_INTL("¡El sol pega fuerte!"))
    when :Rain        then pbDisplay(_INTL("¡Ha empezado a llover!"))
    when :Sandstorm   then pbDisplay(_INTL("¡Se ha desatado una tormenta de arena!"))
    when :Hail        then pbDisplay(_INTL("¡Ha empezado a granizar!"))
    when :Snowstorm   then pbDisplay(_INTL("¡Ha empezado a nevar!"))
    when :HarshSun    then pbDisplay(_INTL("¡El sol que hace ahora es realmente abrasador!"))
    when :HeavyRain   then pbDisplay(_INTL("¡Ha empezado a diluviar!"))
    when :StrongWinds then pbDisplay(_INTL("¡Las misteriosas turbulencias protegen a los Pokémon de tipo Volador!"))
    when :ShadowSky   then pbDisplay(_INTL("¡El cielo se volvió oscuro!"))
    end
    # Terrain announcement
    terrain_data = GameData::BattleTerrain.try_get(@field.terrain)
    pbCommonAnimation(terrain_data.animation) if terrain_data
    
    case @field.terrain
    when :Electric
      pbDisplay(_INTL("¡Se ha formado un campo de corriente eléctrica en el terreno de combate!"))
    when :Grassy
      pbDisplay(_INTL("¡El terreno de combate se ha cubierto de hierba!"))
    when :Misty
      pbDisplay(_INTL("¡La niebla ha envuelto el terreno de combate!"))
    when :Psychic
      pbDisplay(_INTL("¡El terreno de combate se ha vuelto muy extraño!"))
    end
    on_terrain_start
    # Abilities upon entering battle
    pbOnAllBattlersEnteringBattle
    # Main battle loop
    pbBattleLoop if battle_loop
  end 

  #=============================================================================
  # Main battle loop
  #=============================================================================
  def pbBattleLoop
    @turnCount = 0
    loop do   # Now begin the battle loop
      PBDebug.log("")
      PBDebug.log_header("===== Round #{@turnCount + 1} =====")
      if @debug && @turnCount >= 100
        @decision = pbDecisionOnTime
        PBDebug.log("")
        PBDebug.log("***Undecided after 100 rounds, aborting***")
        pbAbort
        break
      end
      PBDebug.log("")
      # Command phase
      PBDebug.logonerr { pbCommandPhase }
      break if decided?
      # Attack phase
      PBDebug.logonerr { pbAttackPhase }
      break if decided?
      # End of round phase
      PBDebug.logonerr { pbEndOfRoundPhase }
      break if decided?
      @turnCount += 1
    end
    pbEndOfBattle
  end

  #=============================================================================
  # End of battle
  #=============================================================================
  def pbGainMoney
    return if !@internalBattle || @rules[:no_money_gain]
    # Money rewarded from opposing trainers
    if trainerBattle?
      tMoney = 0
      @opponent.each_with_index do |t, i|
        tMoney += pbMaxLevelInTeam(1, i) * t.base_money
      end
      tMoney *= 2 if @field.effects[PBEffects::AmuletCoin]
      tMoney *= 2 if @field.effects[PBEffects::HappyHour]
      oldMoney = pbPlayer.money
      pbPlayer.money += tMoney
      moneyGained = pbPlayer.money - oldMoney
      if moneyGained > 0
        $stats.battle_money_gained += moneyGained
        pbDisplayPaused(_INTL("¡Has ganado {1}$ por vencer!", moneyGained.to_s_formatted))
      end
    end
    # Pick up money scattered by Pay Day
    if @field.effects[PBEffects::PayDay] > 0
      @field.effects[PBEffects::PayDay] *= 2 if @field.effects[PBEffects::AmuletCoin]
      @field.effects[PBEffects::PayDay] *= 2 if @field.effects[PBEffects::HappyHour]
      oldMoney = pbPlayer.money
      pbPlayer.money += @field.effects[PBEffects::PayDay]
      moneyGained = pbPlayer.money - oldMoney
      if moneyGained > 0
        $stats.battle_money_gained += moneyGained
        pbDisplayPaused(_INTL("¡Has recogido {1}$!", moneyGained.to_s_formatted))
      end
    end
  end

  def pbLoseMoney
    return if !@internalBattle || @rules[:no_money_gain]
    return if $game_switches[Settings::NO_MONEY_LOSS]
    maxLevel = pbMaxLevelInTeam(0, 0)   # Player's Pokémon only, not partner's
    multiplier = [8, 16, 24, 36, 48, 64, 80, 100, 120]
    idxMultiplier = [pbPlayer.badge_count, multiplier.length - 1].min
    tMoney = maxLevel * multiplier[idxMultiplier]
    tMoney = pbPlayer.money if tMoney > pbPlayer.money
    oldMoney = pbPlayer.money
    pbPlayer.money -= tMoney
    moneyLost = oldMoney - pbPlayer.money
    if moneyLost > 0
      $stats.battle_money_lost += moneyLost
      if trainerBattle?
        pbDisplayPaused(_INTL("Has pagado {1}$ por haber perdido el combate.", moneyLost.to_s_formatted))
      else
        pbDisplayPaused(_INTL("Te has desconcentrado y se te han caído {1}$...", moneyLost.to_s_formatted))
      end
    end
  end

  def pbEndOfBattle
    oldDecision = @decision
    @decision = Outcome::CATCH if @decision == Outcome::WIN && wildBattle? && @caughtPokemon.length > 0
    case oldDecision
    when Outcome::WIN
      PBDebug.log("")
      PBDebug.log_header("===== Player won =====")
      PBDebug.log("")
      if trainerBattle?
        @scene.pbTrainerBattleSuccess
        case @opponent.length
        when 1
          pbDisplayPaused(_INTL("¡{1} ha perdido!", @opponent[0].full_name))
        when 2
          pbDisplayPaused(_INTL("¡{1} y {2} han perdido!", @opponent[0].full_name,
                                @opponent[1].full_name))
        when 3
          pbDisplayPaused(_INTL("¡{1}, {2} y {3} han perdido!", @opponent[0].full_name,
                                @opponent[1].full_name, @opponent[2].full_name))
        end
        @opponent.each_with_index do |trainer, i|
          @scene.pbShowOpponent(i)
          msg = trainer.lose_text
          msg = "..." if !msg || msg.empty?
          pbDisplayPaused(msg.gsub(/\\[Pp][Nn]/, pbPlayer.name).gsub(/\\[Nn]/, "\n"))
        end
        PBDebug.log("")
      end
      # Gain money from winning a trainer battle, and from Pay Day
      pbGainMoney if @decision != Outcome::CATCH
      # Hide remaining trainer
      @scene.pbShowOpponent(@opponent.length) if trainerBattle? && @caughtPokemon.length > 0
    when Outcome::LOSE, Outcome::DRAW
      PBDebug.log("")
      PBDebug.log_header("===== Player lost =====") if @decision == Outcome::LOSE
      PBDebug.log_header("===== Player drew with opponent =====") if @decision == Outcome::DRAW
      PBDebug.log("")
      if @internalBattle
        if pbPlayerBattlerCount == 0
          pbDisplayPaused(_INTL("¡No te quedan Pokémon!"))
          if trainerBattle?
            case @opponent.length
            when 1
              pbDisplayPaused(_INTL("¡Has perdido contra {1}!", @opponent[0].full_name))
            when 2
              pbDisplayPaused(_INTL("¡Has perdido contra {1} y {2}!",
                                    @opponent[0].full_name, @opponent[1].full_name))
            when 3
              pbDisplayPaused(_INTL("¡Has perdido contra {1}, {2} y {3}!",
                                    @opponent[0].full_name, @opponent[1].full_name, @opponent[2].full_name))
            end
          end
        end
        # Lose money from losing a battle
        pbLoseMoney
        pbDisplayPaused(_INTL("¡Estás fuera de combate!")) if !@rules[:continue_if_lose] && pbPlayerBattlerCount == 0
      elsif @decision == Outcome::LOSE   # Lost in a Battle Frontier battle
        if @opponent
          @opponent.each_with_index do |trainer, i|
            @scene.pbShowOpponent(i)
            msg = trainer.win_text
            msg = "..." if !msg || msg.empty?
            pbDisplayPaused(msg.gsub(/\\[Pp][Nn]/, pbPlayer.name).gsub(/\\[Nn]/, "\n"))
          end
          PBDebug.log("")
        end
      end
    when Outcome::CATCH
      PBDebug.log("")
      PBDebug.log_header("===== Pokémon caught =====")
      PBDebug.log("")
      @scene.pbWildBattleSuccess if !Settings::GAIN_EXP_FOR_CAPTURE
    end
    # Swap held items back to their original holders (in trainer battles only)
    if trainerBattle?
      2.times do |side|
        pbParty(side).length.times do |i|
          pkmn = pbParty(side)[i]
          next if !pkmn
          next if @initialItems[side][i][1] == side && @initialItems[side][i][2] == i
          # Find other Pokémon holding the item originally held by pkmn
          other_side = side
          other_i = i
          @initialItems.each_with_index do |side_items, this_side|
            side_items.each_with_index do |pkmn_item, this_i|
              next if pkmn_item[1] != side || pkmn_item[2] != i
              other_side = this_side
              other_i = this_i
              break
            end
            break if other_side != side || other_i != i
          end
          # Swap items
          pkmn.item, pbParty(other_side)[other_i].item = pbParty(other_side)[other_i].item, pkmn.item
          @initialItems[side][i], @initialItems[other_side][other_i] = @initialItems[other_side][other_i], @initialItems[side][i]
        end
      end
    end
    # Restore knocked-off items and some consumed items
    @initialItems.each_with_index do |side_items, side|
      side_items.each_with_index do |pkmn_item, i|
        next if pkmn_item[0].nil?   # No initial item to restore
        next if !pbParty(side)[i] || pbParty(side)[i].hasItem?   # Can't restore item if already holding one
        if pkmn_item[3] ||   # Knocked off
           (Settings::RESTORE_HELD_ITEMS_AFTER_BATTLE &&   # Only restores consumed items in Gen 9+
            !GameData::Item.get(pkmn_item[0]).is_berry?)   # Can't restore consumed berries
          # Restore knocked off/consumed item
          pbParty(side)[i].item = pkmn_item[0]
        end
      end
    end
    # Register captured Pokémon in the Pokédex, and store them
    pbRecordAndStoreCaughtPokemon
    # Collect Pay Day money in a wild battle that ended in a capture
    pbGainMoney if @decision == Outcome::CATCH
    # Pass on Pokérus within the party
    if @internalBattle
      infected = []
      $player.party.each_with_index do |pkmn, i|
        infected.push(i) if pkmn.pokerusStage == 1
      end
      infected.each do |idxParty|
        strain = $player.party[idxParty].pokerusStrain
        if idxParty > 0 && $player.party[idxParty - 1].pokerusStage == 0 && rand(3) == 0   # 33%
          $player.party[idxParty - 1].givePokerus(strain)
        end
        if idxParty < $player.party.length - 1 && $player.party[idxParty + 1].pokerusStage == 0 && rand(3) == 0   # 33%
          $player.party[idxParty + 1].givePokerus(strain)
        end
      end
    end
    # Clean up battle stuff
    @scene.pbEndBattle(@decision)
    @battlers.each do |b|
      next if !b
      pbCancelChoice(b.index)   # Restore unused items to Bag
      Battle::AbilityEffects.triggerOnSwitchOut(b.ability, b, true) if b.abilityActive?
      b.pokemon.makeUnmega if b.mega? 
    end
    # Reset Pokémon forms upon leaving battle
    2.times do |side|   # We do both sides in case the foe side includes a caught wild Pokémon
      pbParty(side).each_with_index do |pkmn, i|
        next if !pkmn
        @peer.pbOnLeavingBattle(self, pkmn, @usedInBattle[side][i], true)
      end
    end
    
    if Settings::UPDATE_PARTY_LEAD_BATTLE_END && decided? && @battlers[0] && !@battlers[0].fainted?
      new_lead_index = @battlers[0].pokemonIndex
      if new_lead_index && new_lead_index > 0 && new_lead_index < $player.party.length
        # Intercambiamos el líder actual (0) con el Pokémon que terminó la batalla
        $player.party[0], $player.party[new_lead_index] = $player.party[new_lead_index], $player.party[0]
      end
    end
    # Restore consumed items (RestoreItemsAfterBattle feature)
    pbRestoreUsedItems if Settings::RESTORE_HELD_ITEMS_AFTER_BATTLE

    return @decision
  end

  # Restores items consumed during battle to the Pokémon that used them
  def pbRestoreUsedItems
    return if !@used_items || @used_items.empty?
    @used_items.each do |obj|
      pokemon = obj[0]
      item_id = obj[1]
      next if !pokemon || !pokemon.item.nil?
      next if Settings::RESTORE_HELD_ITEMS_BLACKLIST.include?(item_id)
      pokemon.item = item_id
    end
  end

  #=============================================================================
  # Judging
  #=============================================================================
  def pbJudgeCheckpoint(user, move = nil); end

  def pbDecisionOnTime
    counts   = [0, 0]
    hpTotals = [0, 0]
    2.times do |side|
      pbParty(side).each do |pkmn|
        next if !pkmn || !pkmn.able?
        counts[side]   += 1
        hpTotals[side] += pkmn.hp
      end
    end
    return Outcome::WIN  if counts[0] > counts[1]        # Win (player has more able Pokémon)
    return Outcome::LOSE if counts[0] < counts[1]       # Loss (foe has more able Pokémon)
    return Outcome::WIN  if hpTotals[0] > hpTotals[1]    # Win (player has more HP in total)
    return Outcome::LOSE if hpTotals[0] < hpTotals[1]   # Loss (foe has more HP in total)
    return Outcome::DRAW
  end

  # Unused
  def pbDecisionOnTime2
    counts   = [0, 0]
    hpTotals = [0, 0]
    2.times do |side|
      pbParty(side).each do |pkmn|
        next if !pkmn || !pkmn.able?
        counts[side]   += 1
        hpTotals[side] += 100 * pkmn.hp / pkmn.totalhp
      end
      hpTotals[side] /= counts[side] if counts[side] > 1
    end
    return Outcome::WIN  if counts[0] > counts[1]        # Win (player has more able Pokémon)
    return Outcome::LOSE if counts[0] < counts[1]       # Loss (foe has more able Pokémon)
    return Outcome::WIN  if hpTotals[0] > hpTotals[1]    # Win (player has a bigger average HP %)
    return Outcome::LOSE if hpTotals[0] < hpTotals[1]   # Loss (foe has a bigger average HP %)
    return Outcome::DRAW
  end

  def pbDecisionOnDraw; return Outcome::DRAW; end   # Draw

  def pbJudge
    fainted1 = pbAllFainted?(0)
    fainted2 = pbAllFainted?(1)
    if fainted1 && fainted2
      @decision = pbDecisionOnDraw
    elsif fainted1
      @decision = Outcome::LOSE
    elsif fainted2
      @decision = Outcome::WIN
    end
  end
end
